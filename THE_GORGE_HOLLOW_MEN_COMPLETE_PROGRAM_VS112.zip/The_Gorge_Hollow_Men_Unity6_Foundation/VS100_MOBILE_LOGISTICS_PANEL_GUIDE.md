# VS100 Mobile Logistics Panel — Authoring Guide

1. Open the project in the intended Unity 6 editor version.
2. In the active gameplay Canvas, create a compact panel anchored to a screen edge. Keep it clear of movement/aim controls and the convoy command panel.
3. Add two UGUI `Text` objects. Name them `TowerPriorityLabel` and `TransferOperationsLabel`.
4. Add `SupplyCampaignLogisticsPanel` to the panel root.
5. Assign the scene `GameBootstrap`, `TowerPriorityLabel`, and `TransferOperationsLabel` in the Inspector.
6. Set `Refresh Seconds` between 0.5 and 2 seconds for mobile. This panel is informational and does not need per-frame updates.
7. Test at narrow phone aspect ratios and large accessibility text sizes. Allow the priority label to wrap and scroll rather than overlap touch controls.
8. Verify that inbound cargo is shown as counted in the assessment and that delivered/destroyed convoys free a transfer slot.

## Dispatch capacity
The campaign permits at most three travelling inter-tower transfers. A fourth dispatch must be rejected before the source depot is debited. The UI displays active and available slots; dispatch remains an explicit operation handled by the existing route/manifest authoring flow.

## Important
Do not use this panel to directly mutate depot stock or create transfer records. Do not replace the bridge reference with a boolean or bypass the physical route. Bridge collapse while crossing must continue to destroy the carrier and its cargo.
