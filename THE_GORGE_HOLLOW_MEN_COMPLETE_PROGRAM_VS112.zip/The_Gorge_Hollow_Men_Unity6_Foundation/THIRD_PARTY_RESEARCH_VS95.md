# Third-Party Research — VS95

No third-party implementation code was copied. The depot model uses the project's existing serializable campaign-record and candidate-save patterns.

Unity documentation checked for the persistence design:
- Unity 6 `JsonUtility` documents conversion of custom serializable objects to/from JSON and explains that it uses Unity's field serializer: https://docs.unity.com/en-us/engine/6000.7/script-reference/unityengine/jsonutility
- Unity 6 JSON serialization documentation describes serializable wrapper classes and supported field-based data: https://docs.unity.com/en-us/engine/6000.0/manual/programming-environment/code-reload-serialization/script-serialization/json-serialization
- Unity 6 serialization rules confirm support for `[Serializable]` custom classes and `List<T>` of supported serializable fields, while dictionaries and nested containers are not supported: https://docs.unity.com/en-us/engine/6000.0/manual/programming-environment/code-reload-serialization/script-serialization/rules

Design application: `TowerDepotRecord` is a plain `[Serializable]` class with public primitive fields, and `CampaignState.towerDepots` is a `List<TowerDepotRecord>`. This avoids unsupported dictionary serialization. No external dependency was introduced.
