# VS79 export and setup

1. Extract and open in Unity 6.
2. Run `VS79StatusSummaryTests` and `VS36FoundationInfoTests`.
3. Play check: issue GUARD, STAY and FORAGE and confirm the bracketed tag on the companion status line changes; confirm the build footer shows VS79.

Unity compilation and device testing were not performed in this environment.
