# VS82 — Bond Trust Ranks

## Added / changed
- Added `AnimalBondTrustRules`, deriving five trust ranks directly from the saved bond value: NEW BOND (0–24), BONDING (25–49), TRUSTED (50–74), LOYAL (75–99) and DEVOTED (100).
- Trust ranks grant a modest companion threat-detection radius bonus of 0%, 4%, 8%, 12% and 16% respectively.
- The companion HUD now displays the rank immediately before the existing `BOND n` value; the trailing bond text remains stable for existing UI checks. Crossing into a higher rank produces a named toast.
- Bond is spent by Bond Resonance as before. Since rank and bonus are derived on every scan from the current saved bond, spending bond can lower the rank and its bonus immediately. No new save fields or schema migration.
- Added five EditMode tests covering thresholds, clamping, monotonic bounded bonuses, Resonance rank loss, HUD output and toast formatting.

## Balance / design boundaries
- This is a small awareness bonus, not damage, health, movement speed or obedience power.
- Trust ranks are not separately persisted; the bond stat remains the sole source of truth.
- Existing species abilities and their unique roles remain intact. The bonus composes with current species, Resonance, veteran-ability and Guard Post detection modifiers.

## Validation
Static source checks and archive integrity checks only. Unity 6 compilation, EditMode execution, scene regeneration, NavMesh baking and Android/iOS testing were not performed.
