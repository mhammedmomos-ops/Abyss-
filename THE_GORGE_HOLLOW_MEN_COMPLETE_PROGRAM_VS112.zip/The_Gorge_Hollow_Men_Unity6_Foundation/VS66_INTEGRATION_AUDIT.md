# VS66 integration audit

## Runtime binding flow
1. `AnimalCompanionController.Bind` receives the selected saved `AnimalRecord`.
2. It activates the visual-root container and calls `AnimalSpeciesVisualBinder.Apply(record)`.
3. The binder selects only the matching species prefab. If none is assigned, the greybox placeholder remains visible; no different species is substituted.
4. After model instantiation, the controller calls `AnimalCompanionAnimationDriver.RefreshAnimator()` so the driver discovers the new child Animator and caches its parameter types.
5. The driver reads the controller's action-state properties and the NavMeshAgent's actual velocity. It never writes transform position, agent velocity or destination.
6. Campaign replacement refreshes the same identity's visual/animator binding. Clearing or losing the companion removes the spawned visual and deactivates the visual root.

## Animation contract
- `Speed` (Float): normalized NavMesh velocity / species movement speed, clamped 0–1.
- `IsMoving`, `IsRunning`, `IsBracing`, `IsForaging`, `IsLuring`, `IsObserving`, `IsIncapacitated`, `IsDead` (Bool).
- `Species` (Int): enum indices 0 GermanShepherd, 1 Falcon, 2 Pangolin, 3 Cat.
- `Attack` (Trigger): edge-triggered when the companion controller reports a successful support strike.
- Controllers may omit parameters they do not use. The driver checks parameter existence and type before setting values.

## Asset validation
- The Editor validator accepts a selected prefab asset or scene instance.
- Core preflight requires an Animator, a valid Avatar, a RuntimeAnimatorController with clips, and at least one correctly skinned mesh with a root bone and bone references.
- It does not require Humanoid rigs; quadrupeds and birds should generally use Generic rigs.
- Missing Idle/locomotion clips, root motion enabled, or absent shared parameters are warnings. A valid controller should provide species-appropriate states/transitions.

## Known limits
- No production animal assets were downloaded or bundled. All four binder prefab slots are unassigned in the generated greybox scene, so the fallback capsule remains visible until the project owner assigns licensed models.
- This phase does not create Falcon flight, flight physics, landing/perching, Pangolin curl animation clips, Cat stalking clips, or Shepherd gait/attack clips. It exposes the state and prefab integration contract needed by those assets.
- No runtime retargeting, Animation Rigging constraints, procedural IK, root-motion traversal or blend-tree assets were generated.
- A newly instantiated model's Animator must be under the assigned species prefab root for automatic discovery.

## Risk controls
- Invalid or missing animation parameters are ignored rather than throwing exceptions.
- Non-finite speed values are sanitized before they reach Animator parameters.
- `NavMeshAgent` remains authoritative for all current ground movement; animation is presentation-only.
- Species is selected from the saved record and is not inferred from the custom display name.
- Visual replacement does not modify health, hunger, stamina, bond, experience, life stage or death state.
