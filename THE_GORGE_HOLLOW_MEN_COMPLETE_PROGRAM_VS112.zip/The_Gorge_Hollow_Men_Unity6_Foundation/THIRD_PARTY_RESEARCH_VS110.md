# Third-Party Research — VS110

Research reviewed before implementation:

- Unity 6 `NavMeshAgent` reference: https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/ai/navmeshagent
  - Relevant to actor movement and the distinction between navigation simulation and presentation. VS110 does not change NavMesh routing.
- Unity multiplayer Netcode packages: https://docs.unity.com/multiplayer/netcode/netcode
  - Unity describes Netcode for GameObjects and Netcode for Entities as networking options with different project scales and architectures.
- Unity server authority concepts: https://docs.unity.cn/Packages/com.unity.netcode.gameobjects%402.13/manual/terms-concepts/authority.html
  - Relevant future requirement: clients should not be trusted to decide which remote tower information they are authorized to receive. Server-side validation and filtered replication are required when multiplayer exists.

No third-party code, assets, or packages were copied or added in VS110.
