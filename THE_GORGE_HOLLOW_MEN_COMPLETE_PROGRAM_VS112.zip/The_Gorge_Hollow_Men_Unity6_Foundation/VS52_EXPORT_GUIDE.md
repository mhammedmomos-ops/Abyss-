# VS52 Export and First Scene Setup

## Import
1. Create/open a Unity 6 URP project (Editor 6000.0 or later).
2. Merge the supplied `Packages/manifest.json` dependencies into the project's manifest; do not replace unrelated packages blindly.
3. Copy/merge the supplied `Assets` folder into the Unity project.
4. Allow Unity Package Manager to resolve the existing Splatter.AI Git dependency, AI Navigation, uGUI and Test Framework packages.
5. Wait for script compilation. Address any project-specific API/package conflicts before proceeding.

## Generate the greybox scene
1. In Unity, use `THE GORGE > Vertical Slice > Validate Greybox Layout`.
2. Then use `THE GORGE > Vertical Slice > Generate Greybox Scene`.
3. The tool creates `Assets/_Project/Scenes/GorgeVerticalSlice.unity`, material assets under `Assets/_Project/PrototypeAssets/`, and adds the scene to Build Settings if missing.
4. Open the generated scene and inspect the player, camera, mobile HUD, two tower platforms, bridge, gorge floor, training target and supply cache.
5. If the Navigation Surface object was created, select it and configure/bake it in the Inspector. Confirm the correct agent type and collection settings for your monster AI.
6. Ensure Project Settings > Player > Active Input Handling is set to Input Manager or Both for the generated StandaloneInputModule and existing legacy keyboard path. If the project standardises on the new Input System, replace the module with InputSystemUIInputModule and add the package explicitly in a separate reviewed change.
7. Test keyboard movement (when legacy input is enabled), touch joystick, right-side camera drag, sprint, training-target fire/reload and proximity loot interaction.
8. Run the EditMode test assembly from Window > General > Test Runner.
9. Only after Editor verification should Android/iOS player settings, graphics quality, safe areas, touch scaling and device profiling be addressed.

## What this export is
The ZIP contains cumulative source plus the VS52 scene generator. It does not contain a generated `.unity` scene because the generator has not been executed in a Unity Editor in this environment. Running the menu command inside Unity creates the scene and persistent material/weapon assets.
