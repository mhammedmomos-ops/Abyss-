# VS58 export and integration guide

1. Open the cumulative project in the intended Unity 6 editor version.
2. Allow scripts to compile; this export has not been compiled in Unity in this environment.
3. Attach `AnimalCareService` to a scene object and assign the active `GameBootstrap`, `CompanionCommandRelay`, and `CompanionSafeZone` references (or allow Awake auto-discovery).
4. Place `CompanionSafeZone` on a trigger volume at the tower safe area, assign the player root, and ensure the player has colliders entering that trigger. `AnimalCareService.TryRest()` checks the trigger-backed owner presence itself; callers cannot simply assert safe-zone status.
5. Call `TryTreat()` from a medical-care interaction. It spends one `medicalSupplies` and restores up to 30 companion health.
6. `CampaignClock` advances animal age when its day-rollover or `CompleteNight()` methods are called. Inspection found no current gameplay caller for these methods, so connect the actual day/night completion flow before expecting automatic ageing during play.
7. Add UI feedback for success/failure when wiring the care panel; this phase exposes tested service APIs but does not fabricate scene button wiring.
8. Run the full EditMode suite and test save/load, safe-zone gating, medical-supply persistence, day rollover and completed-night ageing.
