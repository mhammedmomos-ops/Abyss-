# THE GORGE: HOLLOW MEN — VS19

## Pooled physical collapse debris

VS19 adds a bounded, transient physical-debris layer on top of VS18's authored structural collapse events.

### Added

- `TowerDebrisPiece`: reusable debris prefab root supporting one or more child Rigidbody components. It applies a bounded explosion impulse and torque, then returns itself to its owning pool after its lifetime.
- `TowerDebrisEmitter`: listens for a `TowerStructuralSegment` transition into `Collapsed` and emits a configurable debris burst.
- Uses Unity's built-in `UnityEngine.Pool.ObjectPool<T>` API. The pool has an Inspector-configured maximum active count and optional prewarm count; debris instances are detached from the tower while active so physics motion is not inherited from a moving tower parent.
- Transient debris lifetime and force values are normalized to safe bounds. The emitter refuses to exceed its active-piece budget.
- `TowerDebrisRules`: pure deterministic budget/lifetime helpers with EditMode regression coverage.

### Scene and prefab setup

1. Create a debris prefab with `TowerDebrisPiece` on its root and at least one Rigidbody on the root or a child. Add the desired mesh renderers and colliders. Prefer low-poly fragments and simple primitive/convex colliders; avoid non-convex MeshColliders on dynamic rigidbodies.
2. Ensure the Rigidbody hierarchy is authored in a stable local pose. The component makes all child rigidbodies kinematic while pooled and enables them when launched.
3. Add `TowerDebrisEmitter` beside the `TowerStructuralSegment` on the structural-section controller, or assign the segment explicitly.
4. Assign the debris prefab. Tune requested pieces, maximum active pieces, prewarm, lifetime, explosion radius/force, upward modifier and torque.
5. Optionally assign an emission origin. Otherwise the segment controller's transform is used.
6. Author a modest debris count for mobile. Start with 3–5 pieces per collapse and a scene-wide budget; this component enforces its own per-emitter cap, not a global scene-wide cap.
7. If debris should block monsters after it settles, use the authored static rubble collision/NavMeshObstacle from VS18. This transient effect does not automatically add NavMesh carving to moving fragments.

### Behaviour and persistence

- A burst occurs on a live transition into `Collapsed`. Initial hydration of an already-collapsed section does not emit debris by default, preventing repeated bursts every time the scene loads. `emitOnEnableWhenAlreadyCollapsed` is an optional visual-only override and should normally remain off.
- Debris is intentionally transient and is not saved to the campaign. It deactivates and returns to the pool after its configured lifetime.
- This does not implement runtime mesh fracture, independent beam health, structural load simulation, bridge fall physics, persistent debris, or a global debris budget. Fragments must be authored in the prefab.
- Unity's `ObjectPool<T>` is stack-based and supports create/get/release/destroy callbacks plus a maximum retained size. The implementation adds a stricter active-count cap to prevent a burst from creating an unbounded number of rigidbodies.

### Third-party research and reuse

- Reused Unity's built-in `UnityEngine.Pool.ObjectPool<T>` API; no external source code or new package dependency was added.
- Unity's current performance guidance recommends pooling frequently reused GameObjects to reduce instantiation/destruction overhead and managed-memory/GC pressure. The official API documentation confirms pool callbacks and maximum retained capacity.
- Unity AI Navigation documentation confirms that carving changes path planning and is recalculated with performance-aware delay. VS19 therefore leaves moving debris to physics collision/avoidance and relies on VS18's authored static collapsed obstacle for stable path blocking, rather than continuously carving every moving fragment.

## Verification boundary

Source-level checks, regression-test source inclusion and ZIP integrity were checked. Unity 6 compilation, EditMode execution, prefab/scene wiring, physics simulation, NavMesh baking, Android/iOS builds, device profiling and playtesting have **NOT** been performed.
