# VS92 Integration Audit — Bridge Repair Work

## Runtime flow
1. Put one `BridgeSupportRepairStation` on or beside each required bridge support.
2. Assign the same `BridgeSpanController` used by the bridge, the exact required `TowerStructuralSegment`, and that segment's parent `TowerStructure`.
3. The station rejects supports not listed in `BridgeSpanController.RequiredSupports`, intact supports, fully stable spans, destroyed structures, out-of-range players, players without `PlayerVitals`, dead players and invalid component references.
4. Interacting begins a timed work cycle. Default duration is 4 seconds for a damaged support and 8 seconds for a collapsed support.
5. `PlayerVitals.HealthChanged` interrupts the work if health decreases. Player death, leaving range, station disablement, support-state change or a monster with `MonsterPerception.VisiblePlayer` matching the interactor inside the threat radius also interrupts it.
6. No materials are spent during the work cycle. On successful completion, `TowerStructure.TryRepair` invokes the existing `TowerMaintenanceService` transaction, spends scrap/timber atomically and persists the restored health through the existing campaign save path.
7. The support segment updates from the campaign health event; `BridgeSpanController` recomputes span state. Other damaged/collapsed supports remain damaged until separately repaired.

## Default tuning
| Support state | Work duration | Scrap | Timber | Health restored |
|---|---:|---:|---:|---:|
| Damaged | 4 s | 8 | 5 | 40 |
| Collapsed | 8 s | 16 | 10 | 65 |

All values are serialized tuning fields. A support may require multiple completed cycles to reach Intact, depending on its maximum health and current health. This is intentional: reconstruction is not a free full-health reset.

## Scene authoring checklist
- Assign every required support segment to the bridge controller.
- Ensure each segment has a parent `TowerStructure` with a unique campaign identity and correct owning tower ID.
- Add one `BridgeSupportRepairStation` per support and assign the exact bridge, segment and structure references.
- Keep the station reachable from the player side of the support; do not place its interaction point over a missing/collapsed section of deck.
- Set `enemyLayers` to the project's monster layers. The default all-layers mask is safe for component filtering but can be narrowed for performance.
- If progress UI is desired, add `BridgeRepairProgressPresenter`, assign a child-only `progressRoot`, Slider and Text. Do not assign the station GameObject or an ancestor as `progressRoot`, because hiding it would disable the station.
- Remove old `BridgeRepairInteraction` components and replace them with stations. The legacy component is intentionally non-interactive in VS92, so it cannot bypass the new work rules.
- The generated greybox scene does not yet author campaign-backed bridge supports or these repair stations; scene/prefab wiring is required before runtime use.

## Known integration considerations
- Enemy interruption depends on `MonsterPerception.VisiblePlayer` matching the active interactor. Squad-shared contact without direct visual confirmation does not interrupt repair under this phase's rules.
- `TowerStructure.TryRepair` must be initialized by `GameBootstrap` before the player completes a work cycle.
- Repair is intentionally support-by-support. No work progress is persisted across scene unloads or player death; interrupted work restarts from zero, with no material loss.
- No new save fields or schema migration are required.

## Not performed
Unity Editor compilation, actual NUnit execution, PlayMode, physics simulation, UI wiring, NavMesh bake, Android/iOS builds or device tests.
