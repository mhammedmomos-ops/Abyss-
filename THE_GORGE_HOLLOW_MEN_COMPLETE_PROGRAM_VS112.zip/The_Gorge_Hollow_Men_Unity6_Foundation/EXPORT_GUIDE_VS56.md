# VS56 export and scene setup

## Generate the prototype scene

1. Open the cumulative project in Unity 6 and allow package import/compilation.
2. Ensure AI Navigation 2.0.16 is installed (already declared in `Packages/manifest.json`).
3. Use **THE GORGE > Vertical Slice > Generate Greybox Scene**. The generator now creates a generic companion actor, a pet-selection panel and a command bar alongside the existing player/monster greybox. It does not choose a species or name automatically.
4. Bake a NavMesh covering the companion's traversable area and the player's routes. The companion actor must be placed on the baked surface; the generator does not bake NavMesh data.
5. In Play Mode, choose one of the four pet species, enter a custom name (1–24 characters), and press Confirm Pet. The pet record is saved before the live actor is bound.
6. Use the companion command bar: Follow, Stay, Search, Alert, Protect and Return. Return resumes Follow. Retrieve remains a safe Follow fallback until a world-item retrieval contract exists.
7. Threat scanning uses colliders on objects that have `MonsterAIController` and `DamageableHealth`. Configure `threatMask` to include monster layers and exclude irrelevant geometry where practical. The generated greybox monster's root components are compatible with the scanner.

## Selection and campaign rules

- Approved species: German Shepherd, Falcon, Pangolin and Cat only.
- Each campaign can retain at most one record per approved species through this selection workflow. Selecting an already-owned living species reuses its stable identity and progression while updating its display name.
- A Missing or permanently Dead animal cannot be reselected through this workflow. Permanent death remains campaign-persistent.
- The UI's pet name is player-entered and becomes the campaign record's `displayName`; the HUD displays that name and the species.
- Species have distinct tuning: German Shepherd direct attack support, Falcon broadest local detection/confidence, Pangolin strongest injury mitigation, Cat faster/quiet reconnaissance tuning. These are prototype values, not final balance.

## Known prototype limits

- The generated companion visual is a generic capsule placeholder, not an animal model.
- Falcon currently uses ground NavMesh locomotion; true flight requires a separate aerial navigation layer.
- Pet-specific animations, vocalizations, feeding/needs, ageing progression, senior decline, species abilities, item retrieval, full injury treatment UI, and polished companion presentation are not yet implemented.
- The controller exposes an injury/death API and coalesces changed companion records into campaign saves. Full monster-to-pet target selection and damage routing still need integration.

## Verification boundary

This export was ZIP-integrity checked and source/static checks were run. Unity Editor compilation, EditMode test execution, PlayMode simulation, NavMesh baking, animation/audio validation, Android/iOS builds and device profiling were not performed in this environment.
