# VS67 — Species Animation Authoring Pipeline

## Added
- Added an Editor-only `AnimalSpeciesAnimationSetup` manifest for the four approved companions: German Shepherd, Falcon, Pangolin and Cat.
- Added menu workflow: `THE GORGE > Companions > Create Animation Setup Asset` then assign each species prefab and its own idle, walk, optional run, attack, bracing, foraging, lure, observation, incapacitated and death clips.
- Added `THE GORGE > Companions > Build Species Animator Controllers`. It generates a separate Animator Controller per configured species, creates a 1D locomotion Blend Tree, adds optional action states using the VS66 parameter contract, assigns the controller to the selected prefab and disables root motion. Duplicate species/prefab assignments and prefabs without a valid Avatar are skipped; the tool never creates an empty Animator. Generated controller paths are unique so a rebuild does not delete an earlier controller asset.
- Expanded the model preflight to report estimated triangles, material slots and largest referenced texture, with initial mobile-budget warnings.
- Added import, license, rigging, animation and mobile optimization guidance.

## Asset acquisition decision
No animal model was copied into the project in VS67. Research did not establish one reliable, redistributable, mobile-ready and correctly rigged model for each of the four species. In particular, the Pangolin candidate found is a 130k-triangle sculpt without confirmed rig/animation, while the available Falcon path is an auto-rigging workflow rather than a verified falcon asset. The Shepherd and Cat candidates have attribution/fit caveats. The project therefore keeps its species-specific prefab slots empty rather than shipping mismatched or legally ambiguous art.

## Important limitations
- Generated Animator Controllers are templates; actual authored clips must be supplied per species.
- Falcon flight, takeoff, landing and perch traversal still require a separate movement-authority implementation. The current NavMeshAgent remains authoritative and this phase does not pretend to implement flight.
- Pangolin curl, Cat stalking and Shepherd attack animations depend on the clips assigned by the artist.
- No Unity Editor was available in this environment; menu execution, prefab mutation and Animator playback were not run.
