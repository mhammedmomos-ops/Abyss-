# VS104 Worker Morale Authoring Guide

1. No new scene component is required. Existing `TowerWorkforceController`, `GameBootstrap` and `TowerWorkforceMonitor` continue to be used.
2. Keep the workforce monitor's two tower labels connected. Each worker row now includes Morale, Trust and Stress.
3. Morale/trust/stress values are campaign data, not per-scene tuning. New recruits use the record defaults (morale 70, loyalty 50, stress 0).
4. New dangerous assignments (Guard and Salvage) are refused if morale is below 20, loyalty/trust is below 15 or stress is at least 85. Idle, Production and Rest are not blocked. The returned error string should be shown in the existing command feedback UI.
5. Rest recovery accrues one morale point and removes two stress per 60 minutes, with a persisted remainder. It does not recover loyalty except slowly (one point per four recovery intervals) once morale is at least 60.
6. Rescue, capture and treatment events are integrated. Future mission outcomes may call `TowerWorkerMoraleRules.ApplyEvent` for `ProtectedDuringRaid`, `AbandonedInOverrun` or `CompletedDuty` only when that outcome is explicitly established.
7. Do not apply abandonment penalties simply because a worker was not in the player's camera view or because a raid ended; this must be a deliberate, evidenced gameplay event.
8. Keep worker actors, NavMesh points and capture volumes tower-local. No morale feature changes bridge access rules.
