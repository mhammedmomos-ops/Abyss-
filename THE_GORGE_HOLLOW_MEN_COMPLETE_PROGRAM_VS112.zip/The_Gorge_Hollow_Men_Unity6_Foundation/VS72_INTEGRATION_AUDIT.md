# VS72 integration audit

## Integration path
- `AnimalCommand.Stalk` added to the shared command enum.
- `AnimalCatStalkRules` provides pure deterministic helpers used by the controller and EditMode tests.
- `AnimalCompanionController.IssueCommand` gates Stalk through `TryBeginStalk`, resets the first-acquisition flag, and clears scent/forage destinations.
- `ScanThreats` uses the expanded detection radius while stalking and applies the one-shot confidence bonus + toast on first new threat.
- `MoveTo` applies the reduced move-speed multiplier and suppresses sprint while stalking.
- `TickStalk` holds a cautious offset from a confirmed threat or shadows the owner at a wider follow distance while scanning.
- `CompanionCommandRelay.IsStalking` and `CompanionCommandUI` (stalkButton + CommandStalk + LateUpdate gate) expose the ability to the mobile HUD.
- Vertical-slice scene generator appends a STALK button to the care row.

## Non-interference
- Cat Lure, Pangolin Curl/brace, Shepherd TrackScent, Falcon scouting and all other species behaviours remain unchanged when Stalk is not active.
- Campaign persistence, save/load and monster AI perception of the player are untouched.
- Stimulus quieting only scales loudness when the Cat itself would emit; it does not alter other sources.

## Verification boundary
Static source and archive checks only. Unity Editor compilation, EditMode/PlayMode execution, NavMesh baking, scene generation and device testing have not been performed in this environment.
