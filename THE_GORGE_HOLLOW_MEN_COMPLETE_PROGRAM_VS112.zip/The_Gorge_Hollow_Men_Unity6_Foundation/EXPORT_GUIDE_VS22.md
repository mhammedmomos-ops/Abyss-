# THE GORGE: HOLLOW MEN — Complete Source Export (VS22)

This archive is the cumulative Unity 6 source-code foundation through VS22. It contains the project scripts, assembly definitions, EditMode test source, package manifest, third-party notices/research, changelogs, and setup documentation from the earlier milestones.

## Import into Unity 6

1. Install Unity 6 through Unity Hub. For Android, install Android Build Support (SDK/NDK tools and OpenJDK). For iOS, install iOS Build Support and use a Mac with Xcode for the final build.
2. Create a new **Universal 3D (URP)** project in Unity Hub.
3. Close the Unity Editor.
4. Copy the archive's `Assets/_Project` folder into the new project's `Assets` folder. Merge the `Packages/manifest.json` dependencies into the new project's manifest; do not overwrite unrelated dependencies in an existing project.
5. The required package dependencies are:
   - `com.unity.ai.navigation` version `2.0.16`
   - `com.samorme.splatter.ai` from `https://github.com/ormesam/splatter.ai.git?path=/src/Assets/Splatter.AI`
6. Reopen Unity and allow Package Manager resolution and script import to finish.
7. Open **Window > General > Test Runner**, select EditMode, and run the project's tests.
8. Create and configure gameplay scenes, prefabs, models, materials, animation controllers, audio, UI, NavMesh surfaces, colliders, bridge structural segments, debris fragments and recovery points. Follow `README.md` and the individual `CHANGELOG_VS*.md` files.
9. Configure scenes in **File > Build Profiles** and build Android/iOS only after compilation and device testing.

## What this export is

- Complete cumulative source package for the current VS1–VS22 implementation.
- Mobile-first Unity 6 code foundation with campaign models, persistence, player systems, combat, tower construction/damage, monster AI foundations, mobile controls, bridge structural failure, collapse sequences, debris and bridge fall consequences.
- Includes package dependencies, source assembly definitions, regression test source and integration instructions.

## What this export is not

- It is not an APK, AAB, IPA, compiled Unity player, or signed store submission.
- It is not yet a complete playable game project with finished scenes, prefabs, character/environment art, animation, audio, HUD, menus, authored NavMesh data or final balancing.
- It has not been compiled or played in Unity in this environment. Unity 6 compilation, EditMode execution, Android/iOS builds and device playtesting remain outstanding.

## Recommended first validation pass

1. Resolve both package dependencies.
2. Compile all runtime and EditMode assemblies.
3. Run every EditMode test, not only the new VS22 tests.
4. Create a small bridge test scene with two support segments, one bridge span, one fall trigger, one player and one companion test prefab.
5. Verify stable → strained → collapsed → repaired transitions, player landing damage, companion landing damage/death, NavMesh agent restoration, and save/reload behaviour.
6. Profile the bridge physics and AI on a baseline Android device before scaling up debris or active companions.

Do not interpret source-level checks in `BUILD_VERIFICATION.txt` as Unity compilation or gameplay validation.
