# VS107 — Starting Workforce and Visible Worker Actors

## Added
- New campaigns now begin with four persistent workers: one Mechanic and one Guard at each tower.
- Each starting Mechanic is assigned to Production; each starting Guard is assigned to Guard duty.
- Starting workers have stable campaign identities, full health, no fatigue, baseline morale/trust, and Balanced personality.
- Added `TowerWorkerSpawnDirector`, an optional scene component that materializes campaign worker records under the appropriate tower root.
- A configured worker prefab is supported. If none is assigned, the director creates a simple role-tinted capsule greybox so the roster can be seen before final character art is ready.
- Worker actors remain enabled while dead/captured presentation is hidden, allowing a released captive to become visible again without destroying/recreating their identity.
- Successful survivor recruitment, capture, and captive release publish campaign-replaced events so the scene workforce spawner can reconcile actor visibility and newly recruited workers.
- Four EditMode test cases cover starting count, tower distribution/roles, unique identities, and remaining recruitment capacity.

## Design decisions
- Opening roster: 4 workers total, 2 per tower.
- Each tower starts with 6 open workforce slots (maximum 8 non-dead workers).
- No Medic or Scavenger starts in the roster; these roles remain valuable recruitment discoveries.
- No starting relationships are created. Social bonds must result from recorded gameplay events.
- No save schema change; existing saves remain version 14. The new roster applies to newly created campaigns only.
- No worker receives bridge access, bridge routes, or cross-gorge movement.

## Limitations
- `TowerWorkerSpawnDirector` must be added to the gameplay scene and assigned Tower A and Tower B root transforms. A worker prefab is optional.
- Greybox capsules are placeholders, not final character models, animations, equipment, or navigation-ready prefabs.
- Movement still requires an authored NavMeshAgent prefab, a baked NavMesh, and assignment/tactical target transforms on the worker prefab.
- Unity compilation, EditMode execution, PlayMode, NavMesh, physics, scene wiring, Android/iOS builds, and device tests were not performed.
