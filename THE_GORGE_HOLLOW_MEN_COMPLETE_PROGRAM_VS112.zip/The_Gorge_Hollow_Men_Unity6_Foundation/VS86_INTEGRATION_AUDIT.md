# VS86 Integration Audit

## Input inspected
- User-provided cumulative `THE_GORGE_HOLLOW_MEN_COMPLETE_PROGRAM_VS85.zip`; archive integrity passed before extraction.
- VS85 companion controller, species tactics, guard reporting, Falcon observation, Cat Stalk/Lure, Shepherd attack support, HitscanWeapon, runtime/test assembly definitions, and VS85 audit.

## Key architecture finding
The current source binds a single active companion through `CompanionCommandRelay.BindSelected`; `GameBootstrap.FlushActiveCompanion` also resolves one world actor. A four-animal simultaneous-combat synergy would therefore be unreachable in the current scene contract. VS86 implements companion/player coordination instead: whichever approved companion is active creates a short opening that the player's weapon can exploit.

## Integration
- Pure species-role policy maps Shepherd to Interception, Falcon to Distraction, Pangolin to Defensive Anchor, and Cat to Flank/Distraction.
- Runtime contribution points are tied to actual existing actions: Shepherd attack support, Falcon distraction, Pangolin confirmed Guard Post report, Cat first Stalk acquisition, and Cat Lure pulse.
- `AnimalTeamworkState` stores a five-second transient window per monster instance, validates the exact Transform to protect against instance-ID reuse, and prunes expired entries.
- Player hitscan applies the 1.08 multiplier only when the hit resolves to the exact monster with an active window.
- Repeated contributions do not stack; the same companion cannot manufacture an increasing bonus by pulsing repeatedly.
- The existing weak-point callout remains independent; no campaign schema or player command contract changed.

## Risks / authoring constraints
- This phase assumes the current one-active-companion architecture. If a future phase introduces multiple simultaneous companions, team-wide multi-species coordination needs a separate design and balance pass; VS86 deliberately does not claim that feature.
- The Pangolin contribution requires Guard and a confirmed threat report. Falcon requires a confirmed threat and its existing distraction cooldown. Cat requires Stalk acquisition or active Lure. Shepherd requires an in-range attack-support hit.
- The bonus affects player hitscan damage against the exact monster only. Other damage sources are unchanged.
- The state is static/session-only; expired records are pruned on new registrations and removed on a target's next damage query.

## Validation performed
- Source-level integration review against the actual VS85 call sites.
- C# lexical delimiter scan (comments and string literals ignored).
- Assembly-definition JSON validation.
- Version metadata and manifest review.
- ZIP CRC/integrity verification.

## Not performed
- Unity 6 compilation.
- NUnit/EditMode execution.
- PlayMode combat testing, scene/prefab validation, or NavMesh testing.
- Android/iOS builds or physical-device testing.
