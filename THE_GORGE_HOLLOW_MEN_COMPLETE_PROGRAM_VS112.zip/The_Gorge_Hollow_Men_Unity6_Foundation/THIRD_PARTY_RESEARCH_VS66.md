# VS66 third-party research and reuse review

## Official references reviewed
- Unity 6 model preparation and animation guidance: https://docs.unity.com/en-us/engine/6000.6/manual/assets-and-media/asset-types/models/creating-dccassets/using-humanoid-chars — distinguishes Humanoid rigs from Generic models; animal rigs should not be forced into the Humanoid retargeting model.
- Unity Animation Rigging overview: https://academy.unity.com/courses/animation-rigging-overview — demonstrates constraints layered over authored animation, but this phase does not add that package because no rigged assets or procedural IK requirement is ready to validate.
- Unity 6 NavMeshAgent API: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/ai/navmeshagent — the companion agent's velocity is read for animation while navigation remains the movement authority.
- Unity AI Navigation package documentation: https://docs.unity.com/en-us/engine/6000.3/manual/packages-list/packages-all/pack-safe/com-unity-ai-navigation — current project already depends on AI Navigation 2.0.16.

## Reuse decision
- Reused the existing Unity Animator, NavMeshAgent and campaign-selected animal record. No second movement controller or external animation framework was introduced.
- Added a thin animation bridge and prefab binder in original project code. It does not copy third-party source.
- No external animal model was downloaded because a model's license, rig quality, animation completeness, mobile polygon/texture budget and redistribution rights must be checked before bundling. A generic animal model would not satisfy the four species-specific requirements.
- No package dependencies were changed.
