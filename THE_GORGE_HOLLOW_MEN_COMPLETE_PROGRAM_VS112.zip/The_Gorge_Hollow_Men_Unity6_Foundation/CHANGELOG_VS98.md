# VS98 — Transfer Route Intelligence and Escort System

## Added
- `SupplyTransferThreatRules`: deterministic route threat classification (Clear/Watch/Dangerous/Critical) with fail-closed handling of invalid observations.
- `SupplyTransferEscortController`: optional scene-authored escorts follow the active carrier, scan nearby `MonsterAIController` instances without per-scan collection allocation, select a living `DamageableHealth` target, and attack on a configurable cadence.
- Escort mitigation is bounded: each active escort reduces incoming convoy damage by 12%, capped at 48%. It never grants immunity.
- `SupplyConvoyController` now applies the assigned escort's mitigation before committing convoy damage through the existing campaign save transaction.
- Eight EditMode tests cover threat classification, invalid inputs, mitigation caps and invalid damage.

## Preserved
- VS97 source-depot debit, persistent cargo/waypoint progress, destination delivery and destroyed-cargo loss.
- Live `BridgeSpanController.IsTraversable` gate and fatal fall/cargo-loss on collapse while crossing.
- No monster bridge spawning or bridge entry bypass; escort units do not change bridge access.
- Save schema remains v9; no new persisted campaign fields or duplicated inventory state.

## Not claimed
Unity compilation, NUnit execution, PlayMode, combat balance, physics, NavMesh, Android/iOS builds and device testing were not performed.
