# VS109 Mobile Workforce Command Guide

## Greybox scene
1. Open the Unity 6 project and allow package import/compilation to finish.
2. Run **THE GORGE → Vertical Slice → Generate Greybox Scene**.
3. The generator creates `TowerWorkerSpawnDirector` and `TowerWorkforceController`, then adds the Workforce Command Panel to the generated mobile HUD.
4. Enter Play Mode with a loaded campaign. Use the left/right arrows to cycle living, uncaptured workers from both towers.
5. Use **PRODUCE**, **SCAVENGE**, **GUARD** or **REST** to issue an assignment. Ineligible commands are disabled; a short reason appears in the roster label after a rejected command.

## Hand-authored scenes
1. Add `TowerWorkforceController` to an active scene object and ensure a `GameBootstrap` exists.
2. Create a UGUI panel with a `Text` label and six `Button` components: Previous, Next, Production, Salvage, Guard and Rest.
3. Add `TowerWorkerCommandPanel` and assign all serialized references.
4. Ensure an active `EventSystem` and `GraphicRaycaster` exist for touch input.
5. Ensure `TowerWorkerSpawnDirector` has both tower roots and tower-local work destinations. The command panel does not create routes between towers.

## Assignment behavior
- Production, Salvage and Guard use the existing campaign workforce simulation and fatigue progression.
- Rest enables existing fatigue recovery and injury recovery.
- Assignment capacity, morale refusal, injury and exhaustion rules remain enforced.
- A command is saved through `TowerWorkforceController`; if saving fails, the controller rolls back the assignment.

## Current limits
The greybox command strip does not yet issue a direct move-to-world-point order or add bespoke work animations. Workers use the existing role/assignment destinations authored on `TowerWorkerSpawnDirector`.
