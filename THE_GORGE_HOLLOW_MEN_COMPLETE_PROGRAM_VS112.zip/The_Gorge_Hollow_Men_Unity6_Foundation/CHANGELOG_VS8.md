# VS8 — Nest Territories and Mobile AI Load Smoothing

## Added
- `MonsterNest`: authored territory radius, optional guard point, golden-angle NavMesh-sampled squad guard positions that remain distinct for squads larger than six, and editor gizmos.
- Optional nest association on `MonsterSpawnPoint`.
- `MonsterArchetypeDefinition.defendsNest` tuning switch.
- Nest-aware monster AI state: territorial monsters guard home and decline to pursue last-known contacts outside their assigned territory.
- Raid director injects the spawn point's nest into the spawned monster.
- Deterministic initial perception scan staggering to reduce synchronized raycast bursts after raids.
- Four EditMode regression tests for territory bounds, disabled nests and optional spawn-point association.

## Compatibility
- Cumulative from VS7; all earlier files retained. Existing archetype assets default `defendsNest` to false, preserving existing behaviour. Existing spawn points have no assigned nest by default.
- No campaign save schema changes.

## Not included
- Destructible/persistent nests, nest production/upgrades, dynamic patrol networks, and full performance profiling.

## Verification
- Static source checks and archive integrity only. Unity compilation, EditMode execution, NavMesh bake, Android/iOS builds and device playtesting have not been run.
