# VS101 Third-Party Research

Reviewed Unity documentation: `Serialization best practices` (Unity 6.0.6) https://docs.unity.com/en-us/engine/6000.6/manual/programming-environment/code-reload-serialization/script-serialization/best-practices and `ScriptableObject` (Unity 6.1) https://docs.unity3d.com/6000.1/Documentation/Manual/class-ScriptableObject.html.

Design choice: persistent mutable production jobs belong in the campaign save model, not mutable ScriptableObject assets. Recipe definitions may later be moved to shared immutable ScriptableObject assets. No third-party code was copied.
