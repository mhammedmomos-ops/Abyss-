# VS64 Export Guide

1. Extract the cumulative archive.
2. Merge `Packages/manifest.json` dependencies into the target Unity 6 project's manifest; do not replace the project's full manifest.
3. Copy `Assets/_Project` into the Unity project's `Assets` folder.
4. Open in Unity 6 and allow package resolution and script compilation.
5. Regenerate the greybox scene using **THE GORGE > Vertical Slice > Generate Greybox Scene**.
6. Bake the configured NavMeshSurface. Missing-pet reachability detection is intentionally suspended if the active companion agent is not bound to a baked NavMesh.
7. Configure a `MissingAnimalRecoveryInteraction` at each authored search/rescue recovery location and assign the exact stable identity of the missing pet expected there.
8. Test the missing transition by placing the companion on a disconnected NavMesh island, entering ActiveRaid or ThreatResolution, moving the player more than 35 metres away, and keeping the route incomplete for 60 seconds. Confirm the 30-second warning, persisted Missing state and actor shutdown.
9. Test negative cases: RecoveryPreparation phase, complete path, less than 35 metres, deliberate Stay command, unbaked NavMesh and dead pet.
10. Run the EditMode suite in Unity Test Runner. Then run PlayMode and device testing.

The archive is source code, not a compiled APK/AAB/IPA or verified playable build.
