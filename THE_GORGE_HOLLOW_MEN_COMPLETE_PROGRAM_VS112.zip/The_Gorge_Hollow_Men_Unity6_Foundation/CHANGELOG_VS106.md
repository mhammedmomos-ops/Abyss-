# VS106 — Worker cooperation gameplay integration

- Connected the confirmed Medic field-aid action to the social system. A successful treatment now creates or strengthens a same-tower relationship between the Medic and patient using the existing `ProtectedTogether` interaction.
- The social interaction is committed in the same campaign save as the medical-supply spend and treatment. If saving fails, the treatment, supply spend, and relationship change are all rolled back.
- Relationship capacity is optional to treatment: if the bounded relationship ledger is full, field aid still succeeds and the medical action is not blocked.
- Connected cooperation readiness to production. Two active, non-exhausted workers at the same tower, both assigned to Production, gain a small production-efficiency benefit when they have a recorded relationship.
- Production teamwork is capped at +10% per tower. It cannot create a penalty, does not cross towers, and stops applying if either worker is injured, captured, dead, exhausted, resting, or assigned elsewhere.
- No save schema change. Existing v14 saves remain compatible.
- Bridge access, enemy spawning, collapse and fatal-fall behaviour are unchanged. Workers still receive no bridge access tokens or cross-gorge routes.
