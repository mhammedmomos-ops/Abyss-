# VS94 — Persistent supply convoy logistics

## Objective
Connect the campaign resource economy to visible, attackable supply convoys travelling to either tower. Convoy route progress, cargo and health survive save/load; cargo is delivered once or permanently lost when the convoy is destroyed.

## Changes
- Added campaign save schema v7 and safe v6-to-v7 migration. Existing resource balances and campaign state are preserved; older saves start with an empty convoy manifest.
- Added persistent `SupplyConvoyRecord` entries containing identity, destination tower, route waypoint, world position, health, status and all campaign resource cargo.
- Added `SupplyConvoyController`: authored waypoint route, movement, periodic/waypoint progress checkpoints, restore from saved position, IDamageable health and damage feedback.
- Convoy damage is saved immediately. Lethal damage marks the convoy destroyed and clears its cargo; cargo cannot be reclaimed or duplicated by reloading.
- Delivery atomically transfers cargo to campaign resources, records a unique `supply-convoy-delivery:<identity>` transaction ID, clears the convoy manifest and marks it delivered. Overflow and duplicate deliveries are rejected before save.
- Added a live convoy registry and integrated convoys into monster siege target scoring. Existing `TowerSiegeAttacker` can damage the convoy through `IDamageable`; convoy-under-attack noise is broadcast through normal perception range/occlusion checks.
- Added ten EditMode test methods covering validation, damage, destruction, delivery, duplicate prevention and overflow.

## Scene authoring required
- Add `SupplyConvoyController` to the visible convoy root and provide a unique stable identity and destination tower ID (`tower_a` or `tower_b`).
- Assign ordered waypoint transforms along the intended safe road. Do not route the convoy over the bridge unless the game design explicitly requires it. The convoy itself does not bypass monster bridge access rules.
- Add a collider to the convoy root/child and ensure monster attack line-of-sight masks can hit it. `TowerSiegeAttacker` will resolve the controller through `IDamageable`.
- Ensure the convoy is spawned only once per identity. Reusing an identity restores the existing campaign record; a delivered/destroyed convoy will not respawn with fresh cargo. Use a new identity for a genuinely new shipment.
- Set a safe checkpoint interval for the desired balance between disk writes and rollback distance. Default is two seconds plus every waypoint.

## Preserved invariants
- Existing bridge spawn exclusion and tower-gateway-only enemy bridge access are untouched.
- Enemies caught on a collapsing bridge still fall and die; no recovery/teleport behaviour is added.
- Convoy destruction does not add resources. Only successful arrival at its destination delivers cargo.
- Campaign resources remain non-negative and all delivery cargo is committed exactly once.

## Verification boundary
- Static integration review, lexical delimiter checks, JSON/asmdef validation and ZIP integrity check performed.
- Unity Editor compilation, actual NUnit execution, scene/prefab wiring, NavMesh/AI simulation and Android/iOS builds/device tests have NOT been performed.
- Inherited archive still lacks authored scenes, prefabs, imported art assets and ProjectSettings; this is a cumulative source foundation, not a turnkey playable project.
