# VS44 — Reserve Ammo Warning, Zipline, World Ping, Water Wade & Run Seed

## Scope
VS44 adds low-reserve ammo warning, zipline travel, local world ping markers, water wading slowdown, and a run seed state built on DailySeedUtility.

## Added
- `AmmoReserveWarningUI.cs`
- `ZiplineInteraction.cs`
- `PingWorldMarker.cs` / `PingButtonUI.cs`
- `WaterWadeZone.cs` / `WaterWadeMovementModifier.cs`
- `RunSeedState.cs`
- `VS44WaterWadeTests.cs`

## Modified
- Version tags → VS44

## Scene setup
1. HUD warning → `AmmoReserveWarningUI`.
2. Zipline start interact + start/end points → `ZiplineInteraction`.
3. Ping prefab + `PingWorldMarker` / HUD `PingButtonUI`.
4. Water trigger → `WaterWadeZone`; player → `WaterWadeMovementModifier`.
5. Persistent object → `RunSeedState` (daily or random).

## Limitations
- Zipline disables CharacterController during ride (no mid-path cancel).
- Water slowdown is a post-move damp, not a full movement rewrite.
- Pings are local-only (no multiplayer replication).
- Unity compile / device builds not performed here.
