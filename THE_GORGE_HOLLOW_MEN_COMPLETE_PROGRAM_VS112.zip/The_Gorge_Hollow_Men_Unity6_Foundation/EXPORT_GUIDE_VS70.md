# VS70 export and setup

1. Extract the complete VS70 archive.
2. Open the project using Unity 6 (6000.x) and allow Unity to regenerate missing `.meta` files/import assets.
3. Ensure monster prefabs retain `MonsterAIController`, `NavMeshAgent` and `MonsterPerception`; moving monsters record scent automatically through `MonsterAIController.LateUpdate`.
4. Ensure the Shepherd companion prefab has `AnimalCompanionController` and a valid enabled NavMeshAgent. The default scent search radius is 18m and trail lifetime is 150 seconds.
5. If using the generated vertical-slice scene, the HUD now creates and wires a TRACK SCENT button; it is enabled only while an operational German Shepherd is selected. For an existing custom scene that is not regenerated, add a Button wired to `CompanionCommandUI.CommandTrackScent` and assign its Button component to the optional `scentTrackButton` field. The command succeeds only for a selected German Shepherd with a fresh, locally reachable trail.
6. Test with a moving monster that has travelled at least 1.6m, then approach one of its recent trail samples and issue Track Scent. The Shepherd should follow older samples backward. A newly confirmed threat interrupts tracking.
7. Run `VS70AnimalScentTrailTests` and the full EditMode suite.

No scenes, prefabs or serialized UI assets are silently rewritten in this code-only phase. A UI button must be wired in the scene before the command is player-accessible.

Unity compilation, EditMode execution, PlayMode navigation, NavMesh baking and Android/iOS builds have not been performed in this environment.
