# VS63 — Species-specific companion tactics

## Scope
VS63 replaces the previous mostly-statistical species differences with separate, explicit threat-response policies while retaining player selection, custom names, persistent animal records, the starvation gate, missing-pet recovery and existing campaign save format.

## Species behaviour
- **German Shepherd — engage/tracking protector:** retains direct melee support as the only species that actively attacks monsters. Its broader scent-led search radius is represented by a longer ground-forage search radius; this is not yet a scent-trail visualization system.
- **Falcon — observe/alert specialist:** does not enter melee. When it confirms a nearby threat while following, protecting or alerting, it navigates to a standoff observation point and faces the threat. It has the broadest local detection and forage search radius. This phase does not implement true aerial flight; the current world actor still uses the ground NavMesh.
- **Pangolin — defensive specialist:** does not melee. On receiving a monster strike, if it has at least 8 stamina, it automatically braces for 2.4 seconds, spends 8 stamina, and applies an additional 0.45 damage multiplier to that strike. It stops moving while braced. The current greybox actor has no authored curl animation/model.
- **Cat — evasion/reconnaissance specialist:** does not melee. When it confirms a threat near the owner, it chooses a NavMesh position offset away from that threat while remaining near the owner. It has a distinct cautious forage duration and intermediate search radius. This is tactical evasion, not invisibility or guaranteed monster detection immunity.

## Foraging differences
- Species now have distinct forage action durations: Shepherd 2.2s, Falcon 1.8s, Pangolin 3.4s, Cat 2.5s.
- Search-radius multipliers: Shepherd 1.35x, Falcon 1.6x, Pangolin 0.9x, Cat 1.15x.
- The once-per-day source depletion and transactional food reward remain unchanged.
- Fixed a threat interruption edge case: after a forage trip is aborted, the companion continues retreating to the owner while the threat remains confirmed instead of immediately re-entering its species combat response on the next frame.

## Compatibility
- No campaign save-schema change.
- No new package dependency and no third-party source code copied.
- All four approved species remain selectable; custom display names and stable campaign identities remain unchanged.
- Existing NavMeshAgent remains the movement authority for the current greybox actor.

## Explicitly not implemented
- Finished species meshes, skeletons, authored animation clips/controllers, procedural IK or animation rig assets.
- True Falcon flight, aerial navigation, perches or air-only path planning.
- Fully developed dog scent trails, animal-specific prey simulation, or unique food item categories.
- These require licensed animal assets/rigs and in-Unity animation, NavMesh/off-mesh-link and device validation. The capsule greybox is still a placeholder.

## Tests and verification
- Added seven VS63 EditMode test methods covering species threat policy, melee gating, distinct forage durations/search radii, Pangolin brace parameters, and safe fallback for unsupported enum values. Tests are included but not executed.
- Static lexical/delimiter checks, JSON/asmdef parsing, duplicate-type scan, archive retention comparison and ZIP integrity are performed for this export.
- Unity compilation, EditMode/PlayMode execution, runtime combat/physics, scene generation, NavMesh bake, animation validation and Android/iOS device testing are not performed in this environment.
