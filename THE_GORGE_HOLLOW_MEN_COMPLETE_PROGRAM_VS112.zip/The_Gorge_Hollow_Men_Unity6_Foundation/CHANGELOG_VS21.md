# VS21 — Staged Bridge Collapse and Reconstruction

## Added
- `BridgeCollapseRules`: deterministic, allocation-free timing rules for sag progress and staggered fragment release.
- `BridgeCollapseSection`: authored bridge fragment wrapper for a preconfigured Rigidbody. It captures its authored local pose, remains kinematic while intact, detaches into world space when released, and can be returned to its authored pose after reconstruction.
- `BridgeCollapseSequence`: event-driven collapse presentation that reacts to `BridgeSpanController` initialization and state changes. It animates an optional sag pivot and releases authored fragments in sequence.
- `BridgeSpanController.StateInitialized`, raised after the initial campaign-derived bridge state has been applied. This allows effects to handle a bridge that loads already collapsed without replaying collapse on every refresh.
- EditMode tests for sag timing, invalid timing, bounded progress and staggered release ordering.

## Behaviour and persistence
- Bridge collapse remains derived from persisted `TowerStructuralSegment` support health. No bridge-specific save record or schema migration was added.
- A support repair that restores the span causes the sequence to stop, return fragments to their authored parent/pose, clear fragment velocities, restore kinematic bodies and return the sag pivot to its intact pose.
- Fragments are authored in advance. The system does not generate meshes, Rigidbody components, joints, colliders or debris at runtime.
- Fragments detach from the sag hierarchy when released so subsequent movement of the bridge pivot does not drag dynamic rigidbodies through their parent transform.
- Existing traversal collider disabling and collapsed NavMeshObstacle activation remain owned by `BridgeSpanController`.

## Authoring / setup
1. Keep `BridgeSpanController` configured as described in `CHANGELOG_VS20.md`.
2. Add `BridgeCollapseSequence` to the bridge root and assign the same `BridgeSpanController`.
3. Create a child pivot containing the bridge deck visual group and assign it to `sagPivot`. Do not assign the bridge root or an ancestor.
4. Tune `collapsedLocalOffset`, `collapsedLocalEuler`, `sagDuration` and optional `sagCurve` to match the authored bridge.
5. Create a small number of pre-authored fragment GameObjects with colliders and non-kinematic-capable Rigidbodies; add `BridgeCollapseSection` and assign each Rigidbody. Keep fragments positioned as part of the intact bridge. Set their initial Rigidbodies kinematic in the Inspector or allow the component to enforce this on initialization.
6. Assign the fragments in the intended release order. Tune the first release delay and interval. Use low fragment counts and simple colliders for mobile.
7. Ensure fragment colliders do not overlap the player spawn or create an unbounded pile. If fragments must remain as stable path blockers, author separate static rubble/obstacle objects; released physics pieces are transient visual/physical effects.
8. Test collapse, save/reload while collapsed, support repair, and another collapse in a Unity scene with the actual bridge assets and baked NavMesh.

## Deliberate limitations
- No player/companion fall, damage, rescue, respawn or traversal animation is implemented; the span's existing traversal colliders still prevent crossing after failure.
- No continuous beam stress solver, joint break-force simulation, physically connected bridge assembly, rope/cable simulation, or automatic NavMesh rebuild is included.
- No dynamic bridge state is stored separately. On load, support records determine bridge state and the collapse presentation starts from that derived state; transient fragment positions are not persisted.
- Art, meshes, colliders, animation curves, physics tuning, audio, camera shake, haptics and scene wiring must be authored and validated in Unity.
