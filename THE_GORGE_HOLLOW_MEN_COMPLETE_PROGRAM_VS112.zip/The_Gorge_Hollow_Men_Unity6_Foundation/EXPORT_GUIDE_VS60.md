# VS60 Export / Setup Guide

1. Extract the complete archive into a clean Unity 6 project folder.
2. Open the project with Unity Editor 6000.0 and allow package resolution to finish.
3. Open `Assets/_Project/Editor/GorgeVerticalSliceSceneGenerator.cs` through the Unity project.
4. Run **THE GORGE → Vertical Slice → Generate Greybox Scene**. This regenerates `Assets/_Project/Scenes/GorgeVerticalSlice.unity` and wires the new post-encounter night transition button.
5. Bake or generate NavMesh data for the greybox layout and confirm the player, companion and monster agents are placed on valid NavMesh surfaces.
6. Enter Play Mode. After a raid is requested and all monsters are removed, the HUD should expose **RETURN TO DAWN**. The player must press it to commit the next campaign night. The final night uses **COMPLETE CAMPAIGN**.
7. Run the EditMode suite in Test Runner. In particular, run `VS60CampaignNightAdvanceTests` and all prior regression tests.
8. Test a failed save, a raid still active, a destroyed monster, a second encounter, a campaign reload and the final night before building for mobile.

This archive contains source and editor scene-generation code. The regenerated scene, baked NavMesh, Unity compilation and device builds have not been produced or verified in this environment.
