# VS54 export and Unity setup

1. Extract the cumulative ZIP.
2. Open/import the source into the intended Unity 6 project with the package manifest dependencies restored.
3. Regenerate the vertical-slice scene from `THE GORGE > Vertical Slice > Generate Greybox Scene`. This updates the prototype monster prefab and raid reward listener.
4. If using authored monsters, add `MonsterCombatFeedback` to the monster root and configure the Animator `Hit` trigger and optional impact ParticleSystem.
5. Add `WeakPointBonus` to designated weak-point colliders. Confirm weapon hit masks include those colliders.
6. Bake the NavMesh before playtesting the encounter.
7. Run EditMode tests from the `GorgeHollow.Tests` assembly.

The archive contains source and Editor generation tools. It does not contain generated greybox scene/prefab assets until the Editor generator is run.
