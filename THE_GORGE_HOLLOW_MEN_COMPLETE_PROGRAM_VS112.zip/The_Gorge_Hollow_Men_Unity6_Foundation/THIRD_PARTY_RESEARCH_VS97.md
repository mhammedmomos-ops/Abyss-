# VS97 Third-Party Research

No third-party source code was copied into this phase. Unity's official Unity 6 documentation was consulted to select supported movement/serialization integration patterns:

- Unity 6 `NavMeshAgent` API: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/ai/navmeshagent — relevant for future route/path integrations; the current convoy continues to use authored waypoints so it can persist a deterministic waypoint index and obey the bridge crossing gate.
- Unity serialization rules: https://docs.unity.com/en-us/engine/7000.0/manual/programming-environment/code-reload-serialization/script-serialization/rules — custom persisted records remain `[Serializable]` field-based data and avoid unsupported nested containers.
- Unity 6 serialization guidance: https://docs.unity.cn/Manual/script-serialization-rules.html — used to avoid duplicate runtime-only state in the campaign model.

The transfer deliberately extends the existing convoy and save patterns rather than introducing a second inventory ledger or third-party package.
