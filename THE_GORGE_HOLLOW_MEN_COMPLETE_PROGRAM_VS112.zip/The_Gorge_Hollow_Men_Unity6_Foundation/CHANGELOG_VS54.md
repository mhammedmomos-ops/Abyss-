# VS54 — Confirmed Combat Feedback and Raid Completion Rewards

## Built from
VS53 cumulative source archive. All previous files are retained; this phase extends existing combat, monster health, raid and campaign transaction systems.

## Changes
- `DamageableHealth` now publishes a `DamageReceived` event with amount, hit point, direction and source.
- `MonsterCombatFeedback` connects confirmed damage to optional Animator hit trigger and ParticleSystem impact effect, with a configurable reaction cooldown.
- `MonsterAnimationBridge` drives an authored `Speed` float and `Attack` trigger while leaving movement authority with NavMeshAgent.
- The generated encounter now has two distinct archetypes: Stalker (fast, lower health/damage) and Brute (slower, higher health/damage and Brute tactical branch). Both use greybox placeholder visuals; final creature assets and animation controllers remain authoring tasks.
- `HitscanWeapon` now applies `WeakPointBonus` multipliers to actual damage and publishes `ConfirmedHit` only when an `IDamageable` receiver was found and damaged.
- `HitMarkerBinder` now reacts to confirmed hits instead of magazine decreases, correcting the previous false-positive hit marker on missed shots.
- `MonsterRaidDirector` exposes an instance-scoped `EncounterResolved` event and tracks actual kills separately from removed/destroyed monsters.
- `MonsterRaidReward` grants scrap and ammunition only after a full clear, through the existing `ResourceTransactionService`; reward writes are rolled back in memory if campaign persistence fails.
- The greybox scene generator adds combat feedback and animation hooks to the generated Stalker and derived Brute prefabs, creates both archetype assets, configures both in the raid roster, and attaches the reward listener to its raid director.
- Added VS54 EditMode source tests for weak-point damage, malformed damage values, full-clear criteria, reward scaling, transaction IDs and distinct Stalker/Brute tactical priorities.

## Setup
Regenerate the greybox scene using `THE GORGE > Vertical Slice > Generate Greybox Scene` so the generated prefab and raid director receive VS54 components. If you already have authored monster prefabs, add `MonsterCombatFeedback` and `MonsterAnimationBridge` to each root; configure Animator `Hit`, `Attack` and `Speed` parameters plus an optional impact ParticleSystem. Ensure weak-point colliders have `WeakPointBonus`.

## Explicit limits
- No authored hit/death animations, audio, monster meshes or VFX are included.
- Damage reaction only plays if the Animator has the configured trigger; no fallback animation is fabricated.
- Rewards are currently local campaign resources, not server-authoritative multiplayer rewards.
- A full raid clear is required; abandoned/despawned monsters do not grant rewards.
- Each raid receives one encounter ID at start; the same ID is carried through resolution and used for the idempotent campaign transaction, preventing duplicate reward delivery for that raid.
- Unity compilation and test execution have not been performed in this environment.
