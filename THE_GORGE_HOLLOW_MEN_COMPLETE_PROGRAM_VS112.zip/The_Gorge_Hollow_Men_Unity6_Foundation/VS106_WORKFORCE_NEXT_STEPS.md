# Workforce next steps and starting roster decision

## Current factual state
- `CampaignStateFactory.CreateNew()` creates an empty `towerWorkers` list.
- Workers are recruited only when an authored `WorkerRescueInteraction` is used in the world.
- The workforce capacity is 8 non-dead workers per tower (16 total), not a starting count.
- A recruited worker requires a matching scene actor binding for visible movement and raid response. The source package does not contain a verified complete authored campaign scene with all actor bindings.

## Recommendation
Yes, the game needs a deliberate starting workforce. Do not simply seed eight workers per tower: that would fill capacity, weaken the rescue/recruitment loop, and create a large scene-authoring burden. A sensible first playable roster is **two workers at each tower** (four total): one Mechanic and one Guard per tower. Recruitable survivors can then add Scavengers and Medics, with a hard cap of eight per tower. This is a recommendation, not silently applied campaign balance.

Before enabling that roster in a playable scene, implement a deterministic starting-worker bootstrap that creates the campaign records and their matching worker actors together, validates unique IDs and tower assignment, and avoids duplicate spawning on save/load. The next workforce phase should include actor prefab/greybox fallback, spawn points per tower, role-specific assignments, rescue/recruitment, death/capture persistence, and mobile UI verification. Do not seed campaign-only workers that have no visible actor in the scene.
