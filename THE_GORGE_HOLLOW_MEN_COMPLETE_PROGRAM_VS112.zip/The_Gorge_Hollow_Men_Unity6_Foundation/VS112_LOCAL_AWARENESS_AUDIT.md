# VS112 Local Awareness Integration Audit

## Information-isolation rules

1. No HUD component may show global raid phase, global enemy count, global encounter start/resolution or remote tower condition.
2. A hostile is visually reportable only when within visual radius, inside the active camera viewport/culling mask and not blocked by the nearest physics hit.
3. An unseen hostile inside hearing radius may produce only the generic message `MOVEMENT NEARBY`; it must not reveal count, identity, health or remote tower.
4. When the player is physically inside Tower A, an actor inside Tower B's authored footprint is suppressed from sight, hearing and presentation (and vice versa). Enemies may become observable after leaving the remote tower footprint and approaching over the bridge.
5. A hostile outside local sight/hearing must not alter local HUD, siren, raid music, local wind/flicker or enemy actor presentation.
6. Remote enemies continue to simulate. Visibility must not disable their AI, NavMeshAgent, colliders, attacks or siege logic.
7. World time/day-night ambience may remain shared because it is not an encounter-state report. Raid-specific weather and light changes must not be driven by global campaign phase.
8. Convoy status, destination, delivery/destruction alerts and commands must be available only when the physical convoy is locally observable.
9. The generated player HUD must not show a global encounter-completion/night-advance control.

## Integration

- `MonsterRaidDirector.CopyLivingMonsters` supplies a read-only copy into a caller-owned list; it does not expose mutable director storage.
- `MonsterLocalAwareness` owns local detection and presentation. It is created as a world-level scene object, not as a component on the player, so disabling/replacing the player does not restore remote hostile renderers accidentally.
- The perception controller requires a configured local-access tracker and both tower roots. Missing configuration fails closed by hiding hostile presentation and suppressing awareness. While the player is inside a known tower footprint, the opposite tower footprint is an explicit perception exclusion zone for hostiles and other observed world objects.
- Line of sight uses `Physics.RaycastNonAlloc` and a fixed 24-hit buffer. A saturated buffer fails closed because Unity does not guarantee nearest-hit ordering when the buffer is full.
- Hostile actor renderer, canvas, light and audio states are cached once per spawned actor to avoid repeated child-component allocations. Disabling the perception controller fails closed by hiding/muting all cached hostiles rather than revealing them; authored states are retained for subsequent re-enable. Audio sources are muted outside local hearing and their authored mute state is preserved.
- Only the local player's current camera determines visual viewport and culling-mask eligibility.
- Hearing is intentionally coarse: one or many unseen enemies yield the same `MOVEMENT NEARBY` state.
- Local threat intensity is derived only from visible hostile count and the generic hearing flag. It is capped at 1.

## UI/audio/environment audit

| System | VS112 source of information |
|---|---|
| EncounterStatusUI | Local visible/heard state |
| RaidBannerUI | Local visible/heard state |
| RaidProgressUI | Local visible/heard state; no night/raid progress |
| ThreatMeterUI | Local threat intensity |
| CampaignStatusHUD | Shared clock/night/chapter + local awareness; no phase display |
| WeatherLabelUI | Local awareness |
| AudioEventBinder | Local awareness for raid alarm cue |
| SirenAlertController | Local awareness plus exact local tower ID; silent unless player occupies that tower |
| CrossfadeMusicPlayer | Local awareness |
| WindAudioModulator | Local awareness |
| SpotlightFlicker | Local awareness |
| AmbientWildlifeCue | Local calm state |
| NightAmbientController | Fictional hour only |
| WeatherBlendController | Fictional hour only |
| FogDensityController | Fictional hour only |
| DawnSummaryUI | No automatic global phase subscription |
| CampaignNightAdvanceUI | Disabled; no global encounter completion control |
| SupplyConvoyController | Delivery/destruction/bridge-loss toasts only if the carrier is locally observable |
| SupplyConvoyCommandPanel | Selects and commands only a locally observable active carrier; hides otherwise |

## Known limitations / required Unity validation

- This is a presentation and information-routing boundary for the current single-player client, not a multiplayer security boundary. Future server-authoritative multiplayer must send only authorized local perception events to each client.
- The current greybox scene generator wires one `MonsterRaidDirector`; all hostile actors must be registered with that director to be included in perception. Future spawn systems must register actors or integrate with this perception service.
- Raycast occlusion depends on correctly authored colliders and the `occlusionMask`. The default mask includes all layers; production scenes should verify transparent/trigger/foliage layer treatment.
- The fixed raycast buffer fails closed when saturated. Scenes with more than 24 colliders intersecting a sight ray may cause a false negative, not a false positive.
- A hostile's center point is used for viewport testing; large creatures near screen edges may be hidden until their center enters view.
- Convoy local notifications/commands use the same camera/occlusion/tower-footprint observation check. Other future world-object notifications must opt into `CanObserveWorldObject`; the helper does not automatically gate arbitrary global events.
- Audio sources outside hearing range are muted, but authored ambient audio that is not parented to `MonsterAIController` is not covered. Enemy prefab audio should be parented to its actor and use appropriate 3D spatialization.
- Camera, physics occlusion, fail-closed presentation state, scene wiring and audio transitions require PlayMode/device validation.
- The global night-advance UI is intentionally disabled. A future rest mechanic must be based on locally observable conditions or explicit communication, not global encounter completion.
