# VS84 — Level Authoring Guide: Environmental Awareness

Environmental awareness is deliberately authored into level geometry. The companion does not infer that every rock, bush, rooftop, or patch of ground has a gameplay property.

## Add a marker

1. Select a suitable world object with a Collider. The collider may be a trigger or a normal collider.
2. Add `AnimalEnvironmentMarker` to the same GameObject as the collider, or to a parent of the collider.
3. Set **Features** to one or more relevant flags.
4. Set **Influence Radius** to the local distance within which the feature should affect a companion.
5. Ensure the collider's layer is included in the companion controller's **Environment Mask**.

The marker component requires a Collider. The default companion probe radius is 8 world units and the default environment mask is all layers. For production scenes, assign a dedicated layer such as `CompanionEnvironment` and narrow the mask to that layer to avoid scanning unrelated colliders.

## Feature meanings

| Feature | Intended level geometry | Gameplay effect |
|---|---|---|
| Concealment | Dense brush, shadowed rubble, low cover, concealed passage | Cat receives its environmental bonus only while Stalking |
| Elevated Perch | Stable ledge, rooftop perch, lookout platform | Falcon receives a modest scan and assessment bonus |
| Defensive Ground | Narrow defensible approach, protected ground pocket, stable brace location | Pangolin receives a modest assessment bonus |
| Scent Rich Ground | Mud, damp earth, tracked soil, disturbed ground | German Shepherd's existing scent-trail search radius increases modestly |

Do not tag an entire map as one feature. Use local markers at meaningful positions so the bonuses communicate geography and player positioning.

## Balance and safety rules

- A marker is a contextual modifier, not a threat detector. It never supplies an enemy position.
- The existing scan still requires a valid living monster and line of sight.
- Unmarked areas grant no bonus.
- Bonuses are intentionally modest and do not change attack damage, health, bond, or save data.
- Avoid overlapping dozens of markers at one location; combined flags on one marker are preferred where appropriate.
- The default overlap buffer holds 32 colliders. If a dense scene routinely exceeds this within the probe radius, reduce the mask/radius or increase the controller's serialized buffer capacity in a reviewed performance pass.

## Suggested first-pass placement

- Concealment: selected vegetation clusters and broken-wall recesses near routes used for stealth approaches.
- Elevated Perch: a few accessible high ledges with clear sight lines, not every roof.
- Defensive Ground: selected choke points near tower approaches where the Pangolin can assess threats.
- Scent Rich Ground: muddy tracks, disturbed soil, and the edges of monster travel routes.

After authoring, test each companion in an unmarked area and a marked area. Confirm that only the matching species/command receives the intended modifier and that occluding geometry still blocks direct threat detection.
