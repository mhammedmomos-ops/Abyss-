# VS78 — Veteran Companion Abilities

## Added / changed
- Three veteran-tier abilities extend the VS75 experience ladder: **Steady Post** (60 XP), **Bonded Voice** (85 XP) and **Sharp Eye** (110 XP).
- Steady Post widens Guard Post detection a further 10%. Bonded Voice shortens the Bond Resonance cooldown to 75%. Sharp Eye shortens the Weak Point Callout cooldown to 75%.
- New overloads: `AnimalGuardPostRules.DetectionRadiusWhileGuarding(radius, guarding, learned)`, `AnimalBondResonanceRules.CooldownEndsAt(t, learned)`, `AnimalWeakPointCalloutRules.CooldownEndsAt(t, learned)`. The original overloads are unchanged.
- Unlock toasts for all three. `AnimalExperienceRules.TotalAbilityCount` = 6.
- Eight EditMode tests in `VS78VeteranAbilityTests`.

## Design boundaries
- Each veteran ability tunes exactly one existing command; none adds a new command or a new button.
- No save schema change: abilities are stable string IDs in `AnimalRecord.learnedAbilities`, which campaign validation already accepts. Existing saves with 0 to 3 abilities load unchanged and can earn the new ones with further play.
- Thresholds are above the first tier (40 XP), so VS75 unlock behaviour is not altered.

## Validation
Static checks only (brace balance and symbol cross-references). Run the VS78 tests in Unity 6.
