# THE GORGE: HOLLOW MEN — VS18

## Progressive structural sections and collapse-aware monster navigation

VS18 extends VS17's persistent tower-health presentation with multiple independently staged *visual/functional sections* while deliberately retaining one authoritative saved health value per structure.

### Added

- `TowerStructuralSegmentRules`: pure deterministic rules for Intact, Damaged and Collapsed section states, including boundary, reversed-threshold and non-finite input handling.
- `TowerStructuralSegment`: event-driven scene component that derives its state from its parent `TowerStructure` campaign health. Multiple components on one structure can use different thresholds to create progressive collapse (for example, upper barricade panels fail before lower supports).
- Optional child-only state groups for intact, damaged and collapsed meshes/colliders. A designer can replace a section's intact collision with a broken opening or rubble collision as it crosses the configured threshold.
- Optional `NavMeshObstacle` activation after collapse. Assign a preconfigured obstacle on the section or a child object; the component only enables/disables it. It does not add components or guess obstacle dimensions at runtime.
- `StateChanged` event for downstream animation, audio, camera shake, debris or quest systems.
- Seven EditMode regression tests for thresholds, destruction, normalization and repair-derived restoration.

### Scene setup

1. Keep a `TowerStructure` on the root of the persistent structure.
2. Create child section objects for the parts that can fail separately (e.g. `Gate_UpperBeam`, `Gate_LeftPanel`, `Bridge_Support_A`). Add `TowerStructuralSegment` to each section or a dedicated controller child and assign the parent structure.
3. Author intact, damaged and collapsed child groups. Put renderers and colliders under the matching group. Do not assign the segment GameObject itself or an ancestor; the component intentionally refuses to toggle itself/ancestors.
4. Give each segment its own health thresholds. Example: upper beam damaged at 70%, collapsed at 45%; side panel damaged at 45%, collapsed at 20%. Since all sections currently derive from parent structure health, the different thresholds produce a staged visual/functional sequence rather than separately targeted hit-point pools.
5. For a collapsed section that blocks monster pathfinding, assign a `NavMeshObstacle` and configure its shape/size/center in the Inspector. Enable Carving and normally leave Carve Only Stationary enabled for a static rubble pile. The segment toggles the obstacle only in Collapsed state.
6. Subscribe to `StateChanged` if the scene needs one-shot audio/animation/debris. The event is raised only after the component has received an initialized campaign-health notification and a subsequent state transition; initial scene hydration applies the correct state without playing a collapse event.

### Persistence and repair

- No save schema change. Section states are derived from the already-persisted parent `TowerStructureRecord.currentHealth`.
- On load, the section applies its correct state from the saved parent health. No independent section state can become inconsistent with the campaign record.
- Repairs can move sections back through Damaged/Intact states and restore their intact visual/collider groups and disable the collapse obstacle.
- This phase does not add localized segment damage, independent section hit points, persistent debris, physical falling beams, runtime mesh fracture, bridge traversal logic or automatic NavMesh baking. Those require authored content and/or a deliberately versioned section-health persistence design.

### Third-party research and reuse

- Uses the project's existing Unity AI Navigation 2.0.16 dependency and Unity's built-in `NavMeshObstacle`; no new package was added and no third-party source code was copied.
- Unity documents that carving creates a temporary NavMesh hole recognized by path planning, while non-carved obstacles provide local avoidance only. Carving is recalculated with a delay/when stationary to reduce CPU overhead; this is why VS18 toggles an authored obstacle on a collapsed static section instead of rebuilding the NavMesh on every damage event.
- Runtime mesh-fracture packages and marketplace toolkits were reviewed but not integrated. The project has no confirmed URP pipeline, tower meshes, fragment prefabs or representative mobile profiling scene. The deterministic authored-state approach is the safer integration boundary for this source-only foundation.

## Verification boundary

Static source checks and ZIP integrity checks are included in `Assets/_Project/BUILD_VERIFICATION.txt`. Unity Package Manager restore, Unity 6 compilation, EditMode test execution, scene/prefab validation, NavMesh baking/runtime path tests, Android/iOS builds, device profiling and playtesting have **not** been performed.
