# Export Guide — VS45

1. Unity 6 URP → copy `Assets/_Project`.
2. Packages: AI Navigation 2.0.16, Splatter.AI, Unity UI.
3. Compile + run EditMode tests.
4. Wire inventory panel, flicker lights, reload bar, elevator, armor HUD.
5. Build mobile only after device validation.

Cumulative VS1–VS45 source. Not an APK or finished game.
