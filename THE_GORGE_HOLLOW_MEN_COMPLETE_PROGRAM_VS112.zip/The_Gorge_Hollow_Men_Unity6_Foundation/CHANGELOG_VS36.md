# VS36 — Pinned Objectives, Wind Audio, Fall Feedback, Doors, Resource Popup & Foundation Info

## Scope
VS36 adds objective pinning, wind audio modulation, hard-landing feedback, door/gate toggles, resource pickup popup, offline status stub, and a central foundation info constant.

## Added
- `PinnedObjectiveTracker.cs`
- `WindAudioModulator.cs`
- `FallDamageFeedback.cs`
- `ResourcePickupPopup.cs`
- `DoorToggleInteraction.cs`
- `NetStatusStubUI.cs`
- `GameFoundationInfo.cs`
- `VS36FoundationInfoTests.cs`

## Modified
- `GameVersionLabel.cs` — default foundation tag VS36.

## Scene setup
1. Optional pin button → `PinnedObjectiveTracker.PinPrimaryFromTracker`.
2. Looping wind AudioSource → `WindAudioModulator`.
3. Player → `FallDamageFeedback`.
4. Resource HUD area → `ResourcePickupPopup`.
5. Base doors → `DoorToggleInteraction`.
6. Menu footer → `NetStatusStubUI` / version label.

## Limitations
- Pinned objective is UI preference only (ObjectiveHUD still uses tracker primary unless you extend it).
- Doors are local transforms (not networked/saved).
- Unity compile / device builds not performed here.
