# VS104 Integration Audit

## Integrated
- `TowerWorkerRecord` owns the four persisted fields; no duplicate sidecar roster.
- `CampaignState.IsValid` bounds morale, loyalty and stress to 0–100 and rejects invalid recovery progress.
- `CampaignSaveService` migrates v12 to v13 while retaining the v1–v12 chained migration path.
- `TowerWorkerRules.TryAssign` applies refusal only to Guard/Salvage assignments and exposes the exact reason.
- `TowerWorkerRules.Advance` applies recovery only while resting or injured; captured/dead workers are excluded.
- Capture/rescue and field aid apply morale events; witness morale impact is applied when a worker dies.
- Mobile workforce panel surfaces the values.

## Design constraints
- No random morale rolls; event deltas and recovery are deterministic and clamped.
- No resource or medical supply is minted by morale changes.
- No forced abandonment/death consequence is applied merely because a worker is injured or a raid ends; only explicit capture/death events apply loss.
- Morale does not silently cancel existing assignments. It gates only new dangerous Guard/Salvage orders, and returns a reason.
- Bridge spawn/access/collapse logic is unchanged. No worker is granted bridge access.

## Known integration limitation
- The current capture volume represents an overrun/capture outcome; there is no player-facing explicit “abandon worker” command in this source foundation. The abandonment delta is available as a rules event for a future explicit outcome/mission decision, not applied automatically to all survivors.
- Protected-during-raid and completed-duty events are exposed for future explicit outcome hooks; this phase does not infer successful protection from merely reaching a shelter waypoint.
- No Unity project scenes/prefabs are authored by this phase; inspector wiring remains required.
