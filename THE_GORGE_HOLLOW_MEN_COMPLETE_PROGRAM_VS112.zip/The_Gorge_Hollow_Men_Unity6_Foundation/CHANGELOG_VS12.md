# VS12 — Adaptive Trap Awareness and Vulnerability-Based Siege Targeting

## Added
- Added a scene-authored `PlayerTrap` component with trigger damage, activation limits, cooldown, arm/disarm controls, recognition radius and avoidance radius.
- Monsters learn trap locations only after direct line-of-sight recognition or a trap trigger. Learning is per-monster and bounded to eight hazard records.
- Monster movement destinations are adjusted around learned hazards when the proposed route segment intersects an observed trap's avoidance radius.
- Added non-allocating nearby trap scans using `Physics.OverlapSphereNonAlloc`, staggered by a configurable scan interval.
- Added deterministic target scoring: damaged structures and designer-authored high-priority structures become more attractive siege targets. Brutes weight structural vulnerability more strongly.
- Added six EditMode regression tests for hazard memory bounds, update semantics, route intersection and siege scoring.

## Setup
- Add `PlayerTrap` to a trap prefab with a `SphereCollider`; the component configures it as a trigger and configures a kinematic Rigidbody. Ensure monster root/child colliders can enter the trigger.
- Set a unique trap ID, recognition radius, avoidance radius, damage and activation count. Place traps in the scene or instantiate them from a future player construction/deployment system.
- On each `TowerStructure`, tune **Siege Priority** (default 1). Higher values make the structure more attractive to attackers.
- On monster AI, tune trap scan interval/range and detection/visibility layer masks.

## Compatibility
- Retains the VS11 campaign save schema (v2); no save migration is required.
- Existing tower structures retain default siege priority 1.
- Existing monster learning fields and `TickContact()` compatibility entry point remain.

## Limitations
- Trap placement, crafting, inventory costs, trap UI and trap persistence are not implemented in this milestone. `PlayerTrap` is a reusable scene/prefab component, not a complete deployment system.
- Learned trap locations are per-monster runtime memory and are not saved across raids or campaign sessions. Monsters do not gain global knowledge of hidden traps.
- Avoidance is a local NavMesh waypoint adjustment, not a full tactical route planner; complex overlapping hazards require further path-cost integration and playtesting.
- Tower vulnerability scoring uses existing structure health; no separately authored weak-point hitboxes or damage multipliers have been added.
