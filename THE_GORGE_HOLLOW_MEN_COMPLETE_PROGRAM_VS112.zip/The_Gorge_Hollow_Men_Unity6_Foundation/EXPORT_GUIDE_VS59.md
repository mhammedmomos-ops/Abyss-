# VS59 export and integration guide

1. Extract the complete archive.
2. Open the extracted project root (the folder containing `Assets`, `Packages`, and `ProjectSettings`) in Unity 6.
3. Allow package resolution and script compilation to finish.
4. Run `GorgeHollow.Tests` EditMode tests from Test Runner.
5. In the gameplay transition owner, call `GameBootstrap.TryAdvanceCampaignMinutes(minutes)` only when a deliberate in-game time event occurs.
6. Call `GameBootstrap.TryCompleteCampaignNight()` only after the raid/night resolution is committed. It saves the next night before publishing the night/phase events.
7. Verify the selected companion remains bound after campaign replacement, including custom display name, health, stamina, age and species.
8. Run PlayMode tests for save failure, successful night completion, player reload, pet death and life-stage tuning before shipping.

No automatic real-time clock is enabled by this phase.
