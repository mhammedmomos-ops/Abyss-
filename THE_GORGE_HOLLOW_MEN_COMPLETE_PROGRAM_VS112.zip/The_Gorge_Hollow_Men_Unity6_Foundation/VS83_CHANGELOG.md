# THE GORGE: HOLLOW MEN — VS83

## Companion Intelligence and Contextual Awareness

VS83 extends the four-species companion system with contextual perception rules. It does not add global monster tracking or grant companions knowledge of threats they have not personally detected.

- **German Shepherd:** receives a modest awareness/confidence improvement when a detected threat is closer to the player than to the shepherd, reinforcing protective interception.
- **Falcon:** gains a modest visual-scan and confidence improvement when the companion is genuinely elevated at least 1.5 world units above its owner.
- **Pangolin:** gains a close-range defensive assessment bonus only when a detected threat is within four metres.
- **Cat:** gains a quiet threat-assessment confidence bonus while using the existing Stalk command.
- Contextual confidence remains clamped to 0–1. Invalid distance/confidence inputs are handled safely.
- Existing commands, bond ranks, save records, species roster, mobile architecture and prior systems are retained.

## Verification

- Source-level integration and static review performed.
- New VS83 EditMode tests added (5 cases).
- ZIP integrity checked after packaging.
- Unity Editor compilation, EditMode execution, PlayMode, NavMesh/scene validation and Android/iOS device tests were not run in this environment.

## Install

1. Back up the existing project.
2. Extract this archive.
3. Open the extracted project using Unity 6.
4. Allow Unity to import scripts, then run the EditMode test suite.
