# VS89 — Engine / Reuse Research

No new third-party runtime dependency was added. The implementation reuses the project's campaign-backed `TowerStructure`, `TowerStructuralSegment`, `BridgeSpanController`, and `TowerSiegeAttacker` systems.

Unity AI Navigation remains the supported navigation layer for Unity 6. Unity documents AI Navigation as providing NavMesh surfaces, dynamic obstacles and links; NavMesh obstacles can carve holes into the navigation mesh so agents plan around blocked paths. The existing bridge collapse/navigation obstacle system remains the correct mechanism for making a collapsed span unavailable to pathfinding. The new siege marker deliberately does not attempt to rebuild or mutate NavMesh itself.

References:
- Unity 6 AI Navigation package overview: https://docs.unity.com/en-us/engine/6000.0/manual/packages-list/packages-all/pack-safe/com-unity.ai.navigation
- Unity 6 NavMeshObstacle API and carving behaviour: https://docs.unity.com/en-us/engine/6000.5/script-reference/unityengine/ai/navmeshobstacle
- Unity Technologies AI Navigation authoring guidance: https://github.com/Unity-Technologies/skills/blob/main/skills/initialize-ai-navigation/references/navigation-system.md
