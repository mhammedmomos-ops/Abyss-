# VS51 — Integration and Regression Audit

## Baseline
Built cumulatively from the user-provided VS50 archive. No gameplay source files were removed. The existing runtime assembly definition was relocated from `Scripts/Core/` to `Scripts/` because its previous folder scope split the runtime assembly incorrectly.

## Critical fixes
- Relocated `GorgeHollow.Runtime.asmdef` from `Scripts/Core` to the `Scripts` root. Unity assembly definitions apply to their containing folder and descendants, so the old location isolated only Core scripts while the rest of the runtime scripts compiled into the predefined assembly; Core and tests referenced those sibling types. The root placement puts all runtime scripts in one assembly and keeps the separate EditMode test assembly referencing it.
- Added `CampaignStateFactory` as the single canonical new-campaign initializer.
- Added testable `CampaignAnimalRecordRules` for safe animal-record upsert by stable identity.
- Added `GameBootstrap.TryStartNewCampaign`: save must succeed before the live campaign/clock are replaced.
- Fixed `NewGameResetService` so a failed save does not proceed into gameplay or falsely report a new campaign.
- Added an explicit early execution order to `GameBootstrap`, reducing scene `Awake` dependency races for services/UI that resolve it during initialization.
- Added `CampaignSaveService.HasValidSave` to probe primary/backup recoverability without changing save files.
- Persisted player and animal bridge-fall consequences through the existing campaign save service. Animal fall records are upserted by stable identity and duplicate IDs fail safely.
- Added save-availability and backup-recovery regression tests.
- Added explicit Unity UI and Unity Test Framework package dependencies for the source/test assemblies.
- Fixed the main-menu New Campaign placeholder: it now commits a fresh campaign before loading gameplay.
- Unified first-launch and explicit New Campaign initialization so both start at the same canonical 06:00 recovery-preparation state.
- Hardened save promotion: a corrupt primary can no longer overwrite a verified backup; a new save can still commit when the backup is independently valid.
- Added a downgrade guard that refuses to overwrite either primary or backup saves created with a newer save schema.
- Continue visibility now checks for a valid primary or backup save instead of treating a newly-created in-memory campaign ID as proof of a save.
- Continue requests are rejected cleanly when neither save file is valid.
- Corrected README import guidance to merge dependencies instead of copying only Assets and silently omitting required packages.

## Preserved architecture
- Campaign save schema remains version 4; no new serialized campaign fields were introduced.
- Existing tower, monster, animal, bridge, inventory and event systems remain in place.
- Splatter.AI and Unity AI Navigation remain the chosen AI/navigation dependencies.

## Known gaps retained
- VS50 stubs/placeholders remain explicitly identified; color-blind mode is still a preference flag and does not recolour all HUD elements.
- No Unity scenes, prefabs, art, audio, animation, NavMesh data or project settings are included.
- Git dependency remains branch-based rather than commit-pinned; see research notes.
