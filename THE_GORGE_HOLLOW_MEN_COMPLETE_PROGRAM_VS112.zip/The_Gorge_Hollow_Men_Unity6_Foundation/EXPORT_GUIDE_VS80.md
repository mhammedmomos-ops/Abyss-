# VS80 export and setup

1. Extract and open in Unity 6.
2. Run `VS80BondGrowthTests`, `VS73BondResonanceTests` and `VS75CompanionExperienceTests`.
3. Play check: use abilities repeatedly and confirm bond rises at most once per 45 seconds and the Resonance-ready toast appears once.

Unity compilation and device testing were not performed in this environment.
