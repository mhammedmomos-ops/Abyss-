# VS57 export and setup

1. Extract the complete VS57 archive into a Unity 6 project using the project's existing package manifest.
2. Open the project and allow Unity to import scripts and assets.
3. Ensure the active companion actor has `AnimalCompanionController`, `NavMeshAgent`, and its configured `GameBootstrap` reference (or a discoverable bootstrap in the scene).
4. Ensure the monster prefab retains `MonsterAIController`, `MonsterPerception`, and the existing attack telegraph/animation listeners.
5. Bake the scene NavMesh for the companion's ground-navigation actor and monster agents.
6. Select any approved companion and assign a custom name. Issue Follow/Protect/Alert; allow the companion to locally detect a monster and enter support range. A monster that still directly sees the owner can then telegraph a retaliatory strike against the companion.
7. Run the EditMode suite, then test the combat loop in PlayMode with each approved pet species. Verify wind-up cancellation, damage mitigation, save persistence and permanent death.

The code archive is source-complete for the VS57 changes, but this export has not been opened or compiled in Unity in this environment. Do not treat static checks as a substitute for the Unity validation steps above.
