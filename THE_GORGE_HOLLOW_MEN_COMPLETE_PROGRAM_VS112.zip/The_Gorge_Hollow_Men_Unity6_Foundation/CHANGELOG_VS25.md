# VS25 — Objectives, Scavenging, Pause & Bridge Nav Safety

## Scope
VS25 adds a lightweight objective tracker (persisted via existing campaign flags), world scavenging for resources, a mobile pause controller, an objective HUD, and a bridge-collapse NavMesh path invalidation listener for nearby agents. Builds on VS24 mobile HUD/prompt systems.

## Added runtime files
- `ObjectiveRules.cs` — pure completion-flag helpers (no schema migration).
- `CampaignObjectiveDefinition.cs` — authorable scene objective.
- `ObjectiveTracker.cs` — activates objectives, completes repair-bridge and scavenge goals, raises events.
- `ObjectiveCampaignEvents.cs` — `ObjectiveCompleted` / `ScavengeCompleted` events.
- `ScavengeInteraction.cs` — one-shot resource grant via `ResourceTransactionService`.
- `ObjectiveHUD.cs` — shows primary active objective text.
- `MobilePauseController.cs` — time-scale pause/resume with optional panel.
- `BridgeNavInvalidationListener.cs` — resets nearby NavMeshAgent paths when a span collapses.
- `VS25ObjectiveRulesTests.cs` — EditMode tests.

## Scene setup
1. Add `ObjectiveTracker` to a persistent object; assign `GameBootstrap`. Place `CampaignObjectiveDefinition` components (or enable auto-find).
2. For a repair objective: set kind to RepairBridge and assign the bridge `BridgeSpanController`. Completes when the span returns to Stable.
3. For scavenges: place `ScavengeInteraction` props; set resource grants. Scavenge objectives count `ScavengeCompleted` events.
4. Wire `ObjectiveHUD` Text on the mobile Canvas.
5. Add `MobilePauseController` and a pause panel; bind a UI button to `TogglePause` / `SaveAndResume`.
6. On each critical bridge, add `BridgeNavInvalidationListener` so companions stop walking onto a collapsed span.

## Behaviour and safety
- Objective completion uses `campaignFlags` entries prefixed with `objective_complete:` — no new save fields.
- Scavenge transactions are idempotent by unique transaction ID; root is disabled after success.
- Pause restores the previous non-zero time scale and unpauses the audio listener.
- Nav invalidation only runs on transition into Collapsed; optional player-agent skip.

## Explicit limitations
- No full quest graph, branching dialogue, or map markers.
- Companion long-term repathing / alternate gorge crossings still require authored NavMesh links.
- Pause menu is a shell (no settings, graphics, or quit-to-title flow beyond what you wire).
- Unity 6 compilation, tests, builds and device playtesting not performed here.

## Verification boundary
Static source and archive checks only.
