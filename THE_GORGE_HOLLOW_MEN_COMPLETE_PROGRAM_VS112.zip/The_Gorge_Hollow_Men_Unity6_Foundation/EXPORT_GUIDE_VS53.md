# VS53 Export and Unity Setup Guide

## What this archive contains
A cumulative VS1–VS53 Unity 6 source foundation. It includes scripts, tests, Editor tooling, package manifest and milestone documentation. It is not a precompiled Android/iOS app or a fully authored production Unity project.

## Import
1. Create/open a Unity 6 URP project.
2. Back up the target project.
3. Merge the `Assets/_Project` contents into the target project's `Assets/_Project` folder.
4. Merge dependencies from this archive's `Packages/manifest.json` into the target manifest. Preserve existing URP/template dependencies and resolve package versions in Package Manager.
5. Allow Unity to compile and resolve assemblies. Address any target-project-specific package or API differences before proceeding.

## Generate and configure the first encounter
1. In Unity, run `THE GORGE > Vertical Slice > Generate Greybox Scene`.
2. Open `Assets/_Project/Scenes/GorgeVerticalSlice.unity`.
3. Select `NAVIGATION — BAKE SURFACE IN INSPECTOR`. Configure the AI Navigation `NavMeshSurface` to collect the generated tower/bridge geometry and bake.
4. Confirm the two `STALKER SPAWN` sockets are on the baked NavMesh and the bridge provides a continuous path to the west tower.
5. Enter Play mode and walk towards the bridge approach trigger. The existing `MonsterRaidDirector` should spawn up to two prototype Stalkers from the east tower.
6. Test the encounter end-to-end: detection, pursuit, weapon damage, player damage, monster death, and raid resolution.

## Before building mobile
- Resolve all Unity compiler errors and warnings.
- Run the complete EditMode suite and add PlayMode tests for trigger entry, spawn failure/retry, NavMesh spawn, pursuit, player damage, monster death and raid resolution.
- Test both landscape orientation and safe areas on actual Android and iOS devices.
- Replace the capsule Stalker with an authored rigged monster prefab, Animator Controller, animations, audio, VFX and proper hit colliders.
- Profile NavMesh, perception raycasts, physics and UI on low/mid-tier mobile hardware.

## Verification boundary
VS53 source and archive static checks are recorded in `Assets/_Project/BUILD_VERIFICATION.txt`. Unity Editor compilation, scene generation, NavMesh baking, tests and device builds must be performed in Unity; they have not been claimed as completed here.
