# VS107 Integration Audit

## Source integration
- `CampaignStateFactory` is the single source of the opening roster; no save-version bump or migration was introduced.
- Starting workers satisfy current worker validation: unique IDs, valid tower IDs/roles/assignments, bounded stats, and valid health/status combinations.
- Each tower starts with one Production Mechanic and one Guard. The existing production, fatigue, guard-protection, and assignment systems therefore have workforce inputs from campaign start.
- Starting roster does not consume recruitment events and does not create automatic relationship records.
- `TowerWorkerSpawnDirector` uses stable identity keys and per-tower roots. It does not infer world positions from names or create cross-tower routes.
- Existing actor tactical destinations are not reset on every campaign replacement.
- Captured/dead actor presentation is hidden while the actor remains enabled, so release/recovery can be reflected by the actor's periodic campaign refresh.
- Successful survivor recruitment, capture, and captive release publish `CampaignReplaced`, allowing the spawner to reconcile visible actors without losing stable identities.

## Bridge invariants
- No bridge spawn point or bridge route is created.
- The worker spawner requires one root per tower and only resolves `tower_a` or `tower_b`.
- Worker movement depends on author-authored local assignment targets; no automatic cross-gorge NavMesh path is generated.
- Existing enemy bridge entry/collapse/fatal-fall logic was not modified.

## Known integration requirements
- The scene must include `TowerWorkerSpawnDirector` and both tower roots for automatic visible worker spawning.
- Prefab movement requires NavMeshAgent, baked tower NavMesh, and assigned destinations.
- The capsule fallback is visible but stationary; it is not a substitute for a finished worker prefab.

## Verification performed
- Archive integrity checked.
- C# lexical delimiter scan performed.
- JSON/asmdef/asmref parsing performed.
- Static source assertions performed for roster shape, worker spawn identity handling, and bridge-boundary constraints.
- Unity compilation and all Unity tests remain unperformed.
