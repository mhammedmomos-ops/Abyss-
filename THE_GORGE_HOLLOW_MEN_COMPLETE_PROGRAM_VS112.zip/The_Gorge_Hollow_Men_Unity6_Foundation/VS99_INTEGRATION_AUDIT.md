# VS99 Integration Audit

## Source integration
- Added a serialized tactical order to `SupplyConvoyRecord`; enum value `Advance = 0` preserves old serialized records that omit the new field.
- Added a transactional command setter to `GameBootstrap`. It clones the campaign, checks travelling state and enum validity, persists the candidate before publishing it, then raises campaign replacement and transaction notifications.
- Carrier movement reads the saved order every frame. Hold returns before route advancement; it does not change convoy status or health.
- Escort controller remains operational during Hold. Focus Fire modifies the existing damage application through a pure rules function.
- UI sends commands through the controller to the bootstrap transaction; it does not mutate campaign records directly.

## Safety and regression review
- No command can change `SupplyConvoyStatus`, cargo, source debit or destination credit.
- No command changes bridge traversability or enemy bridge authorization.
- Bridge-collapse event subscription remains independent of movement command, so Hold does not protect a carrier on the bridge from collapse.
- Save failure returns an error and does not publish the cloned candidate campaign.
- Invalid enum values are rejected by the bootstrap and fail closed in movement rules.
- UI listeners are removed using the same delegate instances created during Awake.

## Scene wiring
1. Add `SupplyConvoyCommandPanel` to a Canvas child in the active gameplay scene.
2. Assign the active inter-tower `SupplyConvoyController` and its `SupplyTransferEscortController`.
3. Create three large uGUI Buttons with readable labels: ADVANCE, HOLD, FOCUS FIRE. Assign each Button field.
4. Optionally assign three uGUI Text labels for carrier status, threat status and current order.
5. Use a Canvas Scaler set to Scale With Screen Size and keep the command group inside safe-area margins. Use at least 64–72 reference pixels of button height for touch targets, adjusted after device testing.
6. Ensure an EventSystem is present. If the project uses the Input System package with uGUI, configure `InputSystemUIInputModule`; if it uses the legacy backend, configure the matching Standalone Input Module. Do not add both modules to the same EventSystem.
7. Keep the panel hidden or disabled when no inter-tower transfer is active; the script disables its buttons when the carrier is not travelling.

## Verification boundary
- Source/archive checks are reported separately from Unity compilation and runtime tests.
- No Unity Editor, C# compiler, NUnit runner, PlayMode runtime, physics simulation or mobile build was executed for this phase.
