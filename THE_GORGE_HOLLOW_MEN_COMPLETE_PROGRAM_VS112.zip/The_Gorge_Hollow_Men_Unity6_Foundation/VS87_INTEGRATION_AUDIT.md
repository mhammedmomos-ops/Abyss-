# VS87 Integration Audit

## Input inspected
- User-provided VS86 cumulative archive; ZIP CRC/integrity passed before extraction.
- Reviewed `MonsterAIController`, `MonsterLearningMemory`, `MonsterStimulus`, `AnimalDistractionRules`, runtime/test assembly definitions, VS86 teamwork integration, and existing monster perception/distraction call sites.

## Integration decisions
- Adaptive response is applied only in `OnHeardStimulus` after the existing source-null and `nextDistractionAcceptedAt` checks. This preserves the established perception range/occlusion gate and cooldown.
- `MonsterLearningMemory.RecordAnimalDistraction` tracks accepted decoys by source instance ID. A source change, time reversal, or more than 60 seconds since the previous accepted decoy resets the sequence.
- The first two accepted decoys retain the old response. The third and fourth shorten the investigation to 2.25 seconds and remove the decoy movement-speed penalty. The fifth and later are ignored.
- Ignored decoys do not cancel pending player/companion attacks, change siege targets, or overwrite an already active investigation.
- The memory is runtime-only; no campaign serialization changes.

## Tests added
- First/second decoy response remains unchanged.
- Third/fourth decoy response is shortened.
- Fifth/later decoys are ignored.
- A different source resets the source-specific learning count.
- A gap exceeding 60 seconds resets learning.
- Null source/non-finite time cannot advance learning.
- `Clear()` resets the new learning fields.

## Risks / authoring notes
- The design keys source identity using Unity `GameObject.GetInstanceID()`; the sequence is short-lived and per monster. The source reference is not persisted.
- Decoy source changes reset learning, allowing deliberate tactical variation rather than punishing all companion species globally.
- Tuning constants live in `AnimalDistractionRules` and should be playtested against common encounter durations.

## Validation performed
- Source-level call-site and behavior review.
- C# lexical delimiter scan across the cumulative source tree.
- JSON/asmdef parsing.
- Version metadata and manifest checks.
- ZIP integrity verification.

## Not performed
- Unity 6 compilation.
- NUnit/EditMode execution.
- PlayMode encounter balancing, scene/prefab validation, NavMesh baking, Android/iOS builds, or physical-device testing.
