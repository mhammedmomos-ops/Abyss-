# Third-party research — VS15

Research date: 2026-11-03

## Existing behaviour-tree dependency: Splatter.AI
- Upstream: https://github.com/ormesam/splatter.ai
- Licence: MIT (upstream repository licence file).
- Upstream README states Unity 6 (6000.0+) support, installation through Git URL, and no package dependencies.
- Upstream reference documents `BehaviourTreeManager` central ticking, per-runner Tick Interval, and automatic staggering of agents sharing an interval. It also explicitly says disabling a runner pauses its tree and re-enabling resumes it.
- Repository page showed 106 commits and no GitHub releases/tags surfaced in the Releases section, with a small visible star count. This is a dependency-maintenance/adoption risk, not proof of code defects.
- Source URL currently tracks `main`; production release should pin an audited commit. The build environment could not resolve github.com, so the exact current SHA was not obtained and is intentionally not fabricated.

## Official alternative assessed: Unity Behavior
- Official package: `com.unity.behavior`.
- Unity's 6000.0 released-package documentation lists version 1.0.16 as released for Unity Editor 6000.0.
- Features include graph-authored behaviour trees, reusable subgraphs, C# integration, event-driven observer aborts and real-time debugging.
- It is a stronger first-party long-term candidate, but the current project already has a code-authored Splatter tree. Migrating requires authored graph assets/custom nodes and player-build validation. Introducing it alongside Splatter would duplicate runtime frameworks and increase integration risk, so VS15 does not add it.
- Unity's May 2026 1.0.16 release discussion documents runtime lifecycle updates and fixes; it also notes a known issue involving prefab Apply Component workflows and SerializeReference. This reinforces the need for an editor/player build test before migration.

## Unity systems reused in VS15
- `NavMeshAgent` remains the existing movement system; no custom pathfinder was written.
- Splatter.AI's existing runner enable/disable lifecycle is used for distant decision-tree suspension.
- Existing `MonsterPerception` scan loop is reconfigured by tier rather than introducing a new sensor framework.
- Existing campaign save service remains the serializer/backup mechanism; VS15 only coalesces repeated nest mutations before invoking it.

## Sources
- Splatter.AI README and installation/API overview: https://github.com/ormesam/splatter.ai
- Splatter.AI reference (central ticking, tick interval, disable/resume): https://github.com/ormesam/splatter.ai/blob/main/REFERENCE.md
- Unity Behavior 6000.0 released package listing: https://docs.unity.com/en-us/engine/6000.0/manual/packages-list/packages-all/pack-safe/com-unity-behavior
- Unity Behavior 1.0.16 release discussion: https://discussions.unity.com/t/behavior-package-1-0-16-released/1721488
- Unity NavMeshAgent scripting reference: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/ai/navmeshagent
