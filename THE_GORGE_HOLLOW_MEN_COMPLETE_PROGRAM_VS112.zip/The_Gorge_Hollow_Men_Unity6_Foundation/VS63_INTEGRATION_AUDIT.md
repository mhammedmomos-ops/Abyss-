# VS63 Integration Audit

## Source reviewed
- VS62 cumulative archive integrity and all 547 entries.
- `AnimalCompanionController`, `AnimalCompanionProfile`, `AnimalContracts`, `AnimalForageFoodSource`, `AnimalForageRules`, `CompanionCommandRelay`, `CompanionCommandUI` and the greybox companion actor generator.
- Monster companion retaliation path in `MonsterAIController` and existing `CompanionThreatRules`.
- Existing VS56–VS62 companion regression tests and save compatibility notes.

## Runtime integration
- `AnimalSpeciesTactics` is a pure rules layer and introduces no Unity package dependency.
- The controller dispatches confirmed nearby threats through the selected species' response: engage, observe, hold defence or evade.
- Existing local overlap/line-of-sight threat perception remains the evidence source. The companion does not receive global monster positions.
- Only the German Shepherd engages in direct melee support. Falcon observes at a NavMesh standoff point; Pangolin holds defensive position and gains a temporary brace after a strike; Cat moves to a sampled NavMesh point offset away from a confirmed threat.
- Foraging action time and search radius are selected by species. Campaign-day source depletion, food transaction and save semantics are unchanged.
- A forage run interrupted by a confirmed threat now remains in retreat mode until the threat is no longer confirmed; it cannot immediately re-enter the dog's engage response on the following frame.

## Save and compatibility
- No new campaign fields or save schema changes.
- Existing animal identity, display name, species, life stage, health, hunger, stamina, bond and experience are unchanged.
- Starvation at zero still blocks all companion commands, including foraging. Feeding remains the recovery path.
- Missing/recovered and permanent-death rules are untouched.

## Known limits
- The current actor remains a capsule placeholder and a ground NavMeshAgent. Falcon observation is a ground-based prototype, not flight.
- Pangolin bracing has gameplay mitigation and a temporary movement stop, but no curl animation until a compatible model/Animator Controller is supplied.
- Cat evasion is a tactical destination choice, not stealth invisibility.
- Species-specific forage timings/radii are tuning values, not separate prey ecology or food types.

## Validation boundary
- Static source checks and ZIP checks are run for the export.
- Unity compiler and Test Runner are unavailable here. New tests are included but unexecuted; no runtime, physics, NavMesh, animation or device results are claimed.
