# VS73 — Bond Resonance

## Added
- Added a cross-species **Bond Resonance** pulse that any operational companion can issue when bond is high enough and a threat is confirmed with sufficient confidence.
- New `AnimalCommand.Resonate` and pure static rules in `AnimalBondResonanceRules` covering eligibility, bond cost, detection boost, duration, cooldown and species-flavored toast text.
- Resonance costs 4 bond, lasts 7 seconds, multiplies current detection radius by 1.4×, and starts an 18-second cooldown when it ends.
- Requires bond ≥ 35, a confirmed threat, and threat confidence ≥ 0.55.
- Species-flavored toasts (Shepherd warning, Falcon cry, Pangolin rattle, Cat hiss).
- Species-agnostic **RESONATE** button in the vertical-slice HUD; interactable when bond threshold is met and the companion is not already resonating.
- Six EditMode test methods cover eligibility gates, bond cost clamping, detection boost, timing, toast flavour and constant reasonableness.

## Design boundaries
- Available to all four approved species; species only flavour the toast.
- Resonance is a transient runtime pulse. Bond is campaign data and is reduced by the cost; the detection boost itself is not saved.
- Requires a living, operational companion with a real confirmed threat — it cannot be used as a free scout.
- No third-party packages or external source code were added.

## Validation
- Static source checks and archive integrity are performed for this export.
- Unity compilation and test execution are not claimed; run the included VS73 EditMode tests in Unity 6.
