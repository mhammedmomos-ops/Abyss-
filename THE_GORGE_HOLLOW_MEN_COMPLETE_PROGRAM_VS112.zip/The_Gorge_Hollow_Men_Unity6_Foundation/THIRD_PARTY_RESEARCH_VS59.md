# VS59 third-party research and reuse review

Research reviewed before implementation:

- Unity 6 AI Navigation package documentation: https://docs.unity.com/en-us/engine/6000.0/manual/packages-list/packages-all/pack-safe/com-unity-ai-navigation
- Unity 6 `NavMeshAgent` scripting reference: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/ai/navmeshagent
- Unity Technologies navigation system implementation notes: https://github.com/Unity-Technologies/skills/blob/main/skills/initialize-ai-navigation/references/navigation-system.md
- Unity C# reference for NavMeshAgent API surface: https://github.com/Unity-Technologies/UnityCsReference/blob/master/Modules/AI/Components/NavMeshAgent.bindings.cs

Decision:
- Retain the existing `com.unity.ai.navigation` 2.0.16 dependency and NavMeshAgent companion architecture.
- This phase concerns campaign persistence and life-stage tuning, so importing another companion controller or third-party package would add risk without solving a missing capability.
- No third-party source code was copied. Existing Unity APIs and project-owned architecture were reused.
