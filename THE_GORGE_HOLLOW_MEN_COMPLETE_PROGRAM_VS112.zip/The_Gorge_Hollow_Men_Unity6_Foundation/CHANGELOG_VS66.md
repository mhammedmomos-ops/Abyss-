# VS66 — Species visual binding and animation integration foundation

## Added
- `AnimalSpeciesVisualBinder` provides four independent prefab slots keyed by the saved `AnimalSpecies`: German Shepherd, Falcon, Pangolin and Cat. The player's custom pet name is applied to the spawned visual instance name; campaign identity and progression remain on the `AnimalRecord`.
- The binder retains the explicit greybox placeholder when a species prefab has not yet been assigned. It does not silently substitute one animal model for another.
- `AnimalCompanionAnimationDriver` maps NavMeshAgent velocity and companion action state to optional Animator parameters. NavMeshAgent remains the movement authority; root motion is not enabled by this driver.
- Shared `AnimalAnimationContract` defines normalized `Speed`, movement/run booleans, brace/forage/lure/observe/incapacitated/dead states, a species integer and an attack trigger.
- Attack animation is triggered from a successful German Shepherd support strike; Pangolin brace, foraging, Cat lure, Falcon observation, starvation incapacitation and death are exposed as animation states.
- Added Editor menu `THE GORGE > Companions > Validate Selected Animal Model` to check an imported prefab's Animator, Generic Avatar validity, controller clips, skinned meshes, bone references and recommended parameter names.
- Greybox scene generator now creates a dedicated visual-root container, adds the species binder and animation driver, and keeps the capsule clearly labelled as a fallback.

## Integration and compatibility
- The selected campaign record remains the source of truth. No hard-coded default species and no pet-name restrictions were added.
- Existing save schema remains v6; no migration required.
- No third-party source code copied and no package dependency added.
- No actual animal model, rig, animation clip or sound asset is included in this phase. The new slots and validation workflow prepare the project to accept properly licensed authored assets.
