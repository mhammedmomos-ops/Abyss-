# VS14 — Adaptive Siege Intelligence

## Added
- Authored tower-structure kinds (core, gate, barricade, reinforced barricade, generator, signal, bridge, utility) and configurable siege damage resistance.
- Tower siege damage now applies the structure's authored resistance and reports actual damage efficiency to the attacking monster.
- Monster target scoring now considers distance, health, designer priority, structure role bias, authored resistance and observed attack efficiency.
- Nest-scoped bounded siege observations persist across encounters; monsters only use observations stored by their assigned nest.
- Campaign save schema advances from v3 to v4. v1, v2 and v3 saves migrate without discarding existing nest health, alarms or learned trap records.
- Six new EditMode regression tests cover scoring, bounded memory, restore, validation, migration and role bias.

## Scene setup
1. On each `TowerStructure`, choose its `Structure Kind`, `Siege Damage Resistance` (0–0.9) and `Siege Priority`. Reinforced barricades should have higher resistance than ordinary barricades.
2. Ensure monster prefabs that siege structures have `TowerSiegeAttacker` and `MonsterAIController`.
3. Assign the correct `MonsterNest` through the raid spawn-point configuration for persistent nest-scoped learning. Monsters without an assigned nest still use authored resistance and role preferences, but do not retain observations between encounters.
4. For stationary player-built barricades that should block monster path planning, use Unity AI Navigation's `NavMeshObstacle` with Carve enabled and Carve Only Stationary enabled. Do not carve continuously moving objects; use local avoidance for those. Bake and validate the NavMesh after placing authored obstacles.
5. Keep the `MonsterNestPersistenceService` in the scene and ensure all relevant nests are assigned or auto-discovered.

## Behaviour boundaries
- Learning is evidence-based: monsters record the damage efficiency of attacks they personally execute; the result is stored only on their assigned nest. It is not a global enemy hive mind.
- A target with low observed efficiency is deprioritised, not made impossible to attack.
- Structure kind biases are authored role preferences, not separate pathfinding systems.
- No new external AI framework was added. Existing Splatter.AI, Unity AI Navigation, Unity physics and campaign save systems are reused.
