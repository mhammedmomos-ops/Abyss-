# VS91 — Coordinated Enemy Bridge Siege

## Objective
Make bridge-support assaults more tactical without weakening the strict bridge access and collapse rules established in VS88–VS90.

## Changes
- Added role-aware bridge siege target scoring in `MonsterBridgeSiegeRules`.
- Integrated bridge-support scoring into `MonsterAIController.SelectSiegeTarget`.
- Brutes prioritise weakened bridge supports and are more willing to concentrate force on a critical support.
- Skirmishers are more likely to spread pressure across different supports when nearby squadmates have already committed.
- Lurkers receive a modest bridge-anchor preference; Stalkers retain balanced behaviour.
- Nearby squad pressure is considered only for bridge-support targets through the new role-aware scoring path; non-bridge siege target scoring is unchanged.
- Invalid, missing, destroyed, collapsed, non-required, or non-traversable bridge supports are rejected before scoring.
- Added ten EditMode tests for role priorities, weakened-support focus, squad pressure, invalid scores, and retained bridge validity constraints.

## Preserved invariants
- Enemies never spawn on the bridge.
- Enemies may enter only after physically passing through Tower A or Tower B gateway while the bridge exists and is traversable.
- Bridge support attacks cannot occur against a collapsed/non-traversable span.
- Enemies caught on the bridge when it collapses fall into the gorge and die; they are never returned to a tower.
- Existing campaign-backed structure health remains authoritative; no duplicate bridge health/save record was introduced.

## Verification status
- Source-level integration review completed.
- C# structural checks completed for changed and added files.
- JSON/assembly definition validation completed.
- ZIP integrity check completed.
- Unity Editor compilation and NUnit execution have NOT been performed in this environment.
- PlayMode, NavMesh baking, animation, Android, and iOS tests remain outstanding.

## Scene/prefab requirements
No new scene component is required for the scoring change. Existing bridge support GameObjects must retain `TowerStructure`, `TowerStructuralSegment`, and `MonsterBridgeSiegeTarget` references; the bridge controller must list the same support segments in `requiredSupports`. Monster squad members must continue reporting their current siege target through `MonsterSquadCoordinator` for pressure-aware coordination to work.
