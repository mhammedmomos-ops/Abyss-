# VS80 — Bond Growth From Teamwork

## Added / changed
- `AnimalBondGrowthRules`: each successful ability use (Curl, Stalk mark, Resonate, Callout, Scent track, Guard report) grants +1 bond, limited to one gain per 45 seconds and capped at 100.
- Plain attacks and routine XP do not grant bond; only ability-use XP awards do.
- A one-time toast tells the player when bond first reaches the 35 needed for Bond Resonance.
- Controller: `TryGrowBond` runs inside `AwardExperience` before the XP early-return, so bond still grows for a max-XP companion.
- Seven EditMode tests in `VS80BondGrowthTests`.

## Design boundaries
- Before this, bond rose only by feeding or resting (+1 each) while Resonance costs 4 and needs 35, so Resonance was very hard to reach. The gain per use stays below the Resonance cost so Resonance remains a real spend.
- The 45-second limit is runtime-only (not saved), so there is no save schema change.

## Validation
Static checks only. Run the related tests in Unity 6.
