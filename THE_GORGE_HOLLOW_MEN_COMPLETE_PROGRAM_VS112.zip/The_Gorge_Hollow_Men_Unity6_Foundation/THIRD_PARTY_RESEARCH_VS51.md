# VS51 third-party and integration research

## Unity Test Framework
Unity documents the Test Framework as the supported way to run EditMode/PlayMode tests and requires test assemblies with the TestAssemblies reference. The VS51 manifest explicitly includes `com.unity.test-framework` 1.4.5, which Unity lists as released for Editor 6000.0.

## Unity UI (uGUI)
The project has extensive `UnityEngine.UI` usage. Unity lists uGUI (`com.unity.ugui`) as a Unity 6 core package, version fixed to the Editor. The manifest records 2.0.0 to make the dependency explicit; Unity resolves the Editor-bundled core package.

## Splatter.AI
The upstream repository states that it requires Unity 6 (6000.0+) and documents the exact Git URL used by this project. It is MIT licensed and has no package dependencies; AI Navigation is required only for its sample content. It remains suitable for the project's behaviour-tree adapter, but the Git dependency is currently branch-based and should be pinned to a reviewed commit once the project build environment is available.

## Unity navigation and physics
Unity's documentation warns against simultaneously driving one character with an active NavMeshAgent and a non-kinematic Rigidbody. The bridge-fall component disables the agent before enabling dynamic Rigidbody simulation and attempts to re-warp it after landing. This still requires in-Editor physics/NavMesh validation.

## Reuse decision
No new third-party runtime library was copied into the project. VS51 uses Unity's own packages and the already adopted Splatter.AI integration.
