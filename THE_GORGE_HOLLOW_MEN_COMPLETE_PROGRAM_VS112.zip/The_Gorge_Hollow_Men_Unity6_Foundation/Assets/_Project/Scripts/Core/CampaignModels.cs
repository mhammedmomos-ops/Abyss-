using System;
using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    public enum CampaignPhase
    {
        Initializing, RecoveryPreparation, ThreatDevelopment, ActiveRaid,
        ThreatResolution, DawnReview, Completed, Failed
    }

    public enum AnimalSpecies { GermanShepherd, Falcon, Pangolin, Cat }
    public enum AnimalLifeStage { Young, Adolescent, Adult, Senior }
    public enum AnimalStatus { Alive, Missing, Dead }
    public enum SupplyConvoyStatus { Travelling, Delivered, Destroyed }
    public enum SupplyConvoyCommand { Advance = 0, Hold = 1, FocusFire = 2 }
    public enum TowerWorkerRole { Mechanic, Scavenger, Guard, Medic }
    public enum TowerWorkerStatus { Active, Injured, Dead, Captured}
    public enum TowerWorkerAssignment { Idle, Production, Salvage, Guard, Rest }
    public enum TowerWorkerTacticalState { Normal, Evacuating, Sheltered, Defending, AssistingInjured }
    public enum TowerWorkerPersonality { Balanced, Brave, Cautious, Empathetic, Driven }

    [Serializable]
    public sealed class CampaignState
    {
        public int saveVersion = CampaignSaveService.CurrentSaveVersion;
        public string campaignId = Guid.NewGuid().ToString("N");
        public int chapter = 1;
        public int night = 1;
        public int fictionalDay = 1;
        public int fictionalHour;
        public int fictionalMinute;
        public CampaignPhase phase = CampaignPhase.Initializing;
        public int scrap;
        public int mechanicalParts;
        public int electricalComponents;
        public int timber;
        public int ammunition;
        public int medicalSupplies;
        public int petFood;
        public int reagent;
        public PlayerVitalsData playerVitals = new PlayerVitalsData();
        public List<TowerStructureRecord> towerStructures = new List<TowerStructureRecord>();
        public List<SupplyConvoyRecord> supplyConvoys = new List<SupplyConvoyRecord>();
        public List<TowerDepotRecord> towerDepots = new List<TowerDepotRecord>();
        public List<TowerProductionJobRecord> towerProductionJobs = new List<TowerProductionJobRecord>();
        public List<TowerWorkerRecord> towerWorkers = new List<TowerWorkerRecord>();
        public List<TowerWorkerRelationshipRecord> workerRelationships = new List<TowerWorkerRelationshipRecord>();
        public List<MonsterNestRecord> monsterNests = new List<MonsterNestRecord>();
        public List<string> appliedTransactionIds = new List<string>();
        public List<AnimalRecord> animals = new List<AnimalRecord>();
        public List<string> campaignFlags = new List<string>();
        public List<string> eventHistory = new List<string>();

        public bool IsValid(out string reason)
        {
            if (string.IsNullOrWhiteSpace(campaignId))
            {
                reason = "Campaign ID is missing.";
                return false;
            }
            if (chapter < 1 || chapter > 5)
            {
                reason = "Chapter must be between 1 and 5.";
                return false;
            }
            if (night < 1 || night > 20)
            {
                reason = "Night must be between 1 and 20.";
                return false;
            }
            if (fictionalDay < 1 || fictionalHour < 0 || fictionalHour > 23 || fictionalMinute < 0 || fictionalMinute > 59)
            {
                reason = "Fictional calendar values are invalid.";
                return false;
            }
            if (scrap < 0 || mechanicalParts < 0 || electricalComponents < 0 ||
                timber < 0 || ammunition < 0 || medicalSupplies < 0 || petFood < 0 || reagent < 0)
            {
                reason = "Resource balances cannot be negative.";
                return false;
            }
            if (playerVitals == null) playerVitals = new PlayerVitalsData(); // VS1 save compatibility.
            if (towerStructures == null) towerStructures = new List<TowerStructureRecord>(); // VS1/VS2 save compatibility.
            if (supplyConvoys == null) supplyConvoys = new List<SupplyConvoyRecord>(); // VS7 introduces persistent supply convoys.
            if (towerDepots == null) towerDepots = new List<TowerDepotRecord>(); // VS8 introduces isolated tower stockpiles.
            if (towerProductionJobs == null) towerProductionJobs = new List<TowerProductionJobRecord>(); // VS101 persistent tower production.
            if (towerWorkers == null) towerWorkers = new List<TowerWorkerRecord>(); // VS102 persistent tower workforce.
            if (workerRelationships == null) workerRelationships = new List<TowerWorkerRelationshipRecord>(); // VS105 bounded social bonds.
            if (monsterNests == null) monsterNests = new List<MonsterNestRecord>(); // VS1 saves predate persistent monster nests.
            if (playerVitals.health < 0f || playerVitals.health > 100f ||
                playerVitals.stamina < 0f || playerVitals.stamina > 100f ||
                playerVitals.bloom < 0f || playerVitals.bloom > 100f ||
                playerVitals.nutrition < 0f || playerVitals.nutrition > 100f ||
                playerVitals.hydration < 0f || playerVitals.hydration > 100f ||
                playerVitals.injury < 0f || playerVitals.injury > 100f ||
                (playerVitals.isDead && playerVitals.health > 0f))
            {
                reason = "Player vitals are invalid.";
                return false;
            }
            if (animals == null || appliedTransactionIds == null ||
                campaignFlags == null || eventHistory == null)
            {
                reason = "A required campaign collection is missing.";
                return false;
            }

            var ids = new HashSet<string>();
            foreach (var animal in animals)
            {
                if (animal == null || string.IsNullOrWhiteSpace(animal.identity))
                {
                    reason = "An animal record or identity is missing.";
                    return false;
                }
                if (!ids.Add(animal.identity))
                {
                    reason = "Animal identities must be unique.";
                    return false;
                }
                if (!System.Enum.IsDefined(typeof(AnimalSpecies), animal.species) ||
                    !System.Enum.IsDefined(typeof(AnimalLifeStage), animal.lifeStage) ||
                    !System.Enum.IsDefined(typeof(AnimalStatus), animal.status) ||
                    animal.health < 0 || animal.health > 100 || animal.stamina < 0 || animal.stamina > 100 ||
                    animal.hunger < 0 || animal.hunger > 100 ||
                    animal.experience < 0 || animal.fictionalAgeDays < 0 || animal.starvationDaysAtZero < 0 || animal.starvationDaysAtZero > AnimalCareRules.StarvationDaysToDeath || animal.bond < 0 || animal.bond > 100)
                {
                    reason = "Animal species, lifecycle, or persisted statistics are invalid.";
                    return false;
                }
                if (animal.status == AnimalStatus.Dead && string.IsNullOrWhiteSpace(animal.deathEventId))
                {
                    reason = "A dead animal must have a permanent death event ID.";
                    return false;
                }
            }

            var nestIds = new HashSet<string>();
            foreach (var nest in monsterNests)
            {
                if (nest == null || string.IsNullOrWhiteSpace(nest.identity))
                {
                    reason = "A monster nest record or identity is missing.";
                    return false;
                }
                if (!nestIds.Add(nest.identity))
                {
                    reason = "Monster nest identities must be unique.";
                    return false;
                }
                if (nest.maxHealth < 1 || nest.currentHealth < 0 || nest.currentHealth > nest.maxHealth ||
                    nest.isDestroyed != (nest.currentHealth == 0))
                {
                    reason = "Monster nest health state is invalid.";
                    return false;
                }
                if (nest.alarmCount < 0)
                {
                    reason = "Monster nest alarm count cannot be negative.";
                    return false;
                }
                if (nest.learnedHazards == null) nest.learnedHazards = new List<MonsterHazardRecord>();
                if (nest.learnedHazards.Count > MonsterNest.MaximumPersistedHazards)
                {
                    reason = "Monster nest learned-hazard memory exceeds its bounded capacity.";
                    return false;
                }
                if (nest.learnedSiegeTargets == null) nest.learnedSiegeTargets = new List<MonsterSiegeObservationRecord>();
                if (nest.learnedSiegeTargets.Count > MonsterNest.MaximumPersistedSiegeTargets)
                {
                    reason = "Monster nest learned-siege memory exceeds its bounded capacity.";
                    return false;
                }
                var siegeIds = new HashSet<string>();
                foreach (MonsterSiegeObservationRecord observation in nest.learnedSiegeTargets)
                {
                    if (observation == null || string.IsNullOrWhiteSpace(observation.structureIdentity) ||
                        !siegeIds.Add(observation.structureIdentity) ||
                        float.IsNaN(observation.averageDamageEfficiency) || float.IsInfinity(observation.averageDamageEfficiency) ||
                        observation.averageDamageEfficiency < 0f || observation.averageDamageEfficiency > 1f ||
                        observation.observationCount < 1)
                    {
                        reason = "Monster nest learned-siege evidence is invalid or duplicated.";
                        return false;
                    }
                }
                var hazardIds = new HashSet<string>();
                foreach (MonsterHazardRecord hazard in nest.learnedHazards)
                {
                    if (hazard == null || string.IsNullOrWhiteSpace(hazard.identity) || !hazardIds.Add(hazard.identity) ||
                        float.IsNaN(hazard.position.x) || float.IsNaN(hazard.position.y) || float.IsNaN(hazard.position.z) ||
                        float.IsInfinity(hazard.position.x) || float.IsInfinity(hazard.position.y) || float.IsInfinity(hazard.position.z) ||
                        float.IsNaN(hazard.avoidanceRadius) || float.IsInfinity(hazard.avoidanceRadius) || hazard.avoidanceRadius <= 0f ||
                        float.IsNaN(hazard.severity) || float.IsInfinity(hazard.severity) || hazard.severity < 0f || hazard.observationCount < 1)
                    {
                        reason = "Monster nest learned-hazard evidence is invalid or duplicated.";
                        return false;
                    }
                }
            }

            var structureIds = new HashSet<string>();
            foreach (var structure in towerStructures)
            {
                if (structure == null || string.IsNullOrWhiteSpace(structure.identity) ||
                    string.IsNullOrWhiteSpace(structure.towerId))
                {
                    reason = "A tower structure record or identity is missing.";
                    return false;
                }
                if (!structureIds.Add(structure.identity))
                {
                    reason = "Tower structure identities must be unique.";
                    return false;
                }
                if (!structure.isBuilt || structure.upgradeLevel < 1 || structure.maxHealth < 1 || structure.currentHealth < 0 ||
                    structure.currentHealth > structure.maxHealth ||
                    structure.isDestroyed != (structure.currentHealth == 0))
                {
                    reason = "Tower structure health state is invalid.";
                    return false;
                }
            }

            var depotIds = new HashSet<string>();
            foreach (TowerDepotRecord depot in towerDepots)
            {
                if (depot == null || string.IsNullOrWhiteSpace(depot.towerId) || !depotIds.Add(depot.towerId) ||
                    depot.scrap < 0 || depot.timber < 0 || depot.mechanicalParts < 0 || depot.electricalComponents < 0 ||
                    depot.ammunition < 0 || depot.medicalSupplies < 0 || depot.petFood < 0 || depot.reagent < 0)
                { reason = "Tower depot identity or resource balances are invalid."; return false; }
            }

            var convoyIds = new HashSet<string>();
            foreach (SupplyConvoyRecord convoy in supplyConvoys)
            {
                if (convoy == null || string.IsNullOrWhiteSpace(convoy.identity) ||
                    string.IsNullOrWhiteSpace(convoy.destinationTowerId) || !convoyIds.Add(convoy.identity) ||
                    !System.Enum.IsDefined(typeof(SupplyConvoyStatus), convoy.status) ||
                    convoy.maximumHealth < 1 || convoy.currentHealth < 0 || convoy.currentHealth > convoy.maximumHealth ||
                    convoy.routeWaypointIndex < 0 || convoy.routeWaypointIndex > 256 ||
                    convoy.bridgeCrossingStartWaypointIndex < 0 || convoy.bridgeCrossingStartWaypointIndex > 256 ||
                    convoy.bridgeCrossingEndWaypointIndex < 0 || convoy.bridgeCrossingEndWaypointIndex > 256 ||
                    (convoy.isInterTowerTransfer && (string.IsNullOrWhiteSpace(convoy.originTowerId) || convoy.originTowerId == convoy.destinationTowerId || convoy.bridgeCrossingEndWaypointIndex <= convoy.bridgeCrossingStartWaypointIndex)) ||
                    !SupplyConvoyRules.IsFinite(convoy.worldPosition) ||
                    convoy.scrap < 0 || convoy.timber < 0 || convoy.mechanicalParts < 0 ||
                    convoy.electricalComponents < 0 || convoy.ammunition < 0 || convoy.medicalSupplies < 0 ||
                    convoy.petFood < 0 || convoy.reagent < 0)
                {
                    reason = "Supply convoy identity, route, health, status, or cargo is invalid.";
                    return false;
                }
                if (convoy.status == SupplyConvoyStatus.Destroyed &&
                    (convoy.currentHealth != 0 || !SupplyConvoyRules.HasNoCargo(convoy)))
                {
                    reason = "A destroyed supply convoy must have zero health and no recoverable cargo.";
                    return false;
                }
                if (convoy.status == SupplyConvoyStatus.Delivered && !SupplyConvoyRules.HasNoCargo(convoy))
                {
                    reason = "A delivered supply convoy cannot retain undelivered cargo.";
                    return false;
                }
                if (convoy.status == SupplyConvoyStatus.Travelling && convoy.currentHealth <= 0)
                {
                    reason = "A travelling supply convoy must have positive health.";
                    return false;
                }
            }

            var workerIds = new HashSet<string>();
            foreach (TowerWorkerRecord worker in towerWorkers)
            {
                if (worker == null || string.IsNullOrWhiteSpace(worker.identity) || string.IsNullOrWhiteSpace(worker.displayName) ||
                    (worker.towerId != "tower_a" && worker.towerId != "tower_b") ||
                    !Enum.IsDefined(typeof(TowerWorkerRole), worker.role) ||
                    !Enum.IsDefined(typeof(TowerWorkerStatus), worker.status) ||
                    !Enum.IsDefined(typeof(TowerWorkerAssignment), worker.assignment) ||
                    !Enum.IsDefined(typeof(TowerWorkerTacticalState), worker.tacticalState) ||
                    !Enum.IsDefined(typeof(TowerWorkerPersonality), worker.personality) ||
                    !Enum.IsDefined(typeof(TowerWorkerAssignment), worker.preRaidAssignment) ||
                    !workerIds.Add(worker.identity) || worker.skill < 0 || worker.skill > 100 ||
                    worker.health < 0 || worker.health > 100 || worker.fatigue < 0 || worker.fatigue > 100 ||
                    worker.fatigueProgressMinutes < 0 || worker.fatigueProgressMinutes >= 30 ||
                    worker.recoveryProgressMinutes < 0 || worker.recoveryProgressMinutes >= 120 || worker.recoveryMinutes < 0 || worker.recoveryMinutes >= 60 ||
                    worker.experienceProgressMinutes < 0 || worker.experienceProgressMinutes >= 240 || worker.experienceMinutes < 0 ||
                    worker.status == TowerWorkerStatus.Dead && (worker.health != 0 || worker.assignment != TowerWorkerAssignment.Idle || worker.tacticalState != TowerWorkerTacticalState.Normal) ||
                    worker.status == TowerWorkerStatus.Captured && (worker.health < 1 || worker.assignment != TowerWorkerAssignment.Idle || worker.tacticalState != TowerWorkerTacticalState.Normal || worker.playerOverrideDuringRaid) ||
                    worker.morale < 0 || worker.morale > 100 || worker.loyalty < 0 || worker.loyalty > 100 || worker.stress < 0 || worker.stress > 100 ||
                    worker.status == TowerWorkerStatus.Injured && (worker.health < 1 || worker.health >= TowerWorkerRules.InjuryThreshold || worker.assignment != TowerWorkerAssignment.Rest) ||
                    worker.status == TowerWorkerStatus.Active && worker.health < TowerWorkerRules.InjuryThreshold ||
                    worker.status != TowerWorkerStatus.Dead && worker.status != TowerWorkerStatus.Captured && worker.fatigue == 100 && worker.assignment != TowerWorkerAssignment.Rest)
                { reason = "Tower workforce record is invalid, duplicated, or has an inconsistent health/assignment state."; return false; }
            }
            if (towerWorkers.Count(x => x != null && x.towerId == "tower_a" && x.status != TowerWorkerStatus.Dead) > TowerWorkerRules.MaxWorkersPerTower ||
                towerWorkers.Count(x => x != null && x.towerId == "tower_b" && x.status != TowerWorkerStatus.Dead) > TowerWorkerRules.MaxWorkersPerTower)
            { reason = "A tower exceeds its workforce capacity."; return false; }
            if (workerRelationships.Count > TowerWorkerRelationshipRules.MaximumRelationships)
            { reason = "Worker relationship history exceeds its bounded capacity."; return false; }
            var relationshipIds = new HashSet<string>();
            foreach (TowerWorkerRelationshipRecord relationship in workerRelationships)
            {
                if (relationship == null || string.IsNullOrWhiteSpace(relationship.workerAId) ||
                    string.IsNullOrWhiteSpace(relationship.workerBId) || relationship.workerAId == relationship.workerBId ||
                    !workerIds.Contains(relationship.workerAId) || !workerIds.Contains(relationship.workerBId) ||
                    relationship.bond < 0 || relationship.bond > 100 || relationship.friction < 0 || relationship.friction > 100 ||
                    relationship.interactionCount < 0 ||
                    !relationshipIds.Add(TowerWorkerRelationshipRules.MakeKey(relationship.workerAId, relationship.workerBId)))
                { reason = "Worker relationship is invalid, duplicated, or references an unknown worker."; return false; }
                TowerWorkerRecord a = towerWorkers.Find(x => x.identity == relationship.workerAId);
                TowerWorkerRecord b = towerWorkers.Find(x => x.identity == relationship.workerBId);
                if (a == null || b == null || a.towerId != b.towerId)
                { reason = "Worker relationships must connect two workers assigned to the same tower."; return false; }
            }

            var productionIds = new HashSet<string>();
            foreach (var job in towerProductionJobs)
            {
                if (job == null || string.IsNullOrWhiteSpace(job.identity) ||
                    (job.towerId != "tower_a" && job.towerId != "tower_b") ||
                    !Enum.IsDefined(typeof(TowerProductionStatus), job.status) ||
                    job.durationMinutes < 1 || job.remainingMinutes < 0 || job.remainingMinutes > job.durationMinutes ||
                    float.IsNaN(job.workProgressMinutes) || float.IsInfinity(job.workProgressMinutes) || job.workProgressMinutes < 0f || job.workProgressMinutes >= 1f ||
                    (job.status == TowerProductionStatus.Queued && job.remainingMinutes == 0) ||
                    ((job.status == TowerProductionStatus.ReadyToCollect || job.status == TowerProductionStatus.Completed) && job.remainingMinutes != 0) ||
                    (job.yieldScrap == 0 && job.yieldTimber == 0 && job.yieldMechanicalParts == 0 && job.yieldElectricalComponents == 0 && job.yieldAmmunition == 0 && job.yieldMedicalSupplies == 0 && job.yieldPetFood == 0 && job.yieldReagent == 0) ||
                    job.costScrap < 0 || job.costTimber < 0 || job.costMechanicalParts < 0 || job.costElectricalComponents < 0 ||
                    job.costAmmunition < 0 || job.costMedicalSupplies < 0 || job.costPetFood < 0 || job.costReagent < 0 ||
                    (job.costScrap == 0 && job.costTimber == 0 && job.costMechanicalParts == 0 && job.costElectricalComponents == 0 && job.costAmmunition == 0 && job.costMedicalSupplies == 0 && job.costPetFood == 0 && job.costReagent == 0) ||
                    job.yieldScrap < 0 || job.yieldTimber < 0 || job.yieldMechanicalParts < 0 || job.yieldElectricalComponents < 0 ||
                    job.yieldAmmunition < 0 || job.yieldMedicalSupplies < 0 || job.yieldPetFood < 0 || job.yieldReagent < 0 ||
                    !productionIds.Add(job.identity))
                { reason = "Tower production job data is invalid or duplicated."; return false; }
            }

            reason = null;
            return true;
        }
    }

    [Serializable]
    public sealed class TowerProductionJobRecord
    {
        public string identity;
        public string towerId;
        public TowerProductionStatus status = TowerProductionStatus.Queued;
        public int durationMinutes = 1;
        public int remainingMinutes = 1;
        public float workProgressMinutes;
        public int costScrap, costTimber, costMechanicalParts, costElectricalComponents;
        public int costAmmunition, costMedicalSupplies, costPetFood, costReagent;
        public int yieldScrap, yieldTimber, yieldMechanicalParts, yieldElectricalComponents;
        public int yieldAmmunition, yieldMedicalSupplies, yieldPetFood, yieldReagent;
    }

    public enum TowerProductionStatus { Queued, ReadyToCollect, Completed, Cancelled }

    [Serializable]
    public sealed class TowerWorkerRecord
    {
        public string identity;
        public string displayName;
        public string towerId;
        public TowerWorkerRole role;
        public TowerWorkerStatus status = TowerWorkerStatus.Active;
        public TowerWorkerAssignment assignment = TowerWorkerAssignment.Idle;
        public int skill = 25;
        public int health = 100;
        public int fatigue;
        public int fatigueProgressMinutes;
        public int recoveryProgressMinutes;
        public int experienceProgressMinutes;
        public int experienceMinutes;
        public TowerWorkerTacticalState tacticalState = TowerWorkerTacticalState.Normal;
        public TowerWorkerAssignment preRaidAssignment = TowerWorkerAssignment.Idle;
        public bool playerOverrideDuringRaid;
        public int morale = 70;
        public int loyalty = 50;
        public int stress;
        public int recoveryMinutes;
        public TowerWorkerPersonality personality = TowerWorkerPersonality.Balanced;
    }

    [Serializable]
    public sealed class TowerWorkerRelationshipRecord
    {
        public string workerAId;
        public string workerBId;
        public int bond = 10;
        public int friction;
        public int interactionCount;
    }

    [Serializable]
    public sealed class TowerDepotRecord
    {
        public string towerId;
        public int scrap;
        public int timber;
        public int mechanicalParts;
        public int electricalComponents;
        public int ammunition;
        public int medicalSupplies;
        public int petFood;
        public int reagent;
    }

    [Serializable]
    public sealed class SupplyConvoyRecord
    {
        public string identity;
        public string destinationTowerId;
        public bool isInterTowerTransfer;
        public string originTowerId;
        public int bridgeCrossingStartWaypointIndex;
        public int bridgeCrossingEndWaypointIndex;
        public SupplyConvoyStatus status = SupplyConvoyStatus.Travelling;
        public Vector3 worldPosition;
        public int routeWaypointIndex;
        public SupplyConvoyCommand tacticalCommand = SupplyConvoyCommand.Advance;
        public int currentHealth = 100;
        public int maximumHealth = 100;
        public int scrap;
        public int timber;
        public int mechanicalParts;
        public int electricalComponents;
        public int ammunition;
        public int medicalSupplies;
        public int petFood;
        public int reagent;
    }

    [Serializable]
    public sealed class MonsterNestRecord
    {
        public string identity;
        public int maxHealth = 250;
        public int currentHealth = 250;
        public bool isDestroyed;
        public int alarmCount;
        public List<MonsterHazardRecord> learnedHazards = new List<MonsterHazardRecord>();
        public List<MonsterSiegeObservationRecord> learnedSiegeTargets = new List<MonsterSiegeObservationRecord>();
    }

    [Serializable]
    public sealed class MonsterSiegeObservationRecord
    {
        public string structureIdentity;
        public float averageDamageEfficiency = 1f;
        public int observationCount = 1;
    }

    [Serializable]
    public sealed class MonsterHazardRecord
    {
        public string identity;
        public Vector3 position;
        public float avoidanceRadius = 2f;
        public float severity = 1f;
        public int observationCount = 1;
    }

    [Serializable]
    public sealed class TowerStructureRecord
    {
        public string identity;
        public string towerId;
        public string displayName;
        public int maxHealth = 100;
        public int currentHealth = 100;
        public bool isDestroyed;
        public string lastDamageSource;
        public bool isBuilt = true;
        public int upgradeLevel = 1;
    }

    [Serializable]
    public sealed class AnimalRecord
    {
        public string identity;
        public string displayName;
        public AnimalSpecies species;
        public AnimalLifeStage lifeStage;
        public AnimalStatus status = AnimalStatus.Alive;
        public int fictionalAgeDays;
        public int experience;
        public int health = 100;
        public int stamina = 100;
        public int hunger = 100;
        public int starvationDaysAtZero;
        public int bond;
        public string deathEventId;
        public List<string> learnedAbilities = new List<string>();

        public bool MarkDead(string eventId)
        {
            if (status == AnimalStatus.Dead || string.IsNullOrWhiteSpace(eventId))
                return false;

            status = AnimalStatus.Dead;
            deathEventId = eventId;
            health = 0;
            return true;
        }
    }

    [Serializable]
    public sealed class ResourceDelta
    {
        public int scrap;
        public int mechanicalParts;
        public int electricalComponents;
        public int timber;
        public int ammunition;
        public int medicalSupplies;
        public int petFood;
        public int reagent;
    }
}
