namespace GorgeHollow
{
    /// <summary>
    /// Honest progress snapshot for the source foundation (not a finished game).
    /// </summary>
    public static class FoundationProgressReport
    {
        public const string PackageVersion = "VS103";

        /// <summary>
        /// Estimated completion of the *code systems foundation* only (0-100).
        /// Does not include art, levels, audio assets, builds, or polish.
        /// </summary>
        public const int SystemsFoundationPercent = 74;

        /// <summary>
        /// Estimated completion toward a *shippable mobile game* including content (0-100).
        /// </summary>
        public const int ShippableGamePercent = 19;

        public static string HumanSummary =>
            "Systems foundation ~" + SystemsFoundationPercent +
            "% · Shippable game ~" + ShippableGamePercent +
            "% · Package " + PackageVersion +
            " · Still needs Unity compile, scenes, art, audio, NavMesh, device builds.";
    }
}
