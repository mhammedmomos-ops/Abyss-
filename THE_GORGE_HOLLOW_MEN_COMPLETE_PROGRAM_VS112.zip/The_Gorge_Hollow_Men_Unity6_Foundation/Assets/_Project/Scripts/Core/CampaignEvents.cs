using System;

namespace GorgeHollow
{
    public static partial class CampaignEvents
    {
        public static event Action<int> NightChanged;
        public static event Action<CampaignPhase> PhaseChanged;
        public static event Action<string> CampaignSaved;
        public static event Action<CampaignState> CampaignReplaced;
        public static event Action<string> AnimalDied;
        public static event Action<string> AnimalMissing;
        public static event Action<string, int> AnimalRecovered;
        public static event Action<string> TransactionCommitted;
        public static event Action<string, int, int> TowerStructureChanged;
        public static event Action<string, string> TowerStructureBuilt;
        public static event Action<string, int> TowerStructureUpgraded;
        public static event Action<string> SupplyConvoyDestroyed;
        public static event Action<string, string> SupplyConvoyDelivered;

        public static void RaiseNightChanged(int night) => NightChanged?.Invoke(night);
        public static void RaisePhaseChanged(CampaignPhase phase) => PhaseChanged?.Invoke(phase);
        public static void RaiseCampaignSaved(string path) => CampaignSaved?.Invoke(path);
        public static void RaiseCampaignReplaced(CampaignState state) => CampaignReplaced?.Invoke(state);
        public static void RaiseAnimalDied(string identity) => AnimalDied?.Invoke(identity);
        public static void RaiseAnimalMissing(string identity) => AnimalMissing?.Invoke(identity);
        public static void RaiseAnimalRecovered(string identity, int hunger) => AnimalRecovered?.Invoke(identity, hunger);
        public static void RaiseTransactionCommitted(string id) => TransactionCommitted?.Invoke(id);
        public static void RaiseTowerStructureChanged(string identity, int current, int maximum) => TowerStructureChanged?.Invoke(identity, current, maximum);
        public static void RaiseTowerStructureBuilt(string identity, string towerId) => TowerStructureBuilt?.Invoke(identity, towerId);
        public static void RaiseTowerStructureUpgraded(string identity, int level) => TowerStructureUpgraded?.Invoke(identity, level);
        public static void RaiseSupplyConvoyDestroyed(string identity) => SupplyConvoyDestroyed?.Invoke(identity);
        public static void RaiseSupplyConvoyDelivered(string identity, string towerId) => SupplyConvoyDelivered?.Invoke(identity, towerId);
    }
}
