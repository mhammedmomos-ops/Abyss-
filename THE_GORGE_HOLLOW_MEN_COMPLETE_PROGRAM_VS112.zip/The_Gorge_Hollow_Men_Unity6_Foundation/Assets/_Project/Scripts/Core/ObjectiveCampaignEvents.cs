using System;

namespace GorgeHollow
{
    public static partial class CampaignEvents
    {
        public static event Action<string> ObjectiveCompleted;
        public static event Action<string> ScavengeCompleted;

        public static void RaiseObjectiveCompleted(string objectiveId) => ObjectiveCompleted?.Invoke(objectiveId);
        public static void RaiseScavengeCompleted(string sourceId) => ScavengeCompleted?.Invoke(sourceId);
    }
}
