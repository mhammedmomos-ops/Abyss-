using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Tracks session playtime (unscaled) for stats / dawn summary.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SessionPlaytimeTracker : MonoBehaviour
    {
        public float PlaytimeSeconds { get; private set; }
        public static SessionPlaytimeTracker Instance { get; private set; }

        private void Awake() => Instance = this;
        private void OnDestroy() { if (Instance == this) Instance = null; }

        private void Update()
        {
            if (Time.timeScale > 0f)
                PlaytimeSeconds += Time.unscaledDeltaTime;
        }

        public string FormatPlaytime()
        {
            int total = Mathf.FloorToInt(PlaytimeSeconds);
            int m = total / 60;
            int s = total % 60;
            return string.Format("{0:00}:{1:00}", m, s);
        }
    }
}
