using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Runtime strings useful for bug reports.
    /// </summary>
    public static class BuildManifestUtility
    {
        public static string DeviceLine()
        {
            return SystemInfo.deviceModel + " · " + SystemInfo.operatingSystem +
                   " · " + Screen.width + "x" + Screen.height +
                   " · " + GameFoundationInfo.PackageVersion;
        }

        public static void LogDeviceLine()
        {
            Debug.Log("[Gorge] " + DeviceLine());
        }
    }
}
