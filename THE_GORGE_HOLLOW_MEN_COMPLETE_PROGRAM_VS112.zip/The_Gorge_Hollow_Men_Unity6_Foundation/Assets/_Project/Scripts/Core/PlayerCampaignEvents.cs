namespace GorgeHollow
{
    public static partial class CampaignEvents
    {
        public static event System.Action PlayerDied;
        public static void RaisePlayerDied() => PlayerDied?.Invoke();
    }
}
