using System.Collections.Generic;

namespace GorgeHollow
{
    /// <summary>Maintains one authoritative campaign animal record per stable identity.</summary>
    public static class CampaignAnimalRecordRules
    {
        public static bool TryUpsert(List<AnimalRecord> records, AnimalRecord animal, out string error)
        {
            error = null;
            if (records == null)
            {
                error = "Campaign animal collection is missing.";
                return false;
            }
            if (animal == null || string.IsNullOrWhiteSpace(animal.identity))
            {
                error = "Animal record and stable identity are required.";
                return false;
            }

            int matchingIndex = -1;
            for (int i = 0; i < records.Count; i++)
            {
                AnimalRecord existing = records[i];
                if (existing == null || existing.identity != animal.identity) continue;
                if (matchingIndex >= 0)
                {
                    error = "Duplicate campaign animal identity: " + animal.identity;
                    return false;
                }
                matchingIndex = i;
            }

            if (matchingIndex >= 0) records[matchingIndex] = animal;
            else records.Add(animal);
            return true;
        }
    }
}
