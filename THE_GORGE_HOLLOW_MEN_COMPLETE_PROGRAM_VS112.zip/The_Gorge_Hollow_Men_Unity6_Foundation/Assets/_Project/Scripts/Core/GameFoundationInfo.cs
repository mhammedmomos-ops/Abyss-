namespace GorgeHollow
{
    /// <summary>
    /// Single place to read foundation package metadata.
    /// </summary>
    public static class GameFoundationInfo
    {
        public const string PackageVersion = "VS103";
        public const string ProductName = "The Gorge: Hollow Men";
        public const string EngineTarget = "Unity 6";
        public const string PlatformFocus = "Android / iOS";

        public static string Summary =>
            ProductName + " · " + PackageVersion + " · " + EngineTarget + " · " + PlatformFocus;
    }
}
