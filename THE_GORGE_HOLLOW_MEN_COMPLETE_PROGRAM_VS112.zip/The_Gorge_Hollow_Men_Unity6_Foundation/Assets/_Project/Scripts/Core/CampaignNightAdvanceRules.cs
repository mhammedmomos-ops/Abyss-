namespace GorgeHollow
{
    /// <summary>Pure guards for the optional post-encounter night transition.</summary>
    public static class CampaignNightAdvanceRules
    {
        public static bool CanOfferAdvance(bool encounterResolved, bool raidActive, CampaignPhase phase,
            int currentNight, int encounterNight, bool alreadyAdvancedThisNight)
        {
            return encounterResolved && !raidActive && phase == CampaignPhase.ThreatResolution &&
                   currentNight > 0 && encounterNight == currentNight && !alreadyAdvancedThisNight;
        }

        public static string GetActionLabel(int currentNight, int maximumNights)
        {
            return currentNight >= maximumNights ? "COMPLETE CAMPAIGN" : "RETURN TO DAWN";
        }
    }
}
