using UnityEngine;

namespace GorgeHollow
{
    [DefaultExecutionOrder(-1000)]
    public sealed class GameBootstrap : MonoBehaviour
    {
        public CampaignState Campaign { get; private set; }
        public CampaignClock Clock { get; private set; }
        public CampaignSaveService Saves { get; private set; }
        public ResourceTransactionService Transactions { get; private set; }

        private void Awake()
        {
            try { MobileQualitySettings.Apply(); } catch { }

            Saves = new CampaignSaveService();
            Transactions = new ResourceTransactionService();
            Campaign = Saves.Load(out string loadError);
            if (Campaign == null)
            {
                Campaign = CampaignStateFactory.CreateNew();
                Debug.Log("Starting new campaign. " + loadError);
            }
            else Debug.Log("Campaign loaded. " + loadError);
            if (Campaign.playerVitals == null) Campaign.playerVitals = new PlayerVitalsData();
            Clock = new CampaignClock(Campaign);
        }

        /// <summary>Creates and persists a new campaign before replacing the live in-memory state.</summary>
        public bool TryStartNewCampaign(out string error)
        {
            if (Saves == null)
            {
                error = "Campaign save service is not initialized.";
                return false;
            }

            CampaignState fresh = CampaignStateFactory.CreateNew();
            if (!Saves.Save(fresh, out error)) return false;

            Campaign = fresh;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            return true;
        }

        public void RestorePlayerVitals(PlayerVitals player)
        {
            if (player != null) player.Restore(Campaign.playerVitals);
        }
        public bool SavePlayerVitals(PlayerVitals player)
        {
            if (player != null) Campaign.playerVitals = player.State;
            return SaveCampaign();
        }
        public bool SaveAnimalRecord(AnimalRecord animal)
        {
            if (Campaign == null || animal == null || string.IsNullOrWhiteSpace(animal.identity))
            {
                Debug.LogError("Cannot save an animal record without a campaign and stable identity.", this);
                return false;
            }
            if (Campaign.animals == null) Campaign.animals = new System.Collections.Generic.List<AnimalRecord>();
            if (!CampaignAnimalRecordRules.TryUpsert(Campaign.animals, animal, out string error))
            {
                Debug.LogError("Animal record was not saved: " + error, this);
                return false;
            }
            return SaveCampaign();
        }
        /// <summary>
        /// Advances fictional campaign time transactionally. Pet ageing is applied by CampaignClock;
        /// a failed save leaves the live campaign and its clock unchanged.
        /// </summary>
        public bool TryAdvanceCampaignMinutes(int minutes)
        {
            if (Campaign == null || Saves == null || minutes < 0 || !FlushActiveCompanion()) return false;
            CampaignState candidate = CloneCampaign(Campaign);
            CampaignClock candidateClock = new CampaignClock(candidate);
            candidateClock.AdvanceFictionalMinutes(minutes);
            TowerProductionRules.Advance(candidate, "tower_a", minutes);
            TowerProductionRules.Advance(candidate, "tower_b", minutes);
            TowerWorkerRules.Advance(candidate, minutes);
            if (!Saves.Save(candidate, out string error))
            {
                Debug.LogError("Campaign time advance was rolled back: " + error, this);
                return false;
            }
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            PublishStarvationDeaths(candidateClock);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            return true;
        }

        /// <summary>Persists a campaign phase change before notifying UI and gameplay listeners.</summary>
        public bool TrySetCampaignPhase(CampaignPhase phase)
        {
            if (Campaign == null || Saves == null || !System.Enum.IsDefined(typeof(CampaignPhase), phase) ||
                Campaign.phase == CampaignPhase.Completed || Campaign.phase == CampaignPhase.Failed ||
                !FlushActiveCompanion()) return false;

            CampaignState candidate = CloneCampaign(Campaign);
            candidate.phase = phase;
            if (!Saves.Save(candidate, out string error))
            {
                Debug.LogError("Campaign phase change was rolled back: " + error, this);
                return false;
            }
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            CampaignEvents.RaisePhaseChanged(Campaign.phase);
            return true;
        }

        /// <summary>Completes the current night and publishes progression events only after persistence succeeds.</summary>
        public bool TryCompleteCampaignNight()
        {
            if (Campaign == null || Saves == null || !FlushActiveCompanion()) return false;
            CampaignState candidate = CloneCampaign(Campaign);
            CampaignClock candidateClock = new CampaignClock(candidate);
            candidateClock.CompleteNight(false);
            if (!Saves.Save(candidate, out string error))
            {
                Debug.LogError("Night completion was rolled back: " + error, this);
                return false;
            }
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            PublishStarvationDeaths(candidateClock);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            if (Campaign.night < 20 || Campaign.phase == CampaignPhase.DawnReview)
                CampaignEvents.RaiseNightChanged(Campaign.night);
            CampaignEvents.RaisePhaseChanged(Campaign.phase);
            return true;
        }

        private static void PublishStarvationDeaths(CampaignClock clock)
        {
            if (clock == null || clock.StarvationDeaths == null) return;
            for (int i = 0; i < clock.StarvationDeaths.Count; i++)
                CampaignEvents.RaiseAnimalDied(clock.StarvationDeaths[i]);
        }

        /// <summary>Feeds a living campaign companion and commits the food cost and pet record atomically.</summary>
        public bool TryFeedAnimal(string animalIdentity)
        {
            if (Campaign == null || Saves == null || string.IsNullOrWhiteSpace(animalIdentity) || !FlushActiveCompanion()) return false;
            CampaignState candidate = CloneCampaign(Campaign);
            AnimalRecord target = null;
            if (candidate.animals != null)
                for (int i = 0; i < candidate.animals.Count; i++)
                    if (candidate.animals[i] != null && candidate.animals[i].identity == animalIdentity)
                    { target = candidate.animals[i]; break; }
            if (target == null || !AnimalCareRules.TryFeed(target, ref candidate.petFood)) return false;
            if (!Saves.Save(candidate, out string error))
            {
                Debug.LogError("Companion feeding was rolled back: " + error, this);
                return false;
            }
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            CampaignEvents.RaiseTransactionCommitted("pet-feed:" + animalIdentity);
            return true;
        }

        /// <summary>Checks whether a stable wild-food source remains available on the current fictional day.</summary>
        public bool CanForageFromSource(string sourceId)
        {
            if (Campaign == null || Campaign.campaignFlags == null || string.IsNullOrWhiteSpace(sourceId)) return false;
            return AnimalForageRules.IsAvailable(Campaign.campaignFlags, sourceId, Campaign.fictionalDay);
        }

        /// <summary>Atomically records a harvest only when the active, operational companion reaches the source.</summary>
        public bool TryCollectForagedPetFood(AnimalCompanionController forager, AnimalForageFoodSource source)
        {
            if (Campaign == null || Saves == null || forager == null || source == null || !source.isActiveAndEnabled ||
                !forager.IsOperational || forager.CurrentCommand != AnimalCommand.Forage ||
                Vector3.Distance(forager.transform.position, source.transform.position) > 3f || !FlushActiveCompanion())
                return false;

            CampaignState candidate = CloneCampaign(Campaign);
            string identity = forager.Record != null ? forager.Record.identity : string.Empty;
            AnimalRecord campaignPet = null;
            if (candidate.animals != null)
                for (int i = 0; i < candidate.animals.Count; i++)
                    if (candidate.animals[i] != null && candidate.animals[i].identity == identity)
                    { campaignPet = candidate.animals[i]; break; }
            if (!AnimalCareRules.CanForage(campaignPet)) return false;

            string sourceId = source.SourceId;
            int amount = source.FoodYield;
            if (!AnimalForageRules.TryMarkHarvested(candidate.campaignFlags, sourceId, candidate.fictionalDay) ||
                candidate.petFood > int.MaxValue - amount) return false;
            candidate.petFood += amount;
            campaignPet.experience = campaignPet.experience < int.MaxValue ? campaignPet.experience + 1 : int.MaxValue;
            campaignPet.stamina = System.Math.Max(0, campaignPet.stamina - 10);
            if (!Saves.Save(candidate, out string error))
            {
                Debug.LogError("Foraged food was not committed: " + error, this);
                return false;
            }

            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            CampaignEvents.RaiseTransactionCommitted("pet-forage:" + sourceId + ":day:" + Campaign.fictionalDay);
            return true;
        }

        public bool IsAnimalMissing(string animalIdentity)
        {
            if (Campaign == null || Campaign.animals == null || string.IsNullOrWhiteSpace(animalIdentity)) return false;
            for (int i = 0; i < Campaign.animals.Count; i++)
            {
                AnimalRecord animal = Campaign.animals[i];
                if (animal != null && animal.identity == animalIdentity) return animal.status == AnimalStatus.Missing;
            }
            return false;
        }

        /// <summary>Persists a recoverable missing state for a living companion.</summary>
        public bool TryMarkAnimalMissing(string animalIdentity)
        {
            if (Campaign == null || Saves == null || string.IsNullOrWhiteSpace(animalIdentity) || !FlushActiveCompanion()) return false;
            CampaignState candidate = CloneCampaign(Campaign);
            AnimalRecord target = null;
            if (candidate.animals != null)
                for (int i = 0; i < candidate.animals.Count; i++)
                    if (candidate.animals[i] != null && candidate.animals[i].identity == animalIdentity)
                    { target = candidate.animals[i]; break; }
            if (!AnimalCareRules.TryMarkMissing(target)) return false;
            if (!Saves.Save(candidate, out string error))
            {
                Debug.LogError("Missing companion status was not committed: " + error, this);
                return false;
            }
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            CampaignEvents.RaiseAnimalMissing(animalIdentity);
            CampaignEvents.RaiseTransactionCommitted("pet-missing:" + animalIdentity);
            return true;
        }

        /// <summary>
        /// Recovers a missing (never dead) animal. Hunger is rolled at discovery, between 20 and 85,
        /// to represent the animal's independent hunting while separated from the player.
        /// </summary>
        public bool TryRecoverMissingAnimal(string animalIdentity, out int recoveredHunger)
        {
            recoveredHunger = 0;
            if (Campaign == null || Saves == null || string.IsNullOrWhiteSpace(animalIdentity) || !FlushActiveCompanion()) return false;
            CampaignState candidate = CloneCampaign(Campaign);
            AnimalRecord target = null;
            if (candidate.animals != null)
                for (int i = 0; i < candidate.animals.Count; i++)
                    if (candidate.animals[i] != null && candidate.animals[i].identity == animalIdentity)
                    { target = candidate.animals[i]; break; }

            int hungerRoll = UnityEngine.Random.Range(20, 86);
            if (!AnimalCareRules.TryRecoverMissing(target, hungerRoll)) return false;
            if (!Saves.Save(candidate, out string error))
            {
                Debug.LogError("Missing companion recovery was not committed: " + error, this);
                return false;
            }

            recoveredHunger = target.hunger;
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            CampaignEvents.RaiseAnimalRecovered(animalIdentity, recoveredHunger);
            CampaignEvents.RaiseTransactionCommitted("pet-recovered:" + animalIdentity);
            return true;
        }

        private bool FlushActiveCompanion()
        {
            AnimalCompanionController actor = FindFirstObjectByType<AnimalCompanionController>();
            if (actor == null || actor.FlushPendingRecord()) return true;
            Debug.LogError("Campaign progression was cancelled because pending companion state could not be saved.", this);
            return false;
        }

        private static CampaignState CloneCampaign(CampaignState source)
        {
            return JsonUtility.FromJson<CampaignState>(JsonUtility.ToJson(source));
        }

        public bool TryRepairTowerStructure(string structureIdentity, int repairAmount, int scrapCost,
            int timberCost, string transactionId, out string error)
        {
            error = null;
            if (Campaign == null || Saves == null || string.IsNullOrWhiteSpace(structureIdentity))
            { error = "Campaign or structure identity is unavailable."; return false; }
            CampaignState candidate = CloneCampaign(Campaign);
            TowerMaintenanceService service = new TowerMaintenanceService(Transactions);
            if (!service.TryRepairFromTowerDepot(candidate, structureIdentity, repairAmount,
                    scrapCost, timberCost, transactionId, out _, out error)) return false;
            if (!Saves.Save(candidate, out error)) return false;
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            CampaignEvents.RaiseTransactionCommitted(transactionId);
            CampaignEvents.RaiseTowerStructureChanged(structureIdentity,
                candidate.towerStructures.Find(x => x != null && x.identity == structureIdentity).currentHealth,
                candidate.towerStructures.Find(x => x != null && x.identity == structureIdentity).maxHealth);
            return true;
        }

        public bool TryDispatchInterTowerSupplyTransfer(string originTowerId, SupplyConvoyRecord manifest,
            int bridgeStartWaypoint, int bridgeEndWaypoint, bool routeAuthored, out string error)
        {
            error = null;
            if (Campaign == null || Saves == null) { error = "Campaign persistence is unavailable."; return false; }
            CampaignState candidate = CloneCampaign(Campaign);
            if (!InterTowerSupplyTransferRules.TryDispatch(candidate, originTowerId, manifest,
                bridgeStartWaypoint, bridgeEndWaypoint, routeAuthored, out error)) return false;
            if (!Saves.Save(candidate, out error)) return false;
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            CampaignEvents.RaiseTransactionCommitted("tower-transfer-dispatch:" + manifest.identity);
            return true;
        }

        public bool TrySetSupplyConvoyCommand(string identity, SupplyConvoyCommand command, out string error)
        {
            error = null;
            if (Campaign == null || Saves == null || string.IsNullOrWhiteSpace(identity) ||
                !SupplyConvoyCommandRules.IsValid(command))
            { error = "A valid travelling convoy and tactical command are required."; return false; }
            CampaignState candidate = CloneCampaign(Campaign);
            SupplyConvoyRecord record = candidate.supplyConvoys.Find(x => x != null && x.identity == identity);
            if (record == null || record.status != SupplyConvoyStatus.Travelling)
            { error = "Only a travelling convoy can receive commands."; return false; }
            if (record.tacticalCommand == command) return true;
            record.tacticalCommand = command;
            if (!Saves.Save(candidate, out error)) return false;
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            CampaignEvents.RaiseTransactionCommitted("supply-convoy-command:" + identity + ":" + command);
            return true;
        }

        public bool TryRegisterSupplyConvoy(SupplyConvoyRecord convoy, out string error)
        {
            error = null;
            if (Campaign == null || Saves == null || !SupplyConvoyRules.IsValidNewConvoy(convoy))
            { error = "A valid travelling convoy with cargo is required."; return false; }
            CampaignState candidate = CloneCampaign(Campaign);
            if (candidate.supplyConvoys == null) candidate.supplyConvoys = new System.Collections.Generic.List<SupplyConvoyRecord>();
            if (candidate.supplyConvoys.Exists(x => x != null && x.identity == convoy.identity))
            { error = "A convoy with this identity already exists."; return false; }
            candidate.supplyConvoys.Add(JsonUtility.FromJson<SupplyConvoyRecord>(JsonUtility.ToJson(convoy)));
            if (!Saves.Save(candidate, out error)) return false;
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            return true;
        }

        public bool TryUpdateSupplyConvoyProgress(string identity, Vector3 position, int waypointIndex, out string error)
        {
            error = null;
            if (Campaign == null || Saves == null || string.IsNullOrWhiteSpace(identity) ||
                !SupplyConvoyRules.IsFinite(position) || waypointIndex < 0 || waypointIndex > 256) return false;
            CampaignState candidate = CloneCampaign(Campaign);
            SupplyConvoyRecord record = candidate.supplyConvoys.Find(x => x != null && x.identity == identity);
            if (record == null || record.status != SupplyConvoyStatus.Travelling) { error = "Convoy is not travelling."; return false; }
            record.worldPosition = position;
            record.routeWaypointIndex = waypointIndex;
            if (!Saves.Save(candidate, out error)) return false;
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            return true;
        }

        public bool TryDamageSupplyConvoy(string identity, float damage, out bool destroyed, out string error)
        {
            destroyed = false;
            error = null;
            if (Campaign == null || Saves == null || string.IsNullOrWhiteSpace(identity)) return false;
            CampaignState candidate = CloneCampaign(Campaign);
            SupplyConvoyRecord record = candidate.supplyConvoys.Find(x => x != null && x.identity == identity);
            if (!SupplyConvoyRules.TryApplyDamage(record, damage, out destroyed))
            { error = "Convoy cannot receive this damage."; return false; }
            if (!Saves.Save(candidate, out error)) return false;
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            if (destroyed) CampaignEvents.RaiseSupplyConvoyDestroyed(identity);
            return true;
        }

        public bool TryDeliverSupplyConvoy(string identity, out string error)
        {
            error = null;
            if (Campaign == null || Saves == null || string.IsNullOrWhiteSpace(identity)) return false;
            CampaignState candidate = CloneCampaign(Campaign);
            SupplyConvoyRecord record = candidate.supplyConvoys.Find(x => x != null && x.identity == identity);
            if (!SupplyConvoyRules.TryDeliver(candidate, record, out error)) return false;
            string transactionId = "supply-convoy-delivery:" + identity;
            if (!Saves.Save(candidate, out error)) return false;
            Campaign = candidate;
            Clock = new CampaignClock(Campaign);
            CampaignEvents.RaiseCampaignReplaced(Campaign);
            CampaignEvents.RaiseTransactionCommitted(transactionId);
            CampaignEvents.RaiseSupplyConvoyDelivered(identity, record.destinationTowerId);
            return true;
        }

        public bool SaveCampaign()
        {
            bool success = Saves.Save(Campaign, out string error);
            if (!success) Debug.LogError("Campaign save failed: " + error);
            return success;
        }
    }
}
