using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Deterministic dimensions and encounter coordinates for the greybox scene generator.</summary>
    public static class VerticalSliceLayout
    {
        public const float TowerCenterX = 23f;
        public const float TowerPlatformWidth = 18f;
        public const float TowerPlatformDepth = 18f;
        public const float PlatformTopY = 1f;
        public const float BridgeLength = 28f;
        public const float BridgeWidth = 4f;
        public const float TowerGateClearance = 4.4f;
        public const float BridgeDeckThickness = 0.6f;
        public const float GorgeFloorY = -24f;
        
        public static Vector3 WestTowerCenter => new Vector3(-TowerCenterX, 0f, 0f);
        public static Vector3 EastTowerCenter => new Vector3(TowerCenterX, 0f, 0f);
        public static Vector3 WestBridgeEnd => new Vector3(-TowerCenterX + TowerPlatformWidth * 0.5f, PlatformTopY, 0f);
        public static Vector3 EastBridgeEnd => new Vector3(TowerCenterX - TowerPlatformWidth * 0.5f, PlatformTopY, 0f);
        public static Vector3 PlayerSpawn => new Vector3(-TowerCenterX + 4f, PlatformTopY + 0.05f, 0f);
        public static Vector3 MonsterSpawnNorth => new Vector3(EastTowerCenter.x + 5f, PlatformTopY + 0.05f, 1.25f);
        public static Vector3 MonsterSpawnSouth => new Vector3(EastTowerCenter.x + 5f, PlatformTopY + 0.05f, -1.25f);
        public static Vector3 FirstEncounterTriggerPosition => new Vector3(WestBridgeEnd.x + 0.8f, PlatformTopY + 1.4f, 0f);

        private static bool IsInsidePlatform(Vector3 point, Vector3 center)
        {
            return point.x >= center.x - TowerPlatformWidth * 0.5f && point.x <= center.x + TowerPlatformWidth * 0.5f &&
                   point.z >= -TowerPlatformDepth * 0.5f && point.z <= TowerPlatformDepth * 0.5f &&
                   point.y >= PlatformTopY;
        }

        public static bool IsValid(out string error)
        {
            if (TowerCenterX <= TowerPlatformWidth * 0.5f)
            {
                error = "Tower centers must leave a positive gorge span between platforms.";
                return false;
            }
            float gap = (TowerCenterX * 2f) - TowerPlatformWidth;
            if (BridgeLength < gap - 0.01f)
            {
                error = "Bridge deck is shorter than the gap between tower platforms.";
                return false;
            }
            Vector3 spawn = PlayerSpawn;
            bool spawnInsideWestPlatform = spawn.x >= WestTowerCenter.x - TowerPlatformWidth * 0.5f &&
                                           spawn.x <= WestTowerCenter.x + TowerPlatformWidth * 0.5f &&
                                           spawn.z >= -TowerPlatformDepth * 0.5f && spawn.z <= TowerPlatformDepth * 0.5f;
            if (!spawnInsideWestPlatform || spawn.y <= PlatformTopY)
            {
                error = "Player spawn must be above and inside the west tower platform.";
                return false;
            }
            if (TowerGateClearance < BridgeWidth)
            {
                error = "Tower gate clearance must be at least as wide as the bridge.";
                return false;
            }
            if (BridgeWidth <= 0f || BridgeDeckThickness <= 0f || GorgeFloorY >= PlatformTopY)
            {
                error = "Bridge dimensions or gorge depth are invalid.";
                return false;
            }
            if (!IsInsidePlatform(MonsterSpawnNorth, EastTowerCenter) || !IsInsidePlatform(MonsterSpawnSouth, EastTowerCenter))
            {
                error = "Monster spawn sockets must be located on the east tower platform.";
                return false;
            }
            if (Vector3.Distance(PlayerSpawn, MonsterSpawnNorth) < 16f || Vector3.Distance(PlayerSpawn, MonsterSpawnSouth) < 16f)
            {
                error = "Monster spawn sockets are too close to the initial player spawn for the encounter safety distance.";
                return false;
            }
            error = null;
            return true;
        }
    }
}
