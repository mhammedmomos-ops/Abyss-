using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Holds the active run seed (daily or random) for systems that want deterministic variation.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class RunSeedState : MonoBehaviour
    {
        [SerializeField] private bool useDailySeed = true;
        [SerializeField] private int salt = 17;
        public int Seed { get; private set; }
        public static RunSeedState Instance { get; private set; }

        private void Awake()
        {
            Instance = this;
            Reseed();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        public void Reseed()
        {
            int baseSeed = useDailySeed
                ? DailySeedUtility.GetUtcDailySeed()
                : Random.Range(1, int.MaxValue);
            Seed = DailySeedUtility.Mix(baseSeed, salt);
        }

        public float Next01(ref int cursor)
        {
            unchecked
            {
                cursor = DailySeedUtility.Mix(Seed, cursor + 1);
                return (cursor % 10000) / 10000f;
            }
        }
    }
}
