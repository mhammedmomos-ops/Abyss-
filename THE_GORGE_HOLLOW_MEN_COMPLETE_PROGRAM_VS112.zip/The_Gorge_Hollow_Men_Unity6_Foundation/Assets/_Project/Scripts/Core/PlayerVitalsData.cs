using System;
using UnityEngine;

namespace GorgeHollow
{
    [Serializable]
    public sealed class PlayerVitalsData
    {
        [Range(0, 100)] public float health = 100f;
        [Range(0, 100)] public float stamina = 100f;
        [Range(0, 100)] public float bloom = 0f;
        [Range(0, 100)] public float nutrition = 100f;
        [Range(0, 100)] public float hydration = 100f;
        [Range(0, 100)] public float injury = 0f;
        public bool isDead;
    }
}
