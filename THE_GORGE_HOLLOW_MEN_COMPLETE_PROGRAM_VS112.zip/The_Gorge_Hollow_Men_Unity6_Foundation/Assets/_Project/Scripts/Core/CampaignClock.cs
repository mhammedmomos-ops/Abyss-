using System;
using System.Collections.Generic;

namespace GorgeHollow
{
    // Fictional time advances only through explicit campaign events.
    // No wall-clock delta is applied on startup or after returning from offline.
    public sealed class CampaignClock
    {
        private readonly CampaignState state;
        private readonly List<string> starvationDeaths = new List<string>();
        public IReadOnlyList<string> StarvationDeaths => starvationDeaths;

        public CampaignClock(CampaignState campaignState)
        {
            state = campaignState ?? throw new ArgumentNullException(nameof(campaignState));
        }

        public void AdvanceFictionalMinutes(int minutes)
        {
            if (minutes < 0) throw new ArgumentOutOfRangeException(nameof(minutes));

            int previousDay = state.fictionalDay;
            int totalMinutes = state.fictionalHour * 60 +
                               state.fictionalMinute + minutes;
            state.fictionalDay += totalMinutes / (24 * 60);
            int minuteOfDay = totalMinutes % (24 * 60);
            state.fictionalHour = minuteOfDay / 60;
            state.fictionalMinute = minuteOfDay % 60;
            AdvanceAnimalAges(state.fictionalDay - previousDay);
        }

        private void AdvanceAnimalAges(int days)
        {
            if (days <= 0 || state.animals == null) return;
            for (int i = 0; i < state.animals.Count; i++)
            {
                AnimalLifecycleRules.AdvanceDays(state.animals[i], days);
                AnimalRecord animal = state.animals[i];
                if (AnimalCareRules.AdvanceHunger(animal, days) && animal != null)
                    starvationDeaths.Add(animal.identity);
            }
        }

        public void CompleteNight() => CompleteNight(true);

        /// <summary>Completes a night; callers coordinating an atomic save can defer event publication.</summary>
        public void CompleteNight(bool publishEvents)
        {
            if (state.night >= 20)
            {
                state.phase = CampaignPhase.Completed;
                if (publishEvents) CampaignEvents.RaisePhaseChanged(state.phase);
                return;
            }

            state.night++;
            state.chapter = Math.Min(5, ((state.night - 1) / 4) + 1);
            state.fictionalDay++;
            AdvanceAnimalAges(1);
            state.fictionalHour = 6;
            state.fictionalMinute = 0;
            state.phase = CampaignPhase.DawnReview;
            if (publishEvents)
            {
                CampaignEvents.RaiseNightChanged(state.night);
                CampaignEvents.RaisePhaseChanged(state.phase);
            }
        }
    }
}
