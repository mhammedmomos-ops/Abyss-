using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Unlocks simple achievements into campaignFlags (no schema change).
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AchievementTracker : MonoBehaviour
    {
        [SerializeField] private GameBootstrap bootstrap;
        private const string Prefix = "ach:";

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        private void OnEnable()
        {
            CampaignEvents.ScavengeCompleted += OnScavenge;
            CampaignEvents.ObjectiveCompleted += OnObjective;
            CampaignEvents.NightChanged += OnNight;
            CampaignEvents.PlayerDied += OnDeath;
        }

        private void OnDisable()
        {
            CampaignEvents.ScavengeCompleted -= OnScavenge;
            CampaignEvents.ObjectiveCompleted -= OnObjective;
            CampaignEvents.NightChanged -= OnNight;
            CampaignEvents.PlayerDied -= OnDeath;
        }

        private void OnScavenge(string _) => Unlock("first_scavenge", "First supplies found");
        private void OnObjective(string id) => Unlock("objective_" + id, "Objective complete");
        private void OnNight(int night)
        {
            if (night >= 2) Unlock("survived_night_1", "Survived the first night");
            if (night >= 5) Unlock("survived_night_4", "Held through night 4");
        }
        private void OnDeath() => Unlock("first_death", "First fall");

        private void Unlock(string id, string toast)
        {
            if (bootstrap == null || bootstrap.Campaign == null) return;
            string flag = Prefix + id;
            var flags = bootstrap.Campaign.campaignFlags;
            if (flags == null)
            {
                bootstrap.Campaign.campaignFlags = new System.Collections.Generic.List<string>();
                flags = bootstrap.Campaign.campaignFlags;
            }
            for (int i = 0; i < flags.Count; i++)
                if (flags[i] == flag) return;
            flags.Add(flag);
            bootstrap.SaveCampaign();
            GenericToastUI.Show("Achievement: " + toast, 2.5f);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.UIClick);
        }
    }
}
