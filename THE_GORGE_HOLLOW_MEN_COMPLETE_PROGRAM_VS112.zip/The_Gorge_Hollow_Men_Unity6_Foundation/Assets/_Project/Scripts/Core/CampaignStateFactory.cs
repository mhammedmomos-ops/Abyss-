namespace GorgeHollow
{
    /// <summary>Creates a clean standalone campaign using the canonical opening state.</summary>
    public static class CampaignStateFactory
    {
        public static CampaignState CreateNew()
        {
            return new CampaignState
            {
                phase = CampaignPhase.RecoveryPreparation,
                night = 1,
                chapter = 1,
                fictionalDay = 1,
                fictionalHour = 6,
                fictionalMinute = 0,
                petFood = 2,
                playerVitals = new PlayerVitalsData(),
                towerStructures = new System.Collections.Generic.List<TowerStructureRecord>(),
                supplyConvoys = new System.Collections.Generic.List<SupplyConvoyRecord>(),
                towerDepots = TowerDepotRules.CreateStartingDepots(),
                towerWorkers = CreateStartingWorkers(),
                monsterNests = new System.Collections.Generic.List<MonsterNestRecord>(),
                appliedTransactionIds = new System.Collections.Generic.List<string>(),
                animals = new System.Collections.Generic.List<AnimalRecord>(),
                campaignFlags = new System.Collections.Generic.List<string>(),
                eventHistory = new System.Collections.Generic.List<string>()
            };
        }

        /// <summary>Creates the opening four-person workforce: one mechanic and one guard at each tower.</summary>
        public static System.Collections.Generic.List<TowerWorkerRecord> CreateStartingWorkers()
        {
            return new System.Collections.Generic.List<TowerWorkerRecord>
            {
                StartingWorker("starter_ta_mechanic", "Mara", "tower_a", TowerWorkerRole.Mechanic, TowerWorkerAssignment.Production),
                StartingWorker("starter_ta_guard", "Tunde", "tower_a", TowerWorkerRole.Guard, TowerWorkerAssignment.Guard),
                StartingWorker("starter_tb_mechanic", "Nia", "tower_b", TowerWorkerRole.Mechanic, TowerWorkerAssignment.Production),
                StartingWorker("starter_tb_guard", "Jonah", "tower_b", TowerWorkerRole.Guard, TowerWorkerAssignment.Guard)
            };
        }

        private static TowerWorkerRecord StartingWorker(string id, string name, string tower, TowerWorkerRole role, TowerWorkerAssignment assignment)
        {
            return new TowerWorkerRecord
            {
                identity = id, displayName = name, towerId = tower, role = role,
                status = TowerWorkerStatus.Active, assignment = assignment,
                skill = 25, health = 100, fatigue = 0,
                morale = 70, loyalty = 50, stress = 0,
                personality = TowerWorkerPersonality.Balanced,
                tacticalState = TowerWorkerTacticalState.Normal,
                preRaidAssignment = assignment
            };
        }
    }
}
