using System;

namespace GorgeHollow
{
    /// <summary>
    /// Deterministic daily seed for optional roguelite modifiers (pure helper).
    /// </summary>
    public static class DailySeedUtility
    {
        public static int GetUtcDailySeed(DateTime? utcNow = null)
        {
            DateTime day = (utcNow ?? DateTime.UtcNow).Date;
            return day.Year * 10000 + day.Month * 100 + day.Day;
        }

        public static int Mix(int seed, int salt)
        {
            unchecked
            {
                int x = seed ^ (salt * 397);
                x = (x << 13) ^ x;
                return x & 0x7fffffff;
            }
        }
    }
}
