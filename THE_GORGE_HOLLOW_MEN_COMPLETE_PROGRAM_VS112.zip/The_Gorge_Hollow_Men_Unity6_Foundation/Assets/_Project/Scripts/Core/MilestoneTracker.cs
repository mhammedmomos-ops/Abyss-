using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Announces simple milestone toasts based on run stats thresholds.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class MilestoneTracker : MonoBehaviour
    {
        [SerializeField] private RunStatsTracker stats;
        private int lastScavengeMilestone;
        private int lastObjectiveMilestone;

        private void Awake()
        {
            if (stats == null) stats = FindFirstObjectByType<RunStatsTracker>();
        }

        private void OnEnable()
        {
            if (stats != null) stats.StatsChanged += OnStats;
        }

        private void OnDisable()
        {
            if (stats != null) stats.StatsChanged -= OnStats;
        }

        private void OnStats()
        {
            if (stats == null) return;
            Check(stats.Scavenges, ref lastScavengeMilestone, 5, "Scavenger");
            Check(stats.ObjectivesCompleted, ref lastObjectiveMilestone, 3, "Objective runner");
        }

        private static void Check(int value, ref int last, int step, string label)
        {
            int milestone = (value / step) * step;
            if (milestone <= 0 || milestone <= last) return;
            last = milestone;
            GenericToastUI.Show(label + ": " + milestone, 2f);
            KillFeedUI.Post(label + " " + milestone);
        }
    }
}
