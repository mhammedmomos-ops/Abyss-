using System;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Session statistics collected from campaign events. Not persisted unless saved by author.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class RunStatsTracker : MonoBehaviour
    {
        public int Scavenges { get; private set; }
        public int ObjectivesCompleted { get; private set; }
        public int PlayerDeaths { get; private set; }
        public int Transactions { get; private set; }
        public int NightsSurvived { get; private set; }

        public event Action StatsChanged;
        public static RunStatsTracker Instance { get; private set; }

        private void Awake() => Instance = this;
        private void OnDestroy() { if (Instance == this) Instance = null; }

        private void OnEnable()
        {
            CampaignEvents.ScavengeCompleted += OnScavenge;
            CampaignEvents.ObjectiveCompleted += OnObjective;
            CampaignEvents.PlayerDied += OnDeath;
            CampaignEvents.TransactionCommitted += OnTx;
            CampaignEvents.NightChanged += OnNight;
        }

        private void OnDisable()
        {
            CampaignEvents.ScavengeCompleted -= OnScavenge;
            CampaignEvents.ObjectiveCompleted -= OnObjective;
            CampaignEvents.PlayerDied -= OnDeath;
            CampaignEvents.TransactionCommitted -= OnTx;
            CampaignEvents.NightChanged -= OnNight;
        }

        private void OnScavenge(string _) { Scavenges++; StatsChanged?.Invoke(); }
        private void OnObjective(string _) { ObjectivesCompleted++; StatsChanged?.Invoke(); }
        private void OnDeath() { PlayerDeaths++; StatsChanged?.Invoke(); }
        private void OnTx(string _) { Transactions++; StatsChanged?.Invoke(); }
        private void OnNight(int night) { NightsSurvived = Mathf.Max(NightsSurvived, Mathf.Max(0, night - 1)); StatsChanged?.Invoke(); }

        public void ResetStats()
        {
            Scavenges = ObjectivesCompleted = PlayerDeaths = Transactions = NightsSurvived = 0;
            StatsChanged?.Invoke();
        }
    }
}
