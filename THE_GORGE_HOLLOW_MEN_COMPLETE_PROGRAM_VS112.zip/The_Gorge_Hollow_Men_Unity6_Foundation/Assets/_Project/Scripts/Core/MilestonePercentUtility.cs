namespace GorgeHollow
{
    /// <summary>
    /// Maps campaign night to a rough story percent for UI.
    /// </summary>
    public static class MilestonePercentUtility
    {
        public static int NightToPercent(int night, int maxNights = 20)
        {
            if (maxNights <= 0) return 0;
            if (night < 1) return 0;
            if (night >= maxNights) return 100;
            return (int)((night - 1) * 100f / maxNights);
        }
    }
}
