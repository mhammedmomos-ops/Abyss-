using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Creates a fresh CampaignState and saves it, then reloads gameplay.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class NewGameResetService : MonoBehaviour
    {
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private string gameplaySceneName = "Gameplay";

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        public void ResetAndStart()
        {
            if (bootstrap == null)
            {
                Debug.LogError("NewGameResetService requires GameBootstrap.", this);
                return;
            }

            if (!bootstrap.TryStartNewCampaign(out string error))
            {
                Debug.LogError("New campaign was not started because the save could not be committed: " + error, this);
                GenericToastUI.Show("Unable to start a new campaign. Existing save preserved.", 3f);
                return;
            }

            Time.timeScale = 1f;
            AudioListener.pause = false;
            GenericToastUI.Show("New campaign started", 1.5f);
            LoadingSplashUI.Load(gameplaySceneName);
        }
    }
}
