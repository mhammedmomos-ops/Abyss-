namespace GorgeHollow
{
    /// <summary>
    /// Minimal localization hook. Returns the key/fallback until a full table is authored.
    /// </summary>
    public static class Loc
    {
        public static string Get(string key, string fallback = null)
        {
            if (string.IsNullOrEmpty(key)) return fallback ?? string.Empty;
            // Future: look up in ScriptableObject / JSON tables by language code.
            return string.IsNullOrEmpty(fallback) ? key : fallback;
        }
    }
}
