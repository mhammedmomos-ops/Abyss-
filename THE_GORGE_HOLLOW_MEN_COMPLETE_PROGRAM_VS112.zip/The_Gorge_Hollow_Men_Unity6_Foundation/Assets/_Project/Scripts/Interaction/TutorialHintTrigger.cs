using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Trigger volume that shows a one-shot tutorial hint when the player enters.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider))]
    public sealed class TutorialHintTrigger : MonoBehaviour
    {
        [SerializeField, TextArea] private string message = "Use the left stick to move.";
        [SerializeField] private float duration = 4f;
        [SerializeField] private bool once = true;
        [SerializeField] private string playerTag = "Player";

        private bool fired;

        private void Reset()
        {
            var col = GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (once && fired) return;
            if (other == null) return;
            if (!string.IsNullOrEmpty(playerTag) && !other.CompareTag(playerTag) &&
                other.GetComponentInParent<PlayerVitals>() == null)
                return;
            TutorialHintUI.ShowHint(message, duration);
            fired = true;
            if (once) gameObject.SetActive(false);
        }
    }
}
