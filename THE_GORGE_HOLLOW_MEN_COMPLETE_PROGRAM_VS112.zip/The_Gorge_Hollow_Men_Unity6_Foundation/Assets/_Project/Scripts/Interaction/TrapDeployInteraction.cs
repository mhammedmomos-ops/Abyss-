using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Spends scrap to spawn a SimpleTrapHazard prefab in front of the player.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class TrapDeployInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string prompt = "Deploy trap";
        [SerializeField] private GameObject trapPrefab;
        [SerializeField] private int scrapCost = 4;
        [SerializeField] private float placeDistance = 2f;
        [SerializeField] private GameBootstrap bootstrap;

        public string InteractionPrompt => prompt;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        public bool CanInteract(GameObject interactor)
        {
            if (trapPrefab == null || interactor == null) return false;
            if (bootstrap == null || bootstrap.Campaign == null) return scrapCost <= 0;
            return bootstrap.Campaign.scrap >= scrapCost;
        }

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            Transform t = interactor.transform;
            Vector3 pos = t.position + t.forward * placeDistance;
            pos.y = t.position.y;
            Object.Instantiate(trapPrefab, pos, Quaternion.identity);

            if (scrapCost > 0 && bootstrap != null && bootstrap.Campaign != null)
            {
                var delta = new ResourceDelta { scrap = -scrapCost };
                string tx = "trap:" + System.Guid.NewGuid().ToString("N");
                if (bootstrap.Transactions != null)
                {
                    if (!bootstrap.Transactions.TryApply(bootstrap.Campaign, tx, delta, out string error))
                    {
                        Debug.Log("Trap deploy failed: " + error, this);
                        return;
                    }
                    CampaignEvents.RaiseTransactionCommitted(tx);
                }
                else bootstrap.Campaign.scrap -= scrapCost;
                bootstrap.SaveCampaign();
            }
            GenericToastUI.Show("Trap deployed", 1.2f);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.UIClick);
            MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
        }
    }
}
