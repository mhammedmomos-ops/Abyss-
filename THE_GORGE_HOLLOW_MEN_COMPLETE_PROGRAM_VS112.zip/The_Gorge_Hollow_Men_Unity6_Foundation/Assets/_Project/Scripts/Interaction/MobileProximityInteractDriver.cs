using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Routes the mobile interact tap to the nearest configured interactable.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(AutoInteractProximity))]
    public sealed class MobileProximityInteractDriver : MonoBehaviour
    {
        private AutoInteractProximity proximity;
        private void Awake() => proximity = GetComponent<AutoInteractProximity>();
        private void Update()
        {
            bool requested = MobileInputState.ConsumeInteract();
#if ENABLE_LEGACY_INPUT_MANAGER
            requested |= Input.GetKeyDown(KeyCode.E);
#endif
            if (requested) proximity.TryInteractNearest();
        }
    }
}
