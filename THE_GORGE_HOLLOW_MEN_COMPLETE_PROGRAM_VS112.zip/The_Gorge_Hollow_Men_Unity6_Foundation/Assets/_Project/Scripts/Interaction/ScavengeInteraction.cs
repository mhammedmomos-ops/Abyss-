using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// World interactable that grants campaign resources once. Uses ResourceTransactionService
    /// when a GameBootstrap is available; otherwise no-ops the grant but still raises the event
    /// for objective progress in isolated test scenes.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ScavengeInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string sourceId = "scavenge";
        [SerializeField] private string prompt = "Scavenge supplies";
        [SerializeField] private int scrap = 4;
        [SerializeField] private int timber = 2;
        [SerializeField] private int medicalSupplies;
        [SerializeField] private int ammunition;
        [SerializeField] private int petFood;
        [SerializeField] private bool disableRootOnUse = true;
        [SerializeField] private GameObject disableRoot;
        [SerializeField] private GameBootstrap bootstrap;

        private bool used;

        public string InteractionPrompt => prompt;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            if (string.IsNullOrWhiteSpace(sourceId)) sourceId = gameObject.name;
        }

        public bool CanInteract(GameObject interactor) => !used && isActiveAndEnabled;

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;

            bool granted = true;
            if (bootstrap != null && bootstrap.Campaign != null && bootstrap.Transactions != null)
            {
                var delta = new ResourceDelta
                {
                    scrap = Mathf.Max(0, scrap),
                    timber = Mathf.Max(0, timber),
                    medicalSupplies = Mathf.Max(0, medicalSupplies),
                    ammunition = Mathf.Max(0, ammunition),
                    petFood = Mathf.Max(0, petFood)
                };
                string txId = "scavenge:" + sourceId + ":" + System.Guid.NewGuid().ToString("N");
                if (!bootstrap.Transactions.TryApply(bootstrap.Campaign, txId, delta, out string error))
                {
                    Debug.Log("Scavenge failed: " + error, this);
                    granted = false;
                }
                else
                {
                    bootstrap.SaveCampaign();
                    CampaignEvents.RaiseTransactionCommitted(txId);
                }
            }

            if (!granted) return;

            used = true;
            CampaignEvents.RaiseScavengeCompleted(sourceId);

            if (disableRootOnUse)
            {
                GameObject root = disableRoot != null ? disableRoot : gameObject;
                root.SetActive(false);
            }
        }
    }
}
