using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Optional helper: when the player is within range of an IInteractable and holds Interact,
    /// repeatedly attempts interaction. Useful for dense loot areas on mobile.
    /// Prefer explicit PlayerInteractionController for precise aiming; this is a convenience.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AutoInteractProximity : MonoBehaviour
    {
        [SerializeField] private float radius = 2.2f;
        [SerializeField] private LayerMask mask = ~0;
        [SerializeField] private bool requireInteractHeld = true;

        private readonly Collider[] hits = new Collider[12];

        private void Update()
        {
            bool want = requireInteractHeld ? MobileInputState.InteractPressed : true;
            // InteractPressed is edge-triggered via PressInteract; use a soft proximity scan only
            // when the interact action was just consumed upstream. This component instead
            // exposes TryInteractNearest for UI buttons.
        }

        public bool TryInteractNearest()
        {
            int count = Physics.OverlapSphereNonAlloc(transform.position, radius, hits, mask, QueryTriggerInteraction.Collide);
            float best = float.MaxValue;
            IInteractable bestTarget = null;
            for (int i = 0; i < count; i++)
            {
                if (hits[i] == null) continue;
                var mb = hits[i].GetComponentsInParent<MonoBehaviour>();
                for (int j = 0; j < mb.Length; j++)
                {
                    if (mb[j] is IInteractable interactable && interactable.CanInteract(gameObject))
                    {
                        float d = (hits[i].transform.position - transform.position).sqrMagnitude;
                        if (d < best)
                        {
                            best = d;
                            bestTarget = interactable;
                        }
                        break;
                    }
                }
            }
            if (bestTarget == null) return false;
            bestTarget.Interact(gameObject);
            return true;
        }
    }
}
