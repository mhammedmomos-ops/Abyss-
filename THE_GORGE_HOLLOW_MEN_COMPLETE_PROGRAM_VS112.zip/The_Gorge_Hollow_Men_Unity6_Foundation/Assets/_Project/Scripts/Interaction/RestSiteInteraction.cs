using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Safe rest point: partial heal, injury treatment, stamina refill, optional campaign save.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class RestSiteInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string prompt = "Rest";
        [SerializeField] private float healAmount = 20f;
        [SerializeField] private float injuryTreatment = 15f;
        [SerializeField] private bool refillStamina = true;
        [SerializeField] private bool saveCampaign = true;
        [SerializeField] private float cooldownSeconds = 30f;
        [SerializeField] private GameBootstrap bootstrap;

        private float nextAllowedTime;

        public string InteractionPrompt => prompt;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        public bool CanInteract(GameObject interactor)
        {
            if (interactor == null || Time.time < nextAllowedTime) return false;
            PlayerVitals vitals = interactor.GetComponentInParent<PlayerVitals>();
            return vitals != null && !vitals.IsDead;
        }

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            PlayerVitals vitals = interactor.GetComponentInParent<PlayerVitals>();
            if (vitals == null) return;

            vitals.Heal(healAmount);
            vitals.TreatInjury(injuryTreatment);
            if (refillStamina)
            {
                // RecoverStamina is incremental; push toward full via repeated call approximation
                for (int i = 0; i < 20; i++) vitals.RecoverStamina(5f);
            }

            if (saveCampaign && bootstrap != null)
            {
                bootstrap.SavePlayerVitals(vitals);
                bootstrap.SaveCampaign();
            }

            nextAllowedTime = Time.time + Mathf.Max(0f, cooldownSeconds);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.UISave);
            MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
            TutorialHintUI.ShowHint("You rest and recover.", 2.5f);
        }
    }
}
