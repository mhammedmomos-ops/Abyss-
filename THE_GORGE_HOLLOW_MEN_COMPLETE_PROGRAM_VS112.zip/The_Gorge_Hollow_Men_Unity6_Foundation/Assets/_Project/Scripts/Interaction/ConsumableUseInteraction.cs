using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// World or inventory-style consumable: heal, treat injury, and/or restore stamina.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ConsumableUseInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string prompt = "Use supply";
        [SerializeField] private float healAmount = 15f;
        [SerializeField] private float injuryTreatment = 10f;
        [SerializeField] private float staminaPulses = 10f;
        [SerializeField] private bool disableRootOnUse = true;
        [SerializeField] private GameObject disableRoot;

        private bool used;

        public string InteractionPrompt => prompt;

        public bool CanInteract(GameObject interactor)
        {
            if (used || interactor == null) return false;
            var vitals = interactor.GetComponentInParent<PlayerVitals>();
            return vitals != null && !vitals.IsDead;
        }

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            var vitals = interactor.GetComponentInParent<PlayerVitals>();
            if (vitals == null) return;
            if (healAmount > 0f) vitals.Heal(healAmount);
            if (injuryTreatment > 0f) vitals.TreatInjury(injuryTreatment);
            if (staminaPulses > 0f)
            {
                for (int i = 0; i < 5; i++)
                    vitals.RecoverStamina(staminaPulses);
            }
            used = true;
            SimpleAudioCuePlayer.PlayCue(AudioCueId.Scavenge);
            MobileHaptics.PlayImpact(MobileHapticStrength.Light);
            GenericToastUI.Show("Supplies used", 1.2f);
            if (disableRootOnUse)
            {
                var root = disableRoot != null ? disableRoot : gameObject;
                root.SetActive(false);
            }
        }
    }
}
