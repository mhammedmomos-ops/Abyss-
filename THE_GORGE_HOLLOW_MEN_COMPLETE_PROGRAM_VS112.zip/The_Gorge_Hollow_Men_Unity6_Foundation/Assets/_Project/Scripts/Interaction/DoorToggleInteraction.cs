using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Simple open/close door or gate for base interiors / choke points.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class DoorToggleInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private Transform doorLeaf;
        [SerializeField] private Vector3 closedLocalEuler;
        [SerializeField] private Vector3 openLocalEuler = new Vector3(0f, 90f, 0f);
        [SerializeField] private float speed = 4f;
        [SerializeField] private string openPrompt = "Open";
        [SerializeField] private string closePrompt = "Close";
        [SerializeField] private Collider blockingCollider;

        private bool open;
        private Quaternion target;

        public string InteractionPrompt => open ? closePrompt : openPrompt;

        private void Awake()
        {
            if (doorLeaf == null) doorLeaf = transform;
            target = Quaternion.Euler(closedLocalEuler);
            doorLeaf.localRotation = target;
        }

        public bool CanInteract(GameObject interactor) => doorLeaf != null;

        public void Interact(GameObject interactor)
        {
            open = !open;
            target = Quaternion.Euler(open ? openLocalEuler : closedLocalEuler);
            if (blockingCollider != null) blockingCollider.enabled = !open;
            SimpleAudioCuePlayer.PlayCue(AudioCueId.UIClick);
            MobileHaptics.PlayImpact(MobileHapticStrength.Light);
        }

        private void Update()
        {
            if (doorLeaf == null) return;
            doorLeaf.localRotation = Quaternion.Slerp(doorLeaf.localRotation, target, 1f - Mathf.Exp(-speed * Time.deltaTime));
        }
    }
}
