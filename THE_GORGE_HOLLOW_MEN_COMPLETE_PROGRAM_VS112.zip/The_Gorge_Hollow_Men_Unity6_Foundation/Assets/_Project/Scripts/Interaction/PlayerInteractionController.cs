using UnityEngine;

namespace GorgeHollow
{
    public sealed class PlayerInteractionController : MonoBehaviour
    {
        [SerializeField] private Camera viewCamera;
        [SerializeField] private float interactionRange = 3f;
        [SerializeField] private LayerMask interactionLayers = ~0;
        public IInteractable CurrentTarget { get; private set; }
        public string CurrentPrompt => CurrentTarget != null ? CurrentTarget.InteractionPrompt : string.Empty;

        private void Awake() { if (viewCamera == null) viewCamera = Camera.main; }
        private void Update()
        {
            CurrentTarget = null;
            if (viewCamera == null) return;
            Ray ray = new Ray(viewCamera.transform.position, viewCamera.transform.forward);
            if (Physics.Raycast(ray, out RaycastHit hit, interactionRange, interactionLayers, QueryTriggerInteraction.Ignore))
            {
                MonoBehaviour[] components = hit.collider.GetComponentsInParent<MonoBehaviour>();
                foreach (MonoBehaviour component in components)
                    if (component is IInteractable interactable && interactable.CanInteract(gameObject)) { CurrentTarget = interactable; break; }
            }
            bool requested = MobileInputState.ConsumeInteract();
#if ENABLE_LEGACY_INPUT_MANAGER
            requested |= Input.GetKeyDown(KeyCode.E);
#endif
            if (requested && CurrentTarget != null) CurrentTarget.Interact(gameObject);
        }
    }
}
