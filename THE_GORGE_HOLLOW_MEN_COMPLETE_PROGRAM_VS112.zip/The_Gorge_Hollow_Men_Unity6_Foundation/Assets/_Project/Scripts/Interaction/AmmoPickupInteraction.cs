using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// World pickup that adds reserve ammo to the player's HitscanWeapon.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AmmoPickupInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private int ammoAmount = 12;
        [SerializeField] private string prompt = "Take ammunition";
        [SerializeField] private bool disableRootOnUse = true;
        [SerializeField] private GameObject disableRoot;

        private bool used;

        public string InteractionPrompt => prompt;

        public bool CanInteract(GameObject interactor)
        {
            if (used || interactor == null) return false;
            return interactor.GetComponentInParent<HitscanWeapon>() != null;
        }

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            HitscanWeapon weapon = interactor.GetComponentInParent<HitscanWeapon>();
            if (weapon == null) return;
            weapon.AddReserveAmmo(Mathf.Max(0, ammoAmount));
            used = true;
            SimpleAudioCuePlayer.PlayCue(AudioCueId.Scavenge);
            MobileHaptics.PlayImpact(MobileHapticStrength.Light);
            if (disableRootOnUse)
            {
                GameObject root = disableRoot != null ? disableRoot : gameObject;
                root.SetActive(false);
            }
        }
    }
}
