using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// World interactable that spends medical supplies to heal and treat injury.
    /// Uses existing campaign resource transactions via a caller-supplied cost; for simple
    /// prototype scenes it can also apply effects with zero resource cost.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class MedicalKitInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private float healAmount = 35f;
        [SerializeField] private float injuryTreatment = 25f;
        [SerializeField] private int medicalSupplyCost = 1;
        [SerializeField] private bool consumeOnUse = true;
        [SerializeField] private GameObject disableRootOnConsume;

        public string InteractionPrompt => "Use medical kit";

        public bool CanInteract(GameObject interactor)
        {
            if (interactor == null) return false;
            PlayerVitals vitals = interactor.GetComponentInParent<PlayerVitals>();
            if (vitals == null || vitals.IsDead) return false;
            return vitals.Health < 100f || vitals.Injury > 0f;
        }

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            PlayerVitals vitals = interactor.GetComponentInParent<PlayerVitals>();
            if (vitals == null) return;

            // Resource gate is intentionally light for this phase: if a GameBootstrap + campaign
            // is present, callers can extend with ResourceTransactionService. Prototype scenes
            // may leave medicalSupplyCost at 0 or ignore it.
            if (medicalSupplyCost > 0)
            {
                // Best-effort: only block when an explicit bootstrap campaign with insufficient
                // medical supplies is reachable. Otherwise allow treatment so isolated test
                // scenes remain usable.
                var bootstrap = Object.FindFirstObjectByType<GameBootstrap>();
                if (bootstrap != null && bootstrap.Campaign != null &&
                    bootstrap.Campaign.medicalSupplies < medicalSupplyCost)
                {
                    Debug.Log("Medical kit unavailable: insufficient medical supplies.", this);
                    return;
                }
                if (bootstrap != null && bootstrap.Campaign != null)
                {
                    bootstrap.Campaign.medicalSupplies -= medicalSupplyCost;
                    bootstrap.SaveCampaign();
                }
            }

            vitals.Heal(healAmount);
            vitals.TreatInjury(injuryTreatment);

            if (consumeOnUse)
            {
                GameObject root = disableRootOnConsume != null ? disableRootOnConsume : gameObject;
                root.SetActive(false);
            }
        }
    }
}
