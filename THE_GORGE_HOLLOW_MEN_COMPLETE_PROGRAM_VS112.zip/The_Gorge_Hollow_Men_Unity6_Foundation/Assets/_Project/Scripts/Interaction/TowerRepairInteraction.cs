using UnityEngine;

namespace GorgeHollow
{
    [RequireComponent(typeof(TowerStructure))]
    public sealed class TowerRepairInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField, Min(1)] private int repairPerUse = 35;
        [SerializeField, Min(0)] private int scrapCost = 8;
        [SerializeField, Min(0)] private int timberCost = 4;
        private TowerStructure structure;
        public string InteractionPrompt => structure != null && structure.IsDestroyed ? "Repair destroyed structure" : "Repair structure";
        private void Awake() => structure = GetComponent<TowerStructure>();
        public bool CanInteract(GameObject interactor) => structure != null && structure.enabled && structure.CurrentHealth < structure.MaximumHealth;
        public void Interact(GameObject interactor)
        {
            if (structure != null && !structure.TryRepair(repairPerUse, scrapCost, timberCost, out string error) && !string.IsNullOrEmpty(error))
                Debug.Log("Repair unavailable: " + error, this);
        }
    }
}
