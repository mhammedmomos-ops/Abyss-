using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Simple one-recipe crafting station (e.g. timber+scrap → ammo or medkits).
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class CraftingStationInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string prompt = "Craft supplies";
        [SerializeField] private string recipeId = "craft_ammo";
        [Header("Cost")]
        [SerializeField] private int costScrap = 3;
        [SerializeField] private int costTimber = 1;
        [Header("Yield")]
        [SerializeField] private int yieldAmmo = 8;
        [SerializeField] private int yieldMedical;
        [SerializeField] private GameBootstrap bootstrap;

        public string InteractionPrompt => prompt;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        public bool CanInteract(GameObject interactor)
        {
            if (bootstrap == null || bootstrap.Campaign == null) return false;
            var cost = new ResourceDelta { scrap = costScrap, timber = costTimber };
            var yield = new ResourceDelta { ammunition = yieldAmmo, medicalSupplies = yieldMedical };
            return CraftingRules.CanCraft(bootstrap.Campaign, cost, yield);
        }

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            var cost = new ResourceDelta { scrap = costScrap, timber = costTimber };
            var yield = new ResourceDelta { ammunition = yieldAmmo, medicalSupplies = yieldMedical };
            var delta = CraftingRules.Combine(cost, yield);
            string tx = "craft:" + recipeId + ":" + System.Guid.NewGuid().ToString("N");
            if (bootstrap.Transactions == null)
            {
                // Fallback direct apply
                bootstrap.Campaign.scrap -= costScrap;
                bootstrap.Campaign.timber -= costTimber;
                bootstrap.Campaign.ammunition += yieldAmmo;
                bootstrap.Campaign.medicalSupplies += yieldMedical;
                bootstrap.SaveCampaign();
            }
            else if (!bootstrap.Transactions.TryApply(bootstrap.Campaign, tx, delta, out string error))
            {
                Debug.Log("Craft failed: " + error, this);
                return;
            }
            else
            {
                bootstrap.SaveCampaign();
                CampaignEvents.RaiseTransactionCommitted(tx);
            }
            GenericToastUI.Show("Crafted supplies", 1.5f);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.Scavenge);
            MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
        }
    }
}
