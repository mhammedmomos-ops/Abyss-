using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Lightweight player preferences for mobile controls. No cloud sync.
    /// </summary>
    public static class MobileSettings
    {
        private const string LookSensitivityKey = "gh.lookSensitivity";
        private const string MasterVolumeKey = "gh.masterVolume";
        private const float DefaultLookSensitivity = 0.18f;
        private const float DefaultMasterVolume = 1f;

        public static float LookSensitivity
        {
            get => Mathf.Clamp(PlayerPrefs.GetFloat(LookSensitivityKey, DefaultLookSensitivity), 0.05f, 1f);
            set
            {
                PlayerPrefs.SetFloat(LookSensitivityKey, Mathf.Clamp(value, 0.05f, 1f));
                PlayerPrefs.Save();
            }
        }

        public static float MasterVolume
        {
            get => Mathf.Clamp01(PlayerPrefs.GetFloat(MasterVolumeKey, DefaultMasterVolume));
            set
            {
                float v = Mathf.Clamp01(value);
                PlayerPrefs.SetFloat(MasterVolumeKey, v);
                PlayerPrefs.Save();
                AudioListener.volume = v;
            }
        }

        public static void ApplyAudio()
        {
            AudioListener.volume = MasterVolume;
        }

        public static void ResetToDefaults()
        {
            LookSensitivity = DefaultLookSensitivity;
            MasterVolume = DefaultMasterVolume;
        }
    }

    /// <summary>Pure clamp helpers for settings UI and tests.</summary>
    public static class MobileSettingsRules
    {
        public static float ClampLookSensitivity(float value)
            => float.IsNaN(value) || float.IsInfinity(value) ? 0.18f : Mathf.Clamp(value, 0.05f, 1f);

        public static float ClampMasterVolume(float value)
            => float.IsNaN(value) || float.IsInfinity(value) ? 1f : Mathf.Clamp01(value);
    }
}
