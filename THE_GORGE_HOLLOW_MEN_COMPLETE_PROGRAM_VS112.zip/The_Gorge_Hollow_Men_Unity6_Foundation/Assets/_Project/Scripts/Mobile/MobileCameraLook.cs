using UnityEngine;
using UnityEngine.EventSystems;

namespace GorgeHollow
{
    // Attach to a transparent right-side UI drag panel, separate from action buttons.
    public sealed class MobileCameraLook : MonoBehaviour, IPointerDownHandler, IDragHandler
    {
        [SerializeField] private IsometricCameraFollow cameraFollow;
        [SerializeField] private float sensitivity = 0.18f;
        private Vector2 previousPosition;
        public void OnPointerDown(PointerEventData eventData) => previousPosition = eventData.position;
        public void OnDrag(PointerEventData eventData)
        {
            if (cameraFollow == null) return;
            Vector2 delta = eventData.position - previousPosition;
            previousPosition = eventData.position;
            float sens = sensitivity * (MobileSettings.LookSensitivity / 0.18f);
            cameraFollow.AddYaw(delta.x * sens);
        }

        public void SetBaseSensitivity(float value) => sensitivity = Mathf.Clamp(value, 0.05f, 1f);
    }
}
