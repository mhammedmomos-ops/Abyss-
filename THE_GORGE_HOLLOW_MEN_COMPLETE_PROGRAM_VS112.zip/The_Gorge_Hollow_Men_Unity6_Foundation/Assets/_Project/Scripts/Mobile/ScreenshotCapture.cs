using System.Collections;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Captures a PNG screenshot to persistent data for bug reports / share.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ScreenshotCapture : MonoBehaviour
    {
        [SerializeField] private string filePrefix = "gorge_shot_";

        public void Capture()
        {
            StartCoroutine(CaptureRoutine());
        }

        private IEnumerator CaptureRoutine()
        {
            yield return new WaitForEndOfFrame();
            string name = filePrefix + System.DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png";
            string path = System.IO.Path.Combine(Application.persistentDataPath, name);
            ScreenCapture.CaptureScreenshot(name);
            // ScreenCapture writes relative to persistentDataPath on mobile
            GenericToastUI.Show("Screenshot saved", 1.5f);
            Debug.Log("Screenshot requested: " + path);
        }
    }
}
