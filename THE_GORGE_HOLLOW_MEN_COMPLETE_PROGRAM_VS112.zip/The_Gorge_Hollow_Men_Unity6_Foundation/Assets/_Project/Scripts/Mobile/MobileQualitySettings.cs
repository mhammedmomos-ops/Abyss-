using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Mobile performance knobs persisted in PlayerPrefs.
    /// </summary>
    public static class MobileQualitySettings
    {
        private const string TargetFpsKey = "gh.targetFps";
        private const string ReducedEffectsKey = "gh.reducedEffects";

        public static int TargetFrameRate
        {
            get => PlayerPrefs.GetInt(TargetFpsKey, 60);
            set
            {
                int fps = MobileQualityRules.ClampTargetFps(value);
                PlayerPrefs.SetInt(TargetFpsKey, fps);
                PlayerPrefs.Save();
                Application.targetFrameRate = fps;
            }
        }

        public static bool ReducedEffects
        {
            get => PlayerPrefs.GetInt(ReducedEffectsKey, 0) != 0;
            set
            {
                PlayerPrefs.SetInt(ReducedEffectsKey, value ? 1 : 0);
                PlayerPrefs.Save();
            }
        }

        public static void Apply()
        {
            Application.targetFrameRate = TargetFrameRate;
            QualitySettings.vSyncCount = 0;
        }
    }

    public static class MobileQualityRules
    {
        public static int ClampTargetFps(int value)
        {
            if (value < 30) return 30;
            if (value > 120) return 120;
            // Snap to common mobile targets
            if (value < 45) return 30;
            if (value < 75) return 60;
            return 120;
        }
    }
}
