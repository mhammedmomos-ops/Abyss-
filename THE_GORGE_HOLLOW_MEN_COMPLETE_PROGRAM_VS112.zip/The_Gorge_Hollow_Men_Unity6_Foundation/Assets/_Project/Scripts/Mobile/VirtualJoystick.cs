using UnityEngine;
using UnityEngine.EventSystems;

namespace GorgeHollow
{
    public sealed class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        [SerializeField] private RectTransform background;
        [SerializeField] private RectTransform handle;
        [SerializeField, Range(0.1f, 1f)] private float handleRange = 0.65f;
        private Vector2 value;

        public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);
        public void OnDrag(PointerEventData eventData)
        {
            if (background == null || handle == null) return;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(background, eventData.position, eventData.pressEventCamera, out Vector2 local)) return;
            Vector2 half = background.rect.size * 0.5f;
            value = new Vector2(half.x > 0 ? local.x / half.x : 0f, half.y > 0 ? local.y / half.y : 0f);
            value = Vector2.ClampMagnitude(value, 1f);
            handle.anchoredPosition = new Vector2(value.x * half.x * handleRange, value.y * half.y * handleRange);
            MobileInputState.SetMove(value);
        }
        public void OnPointerUp(PointerEventData eventData) { value = Vector2.zero; MobileInputState.SetMove(value); if (handle != null) handle.anchoredPosition = Vector2.zero; }
        private void OnDisable() { MobileInputState.SetMove(Vector2.zero); }
    }
}
