using UnityEngine;
using UnityEngine.UI;

namespace GorgeHollow
{
    /// <summary>
    /// Simple in-menu calibrator: user drags, system suggests a sensitivity.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class LookSensitivityCalibrator : MonoBehaviour
    {
        [SerializeField] private Text instructionLabel;
        [SerializeField] private Slider resultSlider;
        [SerializeField] private float sampleSeconds = 3f;
        private float sampleAccum;
        private float dragAccum;
        private bool sampling;

        public void BeginSample()
        {
            sampling = true;
            sampleAccum = 0f;
            dragAccum = 0f;
            if (instructionLabel != null)
                instructionLabel.text = "Drag look pad for a few seconds…";
        }

        public void ReportDragMagnitude(float magnitude)
        {
            if (!sampling) return;
            dragAccum += Mathf.Abs(magnitude);
        }

        private void Update()
        {
            if (!sampling) return;
            sampleAccum += Time.unscaledDeltaTime;
            if (sampleAccum < sampleSeconds) return;
            sampling = false;
            // Map average drag to a sensitivity suggestion
            float avg = dragAccum / Mathf.Max(0.01f, sampleSeconds);
            float suggested = MobileSettingsRules.ClampLookSensitivity(0.12f + avg * 0.002f);
            MobileSettings.LookSensitivity = suggested;
            if (resultSlider != null) resultSlider.SetValueWithoutNotify(suggested);
            if (instructionLabel != null)
                instructionLabel.text = "Suggested sensitivity: " + suggested.ToString("0.00");
        }
    }
}
