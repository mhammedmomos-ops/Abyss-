using UnityEngine;

namespace GorgeHollow
{
    public enum MobileHapticStrength { Light, Medium, Heavy }

    /// <summary>
    /// Thin wrapper around handheld vibration. No-ops on unsupported platforms.
    /// </summary>
    public static class MobileHaptics
    {
        public static bool Enabled { get; set; } = true;

        public static void PlayImpact(MobileHapticStrength strength)
        {
            if (!Enabled) return;
#if UNITY_ANDROID || UNITY_IOS
            // Handheld.Vibrate is the only built-in cross-mobile API without extra packages.
            // Strength is not differentiated by the stock API; call still provides feedback.
            try { Handheld.Vibrate(); }
            catch { /* ignored on editor / unsupported */ }
#else
            // Editor / desktop: no-op
#endif
        }
    }
}
