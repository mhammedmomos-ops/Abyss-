using UnityEngine;

namespace GorgeHollow
{
    // Shared touch state. UI controls write here; gameplay systems read it.
    public static class MobileInputState
    {
        public static Vector2 Move { get; private set; }
        public static bool SprintHeld { get; private set; }
        public static bool FireHeld { get; private set; }
        private static bool firePressed;
        public static bool ReloadPressed { get; private set; }
        public static bool InteractPressed { get; private set; }
        public static bool DodgePressed { get; private set; }
        public static void SetMove(Vector2 value) => Move = Vector2.ClampMagnitude(value, 1f);
        public static void SetSprint(bool value) => SprintHeld = value;
        public static void SetFire(bool value) { if (value && !FireHeld) firePressed = true; FireHeld = value; }
        public static bool ConsumeFirePressed() { bool value = firePressed; firePressed = false; return value; }
        public static void PressReload() => ReloadPressed = true;
        public static void PressInteract() => InteractPressed = true;
        public static void PressDodge() => DodgePressed = true;
        public static bool ConsumeReload() { bool value = ReloadPressed; ReloadPressed = false; return value; }
        public static bool ConsumeInteract() { bool value = InteractPressed; InteractPressed = false; return value; }
        public static bool ConsumeDodge() { bool value = DodgePressed; DodgePressed = false; return value; }
        public static void ResetAll() { Move = Vector2.zero; SprintHeld = false; FireHeld = false; firePressed = false; ReloadPressed = false; InteractPressed = false; DodgePressed = false; }
    }
}
