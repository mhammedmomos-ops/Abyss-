using UnityEngine;
using UnityEngine.EventSystems;

namespace GorgeHollow
{
    public enum MobileAction { Sprint, Fire, Reload, Interact, Dodge }
    public sealed class MobileActionButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
    {
        [SerializeField] private MobileAction action;
        public void OnPointerDown(PointerEventData eventData)
        {
            if (action == MobileAction.Sprint) MobileInputState.SetSprint(true);
            else if (action == MobileAction.Fire) MobileInputState.SetFire(true);
            else if (action == MobileAction.Reload) MobileInputState.PressReload();
            else if (action == MobileAction.Dodge) MobileInputState.PressDodge();
            else MobileInputState.PressInteract();
        }
        public void OnPointerUp(PointerEventData eventData)
        {
            if (action == MobileAction.Sprint) MobileInputState.SetSprint(false);
            if (action == MobileAction.Fire) MobileInputState.SetFire(false);
        }
        private void OnDisable() { if (action == MobileAction.Sprint) MobileInputState.SetSprint(false); if (action == MobileAction.Fire) MobileInputState.SetFire(false); }
    }
}
