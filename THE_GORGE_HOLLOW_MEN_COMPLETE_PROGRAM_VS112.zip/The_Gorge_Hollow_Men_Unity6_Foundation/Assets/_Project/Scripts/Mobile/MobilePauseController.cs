using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Simple mobile pause: freezes time scale and can show a pause root panel.
    /// Wire a UI button to TogglePause. Does not implement full settings menus.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class MobilePauseController : MonoBehaviour
    {
        [SerializeField] private GameObject pausePanel;
        [SerializeField] private KeyCode editorToggleKey = KeyCode.Escape;
        [SerializeField] private bool pauseAudioListener = true;

        private bool paused;
        private float previousTimeScale = 1f;

        public bool IsPaused => paused;

        private void Update()
        {
#if ENABLE_LEGACY_INPUT_MANAGER
            if (Input.GetKeyDown(editorToggleKey))
                TogglePause();
#endif
        }

        public void TogglePause()
        {
            if (paused) Resume();
            else Pause();
        }

        public void Pause()
        {
            if (paused) return;
            previousTimeScale = Time.timeScale;
            if (previousTimeScale <= 0f) previousTimeScale = 1f;
            Time.timeScale = 0f;
            paused = true;
            if (pausePanel != null) pausePanel.SetActive(true);
            if (pauseAudioListener) AudioListener.pause = true;
        }

        public void Resume()
        {
            if (!paused) return;
            Time.timeScale = previousTimeScale > 0f ? previousTimeScale : 1f;
            paused = false;
            if (pausePanel != null) pausePanel.SetActive(false);
            if (pauseAudioListener) AudioListener.pause = false;
        }

        public void SaveAndResume(GameBootstrap bootstrap)
        {
            if (bootstrap != null) bootstrap.SaveCampaign();
            Resume();
        }

        private void OnDisable()
        {
            if (paused) Resume();
        }
    }
}
