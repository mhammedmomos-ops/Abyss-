using System;
using System.IO;
using UnityEngine;

namespace GorgeHollow
{
    public sealed class CampaignSaveService
    {
        public const int CurrentSaveVersion = 15;
        private readonly string primaryPath;
        private readonly string backupPath;
        private readonly string temporaryPath;
        private readonly string displacedPath;

        public bool HasValidSave =>
            ReadAndValidate(primaryPath, out _) != null || ReadAndValidate(backupPath, out _) != null;

        public CampaignSaveService(string directory = null, string fileName = "campaign_save.json")
        {
            string root = string.IsNullOrWhiteSpace(directory) ? Application.persistentDataPath : directory;
            Directory.CreateDirectory(root);
            primaryPath = Path.Combine(root, fileName);
            backupPath = primaryPath + ".bak";
            temporaryPath = primaryPath + ".tmp";
            displacedPath = primaryPath + ".old";
        }

        public bool Save(CampaignState state, out string error)
        {
            error = null;
            if (state == null || !state.IsValid(out error)) return false;
            bool primaryIsNewer = IsNewerSave(primaryPath, out int primaryVersion);
            bool backupIsNewer = IsNewerSave(backupPath, out int backupVersion);
            if (primaryIsNewer || backupIsNewer)
            {
                int newerVersion = Math.Max(primaryVersion, backupVersion);
                error = "A campaign save was created by a newer game version (save schema " + newerVersion + "); refusing to overwrite it.";
                return false;
            }
            state.saveVersion = CurrentSaveVersion;
            try
            {
                File.WriteAllText(temporaryPath, JsonUtility.ToJson(state, true));
                CampaignState verification = ReadAndValidate(temporaryPath, out error);
                if (verification == null) return false;

                // Establish a verified backup before moving the current primary out of the way.
                if (File.Exists(primaryPath))
                {
                    string backupCandidate = backupPath + ".tmp";
                    File.Copy(primaryPath, backupCandidate, true);
                    if (ReadAndValidate(backupCandidate, out string backupError) != null)
                    {
                        // A valid primary becomes the new last-known-good backup.
                        if (File.Exists(backupPath)) File.Delete(backupPath);
                        File.Move(backupCandidate, backupPath);
                    }
                    else
                    {
                        // Never replace a verified backup with a corrupt primary. A new save may
                        // still be committed if the existing backup is independently recoverable.
                        if (ReadAndValidate(backupPath, out string existingBackupError) == null)
                        {
                            if (File.Exists(backupCandidate)) File.Delete(backupCandidate);
                            error = "Primary save is invalid and no verified backup exists. Primary: " +
                                    backupError + " Backup: " + existingBackupError;
                            return false;
                        }
                        if (File.Exists(backupCandidate)) File.Delete(backupCandidate);
                    }
                    if (File.Exists(displacedPath)) File.Delete(displacedPath);
                    File.Move(primaryPath, displacedPath);
                }

                try
                {
                    File.Move(temporaryPath, primaryPath);
                }
                catch
                {
                    // Roll back if promotion fails. The verified .bak remains as a second recovery path.
                    if (!File.Exists(primaryPath) && File.Exists(displacedPath)) File.Move(displacedPath, primaryPath);
                    throw;
                }

                if (File.Exists(displacedPath)) File.Delete(displacedPath);
                CampaignEvents.RaiseCampaignSaved(primaryPath);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        public CampaignState Load(out string error)
        {
            CampaignState loaded = ReadAndValidate(primaryPath, out error);
            if (loaded != null) return loaded;
            string primaryError = error;
            CampaignState backup = ReadAndValidate(backupPath, out error);
            if (backup != null)
            {
                error = "Primary save was invalid; loaded last-known-good backup. " + primaryError;
                return backup;
            }
            error = "No valid campaign save was recovered. Primary: " + primaryError + " Backup: " + error;
            return null;
        }

        private static bool IsNewerSave(string path, out int version)
        {
            version = 0;
            if (!File.Exists(path)) return false;
            try
            {
                CampaignState state = JsonUtility.FromJson<CampaignState>(File.ReadAllText(path));
                if (state == null) return false;
                version = state.saveVersion;
                return version > CurrentSaveVersion;
            }
            catch
            {
                return false;
            }
        }

        private static CampaignState ReadAndValidate(string path, out string error)
        {
            error = null;
            if (!File.Exists(path)) { error = "File does not exist: " + path; return null; }
            try
            {
                CampaignState state = JsonUtility.FromJson<CampaignState>(File.ReadAllText(path));
                if (state == null) { error = "Save could not be deserialized."; return null; }
                if (state.saveVersion > CurrentSaveVersion) { error = "Save was created by a newer game version; refusing downgrade."; return null; }
                if (state.saveVersion == 1)
                {
                    // v1 had no persistent monster nests. Existing campaign progress remains intact.
                    state.monsterNests = new System.Collections.Generic.List<MonsterNestRecord>();
                    state.saveVersion = 2;
                }
                if (state.saveVersion == 2)
                {
                    // v2 had persistent nest health but no learned defensive-intelligence records.
                    if (state.monsterNests == null) state.monsterNests = new System.Collections.Generic.List<MonsterNestRecord>();
                    foreach (MonsterNestRecord nest in state.monsterNests)
                        if (nest != null && nest.learnedHazards == null)
                            nest.learnedHazards = new System.Collections.Generic.List<MonsterHazardRecord>();
                    state.saveVersion = 3;
                }
                if (state.saveVersion == 3)
                {
                    // v3 had persistent trap knowledge but no observed siege-efficiency memory.
                    if (state.monsterNests == null) state.monsterNests = new System.Collections.Generic.List<MonsterNestRecord>();
                    foreach (MonsterNestRecord nest in state.monsterNests)
                        if (nest != null && nest.learnedSiegeTargets == null)
                            nest.learnedSiegeTargets = new System.Collections.Generic.List<MonsterSiegeObservationRecord>();
                    state.saveVersion = 4;
                }
                if (state.saveVersion == 4)
                {
                    // v4 predates companion hunger and pet-food inventory. Preserve existing pets as fed.
                    if (state.animals == null) state.animals = new System.Collections.Generic.List<AnimalRecord>();
                    foreach (AnimalRecord animal in state.animals)
                        if (animal != null) animal.hunger = 100;
                    state.petFood = 0;
                    state.saveVersion = 5;
                }
                if (state.saveVersion == 5)
                {
                    // v5 introduced hunger but did not track time spent at zero. Existing saves
                    // receive a fresh starvation grace period rather than being killed on load.
                    if (state.animals == null) state.animals = new System.Collections.Generic.List<AnimalRecord>();
                    foreach (AnimalRecord animal in state.animals)
                        if (animal != null) animal.starvationDaysAtZero = 0;
                    state.saveVersion = 6;
                }
                if (state.saveVersion == 6)
                {
                    // v6 had no persistent convoy manifest. Existing campaign resources remain unchanged.
                    state.supplyConvoys = new System.Collections.Generic.List<SupplyConvoyRecord>();
                    state.saveVersion = 7;
                }
                if (state.saveVersion == 7)
                {
                    // v7 used a shared resource pool. Preserve it unchanged; new isolated tower depots start empty.
                    state.towerDepots = TowerDepotRules.CreateStartingDepots();
                    state.saveVersion = 8;
                }
                if (state.saveVersion == 8)
                {
                    // v8 convoy records predate physical inter-tower transfer metadata.
                    // Existing convoys remain ordinary supply deliveries; no stock is debited or duplicated.
                    if (state.supplyConvoys == null) state.supplyConvoys = new System.Collections.Generic.List<SupplyConvoyRecord>();
                    foreach (SupplyConvoyRecord convoy in state.supplyConvoys)
                        if (convoy != null) { convoy.isInterTowerTransfer = false; convoy.originTowerId = null; convoy.bridgeCrossingStartWaypointIndex = 0; convoy.bridgeCrossingEndWaypointIndex = 0; }
                    state.saveVersion = 9;
                }
                if (state.saveVersion == 9)
                {
                    // v9 predates persistent tower production queues; preserve depots and initialize an empty queue.
                    if (state.towerProductionJobs == null) state.towerProductionJobs = new System.Collections.Generic.List<TowerProductionJobRecord>();
                    state.saveVersion = 10;
                }
                if (state.saveVersion == 10)
                {
                    // v10 predates persistent tower workforce records. Existing campaigns receive an empty roster.
                    if (state.towerWorkers == null) state.towerWorkers = new System.Collections.Generic.List<TowerWorkerRecord>();
                    state.saveVersion = 11;
                }
                if (state.saveVersion == 11)
                {
                    // v11 workers predate persistent raid-response state. Preserve assignments and start in normal posture.
                    if (state.towerWorkers == null) state.towerWorkers = new System.Collections.Generic.List<TowerWorkerRecord>();
                    foreach (TowerWorkerRecord worker in state.towerWorkers)
                    {
                        if (worker == null) continue;
                        worker.tacticalState = TowerWorkerTacticalState.Normal;
                        worker.preRaidAssignment = worker.assignment;
                        worker.playerOverrideDuringRaid = false;
                    }
                    state.saveVersion = 12;
                }
                if (state.saveVersion == 12)
                {
                    // v12 predates morale, loyalty and stress. Start workers at neutral, stable values.
                    if (state.towerWorkers == null) state.towerWorkers = new System.Collections.Generic.List<TowerWorkerRecord>();
                    foreach (TowerWorkerRecord worker in state.towerWorkers)
                    {
                        if (worker == null) continue;
                        worker.morale = 70;
                        worker.loyalty = 50;
                        worker.stress = 0;
                        worker.recoveryMinutes = 0;
                    }
                    state.saveVersion = 13;
                }
                if (state.saveVersion == 13)
                {
                    // v13 predates persistent social bonds and worker personality traits.
                    // Preserve all existing morale/loyalty/stress values; initialize relationships empty.
                    if (state.towerWorkers == null) state.towerWorkers = new System.Collections.Generic.List<TowerWorkerRecord>();
                    foreach (TowerWorkerRecord worker in state.towerWorkers)
                        if (worker != null) worker.personality = TowerWorkerPersonality.Balanced;
                    state.workerRelationships = new System.Collections.Generic.List<TowerWorkerRelationshipRecord>();
                    state.saveVersion = 14;
                }
                if (state.saveVersion == 14)
                {
                    // v14 could represent a campaign created before the starter workforce was introduced.
                    // Seed only a truly empty roster; existing, injured, captured and dead worker records remain untouched.
                    if (state.towerWorkers == null) state.towerWorkers = new System.Collections.Generic.List<TowerWorkerRecord>();
                    bool hasRecordedWorker = state.towerWorkers.Exists(worker => worker != null && !string.IsNullOrWhiteSpace(worker.identity));
                    if (!hasRecordedWorker) state.towerWorkers = CampaignStateFactory.CreateStartingWorkers();
                    state.saveVersion = 15;
                }
                if (state.saveVersion != CurrentSaveVersion) { error = "Unsupported save version; no safe migration is available."; return null; }
                if (!state.IsValid(out error)) return null;
                return state;
            }
            catch (Exception ex) { error = ex.Message; return null; }
        }
    }
}
