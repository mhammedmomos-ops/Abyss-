using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Bridges authored scene nests to the campaign save. Assign one instance beside GameBootstrap.</summary>
    public sealed class MonsterNestPersistenceService : MonoBehaviour
    {
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private MonsterNest[] nests;
        [Tooltip("Automatically save nest changes. Repeated changes are coalesced to reduce mobile storage writes.")]
        [SerializeField] private bool saveImmediatelyOnNestChange = true;
        [SerializeField, Min(0.05f)] private float saveDebounceSeconds = 0.65f;
        private Coroutine pendingSaveRoutine;
        private readonly Dictionary<string, MonsterNestRecord> loadedRecords = new Dictionary<string, MonsterNestRecord>();

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            if (bootstrap == null || bootstrap.Campaign == null)
            {
                Debug.LogError("MonsterNestPersistenceService requires an active GameBootstrap.", this);
                enabled = false;
                return;
            }
            if (nests == null || nests.Length == 0) nests = FindObjectsByType<MonsterNest>(FindObjectsSortMode.None);
            List<MonsterNestRecord> records = bootstrap.Campaign.monsterNests;
            if (records != null)
            {
                foreach (MonsterNestRecord record in records)
                    if (record != null && !string.IsNullOrWhiteSpace(record.identity) && !loadedRecords.ContainsKey(record.identity))
                        loadedRecords.Add(record.identity, record);
            }
            foreach (MonsterNest nest in nests)
            {
                if (nest == null) continue;
                if (string.IsNullOrWhiteSpace(nest.Identity))
                {
                    Debug.LogError("Every authored MonsterNest needs a stable, unique Nest ID.", nest);
                    continue;
                }
                if (loadedRecords.TryGetValue(nest.Identity, out MonsterNestRecord record)) nest.Restore(record);
            }
            ValidateSceneIdentities();
        }

        private void OnEnable() { MonsterNest.StateChanged += OnNestChanged; }
        private void OnDisable()
        {
            MonsterNest.StateChanged -= OnNestChanged;
            FlushPendingSave();
        }

        private void OnApplicationPause(bool paused)
        {
            if (paused) FlushPendingSave();
        }

        private void OnApplicationQuit() { FlushPendingSave(); }

        public bool SaveNestState()
        {
            if (bootstrap == null || bootstrap.Campaign == null) return false;
            var snapshot = new List<MonsterNestRecord>();
            var seen = new HashSet<string>();
            foreach (MonsterNest nest in nests)
            {
                if (nest == null || string.IsNullOrWhiteSpace(nest.Identity)) continue;
                if (!seen.Add(nest.Identity))
                {
                    Debug.LogError("Duplicate MonsterNest ID prevents a safe save: " + nest.Identity, nest);
                    return false;
                }
                snapshot.Add(nest.Capture());
            }
            bootstrap.Campaign.monsterNests = snapshot;
            return bootstrap.SaveCampaign();
        }

        private void OnNestChanged(MonsterNest changed)
        {
            if (!saveImmediatelyOnNestChange || changed == null || !isActiveAndEnabled) return;
            if (pendingSaveRoutine != null) StopCoroutine(pendingSaveRoutine);
            pendingSaveRoutine = StartCoroutine(SaveAfterChanges());
        }

        private IEnumerator SaveAfterChanges()
        {
            yield return new WaitForSecondsRealtime(Mathf.Max(0.05f, saveDebounceSeconds));
            pendingSaveRoutine = null;
            SaveNestState();
        }

        private void FlushPendingSave()
        {
            if (pendingSaveRoutine == null) return;
            StopCoroutine(pendingSaveRoutine);
            pendingSaveRoutine = null;
            SaveNestState();
        }

        private void ValidateSceneIdentities()
        {
            var ids = new HashSet<string>();
            foreach (MonsterNest nest in nests)
            {
                if (nest == null) continue;
                if (!ids.Add(nest.Identity)) Debug.LogError("Duplicate MonsterNest ID in scene: " + nest.Identity, nest);
            }
        }
    }
}
