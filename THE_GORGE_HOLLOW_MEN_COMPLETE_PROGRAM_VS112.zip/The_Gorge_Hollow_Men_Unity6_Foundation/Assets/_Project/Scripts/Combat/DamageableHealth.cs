using System;
using UnityEngine;

namespace GorgeHollow
{
    public sealed class DamageableHealth : MonoBehaviour, IDamageable
    {
        [SerializeField] private float maximumHealth = 100f;
        [SerializeField] private bool destroyOnDeath;
        private float currentHealth;
        public float CurrentHealth => currentHealth;
        public float MaximumHealth => Mathf.Max(1f, maximumHealth);
        public float HealthFraction => Mathf.Clamp01(currentHealth / MaximumHealth);
        public bool IsDead => currentHealth <= 0f;
        public event Action<float> HealthChanged;
        public event Action<float, Vector3, Vector3, GameObject> DamageReceived;
        public event Action<GameObject> Killed;
        private void Awake() { currentHealth = Mathf.Max(1f, maximumHealth); }
        public void ApplyDamage(float amount, Vector3 hitPoint, Vector3 hitDirection, GameObject source)
        {
            if (IsDead || amount <= 0f) return;
            currentHealth = Mathf.Max(0f, currentHealth - amount);
            DamageReceived?.Invoke(amount, hitPoint, hitDirection, source);
            HealthChanged?.Invoke(currentHealth);
            if (currentHealth <= 0f)
            {
                Killed?.Invoke(source);
                if (destroyOnDeath) Destroy(gameObject);
            }
        }
        public void ResetHealth() { currentHealth = Mathf.Max(1f, maximumHealth); }
    }
}
