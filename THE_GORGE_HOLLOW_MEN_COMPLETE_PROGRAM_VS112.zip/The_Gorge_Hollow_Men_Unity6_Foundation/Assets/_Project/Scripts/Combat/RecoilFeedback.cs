using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Applies light camera trauma when the player fires.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class RecoilFeedback : MonoBehaviour
    {
        [SerializeField] private HitscanWeapon weapon;
        [SerializeField] private float traumaPerShot = 0.12f;
        [SerializeField] private float hapticEveryNShots = 1f;
        private int magazineSeen = -1;

        private void Awake()
        {
            if (weapon == null) weapon = GetComponent<HitscanWeapon>();
        }

        private void LateUpdate()
        {
            if (weapon == null) return;
            int mag = weapon.MagazineAmmo;
            if (magazineSeen < 0) { magazineSeen = mag; return; }
            if (mag < magazineSeen)
            {
                CameraShake.Shake(traumaPerShot);
                MobileHaptics.PlayImpact(MobileHapticStrength.Light);
            }
            magazineSeen = mag;
        }
    }
}
