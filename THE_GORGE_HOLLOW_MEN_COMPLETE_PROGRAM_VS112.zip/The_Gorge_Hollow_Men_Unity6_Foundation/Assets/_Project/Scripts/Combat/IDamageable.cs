namespace GorgeHollow
{
    public interface IDamageable
    {
        void ApplyDamage(float amount, UnityEngine.Vector3 hitPoint, UnityEngine.Vector3 hitDirection, UnityEngine.GameObject source);
    }
}
