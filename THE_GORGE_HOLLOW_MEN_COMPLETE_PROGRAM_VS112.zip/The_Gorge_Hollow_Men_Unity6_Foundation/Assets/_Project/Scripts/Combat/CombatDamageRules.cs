using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Sanitizes weapon and weak-point damage before it reaches a damage receiver.</summary>
    public static class CombatDamageRules
    {
        public static float CalculateDamage(float baseDamage, float weakPointMultiplier)
        {
            if (float.IsNaN(baseDamage) || float.IsInfinity(baseDamage) || baseDamage <= 0f) return 0f;
            if (float.IsNaN(weakPointMultiplier) || float.IsInfinity(weakPointMultiplier)) weakPointMultiplier = 1f;
            return Mathf.Clamp(baseDamage * Mathf.Max(1f, weakPointMultiplier), 0f, 100000f);
        }
    }
}
