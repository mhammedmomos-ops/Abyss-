using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Short-range melee bash on Interact when no other interactable is targeted.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class MeleeBashInteraction : MonoBehaviour
    {
        [SerializeField] private PlayerInteractionController interaction;
        [SerializeField] private Transform origin;
        [SerializeField] private float range = 1.8f;
        [SerializeField] private float damage = 18f;
        [SerializeField] private float cooldown = 0.7f;
        [SerializeField] private LayerMask hitMask = ~0;
        private float nextTime;

        private void Awake()
        {
            if (interaction == null) interaction = GetComponent<PlayerInteractionController>();
            if (origin == null) origin = transform;
        }

        private void Update()
        {
            if (Time.time < nextTime) return;
            if (interaction != null && interaction.CurrentTarget != null) return;
            if (!MobileInputState.ConsumeInteract()) return;
            TryBash();
        }

        public void TryBash()
        {
            if (Time.time < nextTime) return;
            nextTime = Time.time + cooldown;
            Vector3 dir = origin.forward;
            if (Physics.SphereCast(origin.position, 0.35f, dir, out RaycastHit hit, range, hitMask, QueryTriggerInteraction.Ignore))
            {
                var health = hit.collider.GetComponentInParent<DamageableHealth>();
                if (health != null && !health.IsDead)
                {
                    health.ApplyDamage(damage, hit.point, dir, gameObject);
                    HitMarkerUI.Pulse();
                    CameraShake.Shake(0.15f);
                    MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
                    SimpleAudioCuePlayer.PlayCue(AudioCueId.WeaponFire);
                    return;
                }
            }
            MobileHaptics.PlayImpact(MobileHapticStrength.Light);
        }
    }
}
