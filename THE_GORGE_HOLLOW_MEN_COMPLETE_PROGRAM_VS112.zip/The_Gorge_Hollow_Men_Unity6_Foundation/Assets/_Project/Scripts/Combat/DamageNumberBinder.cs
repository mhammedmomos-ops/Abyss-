using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Listens to a DamageableHealth and forwards damage deltas to DamageNumberSpawner.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class DamageNumberBinder : MonoBehaviour
    {
        [SerializeField] private DamageableHealth health;
        [SerializeField] private DamageNumberSpawner spawner;
        private float last;

        private void Awake()
        {
            if (health == null) health = GetComponent<DamageableHealth>();
            if (spawner == null) spawner = FindFirstObjectByType<DamageNumberSpawner>();
        }

        private void OnEnable()
        {
            if (health == null) return;
            last = health.CurrentHealth;
            health.HealthChanged += OnHealth;
        }

        private void OnDisable()
        {
            if (health != null) health.HealthChanged -= OnHealth;
        }

        private void OnHealth(float current)
        {
            float delta = last - current;
            last = current;
            if (delta > 0.1f && spawner != null)
                spawner.Show(transform.position, delta);
        }
    }
}
