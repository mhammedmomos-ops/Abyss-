using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Shows hit feedback only after HitscanWeapon confirms a damage receiver was struck.</summary>
    [DisallowMultipleComponent]
    public sealed class HitMarkerBinder : MonoBehaviour
    {
        [SerializeField] private HitscanWeapon weapon;
        private void Awake()
        {
            if (weapon == null) weapon = GetComponent<HitscanWeapon>();
        }
        private void OnEnable()
        {
            if (weapon != null) weapon.ConfirmedHit += OnConfirmedHit;
        }
        private void OnDisable()
        {
            if (weapon != null) weapon.ConfirmedHit -= OnConfirmedHit;
        }
        private void OnConfirmedHit(Collider target, float damage, bool weakPoint)
        {
            HitMarkerUI.Pulse();
        }
    }
}
