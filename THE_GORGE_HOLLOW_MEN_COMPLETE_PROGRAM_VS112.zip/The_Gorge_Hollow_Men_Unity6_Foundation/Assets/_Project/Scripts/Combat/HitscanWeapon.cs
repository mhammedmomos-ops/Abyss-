using System;
using System.Collections;
using UnityEngine;

namespace GorgeHollow
{
    public sealed class HitscanWeapon : MonoBehaviour
    {
        [SerializeField] private WeaponDefinition definition;
        [SerializeField] private Transform muzzle;
        [SerializeField] private Camera aimCamera;
        [SerializeField] private int reserveAmmo = 48;
        [SerializeField] private bool startWithFullMagazine = true;
        [SerializeField] private ParticleSystem muzzleFlash;
        [SerializeField] private AudioSource shotAudio;
        private int magazineAmmo;
        private float nextFireTime;
        private bool reloading;
        public int MagazineAmmo => magazineAmmo;
        public int ReserveAmmo => reserveAmmo;
        public bool IsReloading => reloading;
        public WeaponDefinition Definition => definition;
        public event Action<Collider, float, bool> ConfirmedHit;

        private void Awake()
        {
            if (aimCamera == null) aimCamera = Camera.main;
            magazineAmmo = startWithFullMagazine && definition != null ? definition.MagazineCapacity : 0;
        }
        private void Update()
        {
            if (definition == null || reloading) return;
            bool touchFirePressed = MobileInputState.ConsumeFirePressed();
            bool fire = definition.Automatic ? MobileInputState.FireHeld : touchFirePressed;
#if ENABLE_LEGACY_INPUT_MANAGER
            fire |= definition.Automatic ? Input.GetButton("Fire1") : Input.GetButtonDown("Fire1");
#endif
            if (fire && Time.time >= nextFireTime) TryFire();
            bool reload = MobileInputState.ConsumeReload();
#if ENABLE_LEGACY_INPUT_MANAGER
            reload |= Input.GetKeyDown(KeyCode.R);
#endif
            if (reload) TryReload();
        }

        public bool TryFire()
        {
            if (definition == null || reloading || magazineAmmo <= 0 || Time.time < nextFireTime) return false;
            if (aimCamera == null) return false;
            magazineAmmo--;
            nextFireTime = Time.time + 1f / definition.ShotsPerSecond;
            if (muzzleFlash != null) muzzleFlash.Play();
            if (shotAudio != null) shotAudio.Play();
            MonsterStimulusBus.Emit(MonsterStimulusKind.Gunshot, transform.position,
                definition.NoiseLoudness, gameObject);
            Ray ray = aimCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
            Vector3 origin = muzzle != null ? muzzle.position : ray.origin;
            Vector3 direction = (ray.GetPoint(definition.Range) - origin).normalized;
            if (Physics.Raycast(origin, direction, out RaycastHit hit, definition.Range, definition.HitMask, QueryTriggerInteraction.Ignore))
            {
                MonoBehaviour[] components = hit.collider.GetComponentsInParent<MonoBehaviour>();
                float weakPointMultiplier = WeakPointBonus.TryGetMultiplier(hit.collider, out float configuredMultiplier)
                    ? configuredMultiplier : 1f;
                float appliedDamage = CombatDamageRules.CalculateDamage(definition.Damage, weakPointMultiplier);
                // VS74 — short player damage bonus after a companion weak-point callout
                appliedDamage = AnimalWeakPointCalloutState.ModifyDamage(appliedDamage, Time.time);
                // VS86 — coordinated companion support is scoped to the exact monster target.
                MonsterAIController hitMonster = hit.collider.GetComponentInParent<MonsterAIController>();
                if (hitMonster != null)
                    appliedDamage = AnimalTeamworkState.ModifyDamage(hitMonster.transform, appliedDamage, Time.time);
                foreach (MonoBehaviour component in components)
                {
                    if (component is IDamageable damageable)
                    {
                        if (appliedDamage > 0f)
                        {
                            damageable.ApplyDamage(appliedDamage, hit.point, direction, gameObject);
                            ConfirmedHit?.Invoke(hit.collider, appliedDamage, weakPointMultiplier > 1f);
                        }
                        break;
                    }
                }
            }
            return true;
        }

        public bool TryReload()
        {
            if (definition == null || reloading || magazineAmmo >= definition.MagazineCapacity || reserveAmmo <= 0) return false;
            StartCoroutine(ReloadRoutine());
            return true;
        }
        private IEnumerator ReloadRoutine()
        {
            reloading = true;
            yield return new WaitForSeconds(definition.ReloadDuration);
            int needed = definition.MagazineCapacity - magazineAmmo;
            int loaded = Mathf.Min(needed, reserveAmmo);
            magazineAmmo += loaded;
            reserveAmmo -= loaded;
            reloading = false;
        }
        public void AddReserveAmmo(int amount) { reserveAmmo = Mathf.Max(0, reserveAmmo + amount); }
        public void RestoreAmmo(int magazine, int reserve)
        {
            if (definition == null) return;
            magazineAmmo = Mathf.Clamp(magazine, 0, definition.MagazineCapacity);
            reserveAmmo = Mathf.Max(0, reserve);
        }
    }
}
