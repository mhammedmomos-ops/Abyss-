using UnityEngine;

namespace GorgeHollow
{
    [CreateAssetMenu(menuName = "The Gorge/Weapon Definition", fileName = "WeaponDefinition")]
    public sealed class WeaponDefinition : ScriptableObject
    {
        [SerializeField] private string weaponId = "sidearm";
        [SerializeField] private float damage = 25f;
        [SerializeField] private float range = 80f;
        [SerializeField] private float shotsPerSecond = 3f;
        [SerializeField] private int magazineCapacity = 12;
        [SerializeField] private float reloadDuration = 1.6f;
        [SerializeField] private bool automatic;
        [SerializeField, Min(0f)] private float noiseLoudness = 28f;
        [SerializeField] private LayerMask hitMask = ~0;
        public string WeaponId => weaponId;
        public float Damage => Mathf.Max(0f, damage);
        public float Range => Mathf.Max(0.1f, range);
        public float ShotsPerSecond => Mathf.Max(0.05f, shotsPerSecond);
        public int MagazineCapacity => Mathf.Max(1, magazineCapacity);
        public float ReloadDuration => Mathf.Max(0.05f, reloadDuration);
        public bool Automatic => automatic;
        public float NoiseLoudness => Mathf.Max(0f, noiseLoudness);
        public LayerMask HitMask => hitMask;
    }
}
