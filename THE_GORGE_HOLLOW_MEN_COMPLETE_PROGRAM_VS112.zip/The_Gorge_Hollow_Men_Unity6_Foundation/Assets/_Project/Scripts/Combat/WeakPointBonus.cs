using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Multiplies damage when a ray hits a designated weak-point collider.
    /// Attach to a child collider marked as weak point; Hitscan can query via TryGet.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class WeakPointBonus : MonoBehaviour
    {
        [SerializeField] private float multiplier = 2f;
        public float Multiplier => Mathf.Max(1f, multiplier);

        public static bool TryGetMultiplier(Collider col, out float mult)
        {
            mult = 1f;
            if (col == null) return false;
            var wp = col.GetComponent<WeakPointBonus>();
            if (wp == null) wp = col.GetComponentInParent<WeakPointBonus>();
            if (wp == null) return false;
            mult = wp.Multiplier;
            return true;
        }
    }
}
