using UnityEngine;
using UnityEngine.UI;

namespace GorgeHollow
{
    /// <summary>
    /// Spawns floating damage text in screen space when DamageableHealth changes.
    /// Uses a simple pooled set of UI labels.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class DamageNumberSpawner : MonoBehaviour
    {
        [SerializeField] private Camera worldCamera;
        [SerializeField] private RectTransform canvasRoot;
        [SerializeField] private Text labelPrefab;
        [SerializeField] private int poolSize = 12;
        [SerializeField] private float riseSpeed = 40f;
        [SerializeField] private float lifeSeconds = 0.8f;

        private Text[] pool;
        private float[] life;
        private Vector3[] worldPos;
        private int cursor;

        private void Awake()
        {
            if (worldCamera == null) worldCamera = Camera.main;
            pool = new Text[Mathf.Max(1, poolSize)];
            life = new float[pool.Length];
            worldPos = new Vector3[pool.Length];
            if (labelPrefab != null && canvasRoot != null)
            {
                for (int i = 0; i < pool.Length; i++)
                {
                    pool[i] = i == 0 ? labelPrefab : Object.Instantiate(labelPrefab, canvasRoot);
                    pool[i].gameObject.SetActive(false);
                }
            }
        }

        public void Show(Vector3 world, float amount)
        {
            if (pool == null || pool.Length == 0) return;
            int i = cursor++ % pool.Length;
            if (pool[i] == null) return;
            pool[i].text = Mathf.RoundToInt(amount).ToString();
            pool[i].gameObject.SetActive(true);
            life[i] = lifeSeconds;
            worldPos[i] = world + Vector3.up * 1.2f;
        }

        private void LateUpdate()
        {
            if (pool == null || worldCamera == null) return;
            for (int i = 0; i < pool.Length; i++)
            {
                if (pool[i] == null || life[i] <= 0f)
                {
                    if (pool[i] != null) pool[i].gameObject.SetActive(false);
                    continue;
                }
                life[i] -= Time.unscaledDeltaTime;
                worldPos[i] += Vector3.up * (riseSpeed * Time.unscaledDeltaTime * 0.01f);
                Vector3 sp = worldCamera.WorldToScreenPoint(worldPos[i]);
                if (sp.z < 0f) { pool[i].gameObject.SetActive(false); life[i] = 0f; continue; }
                pool[i].rectTransform.position = sp;
                if (life[i] <= 0f) pool[i].gameObject.SetActive(false);
            }
        }
    }
}
