using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>
    /// Enemy-only bridge-collapse consequence. Monsters caught on the span lose navigation,
    /// visibly fall into the gorge, and are killed. They are never teleported to a tower.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class MonsterBridgeFallParticipant : MonoBehaviour
    {
        [SerializeField] private NavMeshAgent agent;
        [SerializeField] private MonsterAIController ai;
        [SerializeField] private DamageableHealth health;
        [SerializeField] private Animator animator;
        [SerializeField] private string fallTrigger = "Fall";
        [SerializeField, Min(0.1f)] private float gravity = 24f;
        [SerializeField, Min(0.1f)] private float lethalFallSeconds = 2.1f;
        [SerializeField, Min(0f)] private float fallRotationSpeed = 150f;

        private bool falling;
        private float verticalVelocity;
        private float elapsed;
        private float startY;
        private MonsterBridgeAccessToken accessToken;

        public bool IsFalling => falling;

        private void Awake()
        {
            if (agent == null) agent = GetComponent<NavMeshAgent>();
            if (ai == null) ai = GetComponent<MonsterAIController>();
            if (health == null) health = GetComponent<DamageableHealth>();
            if (animator == null) animator = GetComponentInChildren<Animator>();
            accessToken = GetComponent<MonsterBridgeAccessToken>();
        }

        public bool BeginFatalFall()
        {
            if (falling || health == null || health.IsDead) return false;
            falling = true;
            startY = transform.position.y;
            elapsed = 0f;
            verticalVelocity = -1.5f;
            if (agent != null) agent.enabled = false;
            if (ai != null) ai.enabled = false;
            if (accessToken != null) accessToken.enabled = false;
            if (animator != null)
            {
                animator.applyRootMotion = false;
                if (!string.IsNullOrWhiteSpace(fallTrigger) && HasTrigger(animator, fallTrigger))
                    animator.SetTrigger(fallTrigger);
            }
            return true;
        }

        private void Update()
        {
            if (!falling) return;
            float dt = Time.deltaTime;
            elapsed += dt;
            verticalVelocity -= gravity * dt;
            transform.position += Vector3.up * (verticalVelocity * dt);
            transform.Rotate(Vector3.forward, fallRotationSpeed * dt, Space.Self);

            // A bridge fall into the gorge is always fatal for an enemy, regardless of its
            // ordinary health, armour, or the exact landing surface below the bridge.
            if (elapsed >= lethalFallSeconds || transform.position.y <= startY - 18f)
                ResolveDeath();
        }

        private void ResolveDeath()
        {
            if (!falling) return;
            falling = false;
            if (health != null && !health.IsDead)
                health.ApplyDamage(health.MaximumHealth + 1f, transform.position, Vector3.down, null);
            // Fail-safe if a custom health/death listener prevented the normal lethal event.
            if (health != null && !health.IsDead)
                Debug.LogError("Bridge-fallen monster did not enter its death state.", this);
        }

        private static bool HasTrigger(Animator target, string parameterName)
        {
            foreach (AnimatorControllerParameter parameter in target.parameters)
                if (parameter.type == AnimatorControllerParameterType.Trigger && parameter.name == parameterName)
                    return true;
            return false;
        }
    }
}
