using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Converts a resolved siege strike into an observed effectiveness sample.</summary>
    public static class MonsterSiegeEffectiveness
    {
        public static int ExpectedDamage(float rawDamage, float resistance, int remainingHealth)
        {
            return ExpectedDamage(rawDamage, resistance, remainingHealth, 1f);
        }

        public static int ExpectedDamage(float rawDamage, float resistance, int remainingHealth, float vulnerabilityMultiplier)
        {
            if (remainingHealth <= 0 || rawDamage <= 0f || float.IsNaN(rawDamage) || float.IsInfinity(rawDamage)) return 0;
            float multiplier = float.IsNaN(vulnerabilityMultiplier) || float.IsInfinity(vulnerabilityMultiplier)
                ? 1f : Mathf.Clamp(vulnerabilityMultiplier, 0.1f, 4f);
            float safeResistance = float.IsNaN(resistance) || float.IsInfinity(resistance)
                ? 0f : Mathf.Clamp(resistance, 0f, 0.9f);
            float effective = rawDamage * multiplier * (1f - safeResistance);
            if (float.IsInfinity(effective) || effective >= remainingHealth) return remainingHealth;
            int rounded = Mathf.Max(1, Mathf.CeilToInt(effective));
            return Mathf.Min(remainingHealth, rounded);
        }

        public static float CalculateEfficiency(int appliedDamage, int expectedDamage)
        {
            if (expectedDamage <= 0) return 0f;
            return Mathf.Clamp01((float)Mathf.Max(0, appliedDamage) / expectedDamage);
        }
    }
}
