using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Shows an authored warning visual during the monster's attack wind-up.</summary>
    [DisallowMultipleComponent, RequireComponent(typeof(MonsterAIController))]
    public sealed class MonsterAttackTelegraph : MonoBehaviour
    {
        [SerializeField] private MonsterAIController controller;
        [SerializeField] private GameObject warningVisual;
        [SerializeField, Min(0f)] private float pulseAmount = 0.08f;
        [SerializeField, Min(0.1f)] private float pulseFrequency = 8f;
        private Vector3 baseScale = Vector3.one;

        private void Awake()
        {
            if (controller == null) controller = GetComponent<MonsterAIController>();
            if (warningVisual != null)
            {
                baseScale = warningVisual.transform.localScale;
                warningVisual.SetActive(false);
            }
        }
        private void OnEnable()
        {
            if (controller == null) return;
            controller.AttackWindupStarted += OnWindupStarted;
            controller.AttackResolved += OnAttackResolved;
        }
        private void OnDisable()
        {
            if (controller != null)
            {
                controller.AttackWindupStarted -= OnWindupStarted;
                controller.AttackResolved -= OnAttackResolved;
            }
            SetVisible(false);
        }
        private void Update()
        {
            if (warningVisual == null || !warningVisual.activeSelf) return;
            float pulse = 1f + Mathf.Sin(Time.time * pulseFrequency) * pulseAmount;
            warningVisual.transform.localScale = baseScale * pulse;
        }
        private void OnWindupStarted(Transform target, float duration) => SetVisible(true);
        private void OnAttackResolved(bool hit) => SetVisible(false);
        private void SetVisible(bool visible)
        {
            if (warningVisual == null) return;
            if (warningVisual.activeSelf != visible) warningVisual.SetActive(visible);
            if (!visible) warningVisual.transform.localScale = baseScale;
        }
    }
}
