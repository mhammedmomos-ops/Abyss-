using UnityEngine;

namespace GorgeHollow
{
    public struct LearnedHazard
    {
        public string Identity;
        public Vector3 Position;
        public float AvoidanceRadius;
        public float Severity;
        public float LastObservedTime;
    }

    /// <summary>Bounded evidence from actions this monster personally perceived. No global player-state access.</summary>
    public sealed class MonsterLearningMemory
    {
        private const int EvidenceCap = 8;
        private const int HazardCap = 8;
        private readonly LearnedHazard[] hazards = new LearnedHazard[HazardCap];
        private int hazardCount;
        private int nextHazardSlot;

        public int HeardGunshots { get; private set; }
        public int HeardSprintFootsteps { get; private set; }
        public int SawPlayerSprint { get; private set; }
        public Vector3 LastEvidencePosition { get; private set; }
        public MonsterStimulusKind LastEvidenceKind { get; private set; }
        public bool IsCautiousAroundGunfire => HeardGunshots >= 3;
        public bool RecognizesSprintPattern => SawPlayerSprint >= 2 || HeardSprintFootsteps >= 4;
        public int LearnedHazardCount => hazardCount;
        public int RepeatedAnimalDistractionCount { get; private set; }
        private int lastAnimalDistractionSourceId;
        private float lastAnimalDistractionTime = float.NegativeInfinity;

        /// <summary>Tracks a decoy only after normal perception and acceptance-cooldown checks.</summary>
        public int RecordAnimalDistraction(GameObject source, float observedTime)
        {
            if (source == null || !IsFinite(observedTime)) return RepeatedAnimalDistractionCount;
            int sourceId = source.GetInstanceID();
            const float learningWindowSeconds = 60f;
            if (sourceId != lastAnimalDistractionSourceId || observedTime < lastAnimalDistractionTime ||
                observedTime - lastAnimalDistractionTime > learningWindowSeconds)
                RepeatedAnimalDistractionCount = 1;
            else
                RepeatedAnimalDistractionCount = Mathf.Min(EvidenceCap, RepeatedAnimalDistractionCount + 1);
            lastAnimalDistractionSourceId = sourceId;
            lastAnimalDistractionTime = observedTime;
            return RepeatedAnimalDistractionCount;
        }

        public void RecordAudible(MonsterStimulus stimulus)
        {
            LastEvidencePosition = stimulus.Position;
            LastEvidenceKind = stimulus.Kind;
            if (stimulus.Kind == MonsterStimulusKind.Gunshot) HeardGunshots = Mathf.Min(EvidenceCap, HeardGunshots + 1);
            if (stimulus.Kind == MonsterStimulusKind.SprintFootstep) HeardSprintFootsteps = Mathf.Min(EvidenceCap, HeardSprintFootsteps + 1);
        }

        public void RecordVisibleSprint(Vector3 observedPosition)
        {
            SawPlayerSprint = Mathf.Min(EvidenceCap, SawPlayerSprint + 1);
            LastEvidencePosition = observedPosition;
        }

        public bool RecordHazard(string identity, Vector3 position, float avoidanceRadius, float severity, float observedTime)
        {
            if (string.IsNullOrWhiteSpace(identity) || avoidanceRadius <= 0f || !IsFinite(avoidanceRadius) ||
                !IsFinite(severity) || !IsFinite(position.x) || !IsFinite(position.y) || !IsFinite(position.z)) return false;
            for (int i = 0; i < hazardCount; i++)
            {
                if (hazards[i].Identity != identity) continue;
                LearnedHazard previous = hazards[i];
                bool materiallyChanged = (previous.Position - position).sqrMagnitude > 0.25f ||
                    avoidanceRadius > previous.AvoidanceRadius + 0.25f || severity > previous.Severity + 0.1f;
                hazards[i] = new LearnedHazard
                {
                    Identity = identity, Position = position,
                    AvoidanceRadius = Mathf.Max(previous.AvoidanceRadius, avoidanceRadius),
                    Severity = Mathf.Max(previous.Severity, severity), LastObservedTime = observedTime
                };
                return materiallyChanged;
            }

            int slot;
            if (hazardCount < HazardCap) slot = hazardCount++;
            else { slot = nextHazardSlot; nextHazardSlot = (nextHazardSlot + 1) % HazardCap; }
            hazards[slot] = new LearnedHazard
            {
                Identity = identity, Position = position, AvoidanceRadius = avoidanceRadius,
                Severity = Mathf.Max(0f, severity), LastObservedTime = observedTime
            };
            return true;
        }

        public bool KnowsHazard(string identity)
        {
            if (string.IsNullOrWhiteSpace(identity)) return false;
            for (int i = 0; i < hazardCount; i++)
                if (hazards[i].Identity == identity) return true;
            return false;
        }

        public void PublishHazardsToSquad(MonsterSquadCoordinator coordinator, MonsterAIController owner)
        {
            if (coordinator == null || owner == null) return;
            for (int i = 0; i < hazardCount; i++) coordinator.ReportLearnedHazard(owner, hazards[i]);
        }

        public bool TryGetMostRecentHazard(out LearnedHazard result)
        {
            result = default;
            if (hazardCount == 0) return false;
            int best = 0;
            for (int i = 1; i < hazardCount; i++)
                if (hazards[i].LastObservedTime > hazards[best].LastObservedTime) best = i;
            result = hazards[best];
            return true;
        }

        private static bool IsFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

        /// <summary>Returns the most severe learned hazard intersecting a proposed movement segment.</summary>
        public bool TryGetBlockingHazard(Vector3 start, Vector3 end, out LearnedHazard result)
        {
            result = default;
            Vector3 segment = end - start;
            float lengthSquared = segment.sqrMagnitude;
            float bestSeverity = float.MinValue;
            bool found = false;
            for (int i = 0; i < hazardCount; i++)
            {
                LearnedHazard hazard = hazards[i];
                float t = lengthSquared > 0.0001f
                    ? Mathf.Clamp01(Vector3.Dot(hazard.Position - start, segment) / lengthSquared) : 0f;
                Vector3 closest = start + segment * t;
                Vector3 delta = hazard.Position - closest;
                delta.y = 0f;
                if (delta.sqrMagnitude > hazard.AvoidanceRadius * hazard.AvoidanceRadius) continue;
                if (!found || hazard.Severity > bestSeverity)
                {
                    found = true;
                    bestSeverity = hazard.Severity;
                    result = hazard;
                }
            }
            return found;
        }

        public void Clear()
        {
            HeardGunshots = 0; HeardSprintFootsteps = 0; SawPlayerSprint = 0;
            RepeatedAnimalDistractionCount = 0; lastAnimalDistractionSourceId = 0; lastAnimalDistractionTime = float.NegativeInfinity;
            LastEvidencePosition = Vector3.zero; LastEvidenceKind = MonsterStimulusKind.Impact;
            for (int i = 0; i < hazardCount; i++) hazards[i] = default;
            hazardCount = 0;
            nextHazardSlot = 0;
        }
    }
}
