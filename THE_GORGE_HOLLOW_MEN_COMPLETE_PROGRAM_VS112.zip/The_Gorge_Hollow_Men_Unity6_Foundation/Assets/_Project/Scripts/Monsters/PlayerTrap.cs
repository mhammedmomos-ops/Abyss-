using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Scene-authored player trap. Monsters learn its position only after seeing it or triggering it.
    /// Attach to a trap prefab with a SphereCollider; a kinematic Rigidbody enables trigger callbacks
    /// with NavMesh-driven monster colliders.
    /// </summary>
    [RequireComponent(typeof(SphereCollider), typeof(Rigidbody))]
    public sealed class PlayerTrap : MonoBehaviour
    {
        [SerializeField] private string trapId = "player_trap_01";
        [SerializeField, Min(0.1f)] private float triggerRadius = 1.6f;
        [SerializeField, Min(0.1f)] private float recognitionRadius = 12f;
        [SerializeField, Min(0.1f)] private float avoidanceRadius = 3.2f;
        [SerializeField, Min(0f)] private float damage = 28f;
        [SerializeField, Min(0f)] private float severity = 1f;
        [SerializeField, Min(0f)] private float triggerCooldown = 1f;
        [SerializeField, Min(0)] private int maximumActivations = 1;
        [SerializeField] private bool armed = true;
        private SphereCollider trigger;
        private float nextTriggerTime;
        private int activationCount;

        public string Identity => trapId;
        public bool IsArmed => isActiveAndEnabled && armed && (maximumActivations <= 0 || activationCount < maximumActivations);
        public float RecognitionRadius => recognitionRadius;
        public float AvoidanceRadius => avoidanceRadius;
        public float Severity => severity;

        private void Awake()
        {
            trigger = GetComponent<SphereCollider>();
            trigger.isTrigger = true;
            trigger.radius = triggerRadius;
            Rigidbody body = GetComponent<Rigidbody>();
            body.isKinematic = true;
            body.useGravity = false;
        }

        public void Arm() { armed = true; }
        public void Disarm() { armed = false; }

        private void OnTriggerEnter(Collider other)
        {
            if (!IsArmed || Time.time < nextTriggerTime) return;
            MonsterAIController monster = other.GetComponentInParent<MonsterAIController>();
            if (monster == null) return;

            monster.NotifyTrapTriggered(this);
            DamageableHealth health = monster.GetComponent<DamageableHealth>();
            if (health != null && damage > 0f)
                health.ApplyDamage(damage, transform.position, (monster.transform.position - transform.position).normalized, gameObject);

            activationCount++;
            nextTriggerTime = Time.time + triggerCooldown;
            if (maximumActivations > 0 && activationCount >= maximumActivations) armed = false;
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            if (string.IsNullOrWhiteSpace(trapId)) trapId = "player_trap_01";
            triggerRadius = Mathf.Max(0.1f, triggerRadius);
            recognitionRadius = Mathf.Max(triggerRadius, recognitionRadius);
            avoidanceRadius = Mathf.Max(triggerRadius, avoidanceRadius);
            damage = Mathf.Max(0f, damage);
            severity = Mathf.Max(0f, severity);
            triggerCooldown = Mathf.Max(0f, triggerCooldown);
        }
#endif
    }
}
