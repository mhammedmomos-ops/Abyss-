using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Explicit authored spawn socket. Place only on reachable ground outside the gorge void.</summary>
    public sealed class MonsterSpawnPoint : MonoBehaviour
    {
        [SerializeField] private bool spawnEnabled = true;
        [SerializeField] private string routeId = "outer_approach";
        [SerializeField] private MonsterNest associatedNest;
        public bool SpawnEnabled => spawnEnabled && isActiveAndEnabled;
        public string RouteId => routeId;
        public MonsterNest AssociatedNest => associatedNest;
    }
}
