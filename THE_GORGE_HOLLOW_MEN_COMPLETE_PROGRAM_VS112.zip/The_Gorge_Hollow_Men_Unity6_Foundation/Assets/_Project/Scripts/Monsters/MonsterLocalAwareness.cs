using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Converts active hostile actors into player-local perception. It never reads campaign raid phase,
    /// remote tower health, remote workforce, or remote encounter counts.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class MonsterLocalAwareness : MonoBehaviour
    {
        [SerializeField] private MonsterRaidDirector director;
        [SerializeField] private Transform playerEye;
        [SerializeField] private Camera playerCamera;
        [SerializeField] private TowerLocalAccessTracker localAccess;
        [SerializeField] private Transform towerARoot;
        [SerializeField] private Transform towerBRoot;
        [SerializeField] private Vector2 towerFootprintHalfExtents = new Vector2(9f, 9f);
        [SerializeField] private float towerMinimumLocalHeight = 0.5f;
        [SerializeField] private float towerMaximumLocalHeight = 12f;
        [SerializeField, Min(1f)] private float visualRadius = 26f;
        [SerializeField, Min(0f)] private float hearingRadius = 11f;
        [SerializeField, Min(0.05f)] private float scanInterval = 0.2f;
        [SerializeField] private LayerMask occlusionMask = ~0;

        private readonly List<GameObject> actors = new List<GameObject>(16);
        private readonly HashSet<GameObject> cachedActors = new HashSet<GameObject>();
        private readonly Dictionary<GameObject, Collider> aimColliders = new Dictionary<GameObject, Collider>();
        private readonly List<GameObject> staleActorKeys = new List<GameObject>();
        private readonly Dictionary<Renderer, bool> originalRendererStates = new Dictionary<Renderer, bool>();
        private readonly Dictionary<Canvas, bool> originalCanvasStates = new Dictionary<Canvas, bool>();
        private readonly Dictionary<Light, bool> originalLightStates = new Dictionary<Light, bool>();
        private readonly Dictionary<AudioSource, bool> originalAudioMuteStates = new Dictionary<AudioSource, bool>();
        private readonly HashSet<GameObject> visibleActors = new HashSet<GameObject>();
        private readonly HashSet<GameObject> audibleActors = new HashSet<GameObject>();
        private readonly RaycastHit[] hitBuffer = new RaycastHit[24];
        private readonly List<Renderer> staleRenderers = new List<Renderer>();
        private readonly List<Canvas> staleCanvases = new List<Canvas>();
        private readonly List<Light> staleLights = new List<Light>();
        private readonly List<AudioSource> staleAudioSources = new List<AudioSource>();
        private float nextScan;
        private int visibleCount;
        private bool heardMovement;

        public event System.Action<int, bool> AwarenessChanged;

        public int VisibleHostileCount => visibleCount;
        public bool HasHeardHostileMovement => heardMovement;
        public bool HasLocalContact => visibleCount > 0 || heardMovement;
        public float LocalThreatLevel => MonsterLocalAwarenessRules.CalculateLocalThreat(visibleCount, heardMovement);

        /// <summary>Checks whether a world object is locally observable without exposing remote tower activity.</summary>
        public bool CanObserveWorldObject(Transform subject)
        {
            if (!isActiveAndEnabled || subject == null || playerEye == null || localAccess == null || !localAccess.IsConfigured)
                return false;
            string localTowerId = localAccess != null ? localAccess.CurrentTowerId : null;
            if (MonsterLocalAwarenessRules.ShouldSuppressRemoteTowerObject(
                !string.IsNullOrEmpty(localTowerId), IsInsideRemoteTower(subject.position, localTowerId))) return false;
            Vector3 origin = playerCamera != null ? playerCamera.transform.position : playerEye.position + Vector3.up * 1.55f;
            float distance = Vector3.Distance(origin, subject.position);
            return distance <= visualRadius && IsInsidePlayerView(subject.position, subject.gameObject.layer) &&
                   HasLineOfSight(origin, subject.position, subject.gameObject);
        }

        private void Awake()
        {
            if (director == null) director = FindFirstObjectByType<MonsterRaidDirector>();
            if (localAccess == null) localAccess = FindFirstObjectByType<TowerLocalAccessTracker>();
            if (playerEye == null && localAccess != null) playerEye = localAccess.PlayerTransform;
            if (playerCamera == null) playerCamera = Camera.main;
        }

        private void OnEnable() => nextScan = 0f;

        private void Update()
        {
            if (Time.unscaledTime < nextScan) return;
            nextScan = Time.unscaledTime + Mathf.Max(0.05f, scanInterval);
            ScanLocalPerception();
        }

        private void ScanLocalPerception()
        {
            if (director == null || playerEye == null || localAccess == null || !localAccess.IsConfigured)
            {
                ApplyPresentation(null, null);
                SetAwareness(0, false);
                return;
            }

            director.CopyLivingMonsters(actors);
            PruneStaleActors();
            visibleActors.Clear();
            audibleActors.Clear();
            int newVisibleCount = 0;
            bool newHeardMovement = false;
            Vector3 origin = playerCamera != null ? playerCamera.transform.position : playerEye.position + Vector3.up * 1.55f;
            string localTowerId = localAccess != null ? localAccess.CurrentTowerId : null;

            for (int i = 0; i < actors.Count; i++)
            {
                GameObject actor = actors[i];
                if (actor == null) continue;
                CacheActorPresentation(actor);
                bool actorInsideRemoteTower = IsInsideRemoteTower(actor.transform.position, localTowerId);
                if (MonsterLocalAwarenessRules.ShouldSuppressRemoteTowerObject(
                    !string.IsNullOrEmpty(localTowerId), actorInsideRemoteTower))
                    continue;

                Vector3 target = ResolveAimPoint(actor);
                float distance = Vector3.Distance(origin, target);
                bool insideView = IsInsidePlayerView(target, actor.layer);
                bool lineOfSight = distance <= visualRadius && HasLineOfSight(origin, target, actor);
                bool canSee = MonsterLocalAwarenessRules.CanSeeHostile(distance, visualRadius, lineOfSight, insideView);
                bool canHear = MonsterLocalAwarenessRules.CanHearHostile(distance, hearingRadius, canSee);
                if (canSee)
                {
                    newVisibleCount++;
                    visibleActors.Add(actor);
                    audibleActors.Add(actor);
                }
                else if (canHear)
                {
                    // Hearing reveals only that movement is nearby, never an exact count or identity.
                    newHeardMovement = true;
                    audibleActors.Add(actor);
                }
            }

            ApplyPresentation(visibleActors, audibleActors);
            SetAwareness(newVisibleCount, newHeardMovement);
        }

        private bool IsInsideRemoteTower(Vector3 worldPosition, string localTowerId)
        {
            if (string.IsNullOrEmpty(localTowerId)) return false;
            Transform remoteRoot = localTowerId == "tower_a" ? towerBRoot :
                localTowerId == "tower_b" ? towerARoot : null;
            if (remoteRoot == null) return true; // Missing tower bounds fail closed while inside a known tower.
            Vector3 local = remoteRoot.InverseTransformPoint(worldPosition);
            float halfX = Mathf.Max(0.1f, Mathf.Abs(towerFootprintHalfExtents.x));
            float halfZ = Mathf.Max(0.1f, Mathf.Abs(towerFootprintHalfExtents.y));
            float minY = Mathf.Min(towerMinimumLocalHeight, towerMaximumLocalHeight);
            float maxY = Mathf.Max(towerMinimumLocalHeight, towerMaximumLocalHeight);
            return Mathf.Abs(local.x) <= halfX && Mathf.Abs(local.z) <= halfZ && local.y >= minY && local.y <= maxY;
        }

        private bool IsInsidePlayerView(Vector3 target, int actorLayer)
        {
            if (playerCamera == null)
            {
                Vector3 direction = target - playerEye.position;
                return Vector3.Dot(playerEye.forward, direction.normalized) >= 0.15f;
            }
            if ((playerCamera.cullingMask & (1 << actorLayer)) == 0) return false;
            Vector3 viewport = playerCamera.WorldToViewportPoint(target);
            return viewport.z > 0f && viewport.z <= playerCamera.farClipPlane &&
                   viewport.x >= 0f && viewport.x <= 1f && viewport.y >= 0f && viewport.y <= 1f;
        }

        private bool HasLineOfSight(Vector3 origin, Vector3 target, GameObject actor)
        {
            Vector3 delta = target - origin;
            float distance = delta.magnitude;
            if (distance <= 0.05f) return true;
            int hitCount = Physics.RaycastNonAlloc(origin, delta / distance, hitBuffer, distance,
                occlusionMask, QueryTriggerInteraction.Ignore);
            // A saturated buffer cannot guarantee that the nearest blocker was returned; fail closed.
            if (hitCount >= hitBuffer.Length) return false;
            float nearestDistance = float.PositiveInfinity;
            Transform nearestTransform = null;
            for (int i = 0; i < hitCount; i++)
            {
                Transform hitTransform = hitBuffer[i].transform;
                if (hitTransform == null || IsPlayerOwnedTransform(hitTransform)) continue;
                if (hitBuffer[i].distance >= nearestDistance) continue;
                nearestDistance = hitBuffer[i].distance;
                nearestTransform = hitTransform;
            }
            if (nearestTransform == null) return true;
            return nearestTransform == actor.transform || nearestTransform.IsChildOf(actor.transform);
        }

        private bool IsPlayerOwnedTransform(Transform candidate)
        {
            if (candidate == null) return true;
            if (playerEye != null && (candidate == playerEye || candidate.IsChildOf(playerEye)))
                return true;
            return playerCamera != null &&
                   (candidate == playerCamera.transform || candidate.IsChildOf(playerCamera.transform));
        }

        private Vector3 ResolveAimPoint(GameObject actor)
        {
            Collider collider;
            return aimColliders.TryGetValue(actor, out collider) && collider != null
                ? collider.bounds.center : actor.transform.position + Vector3.up;
        }

        private void PruneStaleActors()
        {
            staleActorKeys.Clear();
            foreach (GameObject actor in cachedActors)
                if (actor == null) staleActorKeys.Add(actor);
            for (int i = 0; i < staleActorKeys.Count; i++)
            {
                cachedActors.Remove(staleActorKeys[i]);
                aimColliders.Remove(staleActorKeys[i]);
            }
        }

        private void CacheActorPresentation(GameObject actor)
        {
            if (actor == null || !cachedActors.Add(actor)) return;
            aimColliders[actor] = actor.GetComponentInChildren<Collider>();
            Renderer[] renderers = actor.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < renderers.Length; i++)
            {
                Renderer renderer = renderers[i];
                if (renderer != null && !originalRendererStates.ContainsKey(renderer))
                    originalRendererStates.Add(renderer, renderer.forceRenderingOff);
            }
            Canvas[] canvases = actor.GetComponentsInChildren<Canvas>(true);
            for (int i = 0; i < canvases.Length; i++)
            {
                Canvas canvas = canvases[i];
                if (canvas != null && !originalCanvasStates.ContainsKey(canvas))
                    originalCanvasStates.Add(canvas, canvas.enabled);
            }
            Light[] lights = actor.GetComponentsInChildren<Light>(true);
            for (int i = 0; i < lights.Length; i++)
            {
                Light light = lights[i];
                if (light != null && !originalLightStates.ContainsKey(light))
                    originalLightStates.Add(light, light.enabled);
            }
            AudioSource[] audioSources = actor.GetComponentsInChildren<AudioSource>(true);
            for (int i = 0; i < audioSources.Length; i++)
            {
                AudioSource audioSource = audioSources[i];
                if (audioSource != null && !originalAudioMuteStates.ContainsKey(audioSource))
                    originalAudioMuteStates.Add(audioSource, audioSource.mute);
            }
        }

        private void ApplyPresentation(HashSet<GameObject> visible, HashSet<GameObject> audible)
        {
            staleRenderers.Clear();
            foreach (KeyValuePair<Renderer, bool> pair in originalRendererStates)
            {
                if (pair.Key == null) { staleRenderers.Add(pair.Key); continue; }
                bool shouldRender = IsHostileComponentVisible(pair.Key, visible);
                pair.Key.forceRenderingOff = pair.Value || !shouldRender;
            }
            for (int i = 0; i < staleRenderers.Count; i++) originalRendererStates.Remove(staleRenderers[i]);

            staleCanvases.Clear();
            foreach (KeyValuePair<Canvas, bool> pair in originalCanvasStates)
            {
                if (pair.Key == null) { staleCanvases.Add(pair.Key); continue; }
                pair.Key.enabled = pair.Value && IsHostileComponentVisible(pair.Key, visible);
            }
            for (int i = 0; i < staleCanvases.Count; i++) originalCanvasStates.Remove(staleCanvases[i]);

            staleLights.Clear();
            foreach (KeyValuePair<Light, bool> pair in originalLightStates)
            {
                if (pair.Key == null) { staleLights.Add(pair.Key); continue; }
                pair.Key.enabled = pair.Value && IsHostileComponentVisible(pair.Key, visible);
            }
            for (int i = 0; i < staleLights.Count; i++) originalLightStates.Remove(staleLights[i]);

            staleAudioSources.Clear();
            foreach (KeyValuePair<AudioSource, bool> pair in originalAudioMuteStates)
            {
                if (pair.Key == null) { staleAudioSources.Add(pair.Key); continue; }
                MonsterAIController hostile = pair.Key.GetComponentInParent<MonsterAIController>();
                bool locallyAudible = hostile != null && audible != null && audible.Contains(hostile.gameObject);
                pair.Key.mute = pair.Value || !locallyAudible;
            }
            for (int i = 0; i < staleAudioSources.Count; i++) originalAudioMuteStates.Remove(staleAudioSources[i]);
        }

        private static bool IsHostileComponentVisible(Component component, HashSet<GameObject> visible)
        {
            MonsterAIController hostile = component.GetComponentInParent<MonsterAIController>();
            return hostile != null && visible != null && visible.Contains(hostile.gameObject);
        }

        private void SetAwareness(int newVisibleCount, bool newHeardMovement)
        {
            newVisibleCount = Mathf.Max(0, newVisibleCount);
            if (visibleCount == newVisibleCount && heardMovement == newHeardMovement) return;
            visibleCount = newVisibleCount;
            heardMovement = newHeardMovement;
            AwarenessChanged?.Invoke(visibleCount, heardMovement);
        }

        private void OnDisable()
        {
            SetAwareness(0, false);
            // Fail closed: disabling perception must not reveal every hostile in the world.
            ApplyPresentation(null, null);
            visibleActors.Clear();
            audibleActors.Clear();
            actors.Clear();
        }
    }
}
