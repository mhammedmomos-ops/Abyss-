using System;
using UnityEngine;

namespace GorgeHollow
{
    public enum MonsterStimulusKind { Gunshot, SprintFootstep, Impact, DoorNoise, NestAlarm, AnimalDistraction, RepairWork, ConvoyUnderAttack }

    public readonly struct MonsterStimulus
    {
        public readonly MonsterStimulusKind Kind;
        public readonly Vector3 Position;
        public readonly float Loudness;
        public readonly GameObject Source;

        public MonsterStimulus(MonsterStimulusKind kind, Vector3 position, float loudness, GameObject source)
        { Kind = kind; Position = position; Loudness = Mathf.Max(0f, loudness); Source = source; }
    }

    /// <summary>Broadcasts audible events. AI listeners must independently pass range/occlusion checks.</summary>
    public static class MonsterStimulusBus
    {
        public static event Action<MonsterStimulus> Emitted;
        public static void Emit(MonsterStimulusKind kind, Vector3 position, float loudness, GameObject source)
        { if (loudness > 0f) Emitted?.Invoke(new MonsterStimulus(kind, position, loudness, source)); }
    }
}
