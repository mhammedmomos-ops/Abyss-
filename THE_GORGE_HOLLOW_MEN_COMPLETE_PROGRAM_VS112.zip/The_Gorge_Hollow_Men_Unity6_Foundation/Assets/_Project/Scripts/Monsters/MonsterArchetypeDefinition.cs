using UnityEngine;

namespace GorgeHollow
{
    public enum MonsterArchetypeRole { Stalker, Brute, Skirmisher, Lurker }

    /// <summary>Designer-authored monster profile. Each archetype is a distinct, tuneable threat, not a cosmetic label.</summary>
    [CreateAssetMenu(fileName = "MonsterArchetype", menuName = "Gorge Hollow/Monster Archetype")]
    public sealed class MonsterArchetypeDefinition : ScriptableObject
    {
        [Header("Identity and spawning")]
        public string archetypeId = "stalker";
        public string displayName = "Stalker";
        public MonsterArchetypeRole role = MonsterArchetypeRole.Stalker;
        public GameObject prefab;
        [Min(1)] public int threatCost = 2;
        [Min(0.01f)] public float spawnWeight = 1f;

        [Header("Movement and perception")]
        [Min(0.1f)] public float moveSpeed = 3.1f;
        [Min(0.1f)] public float sightRange = 18f;
        [Range(1f, 180f)] public float fieldOfView = 110f;
        [Min(0.1f)] public float hearingRange = 22f;
        [Min(0.1f)] public float investigateDuration = 9f;
        [Min(1f)] public float sprintPursuitMultiplier = 1.12f;

        [Header("Territory and nest behaviour")]
        [Tooltip("When enabled, this monster guards the nest assigned to its spawn point and will not pursue contacts beyond its territory.")]
        public bool defendsNest;

        [Header("Combat")]
        [Min(0f)] public float playerDamage = 12f;
        [Min(0.1f)] public float playerAttackRange = 1.65f;
        [Min(0.1f)] public float playerAttackInterval = 1.4f;
        [Min(0f)] public float attackWindupSeconds = 0.55f;
        [Min(0f)] public float towerDamage = 12f;

        public bool IsValid(out string reason)
        {
            if (string.IsNullOrWhiteSpace(archetypeId)) { reason = "Archetype ID is required."; return false; }
            if (prefab == null) { reason = "A monster prefab is required."; return false; }
            if (threatCost < 1 || spawnWeight <= 0f || moveSpeed <= 0f || sightRange <= 0f ||
                fieldOfView < 1f || fieldOfView > 180f || hearingRange <= 0f || investigateDuration <= 0f ||
                sprintPursuitMultiplier < 1f || playerDamage < 0f || playerAttackRange <= 0f ||
                playerAttackInterval <= 0f || float.IsNaN(attackWindupSeconds) || float.IsInfinity(attackWindupSeconds) || attackWindupSeconds < 0f || attackWindupSeconds > 3f || towerDamage < 0f)
            { reason = "Archetype tuning contains an invalid value."; return false; }
            if (prefab.GetComponent<MonsterAIController>() == null || prefab.GetComponent<MonsterPerception>() == null ||
                prefab.GetComponent<DamageableHealth>() == null || prefab.GetComponent<MonsterDeathHandler>() == null)
            { reason = "Prefab root requires MonsterAIController, MonsterPerception, DamageableHealth and MonsterDeathHandler."; return false; }
            reason = null;
            return true;
        }
    }
}
