using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    [Serializable]
    public sealed class MonsterSpawnEntry
    {
        public MonsterArchetypeDefinition archetype;
        [Min(0.01f)] public float weightMultiplier = 1f;
    }

    /// <summary>Spawns a single event-requested raid using a threat budget and authored spawn sockets.</summary>
    public sealed class MonsterRaidDirector : MonoBehaviour
    {
        [SerializeField] private MonsterSpawnPoint[] spawnPoints;
        [Tooltip("Bridge-deck exclusion volumes. If none are configured or discovered, raid spawning fails closed.")]
        [SerializeField] private MonsterBridgeZone[] bridgeZones;
        [SerializeField] private MonsterSpawnEntry[] roster;
        [SerializeField] private Transform playerTarget;
        [SerializeField, Min(0.1f)] private float navMeshSampleRadius = 3f;
        [SerializeField, Min(1)] private int maximumLivingMonsters = 12;
        private readonly HashSet<GameObject> livingMonsters = new HashSet<GameObject>();
        private bool raidActive;
        private int lastRaidSpawnCount;
        private int lastRaidKillCount;
        private string activeEncounterId;
        private MonsterSquadCoordinator activeSquad;

        public static event Action<int> RaidStarted;
        public static event Action<GameObject, string> MonsterSpawned;
        public static event Action<int> RaidResolved;
        public event Action<MonsterRaidDirector, int, string> EncounterStarted;
        public event Action<MonsterRaidDirector, string, int, int> EncounterResolved;
        public int LivingMonsterCount => livingMonsters.Count;
        public bool IsRaidActive => raidActive;

        /// <summary>Copies active actors for local perception. Consumers must derive awareness from physical proximity and line of sight.</summary>
        public void CopyLivingMonsters(List<GameObject> destination)
        {
            if (destination == null) return;
            destination.Clear();
            foreach (GameObject monster in livingMonsters)
                if (monster != null) destination.Add(monster);
        }

        private void OnEnable() { MonsterDeathHandler.MonsterKilled += OnMonsterKilled; }
        private void OnDisable() { MonsterDeathHandler.MonsterKilled -= OnMonsterKilled; }

        /// <summary>Called by a campaign event, story beat, or world-state evaluator; never called by a fixed quiet-hour timer.</summary>
        public bool RequestRaid(MonsterRaidRequest request, out int spawnedCount, out string error)
        {
            spawnedCount = 0;
            error = null;
            if (request == null || !request.IsValid(out error)) return false;
            PruneDestroyedMonsters();
            if (raidActive) { error = "A raid is already active."; return false; }
            if (spawnPoints == null || spawnPoints.Length == 0) { error = "No authored monster spawn points are assigned."; return false; }
            MonsterBridgeZone[] activeBridgeZones = ResolveBridgeZones();
            if (activeBridgeZones.Length == 0) { error = "Raid spawning is blocked: no MonsterBridgeZone exclusion volume is configured. Add a zone covering the entire bridge deck before enabling raids."; return false; }
            for (int zoneIndex = 0; zoneIndex < activeBridgeZones.Length; zoneIndex++)
            {
                if (activeBridgeZones[zoneIndex] == null || !activeBridgeZones[zoneIndex].IsConfigured)
                {
                    error = "Raid spawning is blocked: every MonsterBridgeZone must have an enabled deck-volume collider and its BridgeSpanController assigned.";
                    return false;
                }
            }
            if (roster == null || roster.Length == 0) { error = "Monster spawn roster is empty."; return false; }
            if (playerTarget == null) { error = "Assign the active player Transform to the raid director."; return false; }
            if (livingMonsters.Count >= maximumLivingMonsters) { error = "The living monster cap has been reached."; return false; }

            var random = request.RandomSeed == 0 ? new System.Random() : new System.Random(request.RandomSeed);
            var availablePoints = new List<MonsterSpawnPoint>();
            foreach (MonsterSpawnPoint point in spawnPoints)
            {
                if (point == null || !point.SpawnEnabled) continue;
                if (IsInsideBridgeZone(point.transform.position, activeBridgeZones)) continue;
                if (Vector3.Distance(point.transform.position, playerTarget.position) < request.MinimumPlayerDistance) continue;
                NavMeshHit hit;
                if (!NavMesh.SamplePosition(point.transform.position, out hit, navMeshSampleRadius, NavMesh.AllAreas)) continue;
                if (IsInsideBridgeZone(hit.position, activeBridgeZones)) continue;
                availablePoints.Add(point);
            }
            Shuffle(availablePoints, random);
            availablePoints.Sort((a, b) =>
                (a.transform.position - request.TargetPosition).sqrMagnitude.CompareTo(
                    (b.transform.position - request.TargetPosition).sqrMagnitude));

            activeSquad = GetComponent<MonsterSquadCoordinator>();
            if (activeSquad == null) activeSquad = gameObject.AddComponent<MonsterSquadCoordinator>();
            int budgetRemaining = request.ThreatBudget;
            int spawnLimit = Mathf.Min(request.MaximumSpawnCount, maximumLivingMonsters - livingMonsters.Count);
            for (int i = 0; i < availablePoints.Count && spawnedCount < spawnLimit && budgetRemaining > 0; i++)
            {
                MonsterArchetypeDefinition chosen = ChooseAffordableArchetype(budgetRemaining, random);
                if (chosen == null) break;
                MonsterSpawnPoint point = availablePoints[i];
                NavMeshHit hit;
                if (!NavMesh.SamplePosition(point.transform.position, out hit, navMeshSampleRadius, NavMesh.AllAreas)) continue;
                if (IsInsideBridgeZone(hit.position, activeBridgeZones)) continue;

                GameObject instance = Instantiate(chosen.prefab, hit.position, point.transform.rotation);
                // Existing prefab assets predate RequireComponent; guarantee the access
                // token is present on every runtime-spawned monster as well.
                if (instance.GetComponent<MonsterBridgeAccessToken>() == null)
                    instance.AddComponent<MonsterBridgeAccessToken>();
                MonsterAIController controller = instance.GetComponent<MonsterAIController>();
                if (controller == null)
                {
                    Destroy(instance);
                    error = "Spawned prefab lost its MonsterAIController component.";
                    continue;
                }
                controller.ApplyArchetype(chosen);
                controller.ConfigureSiegeTargets(FindLivingTowerTargets());
                controller.ConfigureNest(point.AssociatedNest);
                controller.ConfigureSquad(activeSquad, activeSquad.Register(controller));
                controller.ConfigurePlayerTarget(playerTarget);
                livingMonsters.Add(instance);
                budgetRemaining -= chosen.threatCost;
                spawnedCount++;
                MonsterSpawned?.Invoke(instance, chosen.archetypeId);
            }

            if (spawnedCount == 0)
            {
                error = "No monsters could be spawned. Check NavMesh coverage, spawn sockets, roster costs and prefab configuration.";
                return false;
            }
            raidActive = true;
            lastRaidSpawnCount = spawnedCount;
            lastRaidKillCount = 0;
            activeEncounterId = Guid.NewGuid().ToString("N");
            EncounterStarted?.Invoke(this, spawnedCount, activeEncounterId);
            RaidStarted?.Invoke(spawnedCount);
            return true;
        }

        private MonsterBridgeZone[] ResolveBridgeZones()
        {
            if (bridgeZones != null && bridgeZones.Length > 0)
            {
                var assigned = new List<MonsterBridgeZone>();
                foreach (MonsterBridgeZone zone in bridgeZones)
                    if (zone != null && zone.isActiveAndEnabled) assigned.Add(zone);
                if (assigned.Count > 0) return assigned.ToArray();
            }
            return FindObjectsByType<MonsterBridgeZone>(FindObjectsSortMode.None);
        }

        private static bool IsInsideBridgeZone(Vector3 position, MonsterBridgeZone[] zones)
        {
            if (zones == null) return false;
            for (int i = 0; i < zones.Length; i++)
                if (zones[i] != null && zones[i].ContainsPosition(position)) return true;
            return false;
        }

        private static Transform[] FindLivingTowerTargets()
        {
            TowerStructure[] structures = FindObjectsByType<TowerStructure>(FindObjectsSortMode.None);
            var targets = new List<Transform>(structures.Length);
            foreach (TowerStructure structure in structures)
                if (structure != null && !structure.IsDestroyed) targets.Add(structure.transform);
            return targets.ToArray();
        }

        private MonsterArchetypeDefinition ChooseAffordableArchetype(int budget, System.Random random)
        {
            float total = 0f;
            foreach (MonsterSpawnEntry entry in roster)
            {
                if (entry == null || entry.archetype == null || entry.weightMultiplier <= 0f ||
                    entry.archetype.threatCost > budget || !entry.archetype.IsValid(out _)) continue;
                total += entry.archetype.spawnWeight * entry.weightMultiplier;
            }
            if (total <= 0f) return null;
            double roll = random.NextDouble() * total;
            foreach (MonsterSpawnEntry entry in roster)
            {
                if (entry == null || entry.archetype == null || entry.weightMultiplier <= 0f ||
                    entry.archetype.threatCost > budget || !entry.archetype.IsValid(out _)) continue;
                roll -= entry.archetype.spawnWeight * entry.weightMultiplier;
                if (roll <= 0d) return entry.archetype;
            }
            return null;
        }

        private void OnMonsterKilled(GameObject monster, GameObject source)
        {
            if (monster == null || !livingMonsters.Remove(monster)) return;
            lastRaidKillCount++;
            ResolveIfEmpty();
        }

        private void LateUpdate()
        {
            if (!raidActive) return;
            PruneDestroyedMonsters();
            ResolveIfEmpty();
        }

        private void PruneDestroyedMonsters()
        {
            livingMonsters.RemoveWhere(monster => monster == null);
        }

        private void ResolveIfEmpty()
        {
            if (!raidActive || livingMonsters.Count > 0) return;
            raidActive = false;
            int resolvedSpawnCount = lastRaidSpawnCount;
            int resolvedKillCount = lastRaidKillCount;
            string resolvedEncounterId = activeEncounterId;
            // Clear the completed raid before notifying listeners; a listener may synchronously request another raid.
            lastRaidSpawnCount = 0;
            lastRaidKillCount = 0;
            activeEncounterId = null;
            RaidResolved?.Invoke(resolvedSpawnCount);
            EncounterResolved?.Invoke(this, resolvedEncounterId, resolvedSpawnCount, resolvedKillCount);
        }

        private static void Shuffle<T>(IList<T> values, System.Random random)
        {
            for (int i = values.Count - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);
                T temp = values[i]; values[i] = values[j]; values[j] = temp;
            }
        }
    }
}
