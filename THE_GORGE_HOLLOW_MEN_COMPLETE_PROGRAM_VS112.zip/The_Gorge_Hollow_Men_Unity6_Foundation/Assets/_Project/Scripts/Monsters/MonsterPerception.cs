using System;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Perception is limited to visible targets and audible stimuli within configured range and line of sight.</summary>
    public sealed class MonsterPerception : MonoBehaviour
    {
        [SerializeField] private Transform playerTarget;
        [SerializeField] private PlayerVitals playerVitals;
        [SerializeField, Min(0.1f)] private float sightRange = 18f;
        [SerializeField, Range(1f, 180f)] private float fieldOfView = 110f;
        [SerializeField, Min(0.1f)] private float eyeHeight = 1.5f;
        [SerializeField, Min(0f)] private float hearingRange = 22f;
        [SerializeField] private LayerMask obstructionMask = ~0;
        [SerializeField, Min(0.05f)] private float scanInterval = 0.2f;
        private float nextScan;
        public Transform VisiblePlayer { get; private set; }
        public PlayerVitals VisiblePlayerVitals => playerVitals;
        public event Action<MonsterStimulus> HeardStimulus;
        public event Action<Transform> SawPlayer;

        private void Awake()
        {
            if (playerTarget != null && playerVitals == null) playerVitals = playerTarget.GetComponentInParent<PlayerVitals>();
            // Spread initial scans across the configured interval; this avoids synchronized raycast bursts after a raid spawn.
            int stableOffset = GetInstanceID() & 0x7fffffff;
            nextScan = Time.time + ((stableOffset % 997) / 997f) * scanInterval;
        }
        private void OnEnable() { MonsterStimulusBus.Emitted += OnStimulus; }
        private void OnDisable() { MonsterStimulusBus.Emitted -= OnStimulus; VisiblePlayer = null; }
        private void Update()
        {
            if (Time.time < nextScan) return;
            nextScan = Time.time + scanInterval;
            VisiblePlayer = CanSeePlayer() ? playerTarget : null;
            if (VisiblePlayer != null) SawPlayer?.Invoke(VisiblePlayer);
        }
        public void SetPlayerTarget(Transform target)
        {
            playerTarget = target;
            playerVitals = target != null ? target.GetComponentInParent<PlayerVitals>() : null;
        }

        public void ConfigureSenses(float newSightRange, float newFieldOfView, float newHearingRange)
        {
            sightRange = Mathf.Max(0.1f, newSightRange);
            fieldOfView = Mathf.Clamp(newFieldOfView, 1f, 180f);
            hearingRange = Mathf.Max(0.1f, newHearingRange);
        }

        public void ConfigureScanInterval(float interval)
        {
            scanInterval = Mathf.Max(0.05f, interval);
            nextScan = Mathf.Min(nextScan, Time.time + scanInterval);
        }
        private bool CanSeePlayer()
        {
            if (playerTarget == null || playerVitals == null || playerVitals.IsDead) return false;
            Vector3 origin = transform.position + Vector3.up * eyeHeight;
            Vector3 destination = playerTarget.position + Vector3.up;
            Vector3 delta = destination - origin;
            float distance = delta.magnitude;
            if (distance > sightRange || distance < 0.01f) return false;
            if (Vector3.Angle(transform.forward, delta) > fieldOfView * 0.5f) return false;
            if (Physics.Raycast(origin, delta / distance, out RaycastHit hit, distance, obstructionMask, QueryTriggerInteraction.Ignore))
                return hit.transform == playerTarget || hit.transform == playerTarget.root || hit.transform.IsChildOf(playerTarget) || hit.transform.IsChildOf(playerTarget.root);
            return true;
        }
        private void OnStimulus(MonsterStimulus stimulus)
        {
            if (stimulus.Source == gameObject || stimulus.Loudness <= 0f) return;
            float distance = Vector3.Distance(transform.position, stimulus.Position);
            if (distance > Mathf.Min(hearingRange, stimulus.Loudness)) return;
            Vector3 origin = transform.position + Vector3.up * eyeHeight;
            Vector3 delta = stimulus.Position - origin;
            float length = delta.magnitude;
            if (length > 0.1f && Physics.Raycast(origin, delta / length, out RaycastHit hit, length, obstructionMask, QueryTriggerInteraction.Ignore))
            {
                bool hitEmitter = stimulus.Source != null &&
                    (hit.transform == stimulus.Source.transform || hit.transform.IsChildOf(stimulus.Source.transform) || stimulus.Source.transform.IsChildOf(hit.transform));
                if (!hitEmitter) return;
            }
            HeardStimulus?.Invoke(stimulus);
        }
    }
}
