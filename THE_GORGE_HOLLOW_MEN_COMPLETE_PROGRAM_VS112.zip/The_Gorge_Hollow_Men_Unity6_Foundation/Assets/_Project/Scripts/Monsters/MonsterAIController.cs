using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    public enum MonsterTacticalState { Idle, HuntVisiblePlayer, HuntLastKnownContact, InvestigateEvidence, SiegeStructure, GuardNest, Retreat }

    /// <summary>Owns monster actions. Tactical branch selection is performed by MonsterBehaviourTreeRunner.</summary>
    [RequireComponent(typeof(NavMeshAgent), typeof(MonsterPerception), typeof(MonsterBridgeAccessToken))]
    public sealed class MonsterAIController : MonoBehaviour
    {
        [SerializeField] private NavMeshAgent agent;
        [SerializeField] private MonsterPerception perception;
        [SerializeField] private TowerSiegeAttacker siegeAttacker;
        [SerializeField] private Transform[] siegeTargets;
        [SerializeField, Range(0.05f, 0.95f)] private float retreatHealthFraction = 0.22f;
        [SerializeField, Min(1f)] private float retreatDistance = 8f;
        private MonsterSquadCoordinator squad;
        private MonsterNest homeNest;
        private bool defendsNest;
        private DamageableHealth ownHealth;
        private int squadSlot;
        [SerializeField, Min(0.1f)] private float baseMoveSpeed = 3.1f;
        [SerializeField, Min(0.1f)] private float investigateDuration = 9f;
        [SerializeField, Min(0.1f)] private float repathInterval = 0.35f;
        [SerializeField, Min(0.1f)] private float playerAttackRange = 1.65f;
        [SerializeField, Min(0.1f)] private float playerAttackInterval = 1.4f;
        [SerializeField, Min(0f)] private float attackWindupSeconds = 0.55f;
        [SerializeField, Min(0f)] private float playerDamage = 12f;
        [SerializeField, Min(1f)] private float sprintPursuitMultiplier = 1.12f;
        private string activeArchetypeId = "default";
        private MonsterArchetypeRole activeRole = MonsterArchetypeRole.Stalker;
        [SerializeField] private bool requireBakedNavMesh = true;
        [Header("Trap awareness")]
        [SerializeField, Min(1f)] private float trapScanRange = 14f;
        [SerializeField, Min(0.1f)] private float trapScanInterval = 0.65f;
        [SerializeField] private LayerMask trapDetectionMask = ~0;
        [SerializeField] private LayerMask trapVisibilityMask = ~0;
        private readonly Collider[] trapScanBuffer = new Collider[16];
        private float nextTrapScan;
        private readonly MonsterLearningMemory memory = new MonsterLearningMemory();
        private Vector3 investigatePosition;
        private float investigateUntil;
        private Vector3 distractionPosition;
        private float distractionUntil;
        private float nextDistractionAcceptedAt;
        private bool distractionActive;
        private float nextRepath;
        private float nextAttack;
        private Transform pendingPlayerTarget;
        private float pendingPlayerAttackImpactTime;
        private AnimalCompanionController observedCompanion;
        private Transform pendingCompanionTarget;
        private float pendingCompanionAttackImpactTime;
        private float nextCompanionLookup;
        private Transform currentSiegeTarget;
        [Header("Physical scent trail")]
        [SerializeField, Min(0.1f)] private float scentSampleSpacing = AnimalScentTrailRules.DefaultSampleSpacing;
        [SerializeField, Min(0.1f)] private float scentSampleInterval = AnimalScentTrailRules.DefaultSampleInterval;
        private static int nextScentTrailId = 1;
        private int scentTrailId;
        private Vector3 lastScentSamplePosition;
        private float nextScentSampleAt;
        private bool hasScentSample;
        private readonly List<Transform> expandedSiegeTargets = new List<Transform>(24);
        private readonly HashSet<Transform> uniqueSiegeTargets = new HashSet<Transform>();
        public MonsterTacticalState State { get; private set; }
        public event System.Action AttackStarted;
        public event System.Action<Transform, float> AttackWindupStarted;
        public event System.Action<bool> AttackResolved;
        public MonsterLearningMemory Memory => memory;
        public string ActiveArchetypeId => activeArchetypeId;
        public MonsterArchetypeRole ActiveRole => activeRole;

        public void ConfigurePlayerTarget(Transform target)
        {
            if (perception != null) perception.SetPlayerTarget(target);
            MonsterAIUpdateLod lod = GetComponent<MonsterAIUpdateLod>();
            if (lod != null) lod.ConfigureTarget(target);
        }

        public void ConfigureSiegeTargets(Transform[] targets)
        {
            expandedSiegeTargets.Clear();
            uniqueSiegeTargets.Clear();
            if (targets != null)
            {
                for (int i = 0; i < targets.Length; i++)
                {
                    Transform source = targets[i];
                    if (source == null) continue;
                    TowerWeakPoint suppliedWeakPoint = source.GetComponentInParent<TowerWeakPoint>();
                    if (suppliedWeakPoint != null)
                    {
                        AddSiegeTarget(suppliedWeakPoint.transform);
                        continue;
                    }
                    TowerStructure structure = source.GetComponentInParent<TowerStructure>();
                    bool addedWeakPoint = false;
                    if (structure != null)
                    {
                        TowerWeakPoint[] weakPoints = structure.GetComponentsInChildren<TowerWeakPoint>(true);
                        for (int w = 0; w < weakPoints.Length; w++)
                        {
                            if (weakPoints[w] == null || !weakPoints[w].IsAvailable) continue;
                            AddSiegeTarget(weakPoints[w].transform);
                            addedWeakPoint = true;
                        }
                    }
                    if (!addedWeakPoint) AddSiegeTarget(source);
                }
            }
            siegeTargets = expandedSiegeTargets.ToArray();
        }

        private void AddSiegeTarget(Transform target)
        {
            if (target != null && uniqueSiegeTargets.Add(target)) expandedSiegeTargets.Add(target);
        }
        public void ConfigureNest(MonsterNest nest)
        {
            homeNest = nest;
            if (homeNest != null) homeNest.RestoreLearnedHazards(memory);
        }
        public void ConfigureSquad(MonsterSquadCoordinator coordinator, int slot)
        {
            if (squad != null) squad.Unregister(this);
            squad = coordinator;
            squadSlot = Mathf.Max(0, slot);
            if (squad != null) memory.PublishHazardsToSquad(squad, this);
        }
        private void OnDestroy() { if (squad != null) squad.Unregister(this); }

        public void ApplyArchetype(MonsterArchetypeDefinition definition)
        {
            if (definition == null) { Debug.LogError("Cannot apply a null monster archetype.", this); return; }
            if (!definition.IsValid(out string reason)) { Debug.LogError("Cannot apply invalid monster archetype: " + reason, this); return; }
            activeArchetypeId = definition.archetypeId;
            activeRole = definition.role;
            defendsNest = definition.defendsNest;
            baseMoveSpeed = definition.moveSpeed;
            investigateDuration = definition.investigateDuration;
            playerAttackRange = definition.playerAttackRange;
            playerAttackInterval = definition.playerAttackInterval;
            attackWindupSeconds = MonsterAttackRules.SanitizeWindup(definition.attackWindupSeconds);
            playerDamage = definition.playerDamage;
            sprintPursuitMultiplier = definition.sprintPursuitMultiplier;
            if (agent != null) agent.speed = baseMoveSpeed;
            if (perception != null) perception.ConfigureSenses(definition.sightRange, definition.fieldOfView, definition.hearingRange);
            if (siegeAttacker != null) siegeAttacker.ConfigureDamage(definition.towerDamage);
        }

        private void Awake()
        {
            if (agent == null) agent = GetComponent<NavMeshAgent>();
            scentTrailId = nextScentTrailId++;
            if (nextScentTrailId <= 0) nextScentTrailId = 1;
            if (scentTrailId == 0) scentTrailId = nextScentTrailId++;
            if (perception == null) perception = GetComponent<MonsterPerception>();
            if (siegeAttacker == null) siegeAttacker = GetComponent<TowerSiegeAttacker>();
            if (ownHealth == null) ownHealth = GetComponent<DamageableHealth>();
            if (agent != null) agent.speed = baseMoveSpeed;
            ConfigureSiegeTargets(siegeTargets);
            // Existing prefabs gain the behaviour-tree adapter without requiring manual component migration.
            if (GetComponent<MonsterBehaviourTreeRunner>() == null) gameObject.AddComponent<MonsterBehaviourTreeRunner>();
            if (GetComponent<MonsterAIUpdateLod>() == null) gameObject.AddComponent<MonsterAIUpdateLod>();
        }
        private void OnEnable()
        {
            if (perception != null) { perception.HeardStimulus += OnHeardStimulus; perception.SawPlayer += OnSawPlayer; }
            if (siegeAttacker != null) siegeAttacker.AttackResolved += OnSiegeAttackResolved;
        }
        private void OnDisable()
        {
            if (perception != null) { perception.HeardStimulus -= OnHeardStimulus; perception.SawPlayer -= OnSawPlayer; }
            if (siegeAttacker != null) siegeAttacker.AttackResolved -= OnSiegeAttackResolved;
            CancelPendingPlayerAttack();
            if (pendingCompanionTarget != null)
            {
                pendingCompanionTarget = null;
                AttackResolved?.Invoke(false);
            }
        }

        /// <summary>Compatibility entry point retained for existing callers.</summary>
        public Splatter.AI.NodeResult TickContact()
        {
            Splatter.AI.NodeResult direct = TickDirectContact();
            return direct == Splatter.AI.NodeResult.Failure ? TickSharedContact() : direct;
        }

        public Splatter.AI.NodeResult TickDirectContact()
        {
            if (!CanRunAgent() || perception == null || perception.VisiblePlayer == null)
                return Splatter.AI.NodeResult.Failure;
            Transform target = perception.VisiblePlayer;
            if (squad != null) squad.ReportVisibleContact(this, target);
            return TickContactTarget(target, target.position, true);
        }

        public Splatter.AI.NodeResult TickSharedContact()
        {
            if (!CanRunAgent() || squad == null) return Splatter.AI.NodeResult.Failure;
            Transform target;
            Vector3 lastKnownPosition;
            if (!squad.TryGetSharedContact(this, out target, out lastKnownPosition) || target == null)
                return Splatter.AI.NodeResult.Failure;
            return TickContactTarget(target, lastKnownPosition, false);
        }

        /// <summary>Runs one archetype's ordered tactical profile. Unavailable branches fail through to the next option.</summary>
        public Splatter.AI.NodeResult TickArchetypeDecision(MonsterArchetypeRole requestedRole)
        {
            if (requestedRole != activeRole) return Splatter.AI.NodeResult.Failure;
            RefreshVisibleTrapKnowledge();
            RefreshSquadHazardKnowledge();
            Splatter.AI.NodeResult distraction = TickAnimalDistraction();
            if (distraction != Splatter.AI.NodeResult.Failure) return distraction;
            System.Collections.Generic.IReadOnlyList<MonsterDecisionBranch> order = MonsterTacticalProfile.GetOrder(activeRole);
            for (int i = 0; i < order.Count; i++)
            {
                Splatter.AI.NodeResult result;
                switch (order[i])
                {
                    case MonsterDecisionBranch.DirectContact: result = TickDirectContact(); break;
                    case MonsterDecisionBranch.SharedContact: result = TickSharedContact(); break;
                    case MonsterDecisionBranch.Investigate: result = TickInvestigation(); break;
                    case MonsterDecisionBranch.GuardNest: result = TickNestGuard(); break;
                    case MonsterDecisionBranch.Siege: result = TickSiege(); break;
                    default: result = TickIdle(); break;
                }
                if (result != Splatter.AI.NodeResult.Failure) return result;
            }
            return Splatter.AI.NodeResult.Failure;
        }

        private Splatter.AI.NodeResult TickContactTarget(Transform target, Vector3 contactPosition, bool directSight)
        {
            if (target == null) return Splatter.AI.NodeResult.Failure;
            State = directSight ? MonsterTacticalState.HuntVisiblePlayer : MonsterTacticalState.HuntLastKnownContact;
            if (siegeAttacker != null) siegeAttacker.SetTarget(null);
            if (squad != null) squad.ReportSiegeTarget(this, null);
            PlayerMovement movement = directSight ? target.GetComponentInParent<PlayerMovement>() : null;
            bool observedSprint = directSight && movement != null && movement.IsSprinting;
            float roleSpeed = activeRole == MonsterArchetypeRole.Brute ? 0.88f :
                activeRole == MonsterArchetypeRole.Skirmisher ? 1.18f :
                activeRole == MonsterArchetypeRole.Lurker ? 0.94f : 1f;
            agent.speed = baseMoveSpeed * roleSpeed * (observedSprint && memory.RecognizesSprintPattern ? sprintPursuitMultiplier : 1f);

            if (ownHealth != null && !ownHealth.IsDead && ownHealth.HealthFraction <= retreatHealthFraction)
            {
                State = MonsterTacticalState.Retreat;
                Vector3 away = transform.position - contactPosition;
                if (away.sqrMagnitude < 0.001f) away = -transform.forward;
                away.Normalize();
                NavMeshHit retreatHit;
                Vector3 retreatPoint = transform.position + away * retreatDistance;
                if (NavMesh.SamplePosition(retreatPoint, out retreatHit, retreatDistance, NavMesh.AllAreas)) SetDestination(retreatHit.position);
                else SetDestination(transform.position + away * 2f);
                return Splatter.AI.NodeResult.Running;
            }

            if (defendsNest && homeNest != null && homeNest.IsActive && !homeNest.Contains(contactPosition))
            {
                agent.speed = baseMoveSpeed;
                State = MonsterTacticalState.GuardNest;
                SetDestination(homeNest.GetGuardPosition(squadSlot));
                return Splatter.AI.NodeResult.Running;
            }

            float flankMultiplier = activeRole == MonsterArchetypeRole.Brute ? 0f :
                activeRole == MonsterArchetypeRole.Skirmisher ? 1.65f :
                activeRole == MonsterArchetypeRole.Lurker ? 0.65f : 1.2f;
            Vector3 approach = squad != null
                ? squad.GetFlankDestination(this, contactPosition, squadSlot, squad.MemberCount, flankMultiplier)
                : contactPosition;
            if (directSight && Vector3.Distance(transform.position, target.position) <= playerAttackRange + 0.25f)
                approach = target.position;
            SetDestination(approach);
            if (directSight)
            {
                // A companion actively threatening this monster is a visible defensive target.
                // Resolve target choice before the player attack so the shared attack cooldown is deterministic.
                AttackCompanionIfClose(target);
                AttackPlayerIfClose(target);
            }
            return Splatter.AI.NodeResult.Running;
        }

        public Splatter.AI.NodeResult TickInvestigation()
        {
            if (!CanRunAgent() || Time.time >= investigateUntil) return Splatter.AI.NodeResult.Failure;
            State = MonsterTacticalState.InvestigateEvidence;
            agent.speed = memory.IsCautiousAroundGunfire ? baseMoveSpeed * 0.78f : baseMoveSpeed;
            if (siegeAttacker != null) siegeAttacker.SetTarget(null);
            if (squad != null) squad.ReportSiegeTarget(this, null);
            SetDestination(investigatePosition);
            return Splatter.AI.NodeResult.Running;
        }

        public Splatter.AI.NodeResult TickNestGuard()
        {
            if (!CanRunAgent() || !defendsNest || homeNest == null || !homeNest.IsActive) return Splatter.AI.NodeResult.Failure;
            State = MonsterTacticalState.GuardNest;
            agent.speed = baseMoveSpeed;
            if (siegeAttacker != null) siegeAttacker.SetTarget(null);
            if (squad != null) squad.ReportSiegeTarget(this, null);
            SetDestination(homeNest.GetGuardPosition(squadSlot));
            return Splatter.AI.NodeResult.Running;
        }

        public Splatter.AI.NodeResult TickSiege()
        {
            if (!CanRunAgent()) return Splatter.AI.NodeResult.Failure;
            SelectSiegeTarget();
            if (currentSiegeTarget == null) return Splatter.AI.NodeResult.Failure;
            State = MonsterTacticalState.SiegeStructure;
            if (siegeAttacker != null) siegeAttacker.SetTarget(currentSiegeTarget);
            SetSiegeDestination(currentSiegeTarget);
            return Splatter.AI.NodeResult.Running;
        }

        public Splatter.AI.NodeResult TickIdle()
        {
            if (!CanRunAgent()) return Splatter.AI.NodeResult.Failure;
            State = MonsterTacticalState.Idle;
            agent.speed = baseMoveSpeed;
            if (siegeAttacker != null) siegeAttacker.SetTarget(null);
            if (squad != null) squad.ReportSiegeTarget(this, null);
            if (agent.hasPath) agent.ResetPath();
            return Splatter.AI.NodeResult.Running;
        }

        private bool CanRunAgent() => agent != null && agent.enabled && (!requireBakedNavMesh || agent.isOnNavMesh);
        private void OnHeardStimulus(MonsterStimulus stimulus)
        {
            if (defendsNest && homeNest != null && homeNest.IsActive && !homeNest.Contains(stimulus.Position)) return;
            memory.RecordAudible(stimulus);
            if (stimulus.Kind == MonsterStimulusKind.AnimalDistraction)
            {
                // A decoy is only accepted through MonsterPerception's normal hearing-range and
                // obstruction checks. Rate limiting prevents one pet from permanently pinning AI.
                if (Time.time < nextDistractionAcceptedAt || stimulus.Source == null) return;
                int acceptedDecoyCount = memory.RecordAnimalDistraction(stimulus.Source, Time.time);
                // Experienced monsters can recognise a repeatedly reused decoy. At the highest
                // tier they ignore it and preserve any active combat commitment.
                if (AnimalDistractionRules.ShouldIgnoreRepeatedDecoy(acceptedDecoyCount)) return;
                distractionPosition = stimulus.Position;
                distractionUntil = Time.time + AnimalDistractionRules.InvestigationDurationFor(acceptedDecoyCount);
                CancelPendingPlayerAttack();
                if (pendingCompanionTarget != null)
                {
                    pendingCompanionTarget = null;
                    AttackResolved?.Invoke(false);
                }
                nextDistractionAcceptedAt = Time.time + AnimalDistractionRules.MonsterAcceptanceCooldownSeconds;
                distractionActive = true;
                investigatePosition = stimulus.Position;
                investigateUntil = distractionUntil;
            }
            else
            {
                investigatePosition = stimulus.Position;
                investigateUntil = Time.time + investigateDuration;
            }
            if (siegeAttacker != null) siegeAttacker.SetTarget(null);
            if (squad != null) squad.ReportSiegeTarget(this, null);
        }

        private Splatter.AI.NodeResult TickAnimalDistraction()
        {
            if (!distractionActive) return Splatter.AI.NodeResult.Failure;
            if (Time.time >= distractionUntil)
            {
                distractionActive = false;
                if (agent != null && agent.enabled) agent.isStopped = false;
                return Splatter.AI.NodeResult.Failure;
            }
            if (!CanRunAgent()) return Splatter.AI.NodeResult.Failure;
            State = MonsterTacticalState.InvestigateEvidence;
            agent.speed = baseMoveSpeed * AnimalDistractionRules.InvestigationSpeedFor(memory.RepeatedAnimalDistractionCount);
            if (siegeAttacker != null) siegeAttacker.SetTarget(null);
            if (squad != null) squad.ReportSiegeTarget(this, null);
            float distance = Vector3.Distance(transform.position, distractionPosition);
            if (distance > AnimalDistractionRules.ArrivalRadius) agent.isStopped = false;
            if (distance <= AnimalDistractionRules.ArrivalRadius)
            {
                agent.isStopped = true;
                if (agent.hasPath) agent.ResetPath();
            }
            else
            {
                SetDestination(distractionPosition);
            }
            return Splatter.AI.NodeResult.Running;
        }
        private void OnSawPlayer(Transform player)
        {
            PlayerMovement movement = player != null ? player.GetComponentInParent<PlayerMovement>() : null;
            if (movement != null && movement.IsSprinting) memory.RecordVisibleSprint(player.position);
        }
        private void SelectSiegeTarget()
        {
            currentSiegeTarget = null;
            float bestScore = float.MaxValue;
            float damageFocus = activeRole == MonsterArchetypeRole.Brute ? 0.85f :
                activeRole == MonsterArchetypeRole.Lurker ? 0.55f : 0.4f;
            if (siegeTargets != null) foreach (Transform candidate in siegeTargets)
            {
                if (candidate == null || !candidate.gameObject.activeInHierarchy) continue;
                TowerWeakPoint weakPoint = candidate.GetComponentInParent<TowerWeakPoint>();
                if (weakPoint != null && !weakPoint.IsAvailable) continue;
                TowerStructure structure = candidate.GetComponentInParent<TowerStructure>();
                if (structure != null && structure.IsDestroyed) continue;
                MonsterBridgeSiegeTarget bridgeSupport = candidate.GetComponentInParent<MonsterBridgeSiegeTarget>();
                // A bridge support is a valid tactical target only while the span exists,
                // remains traversable, and still recognises this segment as a required support.
                if (bridgeSupport != null && !bridgeSupport.IsAvailable) continue;
                float distanceSquared = (candidate.position - transform.position).sqrMagnitude;
                float healthFraction = structure != null ? structure.HealthFraction : 1f;
                float priority = structure != null ? structure.SiegePriority : 1f;
                float efficiency = structure != null ? 1f - structure.SiegeDamageResistance : 1f;
                if (structure != null && homeNest != null &&
                    homeNest.TryGetLearnedSiegeEfficiency(structure.Identity, out float learnedEfficiency))
                    efficiency = learnedEfficiency;
                float roleBias = structure != null
                    ? MonsterTargetScoring.GetRoleStructureBias(activeRole, structure.StructureKind) : 1f;
                float weakPointBias = weakPoint != null
                    ? MonsterTargetScoring.GetWeakPointRoleBias(activeRole, weakPoint.Kind) : 1f;
                float weakPointValue = weakPoint != null
                    ? weakPoint.DamageMultiplier * weakPoint.TargetPriority : 1f;
                float effectivePriority = priority * weakPointValue * weakPointBias / Mathf.Max(0.1f, roleBias);
                float score = MonsterTargetScoring.Calculate(distanceSquared, healthFraction,
                    effectivePriority, damageFocus, efficiency);
                if (bridgeSupport != null)
                {
                    int pressure = squad != null ? squad.GetSiegeTargetPressure(this, candidate) : 0;
                    score = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(
                        score, activeRole, pressure, healthFraction);
                }
                else if (squad != null)
                {
                    score *= 1f + squad.GetSiegeTargetPressure(this, candidate) * 0.8f;
                }
                if (score < bestScore) { bestScore = score; currentSiegeTarget = candidate; }
            }
            IReadOnlyList<SupplyConvoyController> convoys = SupplyConvoyController.ActiveConvoys;
            for (int i = 0; i < convoys.Count; i++)
            {
                SupplyConvoyController convoy = convoys[i];
                if (convoy == null || !convoy.IsAttackable) continue;
                Transform candidate = convoy.transform;
                float distanceSquared = (candidate.position - transform.position).sqrMagnitude;
                float score = MonsterTargetScoring.Calculate(distanceSquared, convoy.HealthFraction,
                    convoy.SiegePriority, damageFocus, 1f) * 1.15f;
                if (squad != null) score *= 1f + squad.GetSiegeTargetPressure(this, candidate) * 0.8f;
                if (score < bestScore) { bestScore = score; currentSiegeTarget = candidate; }
            }
            if (squad != null) squad.ReportSiegeTarget(this, currentSiegeTarget);
        }
        private void OnSiegeAttackResolved(TowerStructure structure, float damageEfficiency)
        {
            if (structure == null || homeNest == null || !homeNest.IsActive) return;
            homeNest.RecordSiegeObservation(structure.Identity, damageEfficiency);
        }

        public void NotifyTrapTriggered(PlayerTrap trap)
        {
            if (trap == null || string.IsNullOrWhiteSpace(trap.Identity)) return;
            RememberHazard(trap.Identity, trap.transform.position, trap.AvoidanceRadius, trap.Severity);
            investigatePosition = trap.transform.position;
            investigateUntil = Time.time + investigateDuration;
        }

        private void RememberHazard(string identity, Vector3 position, float radius, float severity)
        {
            bool newlyLearned = memory.RecordHazard(identity, position, radius, severity, Time.time);
            if (!newlyLearned) return;
            if (homeNest != null) homeNest.RecordLearnedHazard(identity, position, radius, severity);
            if (squad != null && memory.TryGetMostRecentHazard(out LearnedHazard hazard))
                squad.ReportLearnedHazard(this, hazard);
        }

        private void RefreshSquadHazardKnowledge()
        {
            if (squad == null || !squad.TryGetSharedHazard(this, out LearnedHazard sharedHazard)) return;
            bool newlyLearned = memory.RecordHazard(sharedHazard.Identity, sharedHazard.Position,
                sharedHazard.AvoidanceRadius, sharedHazard.Severity, Time.time);
            if (!newlyLearned) return;
            if (homeNest != null)
                homeNest.RecordLearnedHazard(sharedHazard.Identity, sharedHazard.Position,
                    sharedHazard.AvoidanceRadius, sharedHazard.Severity);
            // A receiver may relay this exact evidence onward, but each hop still requires range and line of sight.
            squad.ReportLearnedHazard(this, sharedHazard);
        }

        private void RefreshVisibleTrapKnowledge()
        {
            if (Time.time < nextTrapScan) return;
            nextTrapScan = Time.time + trapScanInterval;
            int count = Physics.OverlapSphereNonAlloc(transform.position, trapScanRange, trapScanBuffer,
                trapDetectionMask, QueryTriggerInteraction.Collide);
            Vector3 eye = transform.position + Vector3.up * 1.25f;
            for (int i = 0; i < count; i++)
            {
                Collider candidate = trapScanBuffer[i];
                if (candidate == null) continue;
                PlayerTrap trap = candidate.GetComponentInParent<PlayerTrap>();
                if (trap == null || !trap.IsArmed) continue;
                Vector3 target = trap.transform.position + Vector3.up * 0.15f;
                Vector3 delta = target - eye;
                float distance = delta.magnitude;
                if (distance > trap.RecognitionRadius || distance <= 0.05f) continue;
                if (Physics.Raycast(eye, delta / distance, out RaycastHit hit, distance,
                    trapVisibilityMask, QueryTriggerInteraction.Collide))
                {
                    PlayerTrap visibleTrap = hit.collider.GetComponentInParent<PlayerTrap>();
                    if (visibleTrap != trap) continue;
                }
                else continue;
                RememberHazard(trap.Identity, trap.transform.position, trap.AvoidanceRadius, trap.Severity);
            }
            for (int i = 0; i < count; i++) trapScanBuffer[i] = null;
        }

        private Vector3 GetHazardAwareDestination(Vector3 destination)
        {
            if (!memory.TryGetBlockingHazard(transform.position, destination, out LearnedHazard hazard)) return destination;
            Vector3 forward = destination - hazard.Position;
            forward.y = 0f;
            if (forward.sqrMagnitude < 0.001f) forward = transform.forward;
            forward.Normalize();
            Vector3 lateral = Vector3.Cross(Vector3.up, forward).normalized;
            float clearance = hazard.AvoidanceRadius + 1.35f;
            Vector3 first = hazard.Position + lateral * clearance;
            Vector3 second = hazard.Position - lateral * clearance;
            NavMeshHit firstHit, secondHit;
            bool firstValid = NavMesh.SamplePosition(first, out firstHit, 2.5f, NavMesh.AllAreas);
            bool secondValid = NavMesh.SamplePosition(second, out secondHit, 2.5f, NavMesh.AllAreas);
            if (firstValid && !memory.TryGetBlockingHazard(firstHit.position, destination, out _)) return firstHit.position;
            if (secondValid && !memory.TryGetBlockingHazard(secondHit.position, destination, out _)) return secondHit.position;
            if (firstValid && secondValid)
                return (firstHit.position - destination).sqrMagnitude <= (secondHit.position - destination).sqrMagnitude
                    ? firstHit.position : secondHit.position;
            if (firstValid) return firstHit.position;
            if (secondValid) return secondHit.position;
            return destination;
        }

        private void SetSiegeDestination(Transform target)
        {
            if (target == null || Time.time < nextRepath || agent == null || !agent.isOnNavMesh) return;
            nextRepath = Time.time + repathInterval;
            Vector3 desired = target.position;
            TowerWeakPoint weakPoint = target.GetComponentInParent<TowerWeakPoint>();
            if (weakPoint != null)
            {
                if (weakPoint.ApproachPoint != null)
                {
                    desired = weakPoint.ApproachPoint.position;
                }
                else
                {
                    Vector3 away = transform.position - target.position;
                    away.y = 0f;
                    if (away.sqrMagnitude < 0.001f) away = -transform.forward;
                    away.Normalize();
                    float attackRange = siegeAttacker != null ? siegeAttacker.AttackRange : 2.2f;
                    float standoff = Mathf.Max(agent.radius + 0.35f, attackRange * 0.65f);
                    desired = target.position + away * standoff;
                }
                if (NavMesh.SamplePosition(desired, out NavMeshHit approachHit, 2.5f, agent.areaMask))
                    desired = approachHit.position;
                else if (NavMesh.SamplePosition(target.position, out NavMeshHit targetHit, 2.5f, agent.areaMask))
                    desired = targetHit.position;
            }
            agent.SetDestination(GetHazardAwareDestination(desired));
        }

        private void SetDestination(Vector3 destination)
        {
            if (Time.time < nextRepath || agent == null || !agent.isOnNavMesh) return;
            nextRepath = Time.time + repathInterval;
            agent.SetDestination(GetHazardAwareDestination(destination));
        }
        private void AttackPlayerIfClose(Transform player)
        {
            if (pendingPlayerTarget != null || Time.time < nextAttack || player == null ||
                Vector3.Distance(transform.position, player.position) > playerAttackRange) return;
            PlayerVitals vitals = player.GetComponentInParent<PlayerVitals>();
            if (vitals == null || vitals.IsDead) return;
            pendingPlayerTarget = player;
            attackWindupSeconds = MonsterAttackRules.SanitizeWindup(attackWindupSeconds);
            pendingPlayerAttackImpactTime = Time.time + attackWindupSeconds;
            nextAttack = Time.time + playerAttackInterval;
            AttackStarted?.Invoke(); // Existing animation listeners begin the attack during its readable wind-up.
            AttackWindupStarted?.Invoke(player, attackWindupSeconds);
        }

        private void LateUpdate()
        {
            RecordPhysicalScentTrail();
            ResolvePendingCompanionAttack();
            if (pendingPlayerTarget == null) return;
            PlayerVitals vitals = pendingPlayerTarget.GetComponentInParent<PlayerVitals>();
            if (vitals == null || vitals.IsDead ||
                (perception != null && perception.VisiblePlayer != pendingPlayerTarget) ||
                Vector3.Distance(transform.position, pendingPlayerTarget.position) > playerAttackRange + 0.65f)
            {
                CancelPendingPlayerAttack();
                return;
            }
            if (Time.time < pendingPlayerAttackImpactTime) return;

            PlayerDodgeController dodge = pendingPlayerTarget.GetComponentInParent<PlayerDodgeController>();
            bool avoided = dodge != null && dodge.IsInvulnerable;
            if (!avoided) vitals.ApplyDamage(playerDamage, 4f);
            pendingPlayerTarget = null;
            AttackResolved?.Invoke(!avoided);
        }


        private void RecordPhysicalScentTrail()
        {
            if (agent == null || !agent.enabled || !agent.isOnNavMesh || agent.velocity.sqrMagnitude < 0.12f)
                return;
            Vector3 position = transform.position;
            if (!hasScentSample)
            {
                MonsterScentTrailRegistry.Record(scentTrailId, position, Time.time, activeRole);
                lastScentSamplePosition = position;
                nextScentSampleAt = Time.time + Mathf.Max(0.1f, scentSampleInterval);
                hasScentSample = true;
                return;
            }
            if (!AnimalScentTrailRules.ShouldRecord(lastScentSamplePosition, position, Time.time,
                nextScentSampleAt, scentSampleSpacing)) return;
            MonsterScentTrailRegistry.Record(scentTrailId, position, Time.time, activeRole);
            lastScentSamplePosition = position;
            nextScentSampleAt = Time.time + Mathf.Max(0.1f, scentSampleInterval);
        }

        private void CancelPendingPlayerAttack()
        {
            if (pendingPlayerTarget == null) return;
            pendingPlayerTarget = null;
            AttackResolved?.Invoke(false);
        }

        /// <summary>
        /// A monster only retaliates against the companion it can plausibly observe: its visible player owner
        /// must be in sight, and the companion must have independently confirmed this exact monster locally.
        /// </summary>
        private void AttackCompanionIfClose(Transform visiblePlayer)
        {
            if (pendingCompanionTarget != null || Time.time < nextAttack || visiblePlayer == null) return;
            if (observedCompanion == null || observedCompanion.Owner != visiblePlayer || !observedCompanion.IsOperational)
            {
                if (Time.time < nextCompanionLookup) return;
                nextCompanionLookup = Time.time + 1.25f;
                observedCompanion = FindFirstObjectByType<AnimalCompanionController>();
            }
            AnimalCompanionController companion = observedCompanion;
            if (companion == null || companion.Owner != visiblePlayer || !companion.IsOperational) return;
            float distance = Vector3.Distance(transform.position, companion.transform.position);
            if (!CompanionThreatRules.CanMonsterTargetCompanion(true, companion.Owner == visiblePlayer,
                companion.IsThreateningMonster(transform), companion.IsOperational, distance, playerAttackRange)) return;

            pendingCompanionTarget = companion.transform;
            attackWindupSeconds = MonsterAttackRules.SanitizeWindup(attackWindupSeconds);
            pendingCompanionAttackImpactTime = Time.time + attackWindupSeconds;
            nextAttack = Time.time + playerAttackInterval;
            AttackStarted?.Invoke();
            AttackWindupStarted?.Invoke(companion.transform, attackWindupSeconds);
        }

        private void ResolvePendingCompanionAttack()
        {
            if (pendingCompanionTarget == null) return;
            AnimalCompanionController companion = observedCompanion;
            Transform visiblePlayer = perception != null ? perception.VisiblePlayer : null;
            bool operational = companion != null && companion.transform == pendingCompanionTarget && companion.IsOperational;
            bool stillThreatening = operational && companion.IsThreateningMonster(transform);
            bool ownerVisible = operational && visiblePlayer != null && companion.Owner == visiblePlayer;
            float distance = operational ? Vector3.Distance(transform.position, pendingCompanionTarget.position) : float.MaxValue;
            if (!CompanionThreatRules.CanResolveCompanionAttack(operational, stillThreatening, ownerVisible,
                distance, playerAttackRange + 0.65f))
            {
                pendingCompanionTarget = null;
                AttackResolved?.Invoke(false);
                return;
            }
            if (Time.time < pendingCompanionAttackImpactTime) return;
            companion.ReceiveMonsterAttack(playerDamage);
            pendingCompanionTarget = null;
            AttackResolved?.Invoke(true);
        }
    }
}
