namespace GorgeHollow
{
    /// <summary>Pure rules for keeping enemy spawning off the bridge and requiring tower-gated entry.</summary>
    public static class MonsterBridgeAccessRules
    {
        public static bool CanSpawnAt(bool insideBridgeZone) => !insideBridgeZone;
        public static bool CanEnterBridge(bool bridgeExistsAndTraversable, bool passedTowerGateway) =>
            bridgeExistsAndTraversable && passedTowerGateway;
    }
}
