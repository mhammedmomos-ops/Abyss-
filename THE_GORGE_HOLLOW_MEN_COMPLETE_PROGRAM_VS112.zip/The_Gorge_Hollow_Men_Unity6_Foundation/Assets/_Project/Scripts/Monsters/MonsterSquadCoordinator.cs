using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>Coordinates only nearby, line-of-sight-confirmed contact reports within one raid.</summary>
    public sealed class MonsterSquadCoordinator : MonoBehaviour
    {
        [SerializeField, Min(1f)] private float communicationRange = 18f;
        [SerializeField, Min(0f)] private float flankRadius = 5f;
        [SerializeField, Min(0.1f)] private float contactFreshness = 2.5f;
        [SerializeField] private LayerMask obstructionMask = ~0;
        private readonly List<MonsterAIController> members = new List<MonsterAIController>(12);
        private readonly Dictionary<MonsterAIController, ContactReport> reports = new Dictionary<MonsterAIController, ContactReport>();
        private struct ContactReport { public Transform Target; public Vector3 Position; public float Time; }
        private struct HazardReport { public LearnedHazard Hazard; public float Time; }
        private readonly Dictionary<MonsterAIController, List<HazardReport>> hazardReports = new Dictionary<MonsterAIController, List<HazardReport>>();
        private struct SiegeTargetReport { public Transform Target; public float Time; }
        private readonly Dictionary<MonsterAIController, SiegeTargetReport> siegeTargetReports = new Dictionary<MonsterAIController, SiegeTargetReport>();
        private readonly List<MonsterAIController> expiredMembers = new List<MonsterAIController>(12);

        public int MemberCount => members.Count;

        public int Register(MonsterAIController member)
        {
            if (member == null) return -1;
            if (!members.Contains(member)) members.Add(member);
            return members.IndexOf(member);
        }

        public void Unregister(MonsterAIController member)
        {
            if (member == null) return;
            members.Remove(member);
            reports.Remove(member);
            hazardReports.Remove(member);
            siegeTargetReports.Remove(member);
        }

        /// <summary>Claims are local tactical coordination, not global knowledge. Null clears a member's claim.</summary>
        public void ReportSiegeTarget(MonsterAIController member, Transform target)
        {
            if (member == null || !members.Contains(member)) return;
            if (target == null) siegeTargetReports.Remove(member);
            else siegeTargetReports[member] = new SiegeTargetReport { Target = target, Time = Time.time };
        }

        /// <summary>Returns nearby squadmates currently committed to the exact same weak point/structure.</summary>
        public int GetSiegeTargetPressure(MonsterAIController receiver, Transform target)
        {
            if (receiver == null || target == null || !members.Contains(receiver)) return 0;
            int pressure = 0;
            foreach (KeyValuePair<MonsterAIController, SiegeTargetReport> pair in siegeTargetReports)
            {
                MonsterAIController reporter = pair.Key;
                SiegeTargetReport report = pair.Value;
                if (reporter == null || reporter == receiver || report.Target == null || report.Target != target ||
                    Time.time - report.Time > contactFreshness) continue;
                if (Vector3.Distance(reporter.transform.position, receiver.transform.position) <= communicationRange)
                    pressure++;
            }
            return pressure;
        }

        public void ReportVisibleContact(MonsterAIController reporter, Transform target)
        {
            if (reporter == null || target == null || !members.Contains(reporter)) return;
            reports[reporter] = new ContactReport { Target = target, Position = target.position, Time = Time.time };
        }

        public bool TryGetSharedContact(MonsterAIController receiver, out Transform target, out Vector3 lastKnownPosition)
        {
            target = null;
            lastKnownPosition = Vector3.zero;
            if (receiver == null || !members.Contains(receiver)) return false;
            float bestDistance = float.MaxValue;
            for (int i = 0; i < members.Count; i++)
            {
                MonsterAIController reporter = members[i];
                if (reporter == null || reporter == receiver || !reports.TryGetValue(reporter, out ContactReport report)) continue;
                if (report.Target == null || Time.time - report.Time > contactFreshness) continue;
                Vector3 delta = reporter.transform.position - receiver.transform.position;
                float distance = delta.magnitude;
                if (distance > communicationRange || distance >= bestDistance) continue;
                Vector3 origin = receiver.transform.position + Vector3.up;
                Vector3 direction = reporter.transform.position + Vector3.up - origin;
                if (direction.sqrMagnitude > 0.01f && Physics.Raycast(origin, direction.normalized, out RaycastHit hit, distance, obstructionMask, QueryTriggerInteraction.Ignore))
                {
                    if (hit.transform != reporter.transform && !hit.transform.IsChildOf(reporter.transform)) continue;
                }
                bestDistance = distance;
                target = report.Target;
                lastKnownPosition = report.Position;
            }
            return target != null;
        }

        public void ReportLearnedHazard(MonsterAIController reporter, LearnedHazard hazard)
        {
            if (reporter == null || !members.Contains(reporter) || string.IsNullOrWhiteSpace(hazard.Identity)) return;
            if (!hazardReports.TryGetValue(reporter, out List<HazardReport> reportsForMember))
            {
                reportsForMember = new List<HazardReport>(8);
                hazardReports.Add(reporter, reportsForMember);
            }
            for (int i = 0; i < reportsForMember.Count; i++)
            {
                if (reportsForMember[i].Hazard.Identity != hazard.Identity) continue;
                reportsForMember[i] = new HazardReport { Hazard = hazard, Time = Time.time };
                return;
            }
            if (reportsForMember.Count >= 8) reportsForMember.RemoveAt(0);
            reportsForMember.Add(new HazardReport { Hazard = hazard, Time = Time.time });
        }

        /// <summary>Receivers need proximity and clear sight to the reporting monster; no squad-wide global broadcast.</summary>
        public bool TryGetSharedHazard(MonsterAIController receiver, out LearnedHazard hazard)
        {
            hazard = default;
            if (receiver == null || !members.Contains(receiver)) return false;
            float newest = float.MinValue;
            bool found = false;
            foreach (KeyValuePair<MonsterAIController, List<HazardReport>> pair in hazardReports)
            {
                MonsterAIController reporter = pair.Key;
                if (reporter == null || reporter == receiver) continue;
                float distance = Vector3.Distance(reporter.transform.position, receiver.transform.position);
                if (distance > communicationRange) continue;
                Vector3 origin = receiver.transform.position + Vector3.up;
                Vector3 direction = reporter.transform.position + Vector3.up - origin;
                if (direction.sqrMagnitude > 0.01f && Physics.Raycast(origin, direction.normalized, out RaycastHit hit,
                    distance, obstructionMask, QueryTriggerInteraction.Ignore) &&
                    hit.transform != reporter.transform && !hit.transform.IsChildOf(reporter.transform)) continue;
                List<HazardReport> reportsForMember = pair.Value;
                for (int i = 0; i < reportsForMember.Count; i++)
                {
                    HazardReport report = reportsForMember[i];
                    if (Time.time - report.Time > contactFreshness * 2f || receiver.Memory.KnowsHazard(report.Hazard.Identity) || report.Time <= newest) continue;
                    newest = report.Time;
                    hazard = report.Hazard;
                    found = true;
                }
            }
            return found;
        }

        public Vector3 GetFlankDestination(MonsterAIController member, Vector3 targetPosition, int slot, int count)
        {
            return GetFlankDestination(member, targetPosition, slot, count, 1f);
        }

        public Vector3 GetFlankDestination(MonsterAIController member, Vector3 targetPosition, int slot, int count, float radiusMultiplier)
        {
            float effectiveRadius = flankRadius * Mathf.Max(0f, radiusMultiplier);
            if (member == null || effectiveRadius <= 0f) return targetPosition;
            int safeCount = Mathf.Max(1, count);
            float angle = (Mathf.PI * 2f * (slot % safeCount) / safeCount) + (Mathf.PI / 6f);
            Vector3 offset = new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle)) * effectiveRadius;
            Vector3 desired = targetPosition + offset;
            NavMeshHit hit;
            return NavMesh.SamplePosition(desired, out hit, Mathf.Max(2.5f, effectiveRadius * 0.5f), NavMesh.AllAreas) ? hit.position : targetPosition;
        }

        private void LateUpdate()
        {
            for (int i = members.Count - 1; i >= 0; i--)
                if (members[i] == null) members.RemoveAt(i);
            if (reports.Count == 0 && hazardReports.Count == 0 && siegeTargetReports.Count == 0) return;
            expiredMembers.Clear();
            foreach (KeyValuePair<MonsterAIController, ContactReport> pair in reports)
                if (pair.Key == null || pair.Value.Target == null || Time.time - pair.Value.Time > contactFreshness) expiredMembers.Add(pair.Key);
            for (int i = 0; i < expiredMembers.Count; i++) reports.Remove(expiredMembers[i]);
            expiredMembers.Clear();
            foreach (KeyValuePair<MonsterAIController, List<HazardReport>> pair in hazardReports)
            {
                if (pair.Key == null) { expiredMembers.Add(pair.Key); continue; }
                pair.Value.RemoveAll(report => Time.time - report.Time > contactFreshness * 2f);
                if (pair.Value.Count == 0) expiredMembers.Add(pair.Key);
            }
            for (int i = 0; i < expiredMembers.Count; i++) hazardReports.Remove(expiredMembers[i]);
            expiredMembers.Clear();
            foreach (KeyValuePair<MonsterAIController, SiegeTargetReport> pair in siegeTargetReports)
                if (pair.Key == null || pair.Value.Target == null || Time.time - pair.Value.Time > contactFreshness)
                    expiredMembers.Add(pair.Key);
            for (int i = 0; i < expiredMembers.Count; i++) siegeTargetReports.Remove(expiredMembers[i]);
        }
    }
}
