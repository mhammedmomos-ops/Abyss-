using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Defines the physical bridge-deck volume. It excludes spawn sockets and blocks
    /// any monster that did not enter through one of the tower gateway checkpoints.
    /// The assigned collider must cover the complete walkable deck and be a trigger.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider), typeof(Rigidbody))]
    public sealed class MonsterBridgeZone : MonoBehaviour
    {
        [SerializeField] private BridgeSpanController bridge;
        [SerializeField] private Collider zoneCollider;
        [Tooltip("Safe NavMesh points inside each tower, outside the bridge-deck volume. Both tower-side points are required.")]
        [SerializeField] private Transform[] towerSideRecoveryPoints;
        private readonly HashSet<MonsterBridgeAccessToken> occupants = new HashSet<MonsterBridgeAccessToken>();

        public BridgeSpanController Bridge => bridge;
        public bool IsConfigured
        {
            get
            {
                if (zoneCollider == null || !zoneCollider.enabled || !zoneCollider.isTrigger ||
                    !zoneCollider.gameObject.activeInHierarchy || bridge == null ||
                    towerSideRecoveryPoints == null || towerSideRecoveryPoints.Length < 2) return false;
                int validPoints = 0;
                for (int i = 0; i < towerSideRecoveryPoints.Length; i++)
                    if (towerSideRecoveryPoints[i] != null && !ContainsPosition(towerSideRecoveryPoints[i].position)) validPoints++;
                return validPoints >= 2;
            }
        }

        private void Reset()
        {
            zoneCollider = GetComponent<Collider>();
            if (zoneCollider != null) zoneCollider.isTrigger = true;
        }

        private void Awake()
        {
            if (zoneCollider == null) zoneCollider = GetComponent<Collider>();
            if (zoneCollider != null && !zoneCollider.isTrigger)
                Debug.LogError("MonsterBridgeZone collider must be a trigger covering the bridge deck.", this);
            Rigidbody body = GetComponent<Rigidbody>();
            if (body != null) { body.isKinematic = true; body.useGravity = false; }
            if (bridge == null) bridge = GetComponentInParent<BridgeSpanController>();
        }

        public bool ContainsPosition(Vector3 position)
        {
            return zoneCollider != null && zoneCollider.enabled && zoneCollider.bounds.Contains(position);
        }

        private void OnTriggerEnter(Collider other)
        {
            MonsterBridgeAccessToken token = other.GetComponentInParent<MonsterBridgeAccessToken>();
            if (token == null) return;

            if (!MonsterBridgeAccessRules.CanEnterBridge(
                    bridge != null && bridge.IsTraversable,
                    token.IsAuthorizedFor(bridge)))
            {
                if (!token.HasSafePosition || ContainsPosition(token.LastSafePosition))
                {
                    Transform recovery = FindClosestTowerRecoveryPoint(token.transform.position);
                    if (recovery != null) token.SetSafeTowerPosition(recovery.position);
                }
                token.ReturnToTowerSide();
                return;
            }

            token.MarkEntered(bridge);
            // Attach the lethal collapse behaviour to every enemy admitted onto this span.
            MonsterBridgeFallParticipant fallParticipant = token.GetComponent<MonsterBridgeFallParticipant>();
            if (fallParticipant == null) fallParticipant = token.gameObject.AddComponent<MonsterBridgeFallParticipant>();
            occupants.Add(token);
        }

        private void OnTriggerExit(Collider other)
        {
            MonsterBridgeAccessToken token = other.GetComponentInParent<MonsterBridgeAccessToken>();
            if (token == null || token.IsInsideBridgeZone && ContainsPosition(token.transform.position)) return;
            occupants.Remove(token);
            token.MarkExited(bridge);
        }

        private Transform FindClosestTowerRecoveryPoint(Vector3 fromPosition)
        {
            Transform closest = null;
            float closestDistance = float.PositiveInfinity;
            if (towerSideRecoveryPoints == null) return null;
            for (int i = 0; i < towerSideRecoveryPoints.Length; i++)
            {
                Transform candidate = towerSideRecoveryPoints[i];
                if (candidate == null || ContainsPosition(candidate.position)) continue;
                float distance = (candidate.position - fromPosition).sqrMagnitude;
                if (distance < closestDistance) { closestDistance = distance; closest = candidate; }
            }
            return closest;
        }

        private void Update()
        {
            if (occupants.Count == 0) return;
            if (bridge != null && bridge.IsTraversable) return;

            // A span collapsing beneath an enemy is a lethal fall into the gorge.
            // Never teleport bridge occupants back to either tower.
            var snapshot = new List<MonsterBridgeAccessToken>(occupants);
            occupants.Clear();
            foreach (MonsterBridgeAccessToken token in snapshot)
            {
                if (token == null) continue;
                MonsterBridgeFallParticipant fall = token.GetComponent<MonsterBridgeFallParticipant>();
                if (fall == null) fall = token.gameObject.AddComponent<MonsterBridgeFallParticipant>();
                fall.BeginFatalFall();
            }
        }

        private void OnDisable()
        {
            // Disabling the deck trigger during/after a collapse must not rescue occupants.
            // If the bridge is already non-traversable, preserve the fatal consequence.
            if (bridge != null && !bridge.IsTraversable)
            {
                foreach (MonsterBridgeAccessToken token in occupants)
                {
                    if (token == null) continue;
                    MonsterBridgeFallParticipant fall = token.GetComponent<MonsterBridgeFallParticipant>();
                    if (fall == null) fall = token.gameObject.AddComponent<MonsterBridgeFallParticipant>();
                    fall.BeginFatalFall();
                }
            }
            occupants.Clear();
        }
    }
}
