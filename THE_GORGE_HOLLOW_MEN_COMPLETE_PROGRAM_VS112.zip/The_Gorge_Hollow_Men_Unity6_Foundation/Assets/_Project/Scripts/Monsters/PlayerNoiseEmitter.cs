using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Emits periodic sprint footsteps at the player's actual position; it does not reveal the player globally.</summary>
    public sealed class PlayerNoiseEmitter : MonoBehaviour
    {
        [SerializeField] private PlayerMovement movement;
        [SerializeField, Min(0.05f)] private float sprintFootstepInterval = 0.48f;
        [SerializeField, Min(0f)] private float sprintFootstepLoudness = 9f;
        private float nextStepTime;
        private void Awake() { if (movement == null) movement = GetComponent<PlayerMovement>(); }
        private void Update()
        {
            if (movement == null || !movement.IsSprinting || Time.time < nextStepTime) return;
            nextStepTime = Time.time + sprintFootstepInterval;
            MonsterStimulusBus.Emit(MonsterStimulusKind.SprintFootstep, transform.position, sprintFootstepLoudness, gameObject);
        }
    }
}
