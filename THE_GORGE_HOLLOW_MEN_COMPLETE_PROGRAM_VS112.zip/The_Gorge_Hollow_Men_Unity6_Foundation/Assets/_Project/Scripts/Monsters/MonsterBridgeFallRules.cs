namespace GorgeHollow
{
    /// <summary>Pure rules for the lethal consequence of a bridge collapsing under an enemy.</summary>
    public static class MonsterBridgeFallRules
    {
        public static bool MustFallAndDie(bool wasOnBridgeAtCollapse, bool bridgeCollapsed)
            => wasOnBridgeAtCollapse && bridgeCollapsed;

        public static bool MayReturnToTowerAfterCollapse(bool wasOnBridgeAtCollapse, bool bridgeCollapsed)
            => !MustFallAndDie(wasOnBridgeAtCollapse, bridgeCollapsed);
    }
}
