using UnityEngine;

namespace GorgeHollow
{
    public enum MonsterAILodTier { Near, Mid, Far, Suspended }

    /// <summary>Pure distance-tier policy with hysteresis to prevent repeated enable/disable churn.</summary>
    public static class MonsterAILodPolicy
    {
        public static MonsterAILodTier Evaluate(float distance, MonsterAILodTier current,
            float nearDistance, float midDistance, float suspendDistance, float hysteresis)
        {
            if (float.IsNaN(distance) || float.IsInfinity(distance) || distance < 0f) return current;
            float near = Mathf.Max(0f, nearDistance);
            float mid = Mathf.Max(near + 0.1f, midDistance);
            float suspend = Mathf.Max(mid + 0.1f, suspendDistance);
            float band = Mathf.Clamp(hysteresis, 0f, (mid - near) * 0.45f);

            switch (current)
            {
                case MonsterAILodTier.Near:
                    if (distance > suspend + band) return MonsterAILodTier.Suspended;
                    if (distance > mid + band) return MonsterAILodTier.Far;
                    if (distance > near + band) return MonsterAILodTier.Mid;
                    return MonsterAILodTier.Near;
                case MonsterAILodTier.Mid:
                    if (distance < near - band) return MonsterAILodTier.Near;
                    if (distance > suspend + band) return MonsterAILodTier.Suspended;
                    if (distance > mid + band) return MonsterAILodTier.Far;
                    return MonsterAILodTier.Mid;
                case MonsterAILodTier.Far:
                    if (distance < near - band) return MonsterAILodTier.Near;
                    if (distance < mid - band) return MonsterAILodTier.Mid;
                    if (distance > suspend + band) return MonsterAILodTier.Suspended;
                    return MonsterAILodTier.Far;
                default:
                    if (distance < near - band) return MonsterAILodTier.Near;
                    if (distance < mid - band) return MonsterAILodTier.Mid;
                    if (distance < suspend - band) return MonsterAILodTier.Far;
                    return MonsterAILodTier.Suspended;
            }
        }
    }
}
