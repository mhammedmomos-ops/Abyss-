using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Pure validation and request construction for authored, event-driven encounter triggers.</summary>
    public static class MonsterEncounterRules
    {
        public static bool TryCreateRequest(Vector3 targetPosition, int threatBudget, int maximumSpawnCount,
            float minimumPlayerDistance, int randomSeed, out MonsterRaidRequest request, out string error)
        {
            request = new MonsterRaidRequest
            {
                TargetPosition = targetPosition,
                PlayerPosition = targetPosition,
                ThreatBudget = threatBudget,
                MaximumSpawnCount = maximumSpawnCount,
                MinimumPlayerDistance = minimumPlayerDistance,
                RandomSeed = randomSeed
            };
            if (!request.IsValid(out error))
            {
                request = null;
                return false;
            }
            return true;
        }

        public static int ResolveSeed(int configuredSeed, int encounterIndex)
        {
            unchecked
            {
                int seed = configuredSeed == 0 ? 53001 : configuredSeed;
                seed = (seed * 397) ^ Mathf.Max(0, encounterIndex);
                return seed == 0 ? 1 : seed;
            }
        }
    }
}
