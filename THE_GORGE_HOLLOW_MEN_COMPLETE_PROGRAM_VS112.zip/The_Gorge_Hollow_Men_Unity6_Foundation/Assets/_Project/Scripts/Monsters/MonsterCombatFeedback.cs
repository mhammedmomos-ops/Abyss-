using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Connects confirmed damage to optional authored hit-reaction animation and impact effects.</summary>
    [DisallowMultipleComponent, RequireComponent(typeof(DamageableHealth))]
    public sealed class MonsterCombatFeedback : MonoBehaviour
    {
        [SerializeField] private DamageableHealth health;
        [SerializeField] private Animator animator;
        [SerializeField] private string hitTrigger = "Hit";
        [SerializeField] private ParticleSystem impactEffect;
        [SerializeField, Min(0f)] private float reactionCooldown = 0.12f;
        [SerializeField, Min(0f)] private float minimumReactionDamage = 0.01f;
        private float nextReactionTime;

        private void Awake()
        {
            if (health == null) health = GetComponent<DamageableHealth>();
            if (animator == null) animator = GetComponentInChildren<Animator>();
        }
        private void OnEnable()
        {
            if (health != null) health.DamageReceived += OnDamageReceived;
        }
        private void OnDisable()
        {
            if (health != null) health.DamageReceived -= OnDamageReceived;
        }
        private void OnDamageReceived(float amount, Vector3 hitPoint, Vector3 hitDirection, GameObject source)
        {
            if ((health != null && health.IsDead) || amount < minimumReactionDamage || Time.time < nextReactionTime) return;
            nextReactionTime = Time.time + reactionCooldown;
            if (animator != null && !string.IsNullOrWhiteSpace(hitTrigger))
                animator.SetTrigger(hitTrigger);
            if (impactEffect != null)
            {
                impactEffect.transform.position = hitPoint;
                if (hitDirection.sqrMagnitude > 0.0001f)
                    impactEffect.transform.rotation = Quaternion.LookRotation(-hitDirection.normalized);
                impactEffect.Play();
            }
        }
    }
}
