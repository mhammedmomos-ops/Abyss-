using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Emits a periodic stimulus / toast when a monster first detects the player.
    /// Attach next to MonsterPerception when available.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class MonsterAggroPing : MonoBehaviour
    {
        [SerializeField] private float reaggroCooldown = 12f;
        [SerializeField] private string aggroMessage = "Something spotted you";
        [SerializeField] private float cameraTrauma = 0.2f;
        private float nextAllowed;
        private bool aggroed;

        public void NotifyAggro()
        {
            if (Time.time < nextAllowed) return;
            nextAllowed = Time.time + Mathf.Max(1f, reaggroCooldown);
            aggroed = true;
            if (!string.IsNullOrEmpty(aggroMessage))
            {
                GenericToastUI.Show(aggroMessage, 1.6f);
                KillFeedUI.Post(aggroMessage);
            }
            CameraShake.Shake(cameraTrauma);
            MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.RaidAlarm);
        }

        public void NotifyLost()
        {
            aggroed = false;
        }

        public bool IsAggroed => aggroed;
    }
}
