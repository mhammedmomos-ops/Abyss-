namespace GorgeHollow
{
    /// <summary>Rules for allowing and coordinating enemy attacks against persistent bridge supports.</summary>
    public static class MonsterBridgeSiegeRules
    {
        public static bool CanAttackSupport(bool isBridgeStructure, bool bridgeTraversable, bool isRequiredSupport,
            bool supportIntactOrDamaged, bool structureAlive, bool inRange, bool lineOfSight)
        {
            return isBridgeStructure && bridgeTraversable && isRequiredSupport && supportIntactOrDamaged &&
                   structureAlive && inRange && lineOfSight;
        }

        /// <summary>
        /// Applies role-specific bridge-siege priorities and local squad pressure.
        /// Lower scores are preferred by MonsterAIController. Brutes favour decisive attacks
        /// on weakened supports; skirmishers spread pressure to avoid needless crowding.
        /// </summary>
        public static float CalculateCoordinatedTargetScore(float baseScore, MonsterArchetypeRole role,
            int nearbyCommittedAttackers, float supportHealthFraction)
        {
            if (float.IsNaN(baseScore) || float.IsInfinity(baseScore) || baseScore < 0f)
                return float.PositiveInfinity;

            float roleBias;
            float pressurePenalty;
            switch (role)
            {
                case MonsterArchetypeRole.Brute:
                    roleBias = 0.72f;
                    pressurePenalty = 0.35f;
                    break;
                case MonsterArchetypeRole.Skirmisher:
                    roleBias = 1.12f;
                    pressurePenalty = 1.35f;
                    break;
                case MonsterArchetypeRole.Lurker:
                    roleBias = 0.88f;
                    pressurePenalty = 1.05f;
                    break;
                default:
                    roleBias = 1f;
                    pressurePenalty = 0.85f;
                    break;
            }

            // All roles favour weakened supports, but Brutes gain the strongest focus.
            float health = float.IsNaN(supportHealthFraction) || float.IsInfinity(supportHealthFraction)
                ? 1f : supportHealthFraction < 0f ? 0f
                : supportHealthFraction > 1f ? 1f : supportHealthFraction;
            float weakenedSupportBias = 1f - (1f - health) *
                (role == MonsterArchetypeRole.Brute ? 0.30f : 0.12f);
            int pressure = nearbyCommittedAttackers < 0 ? 0 : nearbyCommittedAttackers;
            return baseScore * roleBias * weakenedSupportBias * (1f + pressure * pressurePenalty);
        }
    }
}
