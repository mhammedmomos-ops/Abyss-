using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>Drives authored monster locomotion and attack animation parameters without taking movement authority from NavMeshAgent.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(MonsterAIController))]
    public sealed class MonsterAnimationBridge : MonoBehaviour
    {
        [SerializeField] private MonsterAIController controller;
        [SerializeField] private NavMeshAgent agent;
        [SerializeField] private Animator animator;
        [SerializeField] private string speedParameter = "Speed";
        [SerializeField] private string attackTrigger = "Attack";
        [SerializeField, Min(0f)] private float speedDampTime = 0.12f;
        private int speedHash;
        private int attackHash;
        private bool hasSpeedParameter;
        private bool hasAttackTrigger;

        private void Awake()
        {
            if (controller == null) controller = GetComponent<MonsterAIController>();
            if (agent == null) agent = GetComponent<NavMeshAgent>();
            if (animator == null) animator = GetComponentInChildren<Animator>();
            speedHash = string.IsNullOrWhiteSpace(speedParameter) ? 0 : Animator.StringToHash(speedParameter);
            attackHash = string.IsNullOrWhiteSpace(attackTrigger) ? 0 : Animator.StringToHash(attackTrigger);
            if (animator != null)
            {
                foreach (AnimatorControllerParameter parameter in animator.parameters)
                {
                    if (parameter.nameHash == speedHash && parameter.type == AnimatorControllerParameterType.Float) hasSpeedParameter = true;
                    if (parameter.nameHash == attackHash && parameter.type == AnimatorControllerParameterType.Trigger) hasAttackTrigger = true;
                }
            }
        }
        private void OnEnable()
        {
            if (controller != null) controller.AttackStarted += OnAttackStarted;
        }
        private void OnDisable()
        {
            if (controller != null) controller.AttackStarted -= OnAttackStarted;
        }
        private void Update()
        {
            if (animator == null || agent == null || !hasSpeedParameter) return;
            float speed = agent.enabled && agent.isOnNavMesh ? agent.velocity.magnitude : 0f;
            animator.SetFloat(speedHash, speed, speedDampTime, Time.deltaTime);
        }
        private void OnAttackStarted()
        {
            if (animator != null && hasAttackTrigger) animator.SetTrigger(attackHash);
        }
    }
}
