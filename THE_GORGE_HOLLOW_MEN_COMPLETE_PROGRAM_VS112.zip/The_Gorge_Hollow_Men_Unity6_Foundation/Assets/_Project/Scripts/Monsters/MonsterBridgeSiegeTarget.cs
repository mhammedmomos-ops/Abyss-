using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Optional marker for a persistent TowerStructure that is one of the active bridge's
    /// required supports. Attach to each bridge support structure that enemies may attack.
    /// The campaign-backed TowerStructure health remains authoritative.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class MonsterBridgeSiegeTarget : MonoBehaviour
    {
        [SerializeField] private BridgeSpanController bridge;
        [SerializeField] private TowerStructuralSegment supportSegment;
        [SerializeField] private TowerStructure structure;

        public BridgeSpanController Bridge => bridge;
        public TowerStructuralSegment SupportSegment => supportSegment;
        public TowerStructure Structure => structure;

        public bool IsAvailable
        {
            get
            {
                if (bridge == null || supportSegment == null || structure == null) return false;
                bool supportUsable = supportSegment.IsStateInitialized &&
                    (supportSegment.CurrentState == TowerStructuralSegmentState.Intact ||
                     supportSegment.CurrentState == TowerStructuralSegmentState.Damaged);
                return MonsterBridgeSiegeRules.CanAttackSupport(
                    structure.StructureKind == TowerStructureKind.Bridge,
                    bridge.IsTraversable,
                    bridge.ContainsRequiredSupport(supportSegment),
                    supportUsable,
                    !structure.IsDestroyed && structure.CurrentHealth > 0,
                    true, true);
            }
        }

        private void Reset() => ResolveReferences();
        private void Awake() => ResolveReferences();

        private void ResolveReferences()
        {
            if (supportSegment == null) supportSegment = GetComponent<TowerStructuralSegment>();
            if (structure == null) structure = GetComponent<TowerStructure>();
            if (structure == null) structure = GetComponentInParent<TowerStructure>();
            if (bridge == null)
            {
                BridgeSpanController[] candidates = FindObjectsByType<BridgeSpanController>(FindObjectsSortMode.None);
                if (candidates.Length == 1) bridge = candidates[0];
            }
        }

        private void OnValidate()
        {
            if (supportSegment == null) supportSegment = GetComponent<TowerStructuralSegment>();
            if (structure == null) structure = GetComponent<TowerStructure>();
        }
    }
}
