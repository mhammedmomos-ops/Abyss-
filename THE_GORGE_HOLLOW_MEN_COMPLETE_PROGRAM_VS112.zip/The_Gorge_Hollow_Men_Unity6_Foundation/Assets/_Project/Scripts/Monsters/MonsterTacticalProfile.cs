using System;
using System.Collections.Generic;

namespace GorgeHollow
{
    public enum MonsterDecisionBranch
    {
        DirectContact,
        SharedContact,
        Investigate,
        GuardNest,
        Siege,
        Idle
    }

    /// <summary>Data-driven branch priorities for the four monster roles.</summary>
    public static class MonsterTacticalProfile
    {
        private static readonly IReadOnlyList<MonsterDecisionBranch> StalkerOrder = Array.AsReadOnly(new[]
        {
            MonsterDecisionBranch.DirectContact, MonsterDecisionBranch.SharedContact,
            MonsterDecisionBranch.Investigate, MonsterDecisionBranch.GuardNest,
            MonsterDecisionBranch.Siege, MonsterDecisionBranch.Idle
        });
        private static readonly IReadOnlyList<MonsterDecisionBranch> BruteOrder = Array.AsReadOnly(new[]
        {
            MonsterDecisionBranch.DirectContact, MonsterDecisionBranch.Siege,
            MonsterDecisionBranch.SharedContact, MonsterDecisionBranch.Investigate,
            MonsterDecisionBranch.GuardNest, MonsterDecisionBranch.Idle
        });
        private static readonly IReadOnlyList<MonsterDecisionBranch> SkirmisherOrder = Array.AsReadOnly(new[]
        {
            MonsterDecisionBranch.DirectContact, MonsterDecisionBranch.SharedContact,
            MonsterDecisionBranch.Investigate, MonsterDecisionBranch.Siege,
            MonsterDecisionBranch.GuardNest, MonsterDecisionBranch.Idle
        });
        private static readonly IReadOnlyList<MonsterDecisionBranch> LurkerOrder = Array.AsReadOnly(new[]
        {
            MonsterDecisionBranch.DirectContact, MonsterDecisionBranch.GuardNest,
            MonsterDecisionBranch.Investigate, MonsterDecisionBranch.SharedContact,
            MonsterDecisionBranch.Siege, MonsterDecisionBranch.Idle
        });

        public static IReadOnlyList<MonsterDecisionBranch> GetOrder(MonsterArchetypeRole role)
        {
            switch (role)
            {
                case MonsterArchetypeRole.Brute: return BruteOrder;
                case MonsterArchetypeRole.Skirmisher: return SkirmisherOrder;
                case MonsterArchetypeRole.Lurker: return LurkerOrder;
                default: return StalkerOrder;
            }
        }
    }
}
