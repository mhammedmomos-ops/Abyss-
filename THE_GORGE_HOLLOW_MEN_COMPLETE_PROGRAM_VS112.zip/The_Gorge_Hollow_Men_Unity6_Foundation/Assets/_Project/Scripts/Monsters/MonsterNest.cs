using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>Authored nest territory with campaign-persistent health and locally audible alarm events.</summary>
    public sealed class MonsterNest : MonoBehaviour
    {
        [Header("Identity and territory")]
        [SerializeField] private string nestId = "nest_outer_01";
        [SerializeField] private Transform guardPoint;
        [SerializeField, Min(1f)] private float territoryRadius = 24f;
        [SerializeField, Min(0f)] private float guardOffsetRadius = 2.5f;
        [SerializeField] private bool territoryEnabled = true;
        [Header("Persistent nest health")]
        [SerializeField, Min(1)] private int maximumHealth = 250;
        [SerializeField, Min(0)] private int currentHealth = 250;
        [SerializeField, Min(0f)] private float alarmLoudness = 30f;
        [SerializeField, Min(0.1f)] private float alarmCooldown = 8f;
        [SerializeField] private bool alarmOnDamage = true;
        public const int MaximumPersistedHazards = 8;
        public const int MaximumPersistedSiegeTargets = 8;
        private int alarmCount;
        private float nextAlarmTime;
        private readonly List<MonsterHazardRecord> learnedHazards = new List<MonsterHazardRecord>(MaximumPersistedHazards);
        private readonly List<MonsterSiegeObservationRecord> learnedSiegeTargets = new List<MonsterSiegeObservationRecord>(MaximumPersistedSiegeTargets);
        public static event Action<MonsterNest> StateChanged;
        public static event Action<MonsterNest> AlarmRaised;
        public string Identity => nestId;
        public bool IsDestroyed => currentHealth <= 0;
        public int CurrentHealth => currentHealth;
        public int MaximumHealth => maximumHealth;
        public int AlarmCount => alarmCount;
        public bool IsActive => isActiveAndEnabled && territoryEnabled && !IsDestroyed;
        public float TerritoryRadius => territoryRadius;
        public int LearnedHazardCount => learnedHazards.Count;
        public int LearnedSiegeTargetCount => learnedSiegeTargets.Count;
        public Vector3 AnchorPosition => guardPoint != null ? guardPoint.position : transform.position;

        /// <summary>Persists only evidence actually observed by this nest's defenders.</summary>
        public bool RecordLearnedHazard(string identity, Vector3 position, float avoidanceRadius, float severity)
        {
            if (string.IsNullOrWhiteSpace(identity) || avoidanceRadius <= 0f || !IsFinite(avoidanceRadius) ||
                !IsFinite(severity) || !IsFinite(position.x) || !IsFinite(position.y) || !IsFinite(position.z)) return false;
            for (int i = 0; i < learnedHazards.Count; i++)
            {
                MonsterHazardRecord existing = learnedHazards[i];
                if (existing.identity != identity) continue;
                bool changed = (existing.position - position).sqrMagnitude > 0.25f ||
                    avoidanceRadius > existing.avoidanceRadius + 0.25f || severity > existing.severity + 0.1f;
                existing.observationCount = Mathf.Min(1000, existing.observationCount + 1);
                if (!changed) return false;
                existing.position = position;
                existing.avoidanceRadius = Mathf.Max(existing.avoidanceRadius, avoidanceRadius);
                existing.severity = Mathf.Max(existing.severity, severity);
                StateChanged?.Invoke(this);
                return true;
            }
            if (learnedHazards.Count >= MaximumPersistedHazards) learnedHazards.RemoveAt(0);
            learnedHazards.Add(new MonsterHazardRecord
            {
                identity = identity, position = position, avoidanceRadius = avoidanceRadius,
                severity = Mathf.Max(0f, severity), observationCount = 1
            });
            StateChanged?.Invoke(this);
            return true;
        }

        /// <summary>Stores observed attack effectiveness for this nest only; no global monster knowledge is created.</summary>
        public bool RecordSiegeObservation(string structureIdentity, float damageEfficiency)
        {
            if (string.IsNullOrWhiteSpace(structureIdentity) || !IsFinite(damageEfficiency)) return false;
            float sample = Mathf.Clamp01(damageEfficiency);
            for (int i = 0; i < learnedSiegeTargets.Count; i++)
            {
                MonsterSiegeObservationRecord record = learnedSiegeTargets[i];
                if (record.structureIdentity != structureIdentity) continue;
                record.averageDamageEfficiency = Mathf.Lerp(record.averageDamageEfficiency, sample, 1f / Mathf.Min(8, record.observationCount + 1));
                record.observationCount = Mathf.Min(1000, record.observationCount + 1);
                StateChanged?.Invoke(this);
                return true;
            }
            if (learnedSiegeTargets.Count >= MaximumPersistedSiegeTargets) learnedSiegeTargets.RemoveAt(0);
            learnedSiegeTargets.Add(new MonsterSiegeObservationRecord
            {
                structureIdentity = structureIdentity,
                averageDamageEfficiency = sample,
                observationCount = 1
            });
            StateChanged?.Invoke(this);
            return true;
        }

        public bool TryGetLearnedSiegeEfficiency(string structureIdentity, out float efficiency)
        {
            efficiency = 1f;
            if (string.IsNullOrWhiteSpace(structureIdentity)) return false;
            for (int i = 0; i < learnedSiegeTargets.Count; i++)
            {
                MonsterSiegeObservationRecord record = learnedSiegeTargets[i];
                if (record == null || record.structureIdentity != structureIdentity) continue;
                efficiency = Mathf.Clamp01(record.averageDamageEfficiency);
                return true;
            }
            return false;
        }

        public void RestoreLearnedHazards(MonsterLearningMemory memory)
        {
            if (memory == null) return;
            for (int i = 0; i < learnedHazards.Count; i++)
            {
                MonsterHazardRecord record = learnedHazards[i];
                if (record == null) continue;
                memory.RecordHazard(record.identity, record.position, record.avoidanceRadius, record.severity, Time.time);
            }
        }

        private static bool IsFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

        private void Awake()
        {
            maximumHealth = Mathf.Max(1, maximumHealth);
            currentHealth = Mathf.Clamp(currentHealth, 0, maximumHealth);
        }

        public bool Contains(Vector3 position)
        {
            if (!IsActive) return false;
            Vector3 delta = position - transform.position;
            delta.y = 0f;
            return delta.sqrMagnitude <= territoryRadius * territoryRadius;
        }

        public Vector3 GetGuardPosition(int squadSlot)
        {
            Vector3 anchor = AnchorPosition;
            if (guardOffsetRadius <= 0f) return anchor;
            int slot = Mathf.Max(0, squadSlot);
            // Golden-angle spacing avoids duplicate guard positions when a squad exceeds six members.
            float angle = slot * 2.39996323f;
            float radius = guardOffsetRadius * Mathf.Sqrt((slot + 1f) / 12f);
            Vector3 desired = anchor + new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle)) * radius;
            NavMeshHit hit;
            return NavMesh.SamplePosition(desired, out hit, 2f, NavMesh.AllAreas) ? hit.position : anchor;
        }

        public bool ApplyDamage(int amount, GameObject source)
        {
            if (amount <= 0 || IsDestroyed || !isActiveAndEnabled) return false;
            int previous = currentHealth;
            currentHealth = Mathf.Max(0, currentHealth - amount);
            if (alarmOnDamage) RaiseAlarm();
            StateChanged?.Invoke(this);
            return currentHealth != previous;
        }

        public bool Repair(int amount)
        {
            if (amount <= 0 || currentHealth >= maximumHealth) return false;
            currentHealth = Mathf.Min(maximumHealth, currentHealth + amount);
            StateChanged?.Invoke(this);
            return true;
        }

        public void Restore(MonsterNestRecord record)
        {
            if (record == null || !string.Equals(record.identity, nestId, StringComparison.Ordinal)) return;
            maximumHealth = Mathf.Max(1, record.maxHealth);
            currentHealth = Mathf.Clamp(record.currentHealth, 0, maximumHealth);
            alarmCount = Mathf.Max(0, record.alarmCount);
            learnedHazards.Clear();
            learnedSiegeTargets.Clear();
            if (record.learnedSiegeTargets != null)
            {
                for (int i = 0; i < record.learnedSiegeTargets.Count && i < MaximumPersistedSiegeTargets; i++)
                {
                    MonsterSiegeObservationRecord observation = record.learnedSiegeTargets[i];
                    if (observation == null || string.IsNullOrWhiteSpace(observation.structureIdentity) ||
                        !IsFinite(observation.averageDamageEfficiency) || observation.averageDamageEfficiency < 0f ||
                        observation.averageDamageEfficiency > 1f) continue;
                    bool duplicate = false;
                    for (int j = 0; j < learnedSiegeTargets.Count; j++)
                        if (learnedSiegeTargets[j].structureIdentity == observation.structureIdentity) { duplicate = true; break; }
                    if (duplicate) continue;
                    learnedSiegeTargets.Add(new MonsterSiegeObservationRecord
                    {
                        structureIdentity = observation.structureIdentity,
                        averageDamageEfficiency = observation.averageDamageEfficiency,
                        observationCount = Mathf.Max(1, observation.observationCount)
                    });
                }
            }
            if (record.learnedHazards != null)
            {
                for (int i = 0; i < record.learnedHazards.Count && i < MaximumPersistedHazards; i++)
                {
                    MonsterHazardRecord hazard = record.learnedHazards[i];
                    if (hazard == null || string.IsNullOrWhiteSpace(hazard.identity) || hazard.avoidanceRadius <= 0f ||
                        !IsFinite(hazard.avoidanceRadius) || !IsFinite(hazard.severity) ||
                        !IsFinite(hazard.position.x) || !IsFinite(hazard.position.y) || !IsFinite(hazard.position.z)) continue;
                    bool duplicate = false;
                    for (int j = 0; j < learnedHazards.Count; j++)
                        if (learnedHazards[j].identity == hazard.identity) { duplicate = true; break; }
                    if (duplicate) continue;
                    learnedHazards.Add(new MonsterHazardRecord
                    {
                        identity = hazard.identity, position = hazard.position,
                        avoidanceRadius = hazard.avoidanceRadius, severity = Mathf.Max(0f, hazard.severity),
                        observationCount = Mathf.Max(1, hazard.observationCount)
                    });
                }
            }
            StateChanged?.Invoke(this);
        }

        public MonsterNestRecord Capture()
        {
            return new MonsterNestRecord
            {
                identity = nestId,
                maxHealth = maximumHealth,
                currentHealth = currentHealth,
                isDestroyed = IsDestroyed,
                alarmCount = alarmCount,
                learnedHazards = CloneLearnedHazards(),
                learnedSiegeTargets = CloneLearnedSiegeTargets()
            };
        }

        private List<MonsterSiegeObservationRecord> CloneLearnedSiegeTargets()
        {
            var copy = new List<MonsterSiegeObservationRecord>(learnedSiegeTargets.Count);
            for (int i = 0; i < learnedSiegeTargets.Count; i++)
            {
                MonsterSiegeObservationRecord record = learnedSiegeTargets[i];
                if (record == null) continue;
                copy.Add(new MonsterSiegeObservationRecord
                {
                    structureIdentity = record.structureIdentity,
                    averageDamageEfficiency = record.averageDamageEfficiency,
                    observationCount = record.observationCount
                });
            }
            return copy;
        }

        private List<MonsterHazardRecord> CloneLearnedHazards()
        {
            var copy = new List<MonsterHazardRecord>(learnedHazards.Count);
            for (int i = 0; i < learnedHazards.Count; i++)
            {
                MonsterHazardRecord hazard = learnedHazards[i];
                if (hazard == null) continue;
                copy.Add(new MonsterHazardRecord
                {
                    identity = hazard.identity, position = hazard.position,
                    avoidanceRadius = hazard.avoidanceRadius, severity = hazard.severity,
                    observationCount = hazard.observationCount
                });
            }
            return copy;
        }

        private void RaiseAlarm()
        {
            if (alarmLoudness <= 0f || Time.time < nextAlarmTime) return;
            nextAlarmTime = Time.time + alarmCooldown;
            alarmCount++;
            AlarmRaised?.Invoke(this);
            MonsterStimulusBus.Emit(MonsterStimulusKind.NestAlarm, transform.position, alarmLoudness, gameObject);
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            maximumHealth = Mathf.Max(1, maximumHealth);
            currentHealth = Mathf.Clamp(currentHealth, 0, maximumHealth);
            territoryRadius = Mathf.Max(1f, territoryRadius);
            if (string.IsNullOrWhiteSpace(nestId)) nestId = "nest_outer_01";
        }
        private void OnDrawGizmosSelected()
        {
            Gizmos.color = IsDestroyed ? Color.gray : new Color(0.55f, 0.12f, 0.12f, 0.8f);
            Gizmos.DrawWireSphere(transform.position, territoryRadius);
            Gizmos.color = Color.yellow;
            Gizmos.DrawSphere(AnchorPosition, 0.25f);
        }
#endif
    }
}
