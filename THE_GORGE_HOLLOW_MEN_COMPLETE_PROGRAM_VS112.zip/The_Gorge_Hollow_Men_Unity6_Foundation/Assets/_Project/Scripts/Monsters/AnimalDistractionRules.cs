namespace GorgeHollow
{
    /// <summary>Shared bounds for audible animal decoys; perception still enforces range and occlusion.</summary>
    public static class AnimalDistractionRules
    {
        public const float MonsterInvestigationSeconds = 5.5f;
        public const float MonsterAcceptanceCooldownSeconds = 2.75f;
        public const float MonsterInvestigationSpeedMultiplier = 0.9f;
        public const float ArrivalRadius = 1.8f;
        public const int SuspiciousAfterAcceptedCount = 3;
        public const int IgnoreAfterAcceptedCount = 5;
        public const float SuspiciousInvestigationSeconds = 2.25f;
        public const float SuspiciousInvestigationSpeedMultiplier = 1f;

        /// <summary>Repeated audible decoys from the same companion lose effectiveness, never increase it.</summary>
        public static bool ShouldIgnoreRepeatedDecoy(int acceptedCount) => acceptedCount >= IgnoreAfterAcceptedCount;

        public static float InvestigationDurationFor(int acceptedCount)
        {
            return acceptedCount >= SuspiciousAfterAcceptedCount
                ? SuspiciousInvestigationSeconds : MonsterInvestigationSeconds;
        }

        public static float InvestigationSpeedFor(int acceptedCount)
        {
            return acceptedCount >= SuspiciousAfterAcceptedCount
                ? SuspiciousInvestigationSpeedMultiplier : MonsterInvestigationSpeedMultiplier;
        }

        public static bool CanEmit(AnimalRecord record, AnimalSpecies species, float now, float nextAllowedAt)
        {
            return record != null && record.status == AnimalStatus.Alive && record.health > 0 &&
                   record.hunger > 0 && record.species == species &&
                   !float.IsNaN(now) && !float.IsInfinity(now) && now >= nextAllowedAt;
        }
    }
}
