using Splatter.AI;
using Splatter.AI.Composites;
using Splatter.AI.Leaves;
using Splatter.AI.Unity;

namespace GorgeHollow
{
    /// <summary>
    /// Splatter.AI owns reactive branch selection and centrally scheduled ticking.
    /// Project-specific tactical order is supplied by MonsterTacticalProfile.
    /// </summary>
    public sealed class MonsterBehaviourTreeRunner : BehaviourTreeRunner
    {
        private MonsterAIController controller;

        protected override void Awake()
        {
            base.Awake();
            controller = GetComponent<MonsterAIController>();
        }

        protected override Node CreateRoot()
        {
            // Role is read at tick time, not tree-construction time, because archetypes are applied after spawn.
            return new ReactiveSelector
            {
                new Leaf("Stalker tactical profile", () => RunRole(MonsterArchetypeRole.Stalker)),
                new Leaf("Brute tactical profile", () => RunRole(MonsterArchetypeRole.Brute)),
                new Leaf("Skirmisher tactical profile", () => RunRole(MonsterArchetypeRole.Skirmisher)),
                new Leaf("Lurker tactical profile", () => RunRole(MonsterArchetypeRole.Lurker))
            };
        }

        private NodeResult RunRole(MonsterArchetypeRole role)
        {
            return controller != null ? controller.TickArchetypeDecision(role) : NodeResult.Failure;
        }
    }
}
