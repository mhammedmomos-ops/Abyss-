using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Sanitizes the readable warning window before a monster attack resolves.</summary>
    public static class MonsterAttackRules
    {
        public static float SanitizeWindup(float seconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds)) return 0.55f;
            return Mathf.Clamp(seconds, 0f, 3f);
        }
    }
}
