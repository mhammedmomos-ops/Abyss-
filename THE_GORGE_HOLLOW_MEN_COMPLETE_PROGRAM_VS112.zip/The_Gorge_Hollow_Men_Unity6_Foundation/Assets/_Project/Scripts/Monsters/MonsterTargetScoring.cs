using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Small deterministic scoring helper for tactical structure selection.</summary>
    public static class MonsterTargetScoring
    {
        /// <param name="distanceSquared">Squared world distance to the candidate.</param>
        /// <param name="healthFraction">Current health divided by maximum health.</param>
        /// <param name="siegePriority">Designer-authored importance; larger values attract attackers.</param>
        /// <param name="damageFocus">How strongly this monster favours already-damaged structures.</param>
        public static float Calculate(float distanceSquared, float healthFraction, float siegePriority, float damageFocus)
        {
            return Calculate(distanceSquared, healthFraction, siegePriority, damageFocus, 1f);
        }

        public static float Calculate(float distanceSquared, float healthFraction, float siegePriority,
            float damageFocus, float observedDamageEfficiency)
        {
            if (float.IsNaN(distanceSquared) || float.IsInfinity(distanceSquared) || distanceSquared < 0f)
                return float.PositiveInfinity;
            float health = Mathf.Clamp01(healthFraction);
            float priority = Mathf.Max(0.1f, siegePriority);
            float focus = Mathf.Clamp01(damageFocus);
            float efficiency = Mathf.Clamp01(observedDamageEfficiency);
            float vulnerabilityWeight = Mathf.Lerp(1f - 0.65f * focus, 1f, health);
            // Repeatedly ineffective attacks make a target less attractive, but never impossible to attack.
            float resistancePenalty = Mathf.Lerp(2.1f, 0.85f, efficiency);
            return distanceSquared * vulnerabilityWeight * resistancePenalty / priority;
        }


        public static float GetWeakPointRoleBias(MonsterArchetypeRole role, TowerWeakPointKind kind)
        {
            switch (role)
            {
                case MonsterArchetypeRole.Brute:
                    return kind == TowerWeakPointKind.GateHinge || kind == TowerWeakPointKind.ReinforcementSeam ? 0.78f : 1f;
                case MonsterArchetypeRole.Skirmisher:
                    return kind == TowerWeakPointKind.PowerCoupling || kind == TowerWeakPointKind.SignalRelay ? 0.78f : 1.05f;
                case MonsterArchetypeRole.Lurker:
                    return kind == TowerWeakPointKind.CoreVent || kind == TowerWeakPointKind.BridgeAnchor ? 0.84f : 1f;
                default:
                    return 1f;
            }
        }

        public static float GetRoleStructureBias(MonsterArchetypeRole role, TowerStructureKind kind)
        {
            switch (role)
            {
                case MonsterArchetypeRole.Brute:
                    return kind == TowerStructureKind.Barricade || kind == TowerStructureKind.ReinforcedBarricade || kind == TowerStructureKind.Gate ? 0.82f : 1f;
                case MonsterArchetypeRole.Skirmisher:
                    return kind == TowerStructureKind.Generator || kind == TowerStructureKind.Signal ? 0.82f : 1.08f;
                case MonsterArchetypeRole.Lurker:
                    return kind == TowerStructureKind.Signal || kind == TowerStructureKind.Utility ? 0.9f : 1.05f;
                default:
                    return 1f;
            }
        }
    }
}
