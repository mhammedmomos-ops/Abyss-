using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Starts one authored encounter when the player reaches the trigger. This is event-driven,
    /// not a clock-based raid scheduler. Failed requests remain retryable by leaving and re-entering.
    /// </summary>
    [RequireComponent(typeof(Collider))]
    public sealed class MonsterEncounterTrigger : MonoBehaviour
    {
        [SerializeField] private MonsterRaidDirector raidDirector;
        [SerializeField] private Transform playerTarget;
        [SerializeField, Min(1)] private int threatBudget = 4;
        [SerializeField, Min(1)] private int maximumSpawnCount = 2;
        [SerializeField, Min(0f)] private float minimumPlayerDistance = 16f;
        [SerializeField] private int configuredSeed = 53001;
        [SerializeField] private bool disableAfterSuccessfulStart = true;
        private bool started;
        private int encounterIndex;

        public bool HasStarted => started;

        private void Awake()
        {
            Collider trigger = GetComponent<Collider>();
            if (trigger != null && !trigger.isTrigger)
                Debug.LogError("MonsterEncounterTrigger requires a trigger collider.", this);
            if (raidDirector == null) raidDirector = FindFirstObjectByType<MonsterRaidDirector>();
        }

        private void OnTriggerEnter(Collider other)
        {
            if (started || other == null) return;
            PlayerVitals vitals = other.GetComponentInParent<PlayerVitals>();
            if (vitals == null || vitals.IsDead) return;
            Transform candidate = vitals.transform;
            if (playerTarget != null && playerTarget != candidate && !candidate.IsChildOf(playerTarget) && !playerTarget.IsChildOf(candidate))
                return;
            playerTarget = candidate;
            TryStartEncounter();
        }

        public bool TryStartEncounter()
        {
            if (started) return false;
            if (raidDirector == null) raidDirector = FindFirstObjectByType<MonsterRaidDirector>();
            if (playerTarget == null)
            {
                Debug.LogWarning("Encounter cannot start: player target is not assigned or has not entered the trigger.", this);
                return false;
            }
            if (raidDirector == null)
            {
                Debug.LogError("Encounter cannot start: MonsterRaidDirector is missing.", this);
                return false;
            }

            int seed = MonsterEncounterRules.ResolveSeed(configuredSeed, encounterIndex);
            if (!MonsterEncounterRules.TryCreateRequest(playerTarget.position, threatBudget, maximumSpawnCount,
                minimumPlayerDistance, seed, out MonsterRaidRequest request, out string validationError))
            {
                Debug.LogError("Encounter request is invalid: " + validationError, this);
                return false;
            }
            request.PlayerPosition = playerTarget.position;
            if (!raidDirector.RequestRaid(request, out int spawned, out string error))
            {
                Debug.LogWarning("Encounter was not started: " + error + " Bake the NavMesh and check spawn sockets and roster assignments.", this);
                return false;
            }

            started = true;
            encounterIndex++;
            if (disableAfterSuccessfulStart) gameObject.SetActive(false);
            Debug.Log("First encounter started. Monsters spawned: " + spawned, this);
            return true;
        }
    }
}
