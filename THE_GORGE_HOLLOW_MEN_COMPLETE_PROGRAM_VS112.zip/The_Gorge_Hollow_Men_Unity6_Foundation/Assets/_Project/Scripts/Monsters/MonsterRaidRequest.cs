using UnityEngine;

namespace GorgeHollow
{
    /// <summary>One explicit story/world-event request. There is deliberately no clock-based raid scheduler.</summary>
    public sealed class MonsterRaidRequest
    {
        public Vector3 TargetPosition { get; set; }
        public Vector3 PlayerPosition { get; set; }
        public int ThreatBudget { get; set; }
        public int MaximumSpawnCount { get; set; }
        public float MinimumPlayerDistance { get; set; } = 16f;
        public int RandomSeed { get; set; }

        public bool IsValid(out string reason)
        {
            if (ThreatBudget < 1) { reason = "Threat budget must be at least one."; return false; }
            if (MaximumSpawnCount < 1) { reason = "Maximum spawn count must be at least one."; return false; }
            if (MinimumPlayerDistance < 0f || float.IsNaN(MinimumPlayerDistance) || float.IsInfinity(MinimumPlayerDistance))
            { reason = "Minimum player distance must be finite and non-negative."; return false; }
            if (!IsFinite(TargetPosition) || !IsFinite(PlayerPosition))
            { reason = "Raid positions must contain finite coordinates."; return false; }
            reason = null;
            return true;
        }

        private static bool IsFinite(Vector3 value)
        {
            return IsFinite(value.x) && IsFinite(value.y) && IsFinite(value.z);
        }
        private static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }
    }
}
