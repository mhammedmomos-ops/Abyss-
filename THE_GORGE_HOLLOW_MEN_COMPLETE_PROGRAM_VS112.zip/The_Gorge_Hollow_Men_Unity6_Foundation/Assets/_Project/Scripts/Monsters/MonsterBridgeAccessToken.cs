using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>
    /// Runtime proof that this monster physically crossed an authored tower gateway.
    /// Place a MonsterBridgeAccessGate inside each tower's bridge-facing passage.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(NavMeshAgent))]
    public sealed class MonsterBridgeAccessToken : MonoBehaviour
    {
        [SerializeField] private NavMeshAgent agent;
        private BridgeSpanController authorizedBridge;
        private Vector3 lastSafeTowerPosition;
        private bool hasSafePosition;
        private bool insideBridgeZone;
        private float authorizationExpiresAt;
        private const float GatewayAuthorizationSeconds = 12f;

        public bool IsInsideBridgeZone => insideBridgeZone;
        public bool HasTowerAuthorization => authorizedBridge != null;
        public bool HasSafePosition => hasSafePosition;
        public Vector3 LastSafePosition => lastSafeTowerPosition;

        private void Awake()
        {
            if (agent == null) agent = GetComponent<NavMeshAgent>();
            // Do not treat an arbitrary spawn location as a safe tower-side recovery point.
            // The tower gateway or bridge-zone recovery points must explicitly set it.
        }

        private void Update()
        {
            if (!insideBridgeZone && authorizedBridge != null && Time.time > authorizationExpiresAt)
                authorizedBridge = null;
        }

        public void SetSafeTowerPosition(Vector3 position)
        {
            lastSafeTowerPosition = position;
            hasSafePosition = true;
        }

        public bool GrantFromTowerGateway(BridgeSpanController bridge, Vector3 towerSideSafePosition)
        {
            if (bridge == null || !bridge.IsTraversable) return false;
            authorizedBridge = bridge;
            authorizationExpiresAt = Time.time + GatewayAuthorizationSeconds;
            SetSafeTowerPosition(towerSideSafePosition);
            return true;
        }

        public bool IsAuthorizedFor(BridgeSpanController bridge) =>
            bridge != null && bridge.IsTraversable && authorizedBridge == bridge &&
            (insideBridgeZone || Time.time <= authorizationExpiresAt);

        public void MarkEntered(BridgeSpanController bridge)
        {
            if (IsAuthorizedFor(bridge)) insideBridgeZone = true;
        }

        public void MarkExited(BridgeSpanController bridge)
        {
            if (authorizedBridge != bridge) return;
            insideBridgeZone = false;
            authorizedBridge = null;
            if (agent != null && agent.isOnNavMesh)
            {
                lastSafeTowerPosition = transform.position;
                hasSafePosition = true;
            }
        }

        public bool ReturnToTowerSide()
        {
            if (!hasSafePosition || agent == null) return false;
            if (!agent.enabled)
            {
                transform.position = lastSafeTowerPosition;
                insideBridgeZone = false;
                authorizedBridge = null;
                return true;
            }
            NavMeshHit safeHit;
            if (NavMesh.SamplePosition(lastSafeTowerPosition, out safeHit, 2.5f, agent.areaMask))
            {
                MonsterBridgeZone[] zones = FindObjectsByType<MonsterBridgeZone>(FindObjectsSortMode.None);
                bool sampledBackOntoBridge = false;
                for (int i = 0; i < zones.Length; i++)
                    if (zones[i] != null && zones[i].ContainsPosition(safeHit.position))
                    { sampledBackOntoBridge = true; break; }

                if (sampledBackOntoBridge)
                {
                    // Never let a broad NavMesh sample pull the recovery destination back
                    // onto the deck. Preserve the known tower-side point and fail closed.
                    agent.enabled = false;
                    transform.position = lastSafeTowerPosition;
                }
                else if (!agent.Warp(safeHit.position))
                {
                    agent.enabled = false;
                    transform.position = lastSafeTowerPosition;
                }
            }
            else
            {
                // Fail closed: if a NavMesh update temporarily removed the tower-side
                // polygon, place the monster at its last safe tower-side point and stop
                // its agent rather than leaving it on the bridge deck.
                agent.enabled = false;
                transform.position = lastSafeTowerPosition;
            }
            insideBridgeZone = false;
            authorizedBridge = null;
            return true;
        }
    }
}
