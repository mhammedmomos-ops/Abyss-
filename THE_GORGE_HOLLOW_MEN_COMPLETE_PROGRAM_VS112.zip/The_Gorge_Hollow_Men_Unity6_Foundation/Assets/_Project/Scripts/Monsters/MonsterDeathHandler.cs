using System;
using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>Stops a defeated monster cleanly and raises a campaign-facing event hook.</summary>
    [RequireComponent(typeof(DamageableHealth))]
    public sealed class MonsterDeathHandler : MonoBehaviour
    {
        [SerializeField] private DamageableHealth health;
        [SerializeField] private NavMeshAgent agent;
        [SerializeField] private Animator animator;
        [SerializeField] private string deathTrigger = "Death";
        [SerializeField, Min(0f)] private float destroyAfterSeconds = 8f;
        private bool handled;
        public static event Action<GameObject, GameObject> MonsterKilled;
        private void Awake()
        {
            if (health == null) health = GetComponent<DamageableHealth>();
            if (agent == null) agent = GetComponent<NavMeshAgent>();
            if (animator == null) animator = GetComponentInChildren<Animator>();
        }
        private void OnEnable() { if (health != null) health.Killed += OnKilled; }
        private void OnDisable() { if (health != null) health.Killed -= OnKilled; }
        private void OnKilled(GameObject source)
        {
            if (handled) return;
            handled = true;
            if (agent != null) { if (agent.isOnNavMesh) agent.isStopped = true; agent.enabled = false; }
            MonsterAIController ai = GetComponent<MonsterAIController>();
            if (ai != null) ai.enabled = false; // Cancels any attack wind-up before a defeated monster can land a hit.
            if (animator != null && !string.IsNullOrWhiteSpace(deathTrigger)) animator.SetTrigger(deathTrigger);
            MonsterKilled?.Invoke(gameObject, source);
            if (destroyAfterSeconds > 0f) Destroy(gameObject, destroyAfterSeconds);
        }
    }
}
