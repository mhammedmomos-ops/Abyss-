using UnityEngine;
using Splatter.AI.Unity;

namespace GorgeHollow
{
    /// <summary>Distance-based background AI LOD. Keeps Unity navigation active while pausing distant decision-tree ticks.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(MonsterPerception))]
    public sealed class MonsterAIUpdateLod : MonoBehaviour
    {
        [SerializeField] private Transform playerTarget;
        [SerializeField, Min(0.1f)] private float evaluationInterval = 0.5f;
        [SerializeField, Min(1f)] private float nearDistance = 28f;
        [SerializeField, Min(1f)] private float midDistance = 58f;
        [SerializeField, Min(1f)] private float suspendDistance = 92f;
        [SerializeField, Min(0f)] private float hysteresis = 7f;
        [Header("Perception scan intervals")]
        [SerializeField, Min(0.05f)] private float nearScanInterval = 0.2f;
        [SerializeField, Min(0.05f)] private float midScanInterval = 0.4f;
        [SerializeField, Min(0.05f)] private float farScanInterval = 0.8f;
        [SerializeField, Min(0.05f)] private float suspendedScanInterval = 1.5f;

        private MonsterPerception perception;
        private BehaviourTreeRunner runner;
        private MonsterAILodTier currentTier = MonsterAILodTier.Near;
        private float nextEvaluation;

        public MonsterAILodTier CurrentTier => currentTier;

        private void Awake()
        {
            perception = GetComponent<MonsterPerception>();
            runner = GetComponent<MonsterBehaviourTreeRunner>();
            nextEvaluation = Time.time;
            ApplyTier(MonsterAILodTier.Near);
        }

        public void ConfigureTarget(Transform target)
        {
            playerTarget = target;
            if (perception != null) perception.SetPlayerTarget(target);
            nextEvaluation = Time.time;
        }

        private void Update()
        {
            if (Time.time < nextEvaluation) return;
            nextEvaluation = Time.time + Mathf.Max(0.1f, evaluationInterval);
            if (playerTarget == null)
            {
                if (currentTier != MonsterAILodTier.Near) ApplyTier(MonsterAILodTier.Near);
                return;
            }

            float distance = Vector3.Distance(transform.position, playerTarget.position);
            MonsterAILodTier next = MonsterAILodPolicy.Evaluate(distance, currentTier, nearDistance,
                midDistance, suspendDistance, hysteresis);
            if (next != currentTier) ApplyTier(next);
        }

        private void ApplyTier(MonsterAILodTier tier)
        {
            currentTier = tier;
            if (perception != null)
            {
                float interval = tier == MonsterAILodTier.Near ? nearScanInterval :
                    tier == MonsterAILodTier.Mid ? midScanInterval :
                    tier == MonsterAILodTier.Far ? farScanInterval : suspendedScanInterval;
                perception.ConfigureScanInterval(interval);
            }
            // Splatter.AI documents that disabling its runner pauses the tree and re-enabling resumes it.
            // NavMeshAgent is deliberately left enabled so an already-issued path can finish in the background.
            if (runner != null) runner.enabled = tier != MonsterAILodTier.Suspended;
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            evaluationInterval = Mathf.Max(0.1f, evaluationInterval);
            nearDistance = Mathf.Max(1f, nearDistance);
            midDistance = Mathf.Max(nearDistance + 0.1f, midDistance);
            suspendDistance = Mathf.Max(midDistance + 0.1f, suspendDistance);
            hysteresis = Mathf.Max(0f, hysteresis);
            nearScanInterval = Mathf.Max(0.05f, nearScanInterval);
            midScanInterval = Mathf.Max(nearScanInterval, midScanInterval);
            farScanInterval = Mathf.Max(midScanInterval, farScanInterval);
            suspendedScanInterval = Mathf.Max(farScanInterval, suspendedScanInterval);
        }
#endif
    }
}
