using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Trigger checkpoint installed in the bridge-facing passage of each tower.
    /// A monster receives bridge permission only by physically passing this trigger.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider), typeof(Rigidbody))]
    public sealed class MonsterBridgeAccessGate : MonoBehaviour
    {
        [SerializeField] private BridgeSpanController bridge;
        [Tooltip("Optional explicit safe point on the tower side of this gateway. If empty, this transform is used.")]
        [SerializeField] private Transform towerSideSafePoint;

        private void Reset()
        {
            Collider trigger = GetComponent<Collider>();
            if (trigger != null) trigger.isTrigger = true;
            Rigidbody body = GetComponent<Rigidbody>();
            if (body != null) { body.isKinematic = true; body.useGravity = false; }
        }

        private void Awake()
        {
            Collider trigger = GetComponent<Collider>();
            Rigidbody body = GetComponent<Rigidbody>();
            if (trigger != null && !trigger.isTrigger)
                Debug.LogError("MonsterBridgeAccessGate collider must be a trigger inside the tower passage.", this);
            if (body != null) { body.isKinematic = true; body.useGravity = false; }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.GetComponentInParent<MonsterAIController>() == null) return;
            MonsterBridgeAccessToken token = other.GetComponentInParent<MonsterBridgeAccessToken>();
            if (token == null || bridge == null || !bridge.IsTraversable) return;
            Vector3 safePosition = towerSideSafePoint != null
                ? towerSideSafePoint.position : transform.position;
            MonsterBridgeZone[] zones = FindObjectsByType<MonsterBridgeZone>(FindObjectsSortMode.None);
            bool hasMatchingZone = false;
            for (int i = 0; i < zones.Length; i++)
            {
                if (zones[i] == null || zones[i].Bridge != bridge) continue;
                hasMatchingZone = true;
                if (zones[i].ContainsPosition(safePosition)) return;
            }
            if (!hasMatchingZone) return;
            token.GrantFromTowerGateway(bridge, safePosition);
        }
    }
}
