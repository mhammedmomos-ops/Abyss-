using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Deterministic reward validation and stable transaction-ID construction for completed raids.</summary>
    public static class MonsterRaidRewardRules
    {
        public static bool IsFullClear(int spawned, int killed)
        {
            return spawned > 0 && killed == spawned;
        }

        public static ResourceDelta CreateFullClearReward(int spawned, int killed, int scrapPerMonster, int ammoPerMonster)
        {
            if (!IsFullClear(spawned, killed)) return null;
            int count = Mathf.Clamp(killed, 1, 100);
            return new ResourceDelta
            {
                scrap = Mathf.Clamp(scrapPerMonster, 0, 1000) * count,
                ammunition = Mathf.Clamp(ammoPerMonster, 0, 1000) * count
            };
        }

        public static string BuildTransactionId(string campaignId, string encounterId)
        {
            if (string.IsNullOrWhiteSpace(campaignId) || string.IsNullOrWhiteSpace(encounterId)) return null;
            return "raid-clear:" + campaignId.Trim() + ":" + encounterId.Trim();
        }
    }

    /// <summary>Persists one-time full-clear rewards through the campaign transaction service.</summary>
    [DisallowMultipleComponent]
    public sealed class MonsterRaidReward : UnityEngine.MonoBehaviour
    {
        [SerializeField] private MonsterRaidDirector director;
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField, Min(0)] private int scrapPerMonster = 6;
        [SerializeField, Min(0)] private int ammunitionPerMonster = 3;
        private void Awake()
        {
            if (director == null) director = GetComponent<MonsterRaidDirector>();
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }
        private void OnEnable()
        {
            if (director != null) director.EncounterResolved += OnEncounterResolved;
        }
        private void OnDisable()
        {
            if (director != null) director.EncounterResolved -= OnEncounterResolved;
        }
        private void OnEncounterResolved(MonsterRaidDirector source, string encounterId, int spawned, int killed)
        {
            if (source != director || bootstrap == null || bootstrap.Campaign == null || bootstrap.Transactions == null) return;
            ResourceDelta reward = MonsterRaidRewardRules.CreateFullClearReward(spawned, killed, scrapPerMonster, ammunitionPerMonster);
            if (reward == null) return;

            string transactionId = MonsterRaidRewardRules.BuildTransactionId(bootstrap.Campaign.campaignId, encounterId);
            CampaignState campaign = bootstrap.Campaign;
            int oldScrap = campaign.scrap;
            int oldAmmo = campaign.ammunition;
            if (!bootstrap.Transactions.TryApply(campaign, transactionId, reward, out string error))
            {
                Debug.LogError("Raid reward transaction failed: " + error, this);
                return;
            }
            if (!bootstrap.SaveCampaign())
            {
                campaign.scrap = oldScrap;
                campaign.ammunition = oldAmmo;
                campaign.appliedTransactionIds.Remove(transactionId);
                Debug.LogError("Raid reward was rolled back because campaign persistence failed.", this);
            }
        }
    }
}
