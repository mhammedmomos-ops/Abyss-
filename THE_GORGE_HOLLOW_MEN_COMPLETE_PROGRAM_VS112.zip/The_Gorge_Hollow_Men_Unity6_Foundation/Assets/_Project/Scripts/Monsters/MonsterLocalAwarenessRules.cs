using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Pure rules for what the player can legitimately perceive at their current position.</summary>
    public static class MonsterLocalAwarenessRules
    {
        public static bool CanSeeHostile(float distance, float visualRadius, bool hasLineOfSight, bool insideView)
        {
            if (float.IsNaN(distance) || float.IsInfinity(distance) || distance < 0f) return false;
            return hasLineOfSight && insideView && distance <= Mathf.Max(0f, visualRadius);
        }

        public static bool CanHearHostile(float distance, float hearingRadius, bool alreadyVisible)
        {
            if (alreadyVisible || float.IsNaN(distance) || float.IsInfinity(distance) || distance < 0f) return false;
            return distance <= Mathf.Max(0f, hearingRadius);
        }

        public static bool ShouldSuppressRemoteTowerObject(bool playerInsideTower, bool hostileInsideOtherTower)
        {
            return playerInsideTower && hostileInsideOtherTower;
        }

        public static float CalculateLocalThreat(int visibleHostiles, bool heardMovement)
        {
            int count = Mathf.Max(0, visibleHostiles);
            float visual = Mathf.Clamp01(count * 0.28f);
            return Mathf.Clamp01(Mathf.Max(visual, heardMovement ? 0.18f : 0f));
        }
    }
}
