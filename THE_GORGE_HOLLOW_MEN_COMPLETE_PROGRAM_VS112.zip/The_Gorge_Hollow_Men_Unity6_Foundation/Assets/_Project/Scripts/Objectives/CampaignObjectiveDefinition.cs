using UnityEngine;

namespace GorgeHollow
{
    public enum ObjectiveKind
    {
        Custom,
        RepairBridge,
        SurviveUntilDawn,
        ScavengeResources,
        ClearNest
    }

    /// <summary>
    /// Authorable objective descriptor placed in a scene or on a bootstrap object.
    /// Completion is persisted via campaign flags (no new save fields).
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class CampaignObjectiveDefinition : MonoBehaviour
    {
        [SerializeField] private string objectiveId = "objective_01";
        [SerializeField] private string displayTitle = "Objective";
        [SerializeField, TextArea] private string displayDescription = "";
        [SerializeField] private ObjectiveKind kind = ObjectiveKind.Custom;
        [SerializeField] private bool activeOnStart = true;
        [SerializeField] private BridgeSpanController linkedBridge;
        [SerializeField] private int scavengeTargetCount = 3;

        public string ObjectiveId => objectiveId;
        public string DisplayTitle => displayTitle;
        public string DisplayDescription => displayDescription;
        public ObjectiveKind Kind => kind;
        public bool ActiveOnStart => activeOnStart;
        public BridgeSpanController LinkedBridge => linkedBridge;
        public int ScavengeTargetCount => scavengeTargetCount;

        private void OnValidate()
        {
            if (string.IsNullOrWhiteSpace(objectiveId))
                objectiveId = "objective_" + gameObject.name;
        }
    }
}
