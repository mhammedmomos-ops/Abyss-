namespace GorgeHollow
{
    /// <summary>
    /// Pure helpers for objective identity and completion flags.
    /// Completion is stored as campaign flags with a stable prefix to avoid schema migration.
    /// </summary>
    public static class ObjectiveRules
    {
        public const string FlagPrefix = "objective_complete:";

        public static string CompletionFlag(string objectiveId)
        {
            if (string.IsNullOrWhiteSpace(objectiveId)) return FlagPrefix + "invalid";
            return FlagPrefix + objectiveId.Trim().ToLowerInvariant();
        }

        public static bool IsComplete(CampaignState state, string objectiveId)
        {
            if (state == null || state.campaignFlags == null || string.IsNullOrWhiteSpace(objectiveId))
                return false;
            string flag = CompletionFlag(objectiveId);
            for (int i = 0; i < state.campaignFlags.Count; i++)
                if (string.Equals(state.campaignFlags[i], flag, System.StringComparison.Ordinal))
                    return true;
            return false;
        }

        public static bool TryMarkComplete(CampaignState state, string objectiveId)
        {
            if (state == null || string.IsNullOrWhiteSpace(objectiveId)) return false;
            if (state.campaignFlags == null)
                state.campaignFlags = new System.Collections.Generic.List<string>();
            string flag = CompletionFlag(objectiveId);
            if (IsComplete(state, objectiveId)) return false;
            state.campaignFlags.Add(flag);
            return true;
        }

        public static bool IsValidObjectiveId(string objectiveId)
            => !string.IsNullOrWhiteSpace(objectiveId) && objectiveId.Trim().Length <= 64;
    }
}
