using System;
using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Tracks active scene objectives, listens for bridge reconstruction and scavenges,
    /// and persists completion through campaign flags.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ObjectiveTracker : MonoBehaviour
    {
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private CampaignObjectiveDefinition[] objectives;
        [SerializeField] private bool autoFindObjectivesInScene = true;

        private readonly List<CampaignObjectiveDefinition> active = new List<CampaignObjectiveDefinition>();
        private readonly Dictionary<string, int> scavengeProgress = new Dictionary<string, int>();

        public event Action<CampaignObjectiveDefinition> ObjectiveActivated;
        public event Action<CampaignObjectiveDefinition> ObjectiveCompleted;
        public event Action<string, int, int> ScavengeProgressChanged;

        public IReadOnlyList<CampaignObjectiveDefinition> ActiveObjectives => active;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            if (autoFindObjectivesInScene)
            {
                var found = FindObjectsByType<CampaignObjectiveDefinition>(FindObjectsSortMode.None);
                objectives = found;
            }
        }

        private void OnEnable()
        {
            if (objectives == null) return;
            for (int i = 0; i < objectives.Length; i++)
            {
                CampaignObjectiveDefinition def = objectives[i];
                if (def == null) continue;
                if (IsAlreadyComplete(def)) continue;
                if (def.ActiveOnStart) Activate(def);
                if (def.Kind == ObjectiveKind.RepairBridge && def.LinkedBridge != null)
                    def.LinkedBridge.SpanStateChanged += OnBridgeSpanChanged;
            }
            CampaignEvents.ScavengeCompleted += OnScavengeCompleted;
        }

        private void OnDisable()
        {
            if (objectives != null)
            {
                for (int i = 0; i < objectives.Length; i++)
                {
                    CampaignObjectiveDefinition def = objectives[i];
                    if (def != null && def.LinkedBridge != null)
                        def.LinkedBridge.SpanStateChanged -= OnBridgeSpanChanged;
                }
            }
            CampaignEvents.ScavengeCompleted -= OnScavengeCompleted;
        }

        public void Activate(CampaignObjectiveDefinition def)
        {
            if (def == null || !ObjectiveRules.IsValidObjectiveId(def.ObjectiveId)) return;
            if (IsAlreadyComplete(def)) return;
            if (active.Contains(def)) return;
            active.Add(def);
            ObjectiveActivated?.Invoke(def);
        }

        public string GetPrimaryPrompt()
        {
            if (active.Count == 0) return string.Empty;
            CampaignObjectiveDefinition def = active[0];
            if (def.Kind == ObjectiveKind.ScavengeResources)
            {
                int current = 0;
                scavengeProgress.TryGetValue(def.ObjectiveId, out current);
                return def.DisplayTitle + " (" + current + "/" + def.ScavengeTargetCount + ")";
            }
            return string.IsNullOrEmpty(def.DisplayTitle) ? def.ObjectiveId : def.DisplayTitle;
        }

        private void OnBridgeSpanChanged(BridgeSpanController span, BridgeSpanState previous, BridgeSpanState current)
        {
            if (current != BridgeSpanState.Stable) return;
            for (int i = active.Count - 1; i >= 0; i--)
            {
                CampaignObjectiveDefinition def = active[i];
                if (def.Kind != ObjectiveKind.RepairBridge) continue;
                if (def.LinkedBridge != span) continue;
                Complete(def);
            }
        }

        private void OnScavengeCompleted(string sourceId)
        {
            for (int i = active.Count - 1; i >= 0; i--)
            {
                CampaignObjectiveDefinition def = active[i];
                if (def.Kind != ObjectiveKind.ScavengeResources) continue;
                int current = 0;
                scavengeProgress.TryGetValue(def.ObjectiveId, out current);
                current++;
                scavengeProgress[def.ObjectiveId] = current;
                ScavengeProgressChanged?.Invoke(def.ObjectiveId, current, def.ScavengeTargetCount);
                if (current >= def.ScavengeTargetCount)
                    Complete(def);
            }
        }

        private void Complete(CampaignObjectiveDefinition def)
        {
            if (def == null) return;
            if (bootstrap != null && bootstrap.Campaign != null)
            {
                if (ObjectiveRules.TryMarkComplete(bootstrap.Campaign, def.ObjectiveId))
                    bootstrap.SaveCampaign();
            }
            active.Remove(def);
            ObjectiveCompleted?.Invoke(def);
            CampaignEvents.RaiseObjectiveCompleted(def.ObjectiveId);
            GenericToastUI.Show("Objective complete: " + def.DisplayTitle, 2.5f);
        }

        private bool IsAlreadyComplete(CampaignObjectiveDefinition def)
        {
            if (def == null) return true;
            if (bootstrap == null || bootstrap.Campaign == null) return false;
            return ObjectiveRules.IsComplete(bootstrap.Campaign, def.ObjectiveId);
        }
    }
}
