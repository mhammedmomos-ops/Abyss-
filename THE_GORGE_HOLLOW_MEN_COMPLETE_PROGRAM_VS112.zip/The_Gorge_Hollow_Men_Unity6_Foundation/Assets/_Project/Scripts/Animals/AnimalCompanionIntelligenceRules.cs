namespace GorgeHollow
{
    /// <summary>VS83: contextual companion awareness. Pure rules; no hidden-world or global monster access.</summary>
    public struct CompanionIntelligenceResult
    {
        public readonly float DetectionMultiplier;
        public readonly float ConfidenceBonus;
        public readonly string BehaviourNote;

        public CompanionIntelligenceResult(float detectionMultiplier, float confidenceBonus, string behaviourNote)
        {
            DetectionMultiplier = detectionMultiplier;
            ConfidenceBonus = confidenceBonus;
            BehaviourNote = behaviourNote;
        }
    }

    public static class AnimalCompanionIntelligenceRules
    {
        public static float ScanRadiusMultiplier(AnimalSpecies species, AnimalCommand command, bool hasHeightAdvantage)
        {
            if (species == AnimalSpecies.Falcon && hasHeightAdvantage) return 1.12f;
            if (species == AnimalSpecies.Cat && command == AnimalCommand.Stalk) return 1.05f;
            return 1f;
        }

        public static CompanionIntelligenceResult Evaluate(AnimalSpecies species, AnimalCommand command,
            float threatDistance, float ownerDistance, bool hasHeightAdvantage)
        {
            threatDistance = IsFiniteNonNegative(threatDistance) ? threatDistance : 0f;
            ownerDistance = IsFiniteNonNegative(ownerDistance) ? ownerDistance : 0f;

            switch (species)
            {
                case AnimalSpecies.GermanShepherd:
                    // The shepherd reads a threat as urgent when it is closing on its person.
                    return ownerDistance + 1.5f < threatDistance
                        ? new CompanionIntelligenceResult(1.08f, 0.08f, "Protective interception")
                        : new CompanionIntelligenceResult(1f, 0f, "Scent-led protection");

                case AnimalSpecies.Falcon:
                    // A genuine height advantage improves visual reconnaissance, not certainty.
                    return hasHeightAdvantage
                        ? new CompanionIntelligenceResult(1.12f, 0.06f, "Elevated visual scan")
                        : new CompanionIntelligenceResult(1f, 0f, "Wide-area observation");

                case AnimalSpecies.Pangolin:
                    // Close danger triggers a more deliberate defensive read, not aggression.
                    return threatDistance <= 4f
                        ? new CompanionIntelligenceResult(1.04f, 0.09f, "Close-range defensive assessment")
                        : new CompanionIntelligenceResult(1f, 0f, "Defensive perimeter awareness");

                case AnimalSpecies.Cat:
                    // Stalking improves confidence in a quiet observation without increasing damage.
                    return command == AnimalCommand.Stalk
                        ? new CompanionIntelligenceResult(1.05f, 0.08f, "Silent flank assessment")
                        : new CompanionIntelligenceResult(1f, 0f, "Independent threat assessment");

                default:
                    return new CompanionIntelligenceResult(1f, 0f, "Basic awareness");
            }
        }

        public static float ApplyConfidence(float baseConfidence, CompanionIntelligenceResult result)
        {
            if (float.IsNaN(baseConfidence) || float.IsInfinity(baseConfidence)) baseConfidence = 0f;
            return UnityEngine.Mathf.Clamp01(baseConfidence + result.ConfidenceBonus);
        }

        private static bool IsFiniteNonNegative(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value) && value >= 0f;
        }
    }
}
