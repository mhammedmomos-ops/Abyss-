using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Flags a local piece of level geometry as useful environmental context for companions.</summary>
    [System.Flags]
    public enum AnimalEnvironmentFeature
    {
        None = 0,
        Concealment = 1 << 0,
        ElevatedPerch = 1 << 1,
        DefensiveGround = 1 << 2,
        ScentRichGround = 1 << 3
    }

    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider))]
    public sealed class AnimalEnvironmentMarker : MonoBehaviour
    {
        [SerializeField] private AnimalEnvironmentFeature features = AnimalEnvironmentFeature.None;
        [SerializeField, Min(0.25f)] private float influenceRadius = 5f;

        public AnimalEnvironmentFeature Features => features;

        public bool IsWithinInfluence(Vector3 position)
        {
            float radius = Mathf.Max(0.25f, influenceRadius);
            return (position - transform.position).sqrMagnitude <= radius * radius;
        }
    }

    /// <summary>Snapshot of nearby, explicitly tagged level features; never reveals unseen enemies.</summary>
    public readonly struct AnimalEnvironmentContext
    {
        public readonly bool HasConcealment;
        public readonly bool HasElevatedPerch;
        public readonly bool HasDefensiveGround;
        public readonly bool HasScentRichGround;

        public AnimalEnvironmentContext(bool concealment, bool elevatedPerch,
            bool defensiveGround, bool scentRichGround)
        {
            HasConcealment = concealment;
            HasElevatedPerch = elevatedPerch;
            HasDefensiveGround = defensiveGround;
            HasScentRichGround = scentRichGround;
        }
    }

    public readonly struct AnimalEnvironmentalAwarenessResult
    {
        public readonly float ScanRadiusMultiplier;
        public readonly float ConfidenceBonus;
        public readonly string BehaviourNote;

        public AnimalEnvironmentalAwarenessResult(float scanRadiusMultiplier,
            float confidenceBonus, string behaviourNote)
        {
            ScanRadiusMultiplier = scanRadiusMultiplier;
            ConfidenceBonus = confidenceBonus;
            BehaviourNote = behaviourNote;
        }
    }

    public static class AnimalEnvironmentalAwarenessRules
    {
        public static AnimalEnvironmentalAwarenessResult Evaluate(AnimalSpecies species,
            AnimalCommand command, AnimalEnvironmentContext context)
        {
            switch (species)
            {
                case AnimalSpecies.GermanShepherd:
                    return context.HasScentRichGround
                        ? new AnimalEnvironmentalAwarenessResult(1f, 0.025f, "Scent-rich ground")
                        : new AnimalEnvironmentalAwarenessResult(1f, 0f, "Ground scent assessment");

                case AnimalSpecies.Falcon:
                    return context.HasElevatedPerch
                        ? new AnimalEnvironmentalAwarenessResult(1.10f, 0.04f, "Elevated perch scan")
                        : new AnimalEnvironmentalAwarenessResult(1f, 0f, "Open-air observation");

                case AnimalSpecies.Pangolin:
                    return context.HasDefensiveGround
                        ? new AnimalEnvironmentalAwarenessResult(1f, 0.07f, "Defensive ground assessment")
                        : new AnimalEnvironmentalAwarenessResult(1f, 0f, "Ground-level threat assessment");

                case AnimalSpecies.Cat:
                    return command == AnimalCommand.Stalk && context.HasConcealment
                        ? new AnimalEnvironmentalAwarenessResult(1.08f, 0.05f, "Concealed stalking")
                        : new AnimalEnvironmentalAwarenessResult(1f, 0f, "Independent cover assessment");

                default:
                    return new AnimalEnvironmentalAwarenessResult(1f, 0f, "Basic environmental awareness");
            }
        }

        public static float ScentSearchRadiusMultiplier(AnimalEnvironmentContext context)
        {
            return context.HasScentRichGround ? 1.15f : 1f;
        }
    }
}
