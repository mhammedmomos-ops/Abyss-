using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Deterministic rules for Weak Point Callout (VS74).
    /// Pure static methods for EditMode tests without scene objects.
    /// </summary>
    public static class AnimalWeakPointCalloutRules
    {
        public static bool CanIssueCallout(
            AnimalStatus status,
            bool hasConfirmedThreat,
            float threatConfidence,
            bool threatHasWeakPoint,
            float now,
            float cooldownUntil)
        {
            if (status != AnimalStatus.Alive) return false;
            if (!hasConfirmedThreat) return false;
            if (threatConfidence < AnimalSpeciesTactics.WeakPointCalloutMinConfidence) return false;
            if (!threatHasWeakPoint) return false;
            if (now < cooldownUntil) return false;
            return true;
        }

        /// <summary>
        /// Returns true if any WeakPointBonus exists under the threat root (self or children).
        /// Safe for null transforms.
        /// </summary>
        public static bool ThreatHasWeakPoint(Transform threatRoot)
        {
            if (threatRoot == null) return false;
            return threatRoot.GetComponentInChildren<WeakPointBonus>(true) != null;
        }

        public static float CooldownEndsAt(float issuedAt) =>
            issuedAt + AnimalSpeciesTactics.WeakPointCalloutCooldownSeconds;

        /// <summary>VS78: cooldown end including the Sharp Eye veteran ability.</summary>
        public static float CooldownEndsAt(float issuedAt, System.Collections.Generic.List<string> learnedAbilities) =>
            issuedAt + AnimalSpeciesTactics.WeakPointCalloutCooldownSeconds *
            AnimalExperienceRules.CalloutCooldownMultiplier(learnedAbilities);

        public static float PlayerBonusEndsAt(float issuedAt) =>
            issuedAt + AnimalSpeciesTactics.WeakPointCalloutPlayerDamageBonusSeconds;

        public static bool IsPlayerBonusActive(float now, float bonusUntil) =>
            now < bonusUntil && !float.IsNaN(bonusUntil) && !float.IsInfinity(bonusUntil);

        public static float ApplyPlayerDamageBonus(float baseDamage, bool bonusActive)
        {
            if (!bonusActive || baseDamage <= 0f) return baseDamage;
            return baseDamage * AnimalSpeciesTactics.WeakPointCalloutPlayerDamageMultiplier;
        }

        public static string FormatToast(AnimalSpecies species, string displayName)
        {
            string name = string.IsNullOrWhiteSpace(displayName) ? species.ToString() : displayName;
            switch (species)
            {
                case AnimalSpecies.GermanShepherd:
                    return name + " marks a weak point — strike there!";
                case AnimalSpecies.Falcon:
                    return name + " spots a weak point from above";
                case AnimalSpecies.Pangolin:
                    return name + " senses a soft point in the armour";
                case AnimalSpecies.Cat:
                    return name + " has found a weak point in the shadows";
                default:
                    return name + " calls out a weak point";
            }
        }
    }
}
