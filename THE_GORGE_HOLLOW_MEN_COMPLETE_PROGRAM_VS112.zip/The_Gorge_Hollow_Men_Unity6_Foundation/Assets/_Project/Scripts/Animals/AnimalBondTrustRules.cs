namespace GorgeHollow
{
    /// <summary>
    /// VS82: bond trust ranks provide a small, transparent companion awareness bonus.
    /// The rank is derived from the saved bond value (not separately persisted), so it
    /// cannot become stale after Resonance spends bond or after save migration.
    /// </summary>
    public static class AnimalBondTrustRules
    {
        public static int RankForBond(int bond)
        {
            if (bond < 0) bond = 0;
            if (bond > AnimalBondGrowthRules.MaxBond) bond = AnimalBondGrowthRules.MaxBond;
            if (bond >= 100) return 4;
            if (bond >= 75) return 3;
            if (bond >= 50) return 2;
            if (bond >= 25) return 1;
            return 0;
        }

        public static string RankName(int bond)
        {
            switch (RankForBond(bond))
            {
                case 4: return "DEVOTED";
                case 3: return "LOYAL";
                case 2: return "TRUSTED";
                case 1: return "BONDING";
                default: return "NEW BOND";
            }
        }

        /// <summary>Small 0/4/8/12/16 percent awareness bonus by trust rank.</summary>
        public static float DetectionMultiplier(int bond)
        {
            switch (RankForBond(bond))
            {
                case 4: return 1.16f;
                case 3: return 1.12f;
                case 2: return 1.08f;
                case 1: return 1.04f;
                default: return 1f;
            }
        }

        public static string FormatRankToast(string displayName, int bond)
        {
            string name = string.IsNullOrWhiteSpace(displayName) ? "Your companion" : displayName;
            return name + " reached " + RankName(bond) + " bond";
        }
    }
}
