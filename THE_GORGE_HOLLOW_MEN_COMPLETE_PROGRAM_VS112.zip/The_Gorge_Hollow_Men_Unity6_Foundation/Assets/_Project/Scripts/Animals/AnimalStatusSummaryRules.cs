namespace GorgeHollow
{
    /// <summary>
    /// Pure formatting for the companion HUD status line (VS79). Keeps string building out of the
    /// MonoBehaviour so it can be covered by EditMode tests.
    /// </summary>
    public static class AnimalStatusSummaryRules
    {
        /// <summary>
        /// Short upper-case tag for what the companion is deliberately doing right now.
        /// Empty for ordinary following/returning. Timed states outrank the raw command.
        /// </summary>
        public static string ActiveStateTag(AnimalCommand command, bool isCurled, bool isStalking,
            bool isResonating, bool isGuarding)
        {
            if (isCurled) return "CURLED";
            if (isResonating) return "RESONATING";
            if (isGuarding || command == AnimalCommand.Guard) return "GUARDING";
            if (isStalking || command == AnimalCommand.Stalk) return "STALKING";
            switch (command)
            {
                case AnimalCommand.Stay: return "STAYING";
                case AnimalCommand.Search: return "SEARCHING";
                case AnimalCommand.Forage: return "FORAGING";
                case AnimalCommand.Alert: return "ALERT";
                case AnimalCommand.Protect: return "PROTECTING";
                case AnimalCommand.TrackScent: return "TRACKING";
                case AnimalCommand.Lure: return "LURING";
                case AnimalCommand.Callout: return "CALLING OUT";
                default: return string.Empty;
            }
        }

        public static int CountKnownAbilities(System.Collections.Generic.List<string> learned)
        {
            if (learned == null) return 0;
            int count = 0;
            if (AnimalExperienceRules.HasAbility(learned, AnimalExperienceRules.AbilityKeenSense)) count++;
            if (AnimalExperienceRules.HasAbility(learned, AnimalExperienceRules.AbilityHardy)) count++;
            if (AnimalExperienceRules.HasAbility(learned, AnimalExperienceRules.AbilitySeasoned)) count++;
            if (AnimalExperienceRules.HasAbility(learned, AnimalExperienceRules.AbilitySteadyPost)) count++;
            if (AnimalExperienceRules.HasAbility(learned, AnimalExperienceRules.AbilityBondedVoice)) count++;
            if (AnimalExperienceRules.HasAbility(learned, AnimalExperienceRules.AbilitySharpEye)) count++;
            return count;
        }

        /// <summary>VS81: same line as the original overload with BOND n appended.</summary>
        public static string FormatStatusLine(string label, AnimalSpecies species, int health, int hunger,
            int food, bool isOperational, int starvationDays, int starvationDaysToDeath,
            string stateTag, int experience, int abilityCount, int bond)
        {
            if (bond < 0) bond = 0;
            if (bond > AnimalBondGrowthRules.MaxBond) bond = AnimalBondGrowthRules.MaxBond;
            return FormatStatusLine(label, species, health, hunger, food, isOperational, starvationDays,
                starvationDaysToDeath, stateTag, experience, abilityCount) + "  " +
                AnimalBondTrustRules.RankName(bond) + "  BOND " + bond;
        }

        /// <summary>
        /// Builds the full HUD line. The leading portion matches the pre-VS79 text exactly so existing
        /// habits and screenshots stay valid; state, XP and abilities are appended.
        /// </summary>
        public static string FormatStatusLine(string label, AnimalSpecies species, int health, int hunger,
            int food, bool isOperational, int starvationDays, int starvationDaysToDeath,
            string stateTag, int experience, int abilityCount)
        {
            string name = string.IsNullOrWhiteSpace(label) ? species.ToString() : label;
            string line = name + " (" + species + ")" +
                "  HP " + health + "  HUNGER " + hunger + "  FOOD " + food;
            if (!isOperational) line += "  OUT OF COMMISSION — FEED REQUIRED";
            if (hunger <= 0) line += "  STARVATION " + starvationDays + "/" + starvationDaysToDeath + " DAYS";
            if (!string.IsNullOrEmpty(stateTag)) line += "  [" + stateTag + "]";
            if (experience < 0) experience = 0;
            if (abilityCount < 0) abilityCount = 0;
            if (abilityCount > AnimalExperienceRules.TotalAbilityCount)
                abilityCount = AnimalExperienceRules.TotalAbilityCount;
            line += "  XP " + experience + "  ABILITIES " + abilityCount + "/" + AnimalExperienceRules.TotalAbilityCount;
            return line;
        }
    }
}
