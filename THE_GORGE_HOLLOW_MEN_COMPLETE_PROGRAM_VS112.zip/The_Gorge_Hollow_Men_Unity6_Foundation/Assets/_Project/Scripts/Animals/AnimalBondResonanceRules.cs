namespace GorgeHollow
{
    /// <summary>
    /// Deterministic rules for Bond Resonance (VS73) — a cross-species awareness pulse
    /// gated by the companion bond stat. Pure static methods for EditMode tests.
    /// </summary>
    public static class AnimalBondResonanceRules
    {
        public static bool CanIssueResonate(
            AnimalStatus status,
            int bond,
            bool hasConfirmedThreat,
            float threatConfidence,
            float now,
            float cooldownUntil,
            bool alreadyResonating)
        {
            if (status != AnimalStatus.Alive) return false;
            if (alreadyResonating) return false;
            if (bond < AnimalSpeciesTactics.BondResonanceMinimumBond) return false;
            if (!hasConfirmedThreat) return false;
            if (threatConfidence < AnimalSpeciesTactics.BondResonanceConfidenceFloor) return false;
            if (now < cooldownUntil) return false;
            return true;
        }

        public static int BondAfterResonate(int currentBond)
        {
            int cost = AnimalSpeciesTactics.BondResonanceBondCost;
            int next = currentBond - cost;
            return next < 0 ? 0 : next;
        }

        public static float DetectionRadiusWhileResonating(float baseRadius, bool isResonating)
        {
            if (!isResonating || baseRadius <= 0f) return baseRadius;
            return baseRadius * AnimalSpeciesTactics.BondResonanceDetectionMultiplier;
        }

        public static float ResonanceEndsAt(float startedAt) =>
            startedAt + AnimalSpeciesTactics.BondResonanceDurationSeconds;

        public static float CooldownEndsAt(float endedAt) =>
            endedAt + AnimalSpeciesTactics.BondResonanceCooldownSeconds;

        /// <summary>VS78: cooldown end including the Bonded Voice veteran ability.</summary>
        public static float CooldownEndsAt(float endedAt, System.Collections.Generic.List<string> learnedAbilities) =>
            endedAt + AnimalSpeciesTactics.BondResonanceCooldownSeconds *
            AnimalExperienceRules.ResonanceCooldownMultiplier(learnedAbilities);

        public static bool IsResonanceActive(float now, float until) =>
            now < until && !float.IsNaN(until) && !float.IsInfinity(until);

        public static string FormatToast(AnimalSpecies species, string displayName)
        {
            string name = string.IsNullOrWhiteSpace(displayName) ? species.ToString() : displayName;
            switch (species)
            {
                case AnimalSpecies.GermanShepherd:
                    return name + " shares a bonded warning — threat locked in";
                case AnimalSpecies.Falcon:
                    return name + " cries a bonded alert from above";
                case AnimalSpecies.Pangolin:
                    return name + " rattles a bonded warning through its scales";
                case AnimalSpecies.Cat:
                    return name + " hisses a bonded warning from the shadows";
                default:
                    return name + " shares a bonded alert";
            }
        }
    }
}
