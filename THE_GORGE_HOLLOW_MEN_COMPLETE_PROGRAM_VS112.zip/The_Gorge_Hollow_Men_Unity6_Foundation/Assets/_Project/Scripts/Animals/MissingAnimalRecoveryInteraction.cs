using UnityEngine;

namespace GorgeHollow
{
    /// <summary>World interaction used by a rescue/search objective to return a missing pet to the roster.</summary>
    [DisallowMultipleComponent]
    public sealed class MissingAnimalRecoveryInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string animalIdentity;
        [SerializeField] private string prompt = "Recover missing companion";
        [SerializeField] private GameBootstrap bootstrap;
        public string InteractionPrompt => bootstrap != null && !bootstrap.IsAnimalMissing(animalIdentity) ? "Companion recovered" : prompt;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        public bool CanInteract(GameObject interactor)
        {
            return !string.IsNullOrWhiteSpace(animalIdentity) && bootstrap != null && bootstrap.IsAnimalMissing(animalIdentity);
        }

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            if (!bootstrap.TryRecoverMissingAnimal(animalIdentity, out int recoveredHunger))
            {
                GenericToastUI.Show("This companion cannot be recovered here", 1.8f);
                return;
            }

            GenericToastUI.Show("Companion found — hunger " + recoveredHunger + ". Return to select and care for them.", 2.8f);
        }
    }
}
