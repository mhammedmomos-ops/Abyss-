namespace GorgeHollow
{
    /// <summary>Rules for distinguishing a genuinely lost companion from one merely out of sight.</summary>
    public static class AnimalSeparationRules
    {
        public const float DefaultMissingDistance = 35f;
        public const float DefaultGraceSeconds = 60f;

        /// <summary>
        /// VS77: commands where the player deliberately parked the companion in place.
        /// A held companion is never treated as lost, even when no route back exists.
        /// </summary>
        public static bool IsHoldCommand(AnimalCommand command)
        {
            return command == AnimalCommand.Stay || command == AnimalCommand.Guard;
        }

        public static bool ShouldAccumulate(CampaignPhase phase, AnimalStatus status,
            AnimalCommand command, bool beyondSeparationDistance, bool ownerPathReachable)
        {
            bool dangerousPhase = phase == CampaignPhase.ActiveRaid || phase == CampaignPhase.ThreatResolution;
            return dangerousPhase && status == AnimalStatus.Alive && !IsHoldCommand(command) &&
                   beyondSeparationDistance && !ownerPathReachable;
        }

        public static bool ShouldMarkMissing(float separatedSeconds, float graceSeconds)
        {
            if (float.IsNaN(separatedSeconds) || float.IsInfinity(separatedSeconds) ||
                float.IsNaN(graceSeconds) || float.IsInfinity(graceSeconds)) return false;
            return graceSeconds > 0f && separatedSeconds >= graceSeconds;
        }
    }
}
