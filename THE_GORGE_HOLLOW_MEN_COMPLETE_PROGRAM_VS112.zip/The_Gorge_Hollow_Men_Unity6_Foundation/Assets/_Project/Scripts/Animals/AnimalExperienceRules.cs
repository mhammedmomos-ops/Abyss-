using System.Collections.Generic;

namespace GorgeHollow
{
    /// <summary>
    /// Deterministic companion experience unlock rules (VS75).
    /// Unlocks are stored as stable string IDs on AnimalRecord.learnedAbilities and persist with the campaign.
    /// </summary>
    public static class AnimalExperienceRules
    {
        public const string AbilityKeenSense = "keen_sense";
        public const string AbilityHardy = "hardy";
        public const string AbilitySeasoned = "seasoned";
        // VS78 veteran tier — unlocked only by long service; each tunes one existing command.
        public const string AbilitySteadyPost = "steady_post";
        public const string AbilityBondedVoice = "bonded_voice";
        public const string AbilitySharpEye = "sharp_eye";

        /// <summary>Total learnable abilities across both tiers (VS75 + VS78).</summary>
        public const int TotalAbilityCount = 6;

        public static int XpForKeenSense => 8;
        public static int XpForHardy => 20;
        public static int XpForSeasoned => 40;
        public static int XpForSteadyPost => 60;
        public static int XpForBondedVoice => 85;
        public static int XpForSharpEye => 110;

        /// <summary>Extra Guard Post detection on top of the base guard multiplier.</summary>
        public static float SteadyPostGuardDetectionMultiplier => 1.1f;
        /// <summary>Bond Resonance cooldown is multiplied by this once Bonded Voice is learned.</summary>
        public static float BondedVoiceCooldownMultiplier => 0.75f;
        /// <summary>Weak Point Callout cooldown is multiplied by this once Sharp Eye is learned.</summary>
        public static float SharpEyeCooldownMultiplier => 0.75f;

        public static float KeenSenseDetectionMultiplier => 1.12f;
        public static float HardyIncomingDamageMultiplier => 0.92f;
        public static float SeasonedStaminaRecoveryMultiplier => 1.2f;
        public static float SeasonedThreatConfidenceBonus => 0.05f;

        public static int AwardXp(int current, int amount)
        {
            if (amount <= 0) return current < 0 ? 0 : current;
            if (current < 0) current = 0;
            long next = (long)current + amount;
            return next > int.MaxValue ? int.MaxValue : (int)next;
        }

        /// <summary>
        /// Evaluates which abilities should be unlocked for the current experience total.
        /// Returns newly unlocked IDs only (not already present). Mutates learned when provided.
        /// </summary>
        public static List<string> EvaluateNewUnlocks(int experience, List<string> learned)
        {
            var newly = new List<string>(6);
            if (learned == null) learned = new List<string>();
            TryUnlock(experience, learned, newly, AbilityKeenSense, XpForKeenSense);
            TryUnlock(experience, learned, newly, AbilityHardy, XpForHardy);
            TryUnlock(experience, learned, newly, AbilitySeasoned, XpForSeasoned);
            TryUnlock(experience, learned, newly, AbilitySteadyPost, XpForSteadyPost);
            TryUnlock(experience, learned, newly, AbilityBondedVoice, XpForBondedVoice);
            TryUnlock(experience, learned, newly, AbilitySharpEye, XpForSharpEye);
            return newly;
        }

        private static void TryUnlock(int experience, List<string> learned, List<string> newly,
            string id, int requiredXp)
        {
            if (experience < requiredXp) return;
            if (HasAbility(learned, id)) return;
            learned.Add(id);
            newly.Add(id);
        }

        public static bool HasAbility(List<string> learned, string id)
        {
            if (learned == null || string.IsNullOrEmpty(id)) return false;
            for (int i = 0; i < learned.Count; i++)
                if (learned[i] == id) return true;
            return false;
        }

        public static float DetectionMultiplier(List<string> learned)
        {
            return HasAbility(learned, AbilityKeenSense) ? KeenSenseDetectionMultiplier : 1f;
        }

        public static float IncomingDamageMultiplier(List<string> learned)
        {
            return HasAbility(learned, AbilityHardy) ? HardyIncomingDamageMultiplier : 1f;
        }

        public static float StaminaRecoveryMultiplier(List<string> learned)
        {
            return HasAbility(learned, AbilitySeasoned) ? SeasonedStaminaRecoveryMultiplier : 1f;
        }

        public static float ThreatConfidenceBonus(List<string> learned)
        {
            return HasAbility(learned, AbilitySeasoned) ? SeasonedThreatConfidenceBonus : 0f;
        }

        public static float GuardDetectionMultiplier(List<string> learned)
        {
            return HasAbility(learned, AbilitySteadyPost) ? SteadyPostGuardDetectionMultiplier : 1f;
        }

        public static float ResonanceCooldownMultiplier(List<string> learned)
        {
            return HasAbility(learned, AbilityBondedVoice) ? BondedVoiceCooldownMultiplier : 1f;
        }

        public static float CalloutCooldownMultiplier(List<string> learned)
        {
            return HasAbility(learned, AbilitySharpEye) ? SharpEyeCooldownMultiplier : 1f;
        }

        public static string FormatUnlockToast(string abilityId, string displayName)
        {
            string name = string.IsNullOrWhiteSpace(displayName) ? "Companion" : displayName;
            switch (abilityId)
            {
                case AbilityKeenSense:
                    return name + " learned Keen Sense — wider awareness";
                case AbilityHardy:
                    return name + " learned Hardy — tougher under fire";
                case AbilitySeasoned:
                    return name + " learned Seasoned — faster recovery and sharper focus";
                case AbilitySteadyPost:
                    return name + " learned Steady Post — a wider guard watch";
                case AbilityBondedVoice:
                    return name + " learned Bonded Voice — resonance recovers faster";
                case AbilitySharpEye:
                    return name + " learned Sharp Eye — weak-point callouts recover faster";
                default:
                    return name + " learned a new ability";
            }
        }

        /// <summary>XP awarded for successful high-value ability uses.</summary>
        public static int XpForSuccessfulAbilityUse => 2;
        public static int XpForSuccessfulAttack => 1;
    }
}
