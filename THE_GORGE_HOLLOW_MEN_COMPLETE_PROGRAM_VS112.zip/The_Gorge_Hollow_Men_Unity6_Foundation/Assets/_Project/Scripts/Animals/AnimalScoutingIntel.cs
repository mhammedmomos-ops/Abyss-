using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Short-lived, locally observed scouting information. It is not a global monster tracker.</summary>
    public struct AnimalScoutingReport
    {
        public readonly Vector3 ObservedPosition;
        public readonly float DistanceMetres;
        public readonly MonsterArchetypeRole ThreatRole;
        public readonly float ObservedAt;
        public readonly string Bearing;

        public AnimalScoutingReport(Vector3 observedPosition, float distanceMetres,
            MonsterArchetypeRole threatRole, float observedAt, string bearing)
        {
            ObservedPosition = observedPosition;
            DistanceMetres = Mathf.Max(0f, distanceMetres);
            ThreatRole = threatRole;
            ObservedAt = observedAt;
            Bearing = bearing ?? "unknown direction";
        }
    }

    public static class AnimalScoutingIntelRules
    {
        private static readonly string[] Bearings =
            { "N", "NE", "E", "SE", "S", "SW", "W", "NW" };

        /// <summary>Builds a report from a threat already confirmed by the companion's own line-of-sight scan.</summary>
        public static AnimalScoutingReport Create(Transform observer, Transform threat,
            MonsterArchetypeRole role, float observedAt)
        {
            if (observer == null || threat == null)
                return new AnimalScoutingReport(Vector3.zero, 0f, role, observedAt, "unknown direction");

            Vector3 offset = threat.position - observer.position;
            Vector3 flat = new Vector3(offset.x, 0f, offset.z);
            Vector3 forward = observer.forward;
            forward.y = 0f;
            if (forward.sqrMagnitude < 0.0001f) forward = Vector3.forward;
            if (flat.sqrMagnitude < 0.0001f)
                return new AnimalScoutingReport(threat.position, 0f, role, observedAt, "nearby");

            float signedAngle = Vector3.SignedAngle(forward.normalized, flat.normalized, Vector3.up);
            int index = Mathf.RoundToInt((signedAngle + 360f) % 360f / 45f) % Bearings.Length;
            return new AnimalScoutingReport(threat.position, flat.magnitude, role, observedAt, Bearings[index]);
        }

        public static string Format(AnimalScoutingReport report)
        {
            return "Falcon spotted " + report.ThreatRole + " threat · " +
                   Mathf.RoundToInt(report.DistanceMetres) + "m " + report.Bearing;
        }
    }
}
