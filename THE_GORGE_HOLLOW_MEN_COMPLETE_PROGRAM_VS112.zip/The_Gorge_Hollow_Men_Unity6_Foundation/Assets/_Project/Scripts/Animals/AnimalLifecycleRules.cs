namespace GorgeHollow
{
    /// <summary>Campaign-time ageing rules. Age advances only when fictional campaign time advances.</summary>
    public static class AnimalLifecycleRules
    {
        public static void AdvanceDays(AnimalRecord record, int days)
        {
            if (record == null || days <= 0 || record.status == AnimalStatus.Dead) return;
            long nextAge = (long)record.fictionalAgeDays + days;
            record.fictionalAgeDays = nextAge > int.MaxValue ? int.MaxValue : (int)nextAge;
            record.lifeStage = ResolveLifeStage(record.species, record.fictionalAgeDays);
        }

        public static AnimalLifeStage ResolveLifeStage(AnimalSpecies species, int ageDays)
        {
            if (ageDays <= 90) return AnimalLifeStage.Young;
            if (ageDays < 365) return AnimalLifeStage.Adolescent;
            int seniorAge;
            switch (species)
            {
                case AnimalSpecies.GermanShepherd: seniorAge = 3650; break;
                case AnimalSpecies.Falcon: seniorAge = 5475; break;
                case AnimalSpecies.Pangolin: seniorAge = 5475; break;
                case AnimalSpecies.Cat: seniorAge = 4380; break;
                default: return AnimalLifeStage.Adult;
            }
            return ageDays >= seniorAge ? AnimalLifeStage.Senior : AnimalLifeStage.Adult;
        }
    }
}
