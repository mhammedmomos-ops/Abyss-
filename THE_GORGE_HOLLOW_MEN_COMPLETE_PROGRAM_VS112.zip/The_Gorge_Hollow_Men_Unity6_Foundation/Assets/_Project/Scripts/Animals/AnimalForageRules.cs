using System.Collections.Generic;

namespace GorgeHollow
{
    /// <summary>Pure, campaign-day scoped rules preventing repeated harvests from one wild-food source.</summary>
    public static class AnimalForageRules
    {
        public static string BuildHarvestFlag(string sourceId, int fictionalDay)
        {
            if (string.IsNullOrWhiteSpace(sourceId) || fictionalDay < 1) return string.Empty;
            return "pet-forage:" + sourceId.Trim() + ":day:" + fictionalDay;
        }

        public static bool IsAvailable(List<string> campaignFlags, string sourceId, int fictionalDay)
        {
            string key = BuildHarvestFlag(sourceId, fictionalDay);
            return campaignFlags != null && key.Length > 0 && !campaignFlags.Contains(key);
        }

        public static bool TryMarkHarvested(List<string> campaignFlags, string sourceId, int fictionalDay)
        {
            if (!IsAvailable(campaignFlags, sourceId, fictionalDay)) return false;
            campaignFlags.Add(BuildHarvestFlag(sourceId, fictionalDay));
            return true;
        }
    }
}
