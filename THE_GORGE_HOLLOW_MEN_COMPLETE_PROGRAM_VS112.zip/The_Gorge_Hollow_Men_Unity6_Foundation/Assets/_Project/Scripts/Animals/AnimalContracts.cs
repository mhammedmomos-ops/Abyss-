namespace GorgeHollow
{
    public enum AnimalCommand { Follow, Stay, Search, Alert, Retrieve, Return, Protect, Forage, Lure, TrackScent, Curl, Stalk, Resonate, Callout, Guard }

    public interface IAnimalBehaviour
    {
        AnimalSpecies Species { get; }
        void Initialize(AnimalRecord record);
        void ReceiveCommand(AnimalCommand command);
        void EvaluateThreat(bool confirmedThreat, float confidence);
        void ApplyInjury(int damage);
        bool TryMarkPermanentDeath(string deathEventId);
    }

    public abstract class AnimalBehaviourBase : IAnimalBehaviour
    {
        protected AnimalRecord Record { get; private set; }
        public abstract AnimalSpecies Species { get; }
        public AnimalCommand CurrentCommand { get; private set; } = AnimalCommand.Follow;
        public bool ThreatConfirmed { get; private set; }
        public float ThreatConfidence { get; private set; }

        public virtual void Initialize(AnimalRecord record)
        {
            bool sameCompanion = Record != null && record != null && Record.identity == record.identity;
            Record = record;
            if (!sameCompanion) CurrentCommand = AnimalCommand.Follow;
            ThreatConfirmed = false;
            ThreatConfidence = 0f;
        }

        public virtual void ReceiveCommand(AnimalCommand command)
        {
            if (Record == null || Record.status != AnimalStatus.Alive) return;
            CurrentCommand = command;
        }

        public virtual void EvaluateThreat(bool confirmedThreat, float confidence)
        {
            ThreatConfirmed = confirmedThreat;
            ThreatConfidence = System.Math.Max(0f, System.Math.Min(1f, confidence));
        }

        public virtual void ApplyInjury(int damage)
        {
            if (Record == null || Record.status == AnimalStatus.Dead) return;
            Record.health = System.Math.Max(0, Record.health - System.Math.Max(0, damage));
        }

        public bool TryMarkPermanentDeath(string deathEventId)
        {
            if (Record == null || !Record.MarkDead(deathEventId)) return false;
            CampaignEvents.RaiseAnimalDied(Record.identity);
            return true;
        }
    }

    // Species controllers are deliberately separate so navigation and perception
    // can diverge without turning every animal into the same AI with a different model.
    public sealed class GermanShepherdBehaviour : AnimalBehaviourBase
    {
        public override AnimalSpecies Species => AnimalSpecies.GermanShepherd;
        // Strongest direct protector: prioritises confirmed threats near its bonded player.
        public override void EvaluateThreat(bool confirmedThreat, float confidence) => base.EvaluateThreat(confirmedThreat, confidence);
    }

    public sealed class FalconBehaviour : AnimalBehaviourBase
    {
        public override AnimalSpecies Species => AnimalSpecies.Falcon;
        // Long-range alert specialist; confidence is deliberately retained as evidence, not certainty.
        public override void EvaluateThreat(bool confirmedThreat, float confidence) => base.EvaluateThreat(confirmedThreat, confidence);
    }

    public sealed class PangolinBehaviour : AnimalBehaviourBase
    {
        public override AnimalSpecies Species => AnimalSpecies.Pangolin;
        // Defensive specialist: command state is shared, while the controller applies its resilience profile.
        public override void EvaluateThreat(bool confirmedThreat, float confidence) => base.EvaluateThreat(confirmedThreat, confidence);
    }

    public sealed class CatBehaviour : AnimalBehaviourBase
    {
        public override AnimalSpecies Species => AnimalSpecies.Cat;
        // Quiet reconnaissance specialist; threat evidence remains local and confidence-bounded.
        public override void EvaluateThreat(bool confirmedThreat, float confidence) => base.EvaluateThreat(confirmedThreat, confidence);
    }
}
