namespace GorgeHollow
{
    /// <summary>Pure companion care rules; dead or missing companions can never be revived by care.</summary>
    public static class AnimalCareRules
    {
        public const int MedicalSupplyTreatmentCost = 1;
        public const int TreatmentHealth = 30;
        public const int RestStamina = 45;
        public const int RestBondGain = 1;
        public const int PetFoodCost = 1;
        public const int FeedHunger = 60;
        public const int HungerLossPerDay = 18;
        public const int FeedBondGain = 1;
        public const int StarvationDaysToDeath = 2;

        public static bool CanOperate(AnimalRecord record)
        {
            return IsAvailable(record) && record.hunger > 0;
        }

        public static bool CanForage(AnimalRecord record)
        {
            // Foraging is still a companion activity and is unavailable once starvation incapacitates the pet.
            return CanOperate(record);
        }

        public static bool CanRest(AnimalRecord record, bool atSafeLocation)
        {
            return atSafeLocation && CanOperate(record) && record.stamina < 100;
        }

        public static bool TryRest(AnimalRecord record, bool atSafeLocation)
        {
            if (!CanRest(record, atSafeLocation)) return false;
            record.stamina = System.Math.Min(100, record.stamina + RestStamina);
            record.bond = System.Math.Min(100, record.bond + RestBondGain);
            return true;
        }

        public static bool CanFeed(AnimalRecord record, int availablePetFood)
        {
            return IsAvailable(record) && record.hunger < 100 && availablePetFood >= PetFoodCost;
        }

        public static bool TryFeed(AnimalRecord record, ref int availablePetFood)
        {
            if (!CanFeed(record, availablePetFood)) return false;
            availablePetFood -= PetFoodCost;
            record.hunger = System.Math.Min(100, record.hunger + FeedHunger);
            record.starvationDaysAtZero = 0;
            record.bond = System.Math.Min(100, record.bond + FeedBondGain);
            return true;
        }

        /// <summary>
        /// Advances hunger by fictional days. Missing pets are assumed to hunt independently;
        /// a living pet that remains at zero hunger for two full additional days dies permanently.
        /// Returns true only when this call caused a new starvation death.
        /// </summary>
        public static bool AdvanceHunger(AnimalRecord record, int days)
        {
            if (record == null || days <= 0 || record.status != AnimalStatus.Alive) return false;
            for (int day = 0; day < days; day++)
            {
                if (record.status != AnimalStatus.Alive) break;
                if (record.hunger > 0)
                {
                    record.starvationDaysAtZero = 0;
                    record.hunger = System.Math.Max(0, record.hunger - HungerLossPerDay);
                    continue;
                }

                record.starvationDaysAtZero = System.Math.Min(StarvationDaysToDeath,
                    record.starvationDaysAtZero + 1);
                if (record.starvationDaysAtZero >= StarvationDaysToDeath)
                {
                    string deathEventId = "starvation-" + record.identity + "-zero-days-" + record.starvationDaysAtZero;
                    return record.MarkDead(deathEventId);
                }
            }
            return false;
        }

        public static bool CanTreat(AnimalRecord record, int availableMedicalSupplies)
        {
            return CanOperate(record) && record.health < 100 && availableMedicalSupplies >= MedicalSupplyTreatmentCost;
        }

        public static bool TryTreat(AnimalRecord record, ref int availableMedicalSupplies)
        {
            if (!CanTreat(record, availableMedicalSupplies)) return false;
            availableMedicalSupplies -= MedicalSupplyTreatmentCost;
            record.health = System.Math.Min(100, record.health + TreatmentHealth);
            return true;
        }

        /// <summary>Marks a living companion missing without converting permanent death into a recoverable state.</summary>
        public static bool TryMarkMissing(AnimalRecord record)
        {
            if (record == null || record.status != AnimalStatus.Alive || record.health <= 0) return false;
            record.status = AnimalStatus.Missing;
            return true;
        }

        /// <summary>Returns a missing animal to the living roster with the hunger level rolled when found.</summary>
        public static bool TryRecoverMissing(AnimalRecord record, int recoveredHunger)
        {
            if (record == null || record.status != AnimalStatus.Missing || record.health <= 0 ||
                !System.Enum.IsDefined(typeof(AnimalSpecies), record.species)) return false;
            record.status = AnimalStatus.Alive;
            record.hunger = System.Math.Max(1, System.Math.Min(100, recoveredHunger));
            record.starvationDaysAtZero = 0;
            return true;
        }

        private static bool IsAvailable(AnimalRecord record)
        {
            return record != null && record.status == AnimalStatus.Alive && record.health > 0 &&
                   System.Enum.IsDefined(typeof(AnimalSpecies), record.species);
        }
    }
}
