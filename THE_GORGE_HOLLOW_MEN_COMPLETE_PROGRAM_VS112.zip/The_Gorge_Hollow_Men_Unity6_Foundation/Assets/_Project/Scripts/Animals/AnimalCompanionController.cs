using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>
    /// Species-agnostic world actor. The campaign-selected record supplies species and custom name;
    /// species tuning changes movement/perception/support rather than creating a fixed dog-only system.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(NavMeshAgent))]
    public sealed class AnimalCompanionController : MonoBehaviour
    {
        [SerializeField] private NavMeshAgent agent;
        [SerializeField] private Transform owner;
        [SerializeField] private GameObject visualRoot;
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private LayerMask threatMask = ~0;
        [SerializeField, Min(0.1f)] private float scanInterval = 0.4f;
        [SerializeField, Min(0.1f)] private float commandSearchRadius = 9f;
        [SerializeField, Min(0.1f)] private float protectRadius = 8f;
        [Header("Lost companion safeguards")]
        [SerializeField, Min(1f)] private float missingSeparationDistance = AnimalSeparationRules.DefaultMissingDistance;
        [SerializeField, Min(1f)] private float missingGraceSeconds = AnimalSeparationRules.DefaultGraceSeconds;
        [SerializeField, Min(0.1f)] private float separationCheckInterval = 1f;
        private readonly Collider[] scanBuffer = new Collider[24];
        private readonly Collider[] environmentBuffer = new Collider[32];
        private NavMeshPath separationPath;
        private float nextSeparationCheckAt;
        private float separatedSeconds;
        private bool separationWarningShown;
        private AnimalRecord record;
        private AnimalBehaviourBase behaviour;
        private AnimalCompanionProfile profile;
        private AnimalLifeStage appliedLifeStage;
        private float nextScan;
        private float nextAttack;
        private float staminaRecoveryAccumulator;
        private float nextPersistTime;
        private bool recordDirty;
        private Transform currentThreat;
        private AnimalForageFoodSource forageSource;
        private float forageStartedAt;
        private float nextForageSearchAt;
        private Vector3 searchPoint;
        private bool hasSearchPoint;
        private float pangolinBraceUntil;
        private bool pangolinBraceActive;
        private float pangolinCurlUntil;
        private float pangolinCurlCooldownUntil;
        private bool pangolinCurlActive;
        private bool catStalkFirstAcquisitionApplied;
        private float bondResonanceUntil;
        private float bondResonanceCooldownUntil;
        private bool bondResonanceActive;
        private float weakPointCalloutCooldownUntil;
        private bool guardThreatReported;
        private Vector3 guardPosition;
        private bool hasGuardPosition;
        private Vector3 falconPerchPosition;
        private bool hasFalconPerch;
        private float nextFalconPerchSearchAt;
        private float nextBondGainAt;
        private bool forageThreatRetreating;
        private float nextFalconDistractionAt;
        private Transform lureThreat;
        private Vector3 lureProtectedPosition;
        private Vector3 lurePoint;
        private float lureUntil;
        private float lureTravelDeadline;
        private bool lureHasReachedPoint;
        private float nextCatLurePulseAt;
        private float attackAnimationUntil;
        private AnimalCompanionAudioFeedback audioFeedback;
        private int scentSourceId;
        private float scentCursorTime;
        private Vector3 scentDestination;
        private bool hasScentDestination;
        private NavMeshPath scentPath;
        [Header("Shepherd scent tracking")]
        [SerializeField, Min(1f)] private float scentSearchRadius = 18f;
        [SerializeField, Min(1f)] private float scentTrailLifetime = AnimalScentTrailRules.DefaultTrailLifetimeSeconds;
        [SerializeField, Min(0.5f)] private float scentArrivalDistance = 1.5f;
        [Header("Environmental awareness")]
        [SerializeField, Min(1f)] private float environmentProbeRadius = 8f;
        [SerializeField] private LayerMask environmentMask = ~0;

        public AnimalRecord Record => record;
        public AnimalCommand CurrentCommand => behaviour != null ? behaviour.CurrentCommand : AnimalCommand.Follow;
        public Transform Owner => owner;
        public bool IsOperational => isActiveAndEnabled && AnimalCareRules.CanOperate(record);
        public Transform CurrentThreat => currentThreat;
        public bool IsThreateningMonster(Transform monster) => IsOperational && monster != null && currentThreat == monster && behaviour != null && behaviour.ThreatConfirmed;
        public bool IsBracing => pangolinBraceActive && Time.time < pangolinBraceUntil;
        public bool IsCurled => pangolinCurlActive && Time.time < pangolinCurlUntil;
        public bool IsStalking => behaviour != null && behaviour.CurrentCommand == AnimalCommand.Stalk &&
            record != null && record.species == AnimalSpecies.Cat;
        public bool IsResonating => bondResonanceActive && Time.time < bondResonanceUntil;
        public bool IsGuarding => behaviour != null && behaviour.CurrentCommand == AnimalCommand.Guard;
        public bool IsAttacking => Time.time < attackAnimationUntil;
        public bool IsIncapacitated => record != null && record.status == AnimalStatus.Alive && record.hunger <= 0;
        public bool IsDead => record != null && record.status == AnimalStatus.Dead;
        public bool IsForaging => record != null && behaviour != null && behaviour.CurrentCommand == AnimalCommand.Forage && forageStartedAt > 0f;
        public bool IsLuring => behaviour != null && behaviour.CurrentCommand == AnimalCommand.Lure && lureThreat != null;
        public bool IsObserving => record != null && record.species == AnimalSpecies.Falcon && currentThreat != null && behaviour != null && behaviour.ThreatConfirmed && !IsLuring;
        public float AnimationMoveSpeed => profile.moveSpeed > 0.01f ? profile.moveSpeed * 1.25f : 1.25f;

        /// <summary>Receives a monster's resolved strike; injury and permanent death use the campaign record path.</summary>
        public void ReceiveMonsterAttack(float damage)
        {
            if (!IsOperational || float.IsNaN(damage) || float.IsInfinity(damage) || damage <= 0f) return;
            ApplyInjury(Mathf.Max(1, Mathf.CeilToInt(damage)));
        }

        public bool Bind(AnimalRecord selectedRecord, Transform playerOwner, IAnimalBehaviour selectedBehaviour)
        {
            if (selectedRecord == null || selectedRecord.status != AnimalStatus.Alive || selectedRecord.health <= 0 ||
                playerOwner == null || !(selectedBehaviour is AnimalBehaviourBase concrete) ||
                selectedBehaviour.Species != selectedRecord.species)
                return false;

            if (agent == null) agent = GetComponent<NavMeshAgent>();
            if (audioFeedback == null) audioFeedback = GetComponent<AnimalCompanionAudioFeedback>();
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            record = selectedRecord;
            if (record.learnedAbilities == null)
                record.learnedAbilities = new System.Collections.Generic.List<string>();
            // Re-evaluate unlocks in case experience was granted offline or by another system.
            AnimalExperienceRules.EvaluateNewUnlocks(record.experience, record.learnedAbilities);
            owner = playerOwner;
            pangolinBraceActive = false;
            pangolinCurlActive = false;
            pangolinCurlUntil = 0f;
            catStalkFirstAcquisitionApplied = false;
            bondResonanceActive = false;
            bondResonanceUntil = 0f;
            weakPointCalloutCooldownUntil = 0f;
            guardThreatReported = false;
            hasGuardPosition = false;
            hasFalconPerch = false;
            nextFalconPerchSearchAt = 0f;
            nextBondGainAt = 0f;
            forageThreatRetreating = false;
            lureThreat = null;
            lureHasReachedPoint = false;
            attackAnimationUntil = 0f;
            hasScentDestination = false;
            scentSourceId = 0;
            nextFalconDistractionAt = 0f;
            separatedSeconds = 0f;
            separationWarningShown = false;
            nextSeparationCheckAt = 0f;
            behaviour = concrete;
            profile = AnimalCompanionProfile.For(record.species, record.lifeStage);
            appliedLifeStage = record.lifeStage;
            behaviour.Initialize(record);
            if (visualRoot != null) visualRoot.SetActive(true);
            AnimalSpeciesVisualBinder visualBinder = GetComponent<AnimalSpeciesVisualBinder>();
            if (visualBinder != null) visualBinder.Apply(record);
            AnimalCompanionAnimationDriver animationDriver = GetComponent<AnimalCompanionAnimationDriver>();
            if (animationDriver != null) animationDriver.RefreshAnimator();
            agent.speed = profile.moveSpeed;
            agent.stoppingDistance = profile.followDistance;
            if (agent.enabled && agent.isOnNavMesh)
            {
                agent.isStopped = record.hunger <= 0;
                if (record.hunger <= 0) agent.ResetPath();
            }
            return true;
        }

        public void ClearBinding()
        {
            currentThreat = null;
            record = null;
            behaviour = null;
            profile = default;
            recordDirty = false;
            pangolinBraceActive = false;
            pangolinCurlActive = false;
            pangolinCurlUntil = 0f;
            catStalkFirstAcquisitionApplied = false;
            bondResonanceActive = false;
            bondResonanceUntil = 0f;
            weakPointCalloutCooldownUntil = 0f;
            guardThreatReported = false;
            hasGuardPosition = false;
            hasFalconPerch = false;
            nextFalconPerchSearchAt = 0f;
            nextBondGainAt = 0f;
            forageThreatRetreating = false;
            lureThreat = null;
            lureHasReachedPoint = false;
            hasScentDestination = false;
            scentSourceId = 0;
            separatedSeconds = 0f;
            separationWarningShown = false;
            if (agent != null && agent.enabled && agent.isOnNavMesh)
            {
                agent.isStopped = true;
                agent.ResetPath();
            }
            AnimalSpeciesVisualBinder visualBinder = GetComponent<AnimalSpeciesVisualBinder>();
            if (visualBinder != null) visualBinder.Clear();
            if (visualRoot != null) visualRoot.SetActive(false);
        }

        public bool IssueCommand(AnimalCommand command)
        {
            if (!IsOperational || behaviour == null || command == AnimalCommand.Lure) return false;
            if (command == AnimalCommand.TrackScent &&
                (record.species != AnimalSpecies.GermanShepherd || !TryBeginScentTrack())) return false;
            if (command == AnimalCommand.Curl && !TryBeginCurl()) return false;
            if (command == AnimalCommand.Stalk && !TryBeginStalk()) return false;
            if (command == AnimalCommand.Resonate && !TryBeginResonate()) return false;
            if (command == AnimalCommand.Callout && !TryBeginCallout()) return false;
            if (command == AnimalCommand.Guard && !TryBeginGuard()) return false;
            behaviour.ReceiveCommand(command);
            forageThreatRetreating = false;
            if (agent != null && command != AnimalCommand.TrackScent)
                agent.stoppingDistance = command == AnimalCommand.Forage ? 1f : profile.followDistance;
            if (command != AnimalCommand.Forage) forageSource = null;
            if (command == AnimalCommand.Search)
            {
                hasSearchPoint = false;
                FindSearchPoint();
            }
            if (command != AnimalCommand.TrackScent)
            {
                hasScentDestination = false;
                scentSourceId = 0;
            }
            if (command != AnimalCommand.Curl && pangolinCurlActive)
            {
                // Explicit non-curl commands cancel an active curl early and start cooldown.
                EndCurlEarly();
            }
            if (command != AnimalCommand.Stalk)
                catStalkFirstAcquisitionApplied = false;
            if (command != AnimalCommand.Guard)
                guardThreatReported = false;
            if (command == AnimalCommand.Forage)
            {
                forageSource = null;
                forageStartedAt = 0f;
                nextForageSearchAt = 0f;
                FindForageSource();
            }
            if (command == AnimalCommand.Return) behaviour.ReceiveCommand(AnimalCommand.Follow);
            return true;
        }

        /// <summary>
        /// Sends the selected Cat around the far side of a confirmed threat and emits an audible
        /// decoy there, drawing the monster away from the supplied protected world position.
        /// </summary>
        public bool IssueLure(Transform threat, Vector3 protectedPosition)
        {
            if (!IsOperational || record.species != AnimalSpecies.Cat || threat == null ||
                behaviour == null || !behaviour.ThreatConfirmed || !agent.enabled || !agent.isOnNavMesh)
                return false;

            Vector3 away = threat.position - protectedPosition;
            away.y = 0f;
            if (away.sqrMagnitude < 0.01f)
            {
                away = threat.position - transform.position;
                away.y = 0f;
            }
            if (away.sqrMagnitude < 0.01f) away = transform.forward;
            Vector3 desired = threat.position + away.normalized * AnimalSpeciesTactics.CatLureDistance;
            if (!NavMesh.SamplePosition(desired, out NavMeshHit hit, 4f, agent.areaMask)) return false;
            NavMeshPath lurePath = new NavMeshPath();
            if (!agent.CalculatePath(hit.position, lurePath) || lurePath.status != NavMeshPathStatus.PathComplete)
                return false;

            lureThreat = threat;
            lureProtectedPosition = protectedPosition;
            lurePoint = hit.position;
            lureUntil = 0f;
            lureTravelDeadline = Time.time + 20f;
            lureHasReachedPoint = false;
            nextCatLurePulseAt = 0f;
            forageSource = null;
            forageThreatRetreating = false;
            behaviour.ReceiveCommand(AnimalCommand.Lure);
            agent.stoppingDistance = 1.1f;
            MoveTo(lurePoint, profile.runDistance);
            return true;
        }

        public void ApplyInjury(int damage)
        {
            if (!IsOperational || behaviour == null || damage <= 0) return;
            float damageMultiplier = profile.incomingDamageMultiplier;
            damageMultiplier *= AnimalExperienceRules.IncomingDamageMultiplier(record.learnedAbilities);
            // VS71 intentional Scale Curl takes priority over the short reactive brace.
            if (record.species == AnimalSpecies.Pangolin && IsCurled)
            {
                damageMultiplier = AnimalPangolinCurlRules.DamageMultiplierWhileCurled(
                    profile.incomingDamageMultiplier, true);
            }
            else if (record.species == AnimalSpecies.Pangolin &&
                (!pangolinBraceActive || Time.time >= pangolinBraceUntil))
            {
                if (record.stamina >= AnimalSpeciesTactics.PangolinBraceStaminaCost)
                {
                    damageMultiplier *= AnimalSpeciesTactics.PangolinBraceDamageMultiplier;
                    record.stamina = Mathf.Max(0, record.stamina - AnimalSpeciesTactics.PangolinBraceStaminaCost);
                    pangolinBraceUntil = Time.time + AnimalSpeciesTactics.PangolinBraceDurationSeconds;
                    pangolinBraceActive = true;
                }
            }
            else if (record.species == AnimalSpecies.Pangolin && pangolinBraceActive)
            {
                damageMultiplier *= AnimalSpeciesTactics.PangolinBraceDamageMultiplier;
            }
            int mitigatedDamage = Mathf.Max(1, Mathf.CeilToInt(Mathf.Max(0, damage) * damageMultiplier));
            behaviour.ApplyInjury(mitigatedDamage);
            record.stamina = Mathf.Clamp(record.stamina - Mathf.Max(1, damage / 2), 0, 100);
            recordDirty = true;
            PlayAudioCue(AnimalAudioCue.Injury);
            if (record.health <= 0) MarkPermanentDeath("companion-injury-" + record.identity + "-" + Time.frameCount);
            else PersistRecord(true);
        }

        public bool MarkPermanentDeath(string deathEventId)
        {
            if (behaviour == null || !behaviour.TryMarkPermanentDeath(deathEventId)) return false;
            currentThreat = null;
            PlayAudioCue(AnimalAudioCue.Death, true);
            if (agent != null && agent.enabled && agent.isOnNavMesh) { agent.isStopped = true; agent.ResetPath(); }
            recordDirty = true;
            PersistRecord(true);
            return true;
        }

        private void Awake()
        {
            if (agent == null) agent = GetComponent<NavMeshAgent>();
            // Repair-cover registration is automatic for every deployed companion.
            if (GetComponent<BridgeRepairGuardian>() == null) gameObject.AddComponent<BridgeRepairGuardian>();
        }

        private void OnEnable() => CampaignEvents.CampaignReplaced += OnCampaignReplaced;

        private void OnCampaignReplaced(CampaignState campaign)
        {
            if (campaign == null || record == null || campaign.animals == null) return;
            for (int i = 0; i < campaign.animals.Count; i++)
            {
                AnimalRecord replacement = campaign.animals[i];
                if (replacement == null || replacement.identity != record.identity) continue;
                if (replacement.status != AnimalStatus.Alive || replacement.health <= 0)
                {
                    ClearBinding();
                    return;
                }
                record = replacement;
                AnimalSpeciesVisualBinder visualBinder = GetComponent<AnimalSpeciesVisualBinder>();
                if (visualBinder != null) visualBinder.Apply(record);
                AnimalCompanionAnimationDriver animationDriver = GetComponent<AnimalCompanionAnimationDriver>();
                if (animationDriver != null) animationDriver.RefreshAnimator();
                attackAnimationUntil = 0f;
                pangolinBraceActive = false;
                forageThreatRetreating = false;
                lureThreat = null;
                lureHasReachedPoint = false;
                if (behaviour != null) behaviour.Initialize(record);
                profile = AnimalCompanionProfile.For(record.species, record.lifeStage);
                appliedLifeStage = record.lifeStage;
                if (agent != null)
                {
                    agent.speed = profile.moveSpeed;
                    if (record.hunger <= 0 && agent.enabled && agent.isOnNavMesh)
                    {
                        agent.isStopped = true;
                        agent.ResetPath();
                    }
                }
                return;
            }
            ClearBinding();
        }

        private void Update()
        {
            // Separation is evaluated before the operational gate so a starving (zero-hunger)
            // companion can still be left behind during an active evacuation.
            EvaluateMissingSeparation();
            if (!IsOperational || owner == null || behaviour == null || agent == null || !agent.enabled) return;
            if (pangolinCurlActive)
            {
                if (Time.time < pangolinCurlUntil) { StopAtCurrentPosition(); return; }
                EndCurlEarly(); // natural expiry starts cooldown
            }
            if (bondResonanceActive && Time.time >= bondResonanceUntil)
            {
                bondResonanceActive = false;
                bondResonanceCooldownUntil = AnimalBondResonanceRules.CooldownEndsAt(Time.time, record.learnedAbilities);
                bondResonanceUntil = 0f;
            }
            if (pangolinBraceActive)
            {
                if (Time.time < pangolinBraceUntil) { StopAtCurrentPosition(); return; }
                pangolinBraceActive = false;
            }
            if (record.lifeStage != appliedLifeStage)
            {
                profile = AnimalCompanionProfile.For(record.species, record.lifeStage);
                appliedLifeStage = record.lifeStage;
                agent.speed = profile.moveSpeed;
            }
            if (Time.time >= nextScan)
            {
                nextScan = Time.time + Mathf.Max(0.1f, scanInterval);
                ScanThreats();
            }
            if (forageThreatRetreating)
            {
                if (currentThreat != null) MoveTo(owner.position, profile.runDistance);
                else { forageThreatRetreating = false; behaviour.ReceiveCommand(AnimalCommand.Follow); }
            }
            else
            {
                switch (behaviour.CurrentCommand)
                {
                    case AnimalCommand.Stay: StopAtCurrentPosition(); break;
                    case AnimalCommand.Search: TickSearch(); break;
                    case AnimalCommand.Forage: TickForage(); break;
                    case AnimalCommand.Lure: TickCatLure(); break;
                    case AnimalCommand.TrackScent: TickScentTrack(); break;
                    case AnimalCommand.Alert: TickAlert(); break;
                    case AnimalCommand.Resonate: TickResonate(); break;
                    case AnimalCommand.Callout: TickCallout(); break;
                    case AnimalCommand.Guard: TickGuard(); break;
                    case AnimalCommand.Protect: TickProtect(); break;
                    case AnimalCommand.Retrieve: TickFollow(); break; // Retrieval target integration is a later item-specific system.
                    case AnimalCommand.Stalk: TickStalk(); break;
                    case AnimalCommand.Return:
                    case AnimalCommand.Follow:
                    default: TickFollow(); break;
                }
            }
            RecoverStamina();
            if (recordDirty && Time.time >= nextPersistTime) PersistRecord(false);
        }



        /// <summary>
        /// Player-commanded Scale Curl for the Pangolin. Longer, stronger, and intentional compared
        /// with the short reactive brace that triggers on damage. Costs stamina up-front, holds the
        /// companion stationary, and applies a deep incoming-damage multiplier for the duration.
        /// </summary>
        private bool TryBeginCurl()
        {
            if (record == null || behaviour == null) return false;
            int maxHealth = 100;
            // Campaign records store health as absolute points; treat 100 as the conventional max
            // used across companion systems unless a higher value is present.
            if (record.health > maxHealth) maxHealth = record.health;
            if (!AnimalPangolinCurlRules.CanIssueCurl(
                    record.species, record.status, record.stamina, record.health, maxHealth,
                    Time.time, pangolinCurlCooldownUntil, IsCurled))
                return false;

            record.stamina = Mathf.Max(0, record.stamina - AnimalSpeciesTactics.PangolinCurlStaminaCost);
            pangolinCurlUntil = AnimalPangolinCurlRules.CurlEndsAt(Time.time);
            pangolinCurlActive = true;
            // Cancel reactive brace so the intentional curl fully owns the defensive state.
            pangolinBraceActive = false;
            pangolinBraceUntil = 0f;
            hasScentDestination = false;
            scentSourceId = 0;
            forageSource = null;
            StopAtCurrentPosition();
            recordDirty = true;
            PlayAudioCue(AnimalAudioCue.ThreatSpotted); // closest existing defensive cue slot
            AwardExperience(AnimalExperienceRules.XpForSuccessfulAbilityUse);
            return true;
        }





        /// <summary>VS80: successful ability uses (not plain attacks) slowly deepen the bond.</summary>
        private void TryGrowBond(int xpAmount)
        {
            if (record == null || xpAmount < AnimalExperienceRules.XpForSuccessfulAbilityUse) return;
            if (!AnimalBondGrowthRules.CanGain(record.status, record.bond, Time.time, nextBondGainAt)) return;
            int before = record.bond;
            int previousTrustRank = AnimalBondTrustRules.RankForBond(before);
            record.bond = AnimalBondGrowthRules.BondAfterGain(before);
            nextBondGainAt = AnimalBondGrowthRules.NextAllowedAt(Time.time);
            recordDirty = true;
            if (AnimalBondTrustRules.RankForBond(record.bond) > previousTrustRank)
                GenericToastUI.Show(AnimalBondTrustRules.FormatRankToast(
                    string.IsNullOrWhiteSpace(record.displayName) ? null : record.displayName, record.bond), 2.4f);
            if (AnimalBondGrowthRules.CrossedResonanceThreshold(before, record.bond))
                GenericToastUI.Show(AnimalBondGrowthRules.FormatResonanceReadyToast(
                    string.IsNullOrWhiteSpace(record.displayName) ? null : record.displayName), 2.6f);
        }

        private void AwardExperience(int amount)
        {
            if (record == null || amount <= 0) return;
            if (record.learnedAbilities == null)
                record.learnedAbilities = new System.Collections.Generic.List<string>();
            TryGrowBond(amount);
            int before = record.experience;
            record.experience = AnimalExperienceRules.AwardXp(record.experience, amount);
            if (record.experience == before) return;
            recordDirty = true;
            var newly = AnimalExperienceRules.EvaluateNewUnlocks(record.experience, record.learnedAbilities);
            for (int i = 0; i < newly.Count; i++)
            {
                string toast = AnimalExperienceRules.FormatUnlockToast(
                    newly[i],
                    string.IsNullOrWhiteSpace(record.displayName) ? null : record.displayName);
                GenericToastUI.Show(toast, 2.6f);
            }
            if (newly.Count > 0) PersistRecord(true);
        }


        private bool TryBeginGuard()
        {
            if (record == null || behaviour == null) return false;
            if (!AnimalGuardPostRules.CanIssueGuard(record.status, IsGuarding)) return false;
            guardThreatReported = false;
            hasGuardPosition = TryFindPreferredEnvironmentalPosition(
                record.species, AnimalCommand.Guard, transform.position, 7f, out guardPosition);
            hasScentDestination = false;
            scentSourceId = 0;
            forageSource = null;
            if (!hasGuardPosition) StopAtCurrentPosition();
            string name = string.IsNullOrWhiteSpace(record.displayName) ? record.species.ToString() : record.displayName;
            GenericToastUI.Show(AnimalGuardPostRules.FormatStartToast(name, record.species), 1.6f);
            return true;
        }

        private void TickGuard()
        {
            if (hasGuardPosition && Vector3.Distance(transform.position, guardPosition) > 0.9f)
                MoveTo(guardPosition, profile.runDistance);
            else
                StopAtCurrentPosition();
            if (currentThreat != null) Face(currentThreat.position);
        }

        private bool TryBeginCallout()
        {
            if (record == null || behaviour == null) return false;
            bool hasWeak = AnimalWeakPointCalloutRules.ThreatHasWeakPoint(currentThreat);
            if (!AnimalWeakPointCalloutRules.CanIssueCallout(
                    record.status, behaviour.ThreatConfirmed, behaviour.ThreatConfidence,
                    hasWeak, Time.time, weakPointCalloutCooldownUntil))
                return false;

            weakPointCalloutCooldownUntil = AnimalWeakPointCalloutRules.CooldownEndsAt(Time.time, record.learnedAbilities);
            AnimalWeakPointCalloutState.Activate(Time.time);
            string toast = AnimalWeakPointCalloutRules.FormatToast(
                record.species,
                string.IsNullOrWhiteSpace(record.displayName) ? null : record.displayName);
            GenericToastUI.Show(toast, 2.4f);
            PlayAudioCue(AnimalAudioCue.ThreatSpotted, true);
            AwardExperience(AnimalExperienceRules.XpForSuccessfulAbilityUse);
            return true;
        }

        /// <summary>
        /// Callout is a pulse command. After issuing, the companion continues useful behaviour.
        /// </summary>
        private void TickCallout()
        {
            if (currentThreat != null && behaviour != null && behaviour.ThreatConfirmed &&
                owner != null && Vector3.Distance(owner.position, currentThreat.position) <= protectRadius)
            {
                TickProtect();
                return;
            }
            TickFollow();
        }

        private bool TryBeginResonate()
        {
            if (record == null || behaviour == null) return false;
            bool confirmed = behaviour.ThreatConfirmed;
            float confidence = behaviour.ThreatConfidence;
            if (!AnimalBondResonanceRules.CanIssueResonate(
                    record.status, record.bond, confirmed, confidence,
                    Time.time, bondResonanceCooldownUntil, IsResonating))
                return false;

            record.bond = AnimalBondResonanceRules.BondAfterResonate(record.bond);
            bondResonanceUntil = AnimalBondResonanceRules.ResonanceEndsAt(Time.time);
            bondResonanceActive = true;
            recordDirty = true;
            string toast = AnimalBondResonanceRules.FormatToast(
                record.species,
                string.IsNullOrWhiteSpace(record.displayName) ? null : record.displayName);
            GenericToastUI.Show(toast, 2.4f);
            PlayAudioCue(AnimalAudioCue.ThreatSpotted, true);
            AwardExperience(AnimalExperienceRules.XpForSuccessfulAbilityUse);
            return true;
        }

        /// <summary>
        /// Bond Resonance keeps the companion on its previous movement behaviour while the
        /// temporary detection boost is active. The command itself is a pulse, not a stance.
        /// </summary>
        private void TickResonate()
        {
            // After the pulse is issued the companion continues its prior useful behaviour.
            // Prefer Protect if a threat is present near the owner, otherwise Follow.
            if (currentThreat != null && behaviour != null && behaviour.ThreatConfirmed &&
                owner != null && Vector3.Distance(owner.position, currentThreat.position) <= protectRadius)
            {
                TickProtect();
                return;
            }
            TickFollow();
        }

        private bool TryBeginStalk()
        {
            if (record == null || behaviour == null) return false;
            if (!AnimalCatStalkRules.CanIssueStalk(record.species, record.status, IsStalking))
                return false;
            catStalkFirstAcquisitionApplied = false;
            hasScentDestination = false;
            scentSourceId = 0;
            forageSource = null;
            return true;
        }

        /// <summary>
        /// Silent Stalk: Cat advances carefully with expanded local perception and reduced movement
        /// speed. The first threat acquired during the stalk receives a confidence bonus.
        /// </summary>
        private void TickStalk()
        {
            if (currentThreat != null)
            {
                // Hold a cautious offset rather than charging; Cat remains an evade specialist.
                Vector3 toThreat = currentThreat.position - transform.position;
                toThreat.y = 0f;
                float dist = toThreat.magnitude;
                float holdDistance = Mathf.Max(2.2f, profile.attackRange + 1.2f);
                if (dist > holdDistance + 0.6f)
                {
                    Vector3 dest = currentThreat.position - toThreat.normalized * holdDistance;
                    if (TryFindPreferredEnvironmentalPosition(record.species, AnimalCommand.Stalk,
                        dest, 4.5f, out Vector3 coverPoint))
                        dest = coverPoint;
                    MoveTo(dest, 999f); // never sprint while stalking
                }
                else
                {
                    StopAtCurrentPosition();
                    Face(currentThreat.position);
                }
                return;
            }
            // No threat yet: shadow the owner at a slightly wider follow distance while scanning.
            if (owner == null) { StopAtCurrentPosition(); return; }
            float follow = profile.followDistance + 1.5f;
            float d = Vector3.Distance(transform.position, owner.position);
            if (d > follow)
                MoveTo(owner.position, 999f);
            else
                StopAtCurrentPosition();
        }

        private void EndCurlEarly()
        {
            if (!pangolinCurlActive) return;
            pangolinCurlActive = false;
            pangolinCurlCooldownUntil = AnimalPangolinCurlRules.CooldownEndsAt(Time.time);
            pangolinCurlUntil = 0f;
        }

        private void EvaluateMissingSeparation()
        {
            if (record == null || record.status != AnimalStatus.Alive || owner == null || bootstrap == null ||
                bootstrap.Campaign == null || Time.time < nextSeparationCheckAt) return;

            float interval = Mathf.Max(0.1f, separationCheckInterval);
            nextSeparationCheckAt = Time.time + interval;
            bool beyondDistance = Vector3.Distance(transform.position, owner.position) >=
                                  Mathf.Max(1f, missingSeparationDistance);
            if (!TryEvaluateOwnerReachability(out bool ownerReachable))
            {
                // Do not punish the player for an unbaked/unavailable NavMesh or a disabled agent.
                separatedSeconds = 0f;
                separationWarningShown = false;
                return;
            }
            bool shouldAccumulate = AnimalSeparationRules.ShouldAccumulate(
                bootstrap.Campaign.phase, record.status, CurrentCommand, beyondDistance, ownerReachable);

            if (!shouldAccumulate)
            {
                separatedSeconds = 0f;
                separationWarningShown = false;
                return;
            }

            separatedSeconds += interval;
            float grace = Mathf.Max(1f, missingGraceSeconds);
            if (!separationWarningShown && separatedSeconds >= grace * 0.5f)
            {
                separationWarningShown = true;
                string petName = string.IsNullOrWhiteSpace(record.displayName) ? record.species.ToString() : record.displayName;
                GenericToastUI.Show(petName + " is cut off from you. Get closer or find a route back!", 3f);
            }

            if (!AnimalSeparationRules.ShouldMarkMissing(separatedSeconds, grace)) return;

            string missingName = string.IsNullOrWhiteSpace(record.displayName) ? record.species.ToString() : record.displayName;
            string identity = record.identity;
            if (bootstrap.TryMarkAnimalMissing(identity))
            {
                GenericToastUI.Show(missingName + " is missing. Search the area and use a recovery point when found.", 4f);
                PlayAudioCue(AnimalAudioCue.Missing);
                separatedSeconds = 0f;
                separationWarningShown = false;
            }
            else
            {
                // Persistence failures must not silently change the in-memory status. Retry later.
                separatedSeconds = grace * 0.75f;
                nextSeparationCheckAt = Time.time + Mathf.Max(2f, interval);
            }
        }

        private bool TryEvaluateOwnerReachability(out bool reachable)
        {
            reachable = false;
            if (agent == null || !agent.enabled || !agent.isOnNavMesh || owner == null) return false;
            if (!NavMesh.SamplePosition(owner.position, out NavMeshHit ownerHit, 3f, agent.areaMask))
                return true; // The player is not on a reachable NavMesh surface.
            if (separationPath == null) separationPath = new NavMeshPath();
            bool calculated = agent.CalculatePath(ownerHit.position, separationPath);
            reachable = calculated && separationPath.status == NavMeshPathStatus.PathComplete;
            return true;
        }

        private void OnDisable()
        {
            CampaignEvents.CampaignReplaced -= OnCampaignReplaced;
            if (recordDirty) PersistRecord(true);
        }

        /// <summary>Commits pending runtime companion changes before a campaign snapshot is cloned.</summary>
        public bool FlushPendingRecord()
        {
            if (!recordDirty) return true;
            if (bootstrap == null || record == null) return false;
            if (!bootstrap.SaveAnimalRecord(record)) return false;
            recordDirty = false;
            return true;
        }

        private void PersistRecord(bool immediate)
        {
            if (!recordDirty || bootstrap == null || record == null) return;
            if (!immediate && Time.time < nextPersistTime) return;
            if (bootstrap.SaveAnimalRecord(record)) recordDirty = false;
            nextPersistTime = Time.time + 10f;
        }

        private AnimalEnvironmentContext SampleEnvironment()
        {
            bool cover = false;
            bool perch = false;
            bool defensiveGround = false;
            bool scentRichGround = false;
            int count = Physics.OverlapSphereNonAlloc(transform.position, environmentProbeRadius,
                environmentBuffer, environmentMask, QueryTriggerInteraction.Collide);
            for (int i = 0; i < count; i++)
            {
                Collider candidate = environmentBuffer[i];
                if (candidate == null) continue;
                AnimalEnvironmentMarker marker = candidate.GetComponentInParent<AnimalEnvironmentMarker>();
                if (marker == null || !marker.IsWithinInfluence(transform.position)) continue;
                AnimalEnvironmentFeature features = marker.Features;
                cover |= (features & AnimalEnvironmentFeature.Concealment) != 0;
                perch |= (features & AnimalEnvironmentFeature.ElevatedPerch) != 0;
                defensiveGround |= (features & AnimalEnvironmentFeature.DefensiveGround) != 0;
                scentRichGround |= (features & AnimalEnvironmentFeature.ScentRichGround) != 0;
            }
            return new AnimalEnvironmentContext(cover, perch, defensiveGround, scentRichGround);
        }

        private bool TryFindPreferredEnvironmentalPosition(AnimalSpecies species, AnimalCommand command,
            Vector3 origin, float searchRadius, out Vector3 destination)
        {
            if (!AnimalAutonomousPositioningRules.TryGetPreferredFeature(species, command, out AnimalEnvironmentFeature feature))
            {
                destination = default;
                return false;
            }
            return TryFindEnvironmentalPosition(feature, origin, searchRadius, out destination);
        }

        /// <summary>Finds the nearest authored feature with a complete path; called only on tactical transitions.</summary>
        private bool TryFindEnvironmentalPosition(AnimalEnvironmentFeature feature, Vector3 origin,
            float searchRadius, out Vector3 destination)
        {
            destination = default;
            if (agent == null || !agent.enabled || !agent.isOnNavMesh || searchRadius <= 0f) return false;
            int count = Physics.OverlapSphereNonAlloc(origin, searchRadius, environmentBuffer,
                environmentMask, QueryTriggerInteraction.Collide);
            if (scentPath == null) scentPath = new NavMeshPath();
            float bestDistance = float.MaxValue;
            bool found = false;
            float tether = owner != null
                ? AnimalAutonomousPositioningRules.MaximumOwnerTetherDistance(record.species, profile.followDistance)
                : searchRadius;
            for (int i = 0; i < count; i++)
            {
                Collider candidate = environmentBuffer[i];
                if (candidate == null) continue;
                AnimalEnvironmentMarker marker = candidate.GetComponentInParent<AnimalEnvironmentMarker>();
                if (marker == null || (marker.Features & feature) == 0 || !marker.IsWithinInfluence(origin)) continue;
                Vector3 markerPosition = marker.transform.position;
                if (owner != null && Vector3.Distance(owner.position, markerPosition) > tether) continue;
                if (!NavMesh.SamplePosition(markerPosition, out NavMeshHit hit, 2.5f, agent.areaMask)) continue;
                if (!agent.CalculatePath(hit.position, scentPath) || scentPath.status != NavMeshPathStatus.PathComplete) continue;
                float distance = (hit.position - transform.position).sqrMagnitude;
                if (distance >= bestDistance) continue;
                bestDistance = distance;
                destination = hit.position;
                found = true;
            }
            return found;
        }

        private void ScanThreats()
        {
            Transform previousThreat = currentThreat;
            currentThreat = null;
            float best = float.MaxValue;
            AnimalEnvironmentContext environment = SampleEnvironment();
            AnimalEnvironmentalAwarenessResult environmentalAwareness =
                AnimalEnvironmentalAwarenessRules.Evaluate(record != null ? record.species : AnimalSpecies.GermanShepherd,
                    behaviour != null ? behaviour.CurrentCommand : AnimalCommand.Follow, environment);
            float scanRadius = AnimalCatStalkRules.DetectionRadiusWhileStalking(profile.detectionRadius, IsStalking);
            scanRadius *= environmentalAwareness.ScanRadiusMultiplier;
            scanRadius = AnimalBondResonanceRules.DetectionRadiusWhileResonating(scanRadius, IsResonating);
            if (record != null)
            {
                scanRadius *= AnimalBondTrustRules.DetectionMultiplier(record.bond);
                scanRadius *= AnimalExperienceRules.DetectionMultiplier(record.learnedAbilities);
            }
            scanRadius = AnimalGuardPostRules.DetectionRadiusWhileGuarding(scanRadius, IsGuarding,
                record != null ? record.learnedAbilities : null);
            if (record != null && owner != null && behaviour != null)
            {
                bool heightAdvantage = transform.position.y >= owner.position.y + 1.5f;
                scanRadius *= AnimalCompanionIntelligenceRules.ScanRadiusMultiplier(
                    record.species, behaviour.CurrentCommand, heightAdvantage);
            }
            int count = Physics.OverlapSphereNonAlloc(transform.position, scanRadius, scanBuffer, threatMask, QueryTriggerInteraction.Ignore);
            for (int i = 0; i < count; i++)
            {
                Collider candidate = scanBuffer[i];
                if (candidate == null) continue;
                MonsterAIController monster = candidate.GetComponentInParent<MonsterAIController>();
                DamageableHealth health = candidate.GetComponentInParent<DamageableHealth>();
                if (monster == null || health == null || health.IsDead) continue;
                Vector3 eye = transform.position + Vector3.up * 0.65f;
                Vector3 target = monster.transform.position + Vector3.up * 0.7f;
                Vector3 delta = target - eye;
                if (Physics.Raycast(eye, delta.normalized, out RaycastHit hit, delta.magnitude, threatMask, QueryTriggerInteraction.Ignore) &&
                    hit.transform != monster.transform && !hit.transform.IsChildOf(monster.transform)) continue;
                float distance = delta.sqrMagnitude;
                if (distance < best) { best = distance; currentThreat = monster.transform; }
            }
            float confidence = currentThreat != null
                ? Mathf.Clamp01(0.62f + profile.threatConfidenceBonus + environmentalAwareness.ConfidenceBonus +
                    (record != null ? AnimalExperienceRules.ThreatConfidenceBonus(record.learnedAbilities) : 0f))
                : 0f;
            if (currentThreat != null && record != null && owner != null && behaviour != null)
            {
                float threatDistance = Vector3.Distance(transform.position, currentThreat.position);
                float ownerDistance = Vector3.Distance(owner.position, currentThreat.position);
                bool heightAdvantage = transform.position.y >= owner.position.y + 1.5f;
                CompanionIntelligenceResult intelligence = AnimalCompanionIntelligenceRules.Evaluate(
                    record.species, behaviour.CurrentCommand, threatDistance, ownerDistance, heightAdvantage);
                confidence = AnimalCompanionIntelligenceRules.ApplyConfidence(confidence, intelligence);
            }
            if (currentThreat != null && currentThreat != previousThreat &&
                AnimalCatStalkRules.ShouldApplyFirstAcquisitionBonus(IsStalking, catStalkFirstAcquisitionApplied))
            {
                confidence = AnimalCatStalkRules.ThreatConfidenceWithStalkBonus(confidence, true, true);
                catStalkFirstAcquisitionApplied = true;
                RegisterTeamworkContribution(AnimalTeamworkRole.CatFlankDistraction);
                GenericToastUI.Show("Cat has silently marked a threat", 2f);
                AwardExperience(AnimalExperienceRules.XpForSuccessfulAbilityUse);
            }
            behaviour.EvaluateThreat(currentThreat != null, confidence);
            if (AnimalGuardPostRules.ShouldReportThreat(
                    IsGuarding, currentThreat != null && behaviour.ThreatConfirmed,
                    confidence, guardThreatReported))
            {
                guardThreatReported = true;
                RegisterTeamworkContribution(AnimalTeamworkRole.PangolinDefensiveAnchor);
                string gName = record != null && !string.IsNullOrWhiteSpace(record.displayName)
                    ? record.displayName : (record != null ? record.species.ToString() : "Companion");
                GenericToastUI.Show(AnimalGuardPostRules.FormatGuardToast(gName, record != null ? record.species : AnimalSpecies.GermanShepherd), 2.2f);
                AwardExperience(AnimalExperienceRules.XpForSuccessfulAbilityUse);
                PlayAudioCue(AnimalAudioCue.ThreatSpotted, true);
            }
            if (currentThreat != null && currentThreat != previousThreat)
            {
                PlayAudioCue(AnimalAudioCue.ThreatSpotted);
                if (record.species == AnimalSpecies.Falcon)
                {
                    MonsterAIController observedMonster = currentThreat.GetComponent<MonsterAIController>();
                    MonsterArchetypeRole role = observedMonster != null
                        ? observedMonster.ActiveRole : MonsterArchetypeRole.Stalker;
                    AnimalScoutingReport report = AnimalScoutingIntelRules.Create(
                        owner != null ? owner : transform, currentThreat, role, Time.time);
                    GenericToastUI.Show(AnimalScoutingIntelRules.Format(report), 2.4f);
                }
            }
        }

        private bool TryBeginScentTrack()
        {
            if (record == null || record.species != AnimalSpecies.GermanShepherd || agent == null ||
                !agent.enabled || !agent.isOnNavMesh) return false;
            if (scentPath == null) scentPath = new NavMeshPath();
            AnimalEnvironmentContext environment = SampleEnvironment();
            float effectiveScentRadius = scentSearchRadius *
                AnimalEnvironmentalAwarenessRules.ScentSearchRadiusMultiplier(environment);
            if (!MonsterScentTrailRegistry.TryFindNearestReachable(transform.position, effectiveScentRadius, Time.time,
                scentTrailLifetime, agent, scentPath, out MonsterScentSample sample)) return false;
            scentSourceId = sample.SourceId;
            scentCursorTime = sample.CreatedAt;
            scentDestination = sample.Position;
            hasScentDestination = true;
            AwardExperience(AnimalExperienceRules.XpForSuccessfulAbilityUse);
            forageSource = null;
            forageThreatRetreating = false;
            agent.stoppingDistance = scentArrivalDistance;
            MoveTo(scentDestination, profile.runDistance);
            GenericToastUI.Show("Shepherd found a monster scent trail · " + sample.Role, 2.2f);
            return true;
        }

        private void TickScentTrack()
        {
            if (currentThreat != null && behaviour.ThreatConfirmed)
            {
                hasScentDestination = false;
                TickSpeciesThreatResponse();
                return;
            }
            if (!hasScentDestination)
            {
                behaviour.ReceiveCommand(AnimalCommand.Follow);
                TickFollow();
                return;
            }
            if (Vector3.Distance(transform.position, scentDestination) > scentArrivalDistance)
            {
                MoveTo(scentDestination, profile.runDistance);
                return;
            }
            if (MonsterScentTrailRegistry.TryGetPrevious(scentSourceId, scentCursorTime, Time.time,
                scentTrailLifetime, out MonsterScentSample previous))
            {
                if (scentPath == null) scentPath = new NavMeshPath();
                if (agent.CalculatePath(previous.Position, scentPath) && scentPath.status == NavMeshPathStatus.PathComplete)
                {
                    scentCursorTime = previous.CreatedAt;
                    scentDestination = previous.Position;
                    MoveTo(scentDestination, profile.runDistance);
                    return;
                }
            }
            hasScentDestination = false;
            scentSourceId = 0;
            behaviour.ReceiveCommand(AnimalCommand.Follow);
            agent.stoppingDistance = profile.followDistance;
            StopAtCurrentPosition();
            GenericToastUI.Show("The scent trail ends, fades, or continues beyond a route you cannot reach.", 3f);
        }

        private void TickFollow()
        {
            if (currentThreat != null && behaviour.ThreatConfirmed && Vector3.Distance(owner.position, currentThreat.position) <= protectRadius)
            {
                TickSpeciesThreatResponse();
                return;
            }
            Vector3 desired = owner.position - owner.forward * profile.followDistance;
            if (record != null && record.species == AnimalSpecies.Falcon)
            {
                if (Time.time >= nextFalconPerchSearchAt)
                {
                    nextFalconPerchSearchAt = Time.time + 4f;
                    hasFalconPerch = TryFindPreferredEnvironmentalPosition(
                        record.species, AnimalCommand.Follow, desired, 8f, out falconPerchPosition);
                }
                if (hasFalconPerch && Vector3.Distance(owner.position, falconPerchPosition) <=
                    AnimalAutonomousPositioningRules.MaximumOwnerTetherDistance(record.species, profile.followDistance))
                {
                    if (Vector3.Distance(transform.position, falconPerchPosition) > 1.1f)
                        MoveTo(falconPerchPosition, profile.runDistance);
                    else
                        StopAtCurrentPosition();
                    return;
                }
            }
            MoveTo(desired, profile.runDistance);
        }

        private void TickProtect()
        {
            if (currentThreat != null && Vector3.Distance(owner.position, currentThreat.position) <= protectRadius)
            {
                TickSpeciesThreatResponse();
                return;
            }
            MoveTo(owner.position, profile.runDistance);
        }

        private void TickSpeciesThreatResponse()
        {
            switch (AnimalSpeciesTactics.ThreatResponse(record.species))
            {
                case CompanionThreatResponse.Engage:
                    TickAttackSupport();
                    break;
                case CompanionThreatResponse.Observe:
                    TickFalconObservation();
                    break;
                case CompanionThreatResponse.HoldDefence:
                    MoveTo(owner.position, profile.runDistance);
                    break;
                case CompanionThreatResponse.Evade:
                    TickCatEvasion();
                    break;
            }
        }

        private void RegisterTeamworkContribution(AnimalTeamworkRole role)
        {
            if (record == null || currentThreat == null) return;
            if (AnimalTeamworkState.Register(currentThreat, record.species, role, Time.time))
                GenericToastUI.Show("Companion opening created · follow up with your weapon", 2.2f);
        }

        private void TickFalconObservation()
        {
            if (currentThreat == null) { TickFollow(); return; }
            if (AnimalDistractionRules.CanEmit(record, AnimalSpecies.Falcon, Time.time, nextFalconDistractionAt))
            {
                MonsterStimulusBus.Emit(MonsterStimulusKind.AnimalDistraction, transform.position,
                    AnimalSpeciesTactics.FalconDistractionLoudness, gameObject);
                nextFalconDistractionAt = Time.time + AnimalSpeciesTactics.FalconDistractionCooldownSeconds;
                RegisterTeamworkContribution(AnimalTeamworkRole.FalconDistraction);
                PlayAudioCue(AnimalAudioCue.Distraction);
            }
            Vector3 away = transform.position - currentThreat.position;
            away.y = 0f;
            if (away.sqrMagnitude < 0.01f) away = owner.position - currentThreat.position;
            if (away.sqrMagnitude < 0.01f) away = -owner.forward;
            Vector3 observationPoint = currentThreat.position + away.normalized * AnimalSpeciesTactics.FalconObservationDistance;
            Vector3 selectedObservationPoint = observationPoint;
            bool hasPerch = TryFindEnvironmentalPosition(AnimalEnvironmentFeature.ElevatedPerch,
                observationPoint, 6f, out Vector3 perchPoint);
            if (hasPerch) selectedObservationPoint = perchPoint;
            if (NavMesh.SamplePosition(selectedObservationPoint, out NavMeshHit hit, 3f, agent.areaMask))
            {
                if (Vector3.Distance(transform.position, hit.position) > 1.2f) MoveTo(hit.position, profile.runDistance);
                else if (agent.isOnNavMesh) agent.isStopped = true;
            }
            Face(currentThreat.position);
        }

        private void TickCatEvasion()
        {
            if (currentThreat == null) { TickFollow(); return; }
            Vector3 away = transform.position - currentThreat.position;
            away.y = 0f;
            if (away.sqrMagnitude < 0.01f) away = owner.position - currentThreat.position;
            if (away.sqrMagnitude < 0.01f) away = -owner.forward;
            Vector3 desired = owner.position - owner.forward * profile.followDistance +
                away.normalized * AnimalSpeciesTactics.CatThreatAvoidanceDistance;
            if (NavMesh.SamplePosition(desired, out NavMeshHit hit, 3f, NavMesh.AllAreas))
                MoveTo(hit.position, profile.runDistance);
            else
                MoveTo(owner.position - owner.forward * profile.followDistance, profile.runDistance);
        }

        private void TickCatLure()
        {
            DamageableHealth lureHealth = lureThreat != null ? lureThreat.GetComponent<DamageableHealth>() : null;
            if (record.species != AnimalSpecies.Cat || lureThreat == null ||
                (lureHealth != null && lureHealth.IsDead) ||
                (lureHasReachedPoint && Time.time >= lureUntil) ||
                (!lureHasReachedPoint && Time.time >= lureTravelDeadline))
            {
                lureThreat = null;
                lureHasReachedPoint = false;
                agent.stoppingDistance = profile.followDistance;
                behaviour.ReceiveCommand(AnimalCommand.Follow);
                return;
            }

            Vector3 away = lureThreat.position - lureProtectedPosition;
            away.y = 0f;
            if (away.sqrMagnitude < 0.01f) away = transform.forward;
            Vector3 desired = lureThreat.position + away.normalized * AnimalSpeciesTactics.CatLureDistance;
            if (NavMesh.SamplePosition(desired, out NavMeshHit hit, 4f, agent.areaMask))
                lurePoint = hit.position;

            float distance = Vector3.Distance(transform.position, lurePoint);
            if (distance > 1.6f)
            {
                MoveTo(lurePoint, profile.runDistance);
                return;
            }

            agent.isStopped = true;
            Face(lureThreat.position);
            if (!lureHasReachedPoint)
            {
                lureHasReachedPoint = true;
                lureUntil = Time.time + AnimalSpeciesTactics.CatLureDurationSeconds;
            }
            if (Time.time >= nextCatLurePulseAt &&
                AnimalDistractionRules.CanEmit(record, AnimalSpecies.Cat, Time.time, nextCatLurePulseAt))
            {
                MonsterStimulusBus.Emit(MonsterStimulusKind.AnimalDistraction, transform.position,
                    AnimalSpeciesTactics.CatLureLoudness, gameObject);
                nextCatLurePulseAt = Time.time + AnimalSpeciesTactics.CatLurePulseIntervalSeconds;
                RegisterTeamworkContribution(AnimalTeamworkRole.CatFlankDistraction);
                PlayAudioCue(AnimalAudioCue.Distraction);
            }
        }

        private void TickAttackSupport()
        {
            if (currentThreat == null || !agent.isOnNavMesh) return;
            float distance = Vector3.Distance(transform.position, currentThreat.position);
            if (distance > profile.attackRange) MoveTo(currentThreat.position, profile.runDistance);
            else
            {
                agent.isStopped = true;
                Face(currentThreat.position);
                if (Time.time >= nextAttack)
                {
                    DamageableHealth health = currentThreat.GetComponent<DamageableHealth>();
                    if (health != null && !health.IsDead)
                    {
                        Vector3 point = currentThreat.position + Vector3.up * 0.7f;
                        health.ApplyDamage(profile.attackDamage, point, (currentThreat.position - transform.position).normalized, gameObject);
                        RegisterTeamworkContribution(AnimalTeamworkRole.ShepherdInterception);
                        attackAnimationUntil = Time.time + 0.38f;
                        PlayAudioCue(AnimalAudioCue.Attack);
                        AwardExperience(AnimalExperienceRules.XpForSuccessfulAttack);
                        recordDirty = true;
                        nextAttack = Time.time + profile.attackInterval;
                    }
                }
            }
        }

        private void TickAlert()
        {
            if (currentThreat != null) { TickSpeciesThreatResponse(); return; }
            TickFollow();
        }

        private void TickSearch()
        {
            if (currentThreat != null) { TickSpeciesThreatResponse(); return; }
            if (!hasSearchPoint) FindSearchPoint();
            if (hasSearchPoint && Vector3.Distance(transform.position, searchPoint) > profile.followDistance)
                MoveTo(searchPoint, profile.runDistance);
            else { hasSearchPoint = false; agent.isStopped = true; }
        }

        private void TickForage()
        {
            // Foraging is a deliberate survival task, not combat. If a threat is perceived,
            // abandon the food run and return to the owner rather than pathing into danger.
            if (currentThreat != null)
            {
                forageSource = null;
                agent.stoppingDistance = profile.followDistance;
                forageThreatRetreating = true;
                Vector3 retreatPoint = owner.position;
                MoveTo(retreatPoint, profile.runDistance);
                return;
            }

            if (forageSource == null || !forageSource.isActiveAndEnabled || bootstrap == null ||
                !bootstrap.CanForageFromSource(forageSource.SourceId))
            {
                forageSource = null;
                if (Time.time >= nextForageSearchAt) FindForageSource();
                if (forageSource == null)
                {
                    agent.isStopped = true;
                    return;
                }
            }

            float distance = Vector3.Distance(transform.position, forageSource.transform.position);
            if (distance > Mathf.Max(1.1f, agent.stoppingDistance + 0.35f))
            {
                forageStartedAt = 0f;
                MoveTo(forageSource.transform.position, profile.runDistance);
                return;
            }

            agent.isStopped = true;
            if (forageStartedAt <= 0f) forageStartedAt = Time.time;
            if (Time.time - forageStartedAt < AnimalSpeciesTactics.ForageDurationSeconds(record.species)) return;

            if (bootstrap.TryCollectForagedPetFood(this, forageSource))
            {
                forageSource = null;
                agent.stoppingDistance = profile.followDistance;
                behaviour.ReceiveCommand(AnimalCommand.Follow);
                GenericToastUI.Show(AnimalSelectionRules.GetDisplayName(record) + " secured pet food", 1.6f);
                PlayAudioCue(AnimalAudioCue.ForageComplete);
            }
            else
            {
                forageSource = null;
                forageStartedAt = 0f;
                nextForageSearchAt = Time.time + 0.5f;
            }
        }

        private void FindForageSource()
        {
            nextForageSearchAt = Time.time + 2f;
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            if (bootstrap == null || !agent.isOnNavMesh) return;

            AnimalForageFoodSource[] sources = FindObjectsByType<AnimalForageFoodSource>(FindObjectsSortMode.None);
            float searchRadius = commandSearchRadius * AnimalSpeciesTactics.ForageSearchRadiusMultiplier(record.species);
            float bestDistance = searchRadius * searchRadius * 4f;
            AnimalForageFoodSource bestSource = null;
            NavMeshPath candidatePath = new NavMeshPath();
            for (int i = 0; i < sources.Length; i++)
            {
                AnimalForageFoodSource candidate = sources[i];
                if (candidate == null || !candidate.isActiveAndEnabled ||
                    !bootstrap.CanForageFromSource(candidate.SourceId)) continue;
                float sqrDistance = (candidate.transform.position - transform.position).sqrMagnitude;
                if (sqrDistance >= bestDistance) continue;
                if (!agent.CalculatePath(candidate.transform.position, candidatePath) ||
                    candidatePath.status != NavMeshPathStatus.PathComplete) continue;
                bestDistance = sqrDistance;
                bestSource = candidate;
            }
            forageSource = bestSource;
            forageStartedAt = 0f;
        }

        private void FindSearchPoint()
        {
            Vector2 offset = Random.insideUnitCircle * commandSearchRadius;
            Vector3 candidate = owner.position + new Vector3(offset.x, 0f, offset.y);
            if (NavMesh.SamplePosition(candidate, out NavMeshHit hit, commandSearchRadius, NavMesh.AllAreas))
            { searchPoint = hit.position; hasSearchPoint = true; }
        }

        private void StopAtCurrentPosition()
        {
            if (!agent.isOnNavMesh) return;
            agent.isStopped = true;
            agent.ResetPath();
        }

        private void PlayAudioCue(AnimalAudioCue cue, bool bypassCooldown = false)
        {
            if (record == null) return;
            if (audioFeedback == null) audioFeedback = GetComponent<AnimalCompanionAudioFeedback>();
            if (audioFeedback != null) audioFeedback.Play(cue, record.species, bypassCooldown);
        }

        private void MoveTo(Vector3 destination, float sprintThreshold)
        {
            if (!agent.isOnNavMesh) return;
            agent.isStopped = false;
            float distance = Vector3.Distance(transform.position, destination);
            float speed = AnimalCatStalkRules.MoveSpeedWhileStalking(profile.moveSpeed, IsStalking);
            agent.speed = speed * (distance > sprintThreshold && !IsStalking ? 1.25f : 1f);
            if (!agent.hasPath || Vector3.Distance(agent.destination, destination) > 0.8f)
                agent.SetDestination(destination);
        }

        private void Face(Vector3 point)
        {
            Vector3 direction = point - transform.position; direction.y = 0f;
            if (direction.sqrMagnitude > 0.01f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), Time.deltaTime * 8f);
        }

        private void RecoverStamina()
        {
            if (record.stamina >= 100 || agent.velocity.sqrMagnitude >= 0.04f) return;
            float hungerRecoveryMultiplier = record.hunger < 20 ? 0.5f : (record.hunger < 40 ? 0.75f : 1f);
            float learnedStaminaMult = AnimalExperienceRules.StaminaRecoveryMultiplier(record.learnedAbilities);
            staminaRecoveryAccumulator += Time.deltaTime * profile.staminaRecoveryPerSecond * hungerRecoveryMultiplier * learnedStaminaMult;
            int wholePoints = Mathf.FloorToInt(staminaRecoveryAccumulator);
            if (wholePoints <= 0) return;
            int previous = record.stamina;
            record.stamina = Mathf.Min(100, record.stamina + wholePoints);
            if (record.stamina != previous) recordDirty = true;
            staminaRecoveryAccumulator -= wholePoints;
        }
    }
}
