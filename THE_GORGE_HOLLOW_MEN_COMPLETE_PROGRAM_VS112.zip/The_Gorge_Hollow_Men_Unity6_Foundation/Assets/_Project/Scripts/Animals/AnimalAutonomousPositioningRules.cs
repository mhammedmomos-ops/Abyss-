namespace GorgeHollow
{
    /// <summary>VS85 policy for choosing authored environmental positions without changing player commands.</summary>
    public static class AnimalAutonomousPositioningRules
    {
        public static bool TryGetPreferredFeature(AnimalSpecies species, AnimalCommand command,
            out AnimalEnvironmentFeature feature)
        {
            feature = AnimalEnvironmentFeature.None;
            switch (species)
            {
                case AnimalSpecies.Falcon:
                    if (command != AnimalCommand.Follow && command != AnimalCommand.Protect &&
                        command != AnimalCommand.Alert) return false;
                    feature = AnimalEnvironmentFeature.ElevatedPerch;
                    return true;

                case AnimalSpecies.Pangolin:
                    if (command != AnimalCommand.Guard) return false;
                    feature = AnimalEnvironmentFeature.DefensiveGround;
                    return true;

                case AnimalSpecies.Cat:
                    if (command != AnimalCommand.Stalk) return false;
                    feature = AnimalEnvironmentFeature.Concealment;
                    return true;

                case AnimalSpecies.GermanShepherd:
                    if (command != AnimalCommand.TrackScent) return false;
                    feature = AnimalEnvironmentFeature.ScentRichGround;
                    return true;

                default:
                    return false;
            }
        }

        public static float MaximumOwnerTetherDistance(AnimalSpecies species, float followDistance)
        {
            float safeFollow = UnityEngine.Mathf.Clamp(
                float.IsNaN(followDistance) || float.IsInfinity(followDistance) ? 3f : followDistance,
                1f, 12f);
            // Environmental positioning is a small tactical adjustment, never a reason to abandon the owner.
            return species == AnimalSpecies.Falcon ? safeFollow + 5f : safeFollow + 2.5f;
        }

        public static bool ShouldUseEnvironmentalPosition(AnimalSpecies species, AnimalCommand command)
        {
            return species == AnimalSpecies.Falcon &&
                   (command == AnimalCommand.Follow || command == AnimalCommand.Protect || command == AnimalCommand.Alert) ||
                   species == AnimalSpecies.Pangolin && command == AnimalCommand.Guard ||
                   species == AnimalSpecies.Cat && command == AnimalCommand.Stalk ||
                   species == AnimalSpecies.GermanShepherd && command == AnimalCommand.TrackScent;
        }
    }
}
