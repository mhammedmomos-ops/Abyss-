using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// A local wild-food opportunity a living companion can locate and forage.
    /// A source can be harvested once per fictional campaign day; the campaign owns depletion state.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AnimalForageFoodSource : MonoBehaviour
    {
        [SerializeField] private string sourceId;
        [SerializeField, Min(1)] private int foodYield = 1;

        public string SourceId => sourceId != null ? sourceId.Trim() : string.Empty;
        public int FoodYield => Mathf.Clamp(foodYield, 1, 5);

        private void Awake()
        {
            if (string.IsNullOrWhiteSpace(sourceId))
            {
                Debug.LogError("Forage food source requires a stable, unique Source ID.", this);
                enabled = false;
            }
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            foodYield = Mathf.Clamp(foodYield, 1, 5);
            if (sourceId != null) sourceId = sourceId.Trim();
        }
#endif
    }
}
