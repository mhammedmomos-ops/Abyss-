using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Campaign-facing care actions for the currently selected companion.</summary>
    [DisallowMultipleComponent]
    public sealed class AnimalCareService : MonoBehaviour
    {
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private CompanionCommandRelay companion;
        [SerializeField] private CompanionSafeZone safeZone;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            if (companion == null) companion = FindFirstObjectByType<CompanionCommandRelay>();
            if (safeZone == null) safeZone = FindFirstObjectByType<CompanionSafeZone>();
        }

        public bool TryRest()
        {
            AnimalRecord record = GetSelectedRecord();
            if (bootstrap == null || safeZone == null || !safeZone.IsOwnerInside || record == null) return false;
            int oldStamina = record.stamina;
            int oldBond = record.bond;
            if (!AnimalCareRules.TryRest(record, true)) return false;
            if (bootstrap.SaveAnimalRecord(record)) return true;
            record.stamina = oldStamina;
            record.bond = oldBond;
            return false;
        }

        public bool TryFeed()
        {
            AnimalRecord record = GetSelectedRecord();
            if (bootstrap == null || record == null) return false;
            return bootstrap.TryFeedAnimal(record.identity);
        }

        public bool TryTreat()
        {
            AnimalRecord record = GetSelectedRecord();
            if (bootstrap == null || bootstrap.Campaign == null || record == null) return false;
            int oldHealth = record.health;
            int oldSupplies = bootstrap.Campaign.medicalSupplies;
            if (!AnimalCareRules.TryTreat(record, ref bootstrap.Campaign.medicalSupplies)) return false;
            if (bootstrap.SaveAnimalRecord(record)) return true;
            record.health = oldHealth;
            bootstrap.Campaign.medicalSupplies = oldSupplies;
            return false;
        }

        private AnimalRecord GetSelectedRecord()
        {
            return companion != null && companion.HasCompanion ? companion.Record : null;
        }
    }
}
