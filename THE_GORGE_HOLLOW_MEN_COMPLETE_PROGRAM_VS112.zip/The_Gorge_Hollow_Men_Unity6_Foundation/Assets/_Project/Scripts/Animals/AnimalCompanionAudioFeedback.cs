using System;
using UnityEngine;

namespace GorgeHollow
{
    public enum AnimalAudioCue
    {
        ThreatSpotted, Injury, Attack, ForageComplete, Distraction, Missing, Death
    }

    /// <summary>Optional, species-authored one-shot feedback. No clip is required for the companion to function.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(AnimalCompanionController))]
    [RequireComponent(typeof(AudioSource))]
    public sealed class AnimalCompanionAudioFeedback : MonoBehaviour
    {
        [Serializable]
        private sealed class CueSet
        {
            public AnimalSpecies species;
            public AudioClip threatSpotted;
            public AudioClip injury;
            public AudioClip attack;
            public AudioClip forageComplete;
            public AudioClip distraction;
            public AudioClip missing;
            public AudioClip death;
        }

        [SerializeField] private AudioSource source;
        [SerializeField] private CueSet[] speciesCues = new CueSet[4];
        [SerializeField, Min(0f)] private float minimumCueInterval = 0.8f;
        [SerializeField, Range(0f, 1f)] private float volume = 0.8f;
        [SerializeField, Range(0f, 0.3f)] private float pitchVariation = 0.06f;
        private float nextAllowedAt;

        private void Awake()
        {
            if (source == null) source = GetComponent<AudioSource>();
            if (source != null) { source.playOnAwake = false; source.loop = false; source.spatialBlend = 1f; source.rolloffMode = AudioRolloffMode.Logarithmic; source.minDistance = 2f; source.maxDistance = 24f; }
        }

        public bool Play(AnimalAudioCue cue, AnimalSpecies species, bool bypassCooldown = false)
        {
            if (source == null) source = GetComponent<AudioSource>();
            if (source == null || !isActiveAndEnabled || (!bypassCooldown && Time.time < nextAllowedAt)) return false;
            CueSet set = FindSet(species);
            if (set == null) return false;
            AudioClip clip = ClipFor(set, cue);
            if (clip == null) return false;
            source.pitch = 1f + UnityEngine.Random.Range(-pitchVariation, pitchVariation);
            source.PlayOneShot(clip, volume);
            nextAllowedAt = Time.time + Mathf.Max(0f, minimumCueInterval);
            return true;
        }

        private CueSet FindSet(AnimalSpecies species)
        {
            if (speciesCues == null) return null;
            for (int i = 0; i < speciesCues.Length; i++)
                if (speciesCues[i] != null && speciesCues[i].species == species) return speciesCues[i];
            return null;
        }

        private static AudioClip ClipFor(CueSet set, AnimalAudioCue cue)
        {
            switch (cue)
            {
                case AnimalAudioCue.ThreatSpotted: return set.threatSpotted;
                case AnimalAudioCue.Injury: return set.injury;
                case AnimalAudioCue.Attack: return set.attack;
                case AnimalAudioCue.ForageComplete: return set.forageComplete;
                case AnimalAudioCue.Distraction: return set.distraction;
                case AnimalAudioCue.Missing: return set.missing;
                case AnimalAudioCue.Death: return set.death;
                default: return null;
            }
        }

        public void ResetCooldown() { nextAllowedAt = 0f; }
    }
}
