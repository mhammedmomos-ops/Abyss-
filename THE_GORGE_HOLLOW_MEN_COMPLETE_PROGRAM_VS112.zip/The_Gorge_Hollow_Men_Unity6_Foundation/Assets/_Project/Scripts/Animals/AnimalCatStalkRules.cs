namespace GorgeHollow
{
    /// <summary>
    /// Deterministic rules for the Cat Silent Stalk command (VS72).
    /// Pure static methods for EditMode tests without scene or NavMesh.
    /// </summary>
    public static class AnimalCatStalkRules
    {
        public static bool CanIssueStalk(AnimalSpecies species, AnimalStatus status, bool alreadyStalking)
        {
            if (species != AnimalSpecies.Cat) return false;
            if (status != AnimalStatus.Alive) return false;
            if (alreadyStalking) return false;
            return true;
        }

        public static float MoveSpeedWhileStalking(float baseMoveSpeed, bool isStalking)
        {
            if (!isStalking || baseMoveSpeed <= 0f) return baseMoveSpeed;
            return baseMoveSpeed * AnimalSpeciesTactics.CatStalkMoveSpeedMultiplier;
        }

        public static float DetectionRadiusWhileStalking(float baseRadius, bool isStalking)
        {
            if (!isStalking || baseRadius <= 0f) return baseRadius;
            return baseRadius * AnimalSpeciesTactics.CatStalkDetectionRadiusMultiplier;
        }

        public static float StimulusLoudnessWhileStalking(float baseLoudness, bool isStalking)
        {
            if (!isStalking) return baseLoudness;
            float loud = baseLoudness > 0f ? baseLoudness : 0f;
            return loud * AnimalSpeciesTactics.CatStalkStimulusLoudnessMultiplier;
        }

        public static float ThreatConfidenceWithStalkBonus(float currentConfidence, bool isStalking, bool firstAcquisitionThisStalk)
        {
            float c = currentConfidence < 0f ? 0f : (currentConfidence > 1f ? 1f : currentConfidence);
            if (!isStalking || !firstAcquisitionThisStalk) return c;
            float bonus = AnimalSpeciesTactics.CatStalkThreatConfidenceBonus;
            float result = c + bonus;
            return result > 1f ? 1f : result;
        }

        public static bool ShouldApplyFirstAcquisitionBonus(bool isStalking, bool alreadyAppliedThisStalk)
        {
            return isStalking && !alreadyAppliedThisStalk;
        }
    }
}
