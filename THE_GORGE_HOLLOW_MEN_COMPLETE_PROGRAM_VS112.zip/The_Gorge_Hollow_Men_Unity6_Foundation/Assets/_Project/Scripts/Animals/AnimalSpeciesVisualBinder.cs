using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Optional species-prefab adapter. Unassigned species retain the clearly labelled greybox fallback.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(AnimalCompanionController))]
    public sealed class AnimalSpeciesVisualBinder : MonoBehaviour
    {
        [SerializeField] private Transform visualRoot;
        [SerializeField] private GameObject fallbackVisual;
        [Header("Optional imported animal prefabs")]
        [SerializeField] private GameObject germanShepherdPrefab;
        [SerializeField] private GameObject falconPrefab;
        [SerializeField] private GameObject pangolinPrefab;
        [SerializeField] private GameObject catPrefab;

        private GameObject activeInstance;
        private string boundIdentity;
        private AnimalSpecies boundSpecies;

        public bool HasAssignedPrefab(AnimalSpecies species) => GetPrefab(species) != null;
        public GameObject ActiveInstance => activeInstance;

        private void Awake()
        {
            if (visualRoot == null) visualRoot = transform;
        }

        public bool Apply(AnimalRecord record)
        {
            if (record == null || record.status != AnimalStatus.Alive || string.IsNullOrWhiteSpace(record.identity))
                return false;
            if (visualRoot == null) visualRoot = transform;
            if (activeInstance != null && boundIdentity == record.identity && boundSpecies == record.species)
            {
                activeInstance.name = record.species + " — " + SafeDisplayName(record);
                if (fallbackVisual != null) fallbackVisual.SetActive(false);
                return true;
            }

            ClearSpawnedInstance();
            GameObject prefab = GetPrefab(record.species);
            if (prefab == null)
            {
                if (fallbackVisual != null) fallbackVisual.SetActive(true);
                boundIdentity = record.identity;
                boundSpecies = record.species;
                return true; // A greybox fallback is intentional until licensed art is assigned.
            }

            activeInstance = Instantiate(prefab, visualRoot, false);
            activeInstance.name = record.species + " — " + SafeDisplayName(record);
            activeInstance.transform.localPosition = Vector3.zero;
            activeInstance.transform.localRotation = Quaternion.identity;
            boundIdentity = record.identity;
            boundSpecies = record.species;
            if (fallbackVisual != null) fallbackVisual.SetActive(false);
            return true;
        }

        public void Clear()
        {
            ClearSpawnedInstance();
            boundIdentity = null;
            if (fallbackVisual != null) fallbackVisual.SetActive(true);
        }

        private void ClearSpawnedInstance()
        {
            if (activeInstance != null)
            {
                if (Application.isPlaying) Destroy(activeInstance);
                else DestroyImmediate(activeInstance);
            }
            activeInstance = null;
        }

        private GameObject GetPrefab(AnimalSpecies species)
        {
            switch (species)
            {
                case AnimalSpecies.GermanShepherd: return germanShepherdPrefab;
                case AnimalSpecies.Falcon: return falconPrefab;
                case AnimalSpecies.Pangolin: return pangolinPrefab;
                case AnimalSpecies.Cat: return catPrefab;
                default: return null;
            }
        }

        private static string SafeDisplayName(AnimalRecord record) =>
            string.IsNullOrWhiteSpace(record.displayName) ? record.species.ToString() : record.displayName.Trim();
    }
}
