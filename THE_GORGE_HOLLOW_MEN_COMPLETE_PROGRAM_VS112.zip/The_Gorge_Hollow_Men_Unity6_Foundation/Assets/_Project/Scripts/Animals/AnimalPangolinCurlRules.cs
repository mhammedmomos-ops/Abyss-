namespace GorgeHollow
{
    /// <summary>
    /// Deterministic eligibility and mitigation rules for the Pangolin Scale Curl command (VS71).
    /// Pure static methods so EditMode tests require no scene, NavMesh or MonoBehaviour.
    /// </summary>
    public static class AnimalPangolinCurlRules
    {
        public static bool CanIssueCurl(
            AnimalSpecies species,
            AnimalStatus status,
            int stamina,
            int health,
            int maxHealth,
            float now,
            float curlCooldownUntil,
            bool alreadyCurled)
        {
            if (species != AnimalSpecies.Pangolin) return false;
            if (status != AnimalStatus.Alive) return false;
            if (alreadyCurled) return false;
            if (stamina < AnimalSpeciesTactics.PangolinCurlStaminaCost) return false;
            if (now < curlCooldownUntil) return false;
            if (maxHealth <= 0) return false;
            float healthFraction = (float)health / maxHealth;
            if (healthFraction < AnimalSpeciesTactics.PangolinCurlMinHealthFraction) return false;
            return true;
        }

        public static float DamageMultiplierWhileCurled(float baseIncomingMultiplier, bool isCurled)
        {
            if (!isCurled) return baseIncomingMultiplier;
            float base = baseIncomingMultiplier > 0f ? baseIncomingMultiplier : 1f;
            return base * AnimalSpeciesTactics.PangolinCurlDamageMultiplier;
        }

        public static int MitigatedDamage(int rawDamage, float baseIncomingMultiplier, bool isCurled)
        {
            if (rawDamage <= 0) return 0;
            float mult = DamageMultiplierWhileCurled(baseIncomingMultiplier, isCurled);
            return System.Math.Max(1, (int)System.Math.Ceiling(rawDamage * mult));
        }

        public static float CurlEndsAt(float startedAt) =>
            startedAt + AnimalSpeciesTactics.PangolinCurlDurationSeconds;

        public static float CooldownEndsAt(float curlEndedAt) =>
            curlEndedAt + AnimalSpeciesTactics.PangolinCurlCooldownSeconds;

        public static bool IsCurlActive(float now, float curlUntil) =>
            now < curlUntil && !float.IsNaN(curlUntil) && !float.IsInfinity(curlUntil);

        public static bool IsOnCooldown(float now, float cooldownUntil) =>
            now < cooldownUntil && !float.IsNaN(cooldownUntil) && !float.IsInfinity(cooldownUntil);
    }
}
