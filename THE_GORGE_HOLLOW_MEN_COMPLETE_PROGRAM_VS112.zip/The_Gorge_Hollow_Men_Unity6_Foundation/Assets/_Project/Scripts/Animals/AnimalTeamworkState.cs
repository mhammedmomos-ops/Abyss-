using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Session-only companion/player opening ledger keyed to a specific monster instance. It never
    /// persists campaign state and cannot grant a bonus against a different target.
    /// </summary>
    public static class AnimalTeamworkState
    {
        private sealed class TargetWindow
        {
            public Transform Target;
            public int SpeciesMask;
            public float ExpiresAt;
            public bool OpeningAnnounced;
        }

        private static readonly Dictionary<int, TargetWindow> Windows = new Dictionary<int, TargetWindow>();
        private static readonly List<int> ExpiredKeys = new List<int>();

        private static void PruneExpired(float now)
        {
            ExpiredKeys.Clear();
            foreach (KeyValuePair<int, TargetWindow> pair in Windows)
                if (pair.Value == null || !AnimalTeamworkRules.IsWindowValid(now, pair.Value.ExpiresAt))
                    ExpiredKeys.Add(pair.Key);
            for (int i = 0; i < ExpiredKeys.Count; i++) Windows.Remove(ExpiredKeys[i]);
        }

        /// <returns>True only when this companion first opens a player follow-through window.</returns>
        public static bool Register(Transform target, AnimalSpecies species, AnimalTeamworkRole role, float now)
        {
            if (target == null || !AnimalTeamworkRules.CanContribute(species, role) ||
                float.IsNaN(now) || float.IsInfinity(now)) return false;

            PruneExpired(now);
            int id = target.GetInstanceID();
            if (!Windows.TryGetValue(id, out TargetWindow window) || window.Target != target ||
                !AnimalTeamworkRules.IsWindowValid(now, window.ExpiresAt))
            {
                window = new TargetWindow { Target = target };
                Windows[id] = window;
            }

            int previousCount = AnimalTeamworkRules.SpeciesCount(window.SpeciesMask);
            window.SpeciesMask = AnimalTeamworkRules.AddSpecies(window.SpeciesMask, species);
            window.ExpiresAt = now + AnimalTeamworkRules.CoordinationWindowSeconds;
            int nextCount = AnimalTeamworkRules.SpeciesCount(window.SpeciesMask);
            bool activated = previousCount == 0 && nextCount >= 1 && !window.OpeningAnnounced;
            if (activated) window.OpeningAnnounced = true;
            return activated;
        }

        public static float ModifyDamage(Transform target, float damage, float now)
        {
            if (!float.IsNaN(now) && !float.IsInfinity(now)) PruneExpired(now);
            if (target == null || !Windows.TryGetValue(target.GetInstanceID(), out TargetWindow window) ||
                window.Target != target) return damage;
            if (!AnimalTeamworkRules.IsWindowValid(now, window.ExpiresAt))
            {
                Windows.Remove(target.GetInstanceID());
                return damage;
            }
            return AnimalTeamworkRules.ApplyDamageMultiplier(damage, window.SpeciesMask, true, now, window.ExpiresAt);
        }

        public static int ActiveSpeciesCount(Transform target, float now)
        {
            if (!float.IsNaN(now) && !float.IsInfinity(now)) PruneExpired(now);
            if (target == null || !Windows.TryGetValue(target.GetInstanceID(), out TargetWindow window) ||
                window.Target != target || !AnimalTeamworkRules.IsWindowValid(now, window.ExpiresAt)) return 0;
            return AnimalTeamworkRules.SpeciesCount(window.SpeciesMask);
        }

        public static void ClearForTests()
        {
            Windows.Clear();
            ExpiredKeys.Clear();
        }
    }
}
