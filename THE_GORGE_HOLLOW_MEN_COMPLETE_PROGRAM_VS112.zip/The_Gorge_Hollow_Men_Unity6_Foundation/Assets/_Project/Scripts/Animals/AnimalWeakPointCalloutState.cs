using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Session-only player damage bonus granted by a successful companion weak-point callout.
    /// Not campaign-persisted. Queried by combat systems that deal player weapon damage.
    /// </summary>
    public static class AnimalWeakPointCalloutState
    {
        private static float bonusUntil;

        public static void Activate(float now)
        {
            bonusUntil = AnimalWeakPointCalloutRules.PlayerBonusEndsAt(now);
        }

        public static void ClearForTests() => bonusUntil = 0f;

        public static bool IsActive(float now) =>
            AnimalWeakPointCalloutRules.IsPlayerBonusActive(now, bonusUntil);

        public static float ModifyDamage(float baseDamage, float now) =>
            AnimalWeakPointCalloutRules.ApplyPlayerDamageBonus(baseDamage, IsActive(now));
    }
}
