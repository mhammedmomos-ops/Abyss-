using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>A short-lived physical trace left where a living monster actually travelled.</summary>
    public readonly struct MonsterScentSample
    {
        public readonly int SourceId;
        public readonly Vector3 Position;
        public readonly float CreatedAt;
        public readonly MonsterArchetypeRole Role;

        public MonsterScentSample(int sourceId, Vector3 position, float createdAt, MonsterArchetypeRole role)
        {
            SourceId = sourceId;
            Position = position;
            CreatedAt = createdAt;
            Role = role;
        }
    }

    public static class AnimalScentTrailRules
    {
        public const float DefaultTrailLifetimeSeconds = 150f;
        public const float DefaultSampleSpacing = 1.6f;
        public const float DefaultSampleInterval = 0.85f;

        public static bool IsFresh(float now, float createdAt, float lifetime)
        {
            if (float.IsNaN(now) || float.IsInfinity(now) || float.IsNaN(createdAt) ||
                float.IsInfinity(createdAt) || float.IsNaN(lifetime) || float.IsInfinity(lifetime) || lifetime <= 0f)
                return false;
            float age = now - createdAt;
            return age >= 0f && age <= lifetime;
        }

        public static float Freshness(float now, float createdAt, float lifetime)
        {
            if (!IsFresh(now, createdAt, lifetime)) return 0f;
            return Mathf.Clamp01(1f - (now - createdAt) / lifetime);
        }

        public static bool ShouldRecord(Vector3 previous, Vector3 current, float now, float nextRecordAt,
            float minimumSpacing)
        {
            if (float.IsNaN(now) || float.IsInfinity(now) || float.IsNaN(nextRecordAt) ||
                float.IsInfinity(nextRecordAt) || float.IsNaN(minimumSpacing) || float.IsInfinity(minimumSpacing) ||
                now < nextRecordAt) return false;
            float spacing = Mathf.Max(0.1f, minimumSpacing);
            Vector3 delta = current - previous;
            delta.y = 0f;
            return delta.sqrMagnitude >= spacing * spacing;
        }
    }

    /// <summary>
    /// Bounded in-memory scent history. It stores only sampled monster positions, never live target
    /// transforms or hidden monster state. Consumers must independently search within local range.
    /// </summary>
    public static class MonsterScentTrailRegistry
    {
        private const int MaximumSamples = 768;
        private static readonly List<MonsterScentSample> Samples = new List<MonsterScentSample>(MaximumSamples);

        public static int SampleCount => Samples.Count;

        public static void Record(int sourceId, Vector3 position, float createdAt, MonsterArchetypeRole role)
        {
            if (sourceId == 0 || !IsFinite(position) || float.IsNaN(createdAt) || float.IsInfinity(createdAt)) return;
            Prune(createdAt - AnimalScentTrailRules.DefaultTrailLifetimeSeconds);
            if (Samples.Count >= MaximumSamples) Samples.RemoveAt(0);
            Samples.Add(new MonsterScentSample(sourceId, position, createdAt, role));
        }

        public static bool TryFindNearest(Vector3 origin, float radius, float now, float lifetime,
            out MonsterScentSample sample)
        {
            sample = default;
            if (!IsFinite(origin) || float.IsNaN(radius) || float.IsInfinity(radius) || radius <= 0f) return false;
            Prune(now - Mathf.Max(0f, lifetime));
            float best = radius * radius;
            bool found = false;
            for (int i = 0; i < Samples.Count; i++)
            {
                MonsterScentSample candidate = Samples[i];
                if (!AnimalScentTrailRules.IsFresh(now, candidate.CreatedAt, lifetime)) continue;
                Vector3 delta = candidate.Position - origin;
                delta.y = 0f;
                float distance = delta.sqrMagnitude;
                if (distance > best) continue;
                best = distance;
                sample = candidate;
                found = true;
            }
            return found;
        }

        public static bool TryFindNearestReachable(Vector3 origin, float radius, float now, float lifetime,
            NavMeshAgent agent, NavMeshPath pathBuffer, out MonsterScentSample sample)
        {
            sample = default;
            if (!IsFinite(origin) || float.IsNaN(radius) || float.IsInfinity(radius) || radius <= 0f ||
                agent == null || pathBuffer == null || !agent.enabled || !agent.isOnNavMesh)
                return false;
            Prune(now - Mathf.Max(0f, lifetime));
            float bestDistance = radius * radius;
            bool found = false;
            for (int i = 0; i < Samples.Count; i++)
            {
                MonsterScentSample candidate = Samples[i];
                if (!AnimalScentTrailRules.IsFresh(now, candidate.CreatedAt, lifetime)) continue;
                Vector3 delta = candidate.Position - origin;
                delta.y = 0f;
                float distance = delta.sqrMagnitude;
                if (distance > bestDistance) continue;
                if (!agent.CalculatePath(candidate.Position, pathBuffer) || pathBuffer.status != NavMeshPathStatus.PathComplete)
                    continue;
                bestDistance = distance;
                sample = candidate;
                found = true;
            }
            return found;
        }

        public static bool TryGetPrevious(int sourceId, float beforeTime, float now, float lifetime,
            out MonsterScentSample sample)
        {
            sample = default;
            bool found = false;
            float bestTime = float.NegativeInfinity;
            for (int i = 0; i < Samples.Count; i++)
            {
                MonsterScentSample candidate = Samples[i];
                if (candidate.SourceId != sourceId || candidate.CreatedAt >= beforeTime ||
                    !AnimalScentTrailRules.IsFresh(now, candidate.CreatedAt, lifetime)) continue;
                if (candidate.CreatedAt <= bestTime) continue;
                bestTime = candidate.CreatedAt;
                sample = candidate;
                found = true;
            }
            return found;
        }

        public static void ClearForTests() => Samples.Clear();

        private static void Prune(float cutoff)
        {
            for (int i = Samples.Count - 1; i >= 0; i--)
                if (Samples[i].CreatedAt < cutoff) Samples.RemoveAt(i);
        }

        private static bool IsFinite(Vector3 value)
        {
            return !float.IsNaN(value.x) && !float.IsInfinity(value.x) &&
                   !float.IsNaN(value.y) && !float.IsInfinity(value.y) &&
                   !float.IsNaN(value.z) && !float.IsInfinity(value.z);
        }
    }
}
