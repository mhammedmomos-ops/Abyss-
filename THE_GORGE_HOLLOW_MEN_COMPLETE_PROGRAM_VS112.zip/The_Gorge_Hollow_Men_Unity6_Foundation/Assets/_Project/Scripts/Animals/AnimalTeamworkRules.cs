using UnityEngine;

namespace GorgeHollow
{
    /// <summary>VS86 deterministic species-role rules for short-lived companion/player combat coordination.</summary>
    public enum AnimalTeamworkRole
    {
        ShepherdInterception,
        FalconDistraction,
        PangolinDefensiveAnchor,
        CatFlankDistraction
    }

    public static class AnimalTeamworkRules
    {
        public const float CoordinationWindowSeconds = 5f;
        public const float CompanionPlayerDamageMultiplier = 1.08f;

        public static bool TryGetRole(AnimalSpecies species, out AnimalTeamworkRole role)
        {
            switch (species)
            {
                case AnimalSpecies.GermanShepherd: role = AnimalTeamworkRole.ShepherdInterception; return true;
                case AnimalSpecies.Falcon: role = AnimalTeamworkRole.FalconDistraction; return true;
                case AnimalSpecies.Pangolin: role = AnimalTeamworkRole.PangolinDefensiveAnchor; return true;
                case AnimalSpecies.Cat: role = AnimalTeamworkRole.CatFlankDistraction; return true;
                default: role = AnimalTeamworkRole.ShepherdInterception; return false;
            }
        }

        public static bool CanContribute(AnimalSpecies species, AnimalTeamworkRole role)
        {
            return TryGetRole(species, out AnimalTeamworkRole expected) && expected == role;
        }

        public static int SpeciesCount(int speciesMask)
        {
            // Only the four approved species bits are meaningful; mask hostile/invalid inputs.
            int value = speciesMask & 15;
            int count = 0;
            while (value != 0) { count += value & 1; value >>= 1; }
            return count;
        }

        public static float DamageMultiplier(int speciesMask)
        {
            // The current campaign scene binds one active companion at a time. The player's
            // follow-through completes the team action; extra species bits never stack damage.
            return SpeciesCount(speciesMask) > 0 ? CompanionPlayerDamageMultiplier : 1f;
        }

        public static int AddSpecies(int speciesMask, AnimalSpecies species)
        {
            int bit = SpeciesBit(species);
            return bit == 0 ? speciesMask : speciesMask | bit;
        }

        public static int SpeciesBit(AnimalSpecies species)
        {
            switch (species)
            {
                case AnimalSpecies.GermanShepherd: return 1;
                case AnimalSpecies.Falcon: return 2;
                case AnimalSpecies.Pangolin: return 4;
                case AnimalSpecies.Cat: return 8;
                default: return 0;
            }
        }

        public static bool IsWindowValid(float now, float expiresAt)
        {
            return IsFinite(now) && IsFinite(expiresAt) && now < expiresAt;
        }

        public static float ApplyDamageMultiplier(float damage, int speciesMask, bool targetMatches, float now, float expiresAt)
        {
            if (damage <= 0f || !IsFinite(damage) || !targetMatches || !IsWindowValid(now, expiresAt))
                return damage;
            return damage * DamageMultiplier(speciesMask);
        }

        private static bool IsFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }
}
