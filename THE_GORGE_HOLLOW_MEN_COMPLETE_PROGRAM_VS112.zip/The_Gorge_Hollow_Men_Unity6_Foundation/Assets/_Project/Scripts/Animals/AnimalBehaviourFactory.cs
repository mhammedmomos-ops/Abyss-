namespace GorgeHollow
{
    /// <summary>Creates the selected roster species without hard-coding a default pet.</summary>
    public static class AnimalBehaviourFactory
    {
        public static IAnimalBehaviour Create(AnimalSpecies species)
        {
            switch (species)
            {
                case AnimalSpecies.GermanShepherd: return new GermanShepherdBehaviour();
                case AnimalSpecies.Falcon: return new FalconBehaviour();
                case AnimalSpecies.Pangolin: return new PangolinBehaviour();
                case AnimalSpecies.Cat: return new CatBehaviour();
                default: return null;
            }
        }

        public static bool IsSupported(AnimalSpecies species) => Create(species) != null;
    }
}
