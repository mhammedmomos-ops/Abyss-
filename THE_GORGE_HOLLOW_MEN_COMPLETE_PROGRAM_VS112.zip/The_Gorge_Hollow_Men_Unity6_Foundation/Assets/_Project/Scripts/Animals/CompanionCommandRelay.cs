using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Scene bridge between mobile UI commands and an IAnimalBehaviour instance.
    /// Assign or inject the live behaviour when the companion is spawned.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class CompanionCommandRelay : MonoBehaviour
    {
        [SerializeField] private string companionLabel = "Companion";
        [SerializeField] private AnimalCompanionController worldActor;
        private IAnimalBehaviour behaviour;
        private AnimalRecord record;

        public string CompanionLabel => record != null ? AnimalSelectionRules.GetDisplayName(record) : companionLabel;
        public bool HasCompanion => behaviour != null && record != null && record.status == AnimalStatus.Alive && record.health > 0;
        public bool IsOperational => HasCompanion && AnimalCareRules.CanOperate(record);
        public AnimalRecord Record => record;
        public bool IsCurled => worldActor != null && worldActor.IsCurled;
        public bool IsStalking => worldActor != null && worldActor.IsStalking;
        public bool IsResonating => worldActor != null && worldActor.IsResonating;
        public bool IsGuarding => worldActor != null && worldActor.IsGuarding;
        public AnimalCommand CurrentCommand => worldActor != null ? worldActor.CurrentCommand : AnimalCommand.Follow;

        private void OnEnable() => CampaignEvents.CampaignReplaced += OnCampaignReplaced;
        private void OnDisable() => CampaignEvents.CampaignReplaced -= OnCampaignReplaced;

        private void OnCampaignReplaced(CampaignState campaign)
        {
            if (campaign == null || record == null || campaign.animals == null) return;
            for (int i = 0; i < campaign.animals.Count; i++)
            {
                AnimalRecord replacement = campaign.animals[i];
                if (replacement == null || replacement.identity != record.identity) continue;
                if (replacement.status != AnimalStatus.Alive || replacement.health <= 0)
                {
                    behaviour = null;
                    record = null;
                    if (worldActor != null) worldActor.ClearBinding();
                    return;
                }
                record = replacement;
                if (behaviour != null) behaviour.Initialize(record);
                return;
            }
            behaviour = null;
            record = null;
            if (worldActor != null) worldActor.ClearBinding();
        }

        public void Bind(IAnimalBehaviour animalBehaviour, AnimalRecord animalRecord)
        {
            behaviour = animalBehaviour;
            record = animalRecord;
            if (behaviour != null && record != null)
                behaviour.Initialize(record);
        }

        /// <summary>Binds whichever approved species the player selected, with their chosen name.</summary>
        public bool BindSelected(AnimalRecord selectedRecord, Transform playerOwner)
        {
            if (selectedRecord == null) return false;
            IAnimalBehaviour selectedBehaviour = AnimalBehaviourFactory.Create(selectedRecord.species);
            if (selectedBehaviour == null) return false;
            if (worldActor == null) worldActor = GetComponent<AnimalCompanionController>();
            if (worldActor == null || !worldActor.Bind(selectedRecord, playerOwner, selectedBehaviour)) return false;
            behaviour = selectedBehaviour;
            record = selectedRecord;
            return true;
        }

        public void Clear()
        {
            behaviour = null;
            record = null;
            worldActor = null;
        }

        public bool TryLureFrom(Transform protectedTarget)
        {
            if (!IsOperational || record.species != AnimalSpecies.Cat || worldActor == null || worldActor.CurrentThreat == null)
                return false;
            Vector3 protectedPosition = protectedTarget != null ? protectedTarget.position :
                (worldActor.Owner != null ? worldActor.Owner.position : worldActor.transform.position);
            if (!worldActor.IssueLure(worldActor.CurrentThreat, protectedPosition)) return false;
            SimpleAudioCuePlayer.PlayCue(AudioCueId.UIClick);
            MobileHaptics.PlayImpact(MobileHapticStrength.Light);
            return true;
        }

        public bool TryCommand(AnimalCommand command)
        {
            if (!IsOperational || command == AnimalCommand.Lure) return false;
            if (worldActor != null)
            {
                if (!worldActor.IssueCommand(command)) return false;
            }
            else behaviour.ReceiveCommand(command);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.UIClick);
            MobileHaptics.PlayImpact(MobileHapticStrength.Light);
            return true;
        }
    }
}
