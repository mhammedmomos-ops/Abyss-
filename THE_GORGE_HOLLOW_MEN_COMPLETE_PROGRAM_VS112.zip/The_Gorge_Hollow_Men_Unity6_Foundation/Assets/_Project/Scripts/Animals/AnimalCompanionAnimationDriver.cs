using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>
    /// Drives optional authored animal animation without taking movement authority from NavMeshAgent.
    /// Any imported species rig can use the same parameter contract; species-specific Animator
    /// Controllers may ignore parameters they do not need.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(AnimalCompanionController))]
    public sealed class AnimalCompanionAnimationDriver : MonoBehaviour
    {
        [SerializeField] private AnimalCompanionController companion;
        [SerializeField] private NavMeshAgent agent;
        [SerializeField] private Animator animator;
        [SerializeField, Min(0f)] private float speedDampTime = 0.12f;
        [SerializeField, Range(0.1f, 1f)] private float runningThreshold = 0.9f;

        private readonly HashSet<int> floatParameters = new HashSet<int>();
        private readonly HashSet<int> boolParameters = new HashSet<int>();
        private readonly HashSet<int> intParameters = new HashSet<int>();
        private readonly HashSet<int> triggerParameters = new HashSet<int>();
        private int lastSpecies = -1;
        private bool previousAttacking;
        private bool cached;

        private static readonly int SpeedHash = Animator.StringToHash(AnimalAnimationContract.Speed);
        private static readonly int MovingHash = Animator.StringToHash(AnimalAnimationContract.IsMoving);
        private static readonly int RunningHash = Animator.StringToHash(AnimalAnimationContract.IsRunning);
        private static readonly int BracingHash = Animator.StringToHash(AnimalAnimationContract.IsBracing);
        private static readonly int ForagingHash = Animator.StringToHash(AnimalAnimationContract.IsForaging);
        private static readonly int LuringHash = Animator.StringToHash(AnimalAnimationContract.IsLuring);
        private static readonly int ObservingHash = Animator.StringToHash(AnimalAnimationContract.IsObserving);
        private static readonly int IncapacitatedHash = Animator.StringToHash(AnimalAnimationContract.IsIncapacitated);
        private static readonly int DeadHash = Animator.StringToHash(AnimalAnimationContract.IsDead);
        private static readonly int SpeciesHash = Animator.StringToHash(AnimalAnimationContract.Species);
        private static readonly int AttackHash = Animator.StringToHash(AnimalAnimationContract.Attack);

        private void Awake()
        {
            ResolveReferences();
            CacheParameters();
        }

        private void OnEnable()
        {
            if (animator == null) ResolveReferences();
            if (!cached) CacheParameters();
        }

        private void ResolveReferences()
        {
            if (companion == null) companion = GetComponent<AnimalCompanionController>();
            if (agent == null) agent = GetComponent<NavMeshAgent>();
            if (animator == null) animator = GetComponentInChildren<Animator>(true);
        }

        private void CacheParameters()
        {
            floatParameters.Clear(); boolParameters.Clear(); intParameters.Clear(); triggerParameters.Clear();
            cached = true;
            if (animator == null || animator.runtimeAnimatorController == null) return;
            AnimatorControllerParameter[] parameters = animator.parameters;
            for (int i = 0; i < parameters.Length; i++)
            {
                AnimatorControllerParameter parameter = parameters[i];
                switch (parameter.type)
                {
                    case AnimatorControllerParameterType.Float: floatParameters.Add(parameter.nameHash); break;
                    case AnimatorControllerParameterType.Bool: boolParameters.Add(parameter.nameHash); break;
                    case AnimatorControllerParameterType.Int: intParameters.Add(parameter.nameHash); break;
                    case AnimatorControllerParameterType.Trigger: triggerParameters.Add(parameter.nameHash); break;
                }
            }
        }

        private void Update()
        {
            if (companion == null || animator == null || !animator.isActiveAndEnabled) return;
            if (!cached) CacheParameters();

            float worldSpeed = agent != null && agent.enabled && agent.isOnNavMesh ? agent.velocity.magnitude : 0f;
            float normalizedSpeed = AnimalAnimationContract.NormalizeSpeed(worldSpeed, companion.AnimationMoveSpeed);
            SetFloat(SpeedHash, normalizedSpeed);
            SetBool(MovingHash, normalizedSpeed > 0.035f);
            SetBool(RunningHash, AnimalAnimationContract.IsRunning(normalizedSpeed, runningThreshold));
            SetBool(BracingHash, companion.IsBracing);
            SetBool(ForagingHash, companion.IsForaging);
            SetBool(LuringHash, companion.IsLuring);
            SetBool(ObservingHash, companion.IsObserving);
            SetBool(IncapacitatedHash, companion.IsIncapacitated);
            SetBool(DeadHash, companion.IsDead);

            AnimalRecord record = companion.Record;
            if (record != null)
            {
                int species = AnimalAnimationContract.SpeciesIndex(record.species);
                if (species != lastSpecies) { SetInt(SpeciesHash, species); lastSpecies = species; }
            }

            bool attacking = companion.IsAttacking;
            if (attacking && !previousAttacking && triggerParameters.Contains(AttackHash)) animator.SetTrigger(AttackHash);
            previousAttacking = attacking;
        }

        private void SetFloat(int hash, float value)
        {
            if (floatParameters.Contains(hash)) animator.SetFloat(hash, value, Mathf.Max(0f, speedDampTime), Time.deltaTime);
        }
        private void SetBool(int hash, bool value) { if (boolParameters.Contains(hash)) animator.SetBool(hash, value); }
        private void SetInt(int hash, int value) { if (intParameters.Contains(hash)) animator.SetInteger(hash, value); }

        /// <summary>Call after replacing the visual rig at runtime so its Animator parameters are recached.</summary>
        public void RefreshAnimator()
        {
            animator = GetComponentInChildren<Animator>(true);
            cached = false;
            lastSpecies = -1;
            previousAttacking = false;
            CacheParameters();
        }
    }
}
