namespace GorgeHollow
{
    /// <summary>Species-level decision policy kept separate from scene movement and campaign persistence.</summary>
    public enum CompanionThreatResponse
    {
        Engage,
        Observe,
        HoldDefence,
        Evade
    }

    public static class AnimalSpeciesTactics
    {
        public static CompanionThreatResponse ThreatResponse(AnimalSpecies species)
        {
            switch (species)
            {
                case AnimalSpecies.GermanShepherd: return CompanionThreatResponse.Engage;
                case AnimalSpecies.Falcon: return CompanionThreatResponse.Observe;
                case AnimalSpecies.Pangolin: return CompanionThreatResponse.HoldDefence;
                case AnimalSpecies.Cat: return CompanionThreatResponse.Evade;
                default: return CompanionThreatResponse.HoldDefence;
            }
        }

        public static bool CanEngage(AnimalSpecies species) => ThreatResponse(species) == CompanionThreatResponse.Engage;

        public static float ForageDurationSeconds(AnimalSpecies species)
        {
            switch (species)
            {
                case AnimalSpecies.GermanShepherd: return 2.2f; // scent-led ground search
                case AnimalSpecies.Falcon: return 1.8f;          // rapid visual search
                case AnimalSpecies.Pangolin: return 3.4f;        // slower ground foraging
                case AnimalSpecies.Cat: return 2.5f;             // cautious, quiet search
                default: return 2.5f;
            }
        }

        public static float ForageSearchRadiusMultiplier(AnimalSpecies species)
        {
            switch (species)
            {
                case AnimalSpecies.GermanShepherd: return 1.35f;
                case AnimalSpecies.Falcon: return 1.6f;
                case AnimalSpecies.Pangolin: return 0.9f;
                case AnimalSpecies.Cat: return 1.15f;
                default: return 1f;
            }
        }

        public static int PangolinBraceStaminaCost => 8;
        public static float PangolinBraceDurationSeconds => 2.4f;
        public static float PangolinBraceDamageMultiplier => 0.45f;
        public static float FalconObservationDistance => 5.5f;
        public static float CatThreatAvoidanceDistance => 3.5f;
        public static float FalconDistractionCooldownSeconds => 4f;
        public static float FalconDistractionLoudness => 27f;
        public static float FalconDistractionHoldSeconds => 5f;
        public static float CatLureDistance => 10f;
        public static float CatLureDurationSeconds => 9f;
        public static float CatLurePulseIntervalSeconds => 2.5f;
        public static float CatLureLoudness => 25f;

        // VS71 — intentional Scale Curl (distinct from the short reactive brace on hit)
        public static int PangolinCurlStaminaCost => 18;
        public static float PangolinCurlDurationSeconds => 8f;
        public static float PangolinCurlDamageMultiplier => 0.18f;
        public static float PangolinCurlCooldownSeconds => 14f;
        public static float PangolinCurlMinHealthFraction => 0.05f;

        // VS72 — Cat Silent Stalk
        public static float CatStalkMoveSpeedMultiplier => 0.72f;
        public static float CatStalkDetectionRadiusMultiplier => 1.35f;
        public static float CatStalkThreatConfidenceBonus => 0.22f;
        public static float CatStalkStimulusLoudnessMultiplier => 0.15f;
        public static float CatStalkMinimumDurationSeconds => 4f;

        // VS73 — Bond Resonance (cross-species)
        public static int BondResonanceMinimumBond => 35;
        public static int BondResonanceBondCost => 4;
        public static float BondResonanceDurationSeconds => 7f;
        public static float BondResonanceDetectionMultiplier => 1.4f;
        public static float BondResonanceCooldownSeconds => 18f;
        public static float BondResonanceConfidenceFloor => 0.55f;

        // VS74 — Weak Point Callout
        public static float WeakPointCalloutMinConfidence => 0.6f;
        public static float WeakPointCalloutCooldownSeconds => 12f;
        public static float WeakPointCalloutPlayerDamageBonusSeconds => 6f;
        public static float WeakPointCalloutPlayerDamageMultiplier => 1.15f;

        // VS76 — Guard Post
        public static float GuardPostDetectionMultiplier => 1.25f;
        public static float GuardPostMinConfidenceForReport => 0.5f;
    }
}




