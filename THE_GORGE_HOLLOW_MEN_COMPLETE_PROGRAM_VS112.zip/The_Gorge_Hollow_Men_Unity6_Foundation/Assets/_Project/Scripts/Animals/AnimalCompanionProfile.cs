using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Species tuning is data, while save identity/name remain player-selected campaign data.</summary>
    public struct AnimalCompanionProfile
    {
        public float followDistance;
        public float runDistance;
        public float moveSpeed;
        public float detectionRadius;
        public float attackDamage;
        public float attackRange;
        public float attackInterval;
        public float threatConfidenceBonus;
        public float incomingDamageMultiplier;
        public float staminaRecoveryPerSecond;

        public static AnimalCompanionProfile For(AnimalSpecies species) => For(species, AnimalLifeStage.Adult);

        public static AnimalCompanionProfile For(AnimalSpecies species, AnimalLifeStage lifeStage)
        {
            switch (species)
            {
                case AnimalSpecies.GermanShepherd:
                    return ApplyLifeStage(new AnimalCompanionProfile { followDistance = 2.1f, runDistance = 7f, moveSpeed = 4.1f, detectionRadius = 12f, attackDamage = 9f, attackRange = 1.7f, attackInterval = 1.35f, threatConfidenceBonus = 0.12f, incomingDamageMultiplier = 1f, staminaRecoveryPerSecond = 5.5f }, lifeStage);
                case AnimalSpecies.Falcon:
                    return ApplyLifeStage(new AnimalCompanionProfile { followDistance = 3.8f, runDistance = 10f, moveSpeed = 5.2f, detectionRadius = 22f, attackDamage = 3f, attackRange = 2.2f, attackInterval = 2.2f, threatConfidenceBonus = 0.24f, incomingDamageMultiplier = 1.2f, staminaRecoveryPerSecond = 4.5f }, lifeStage);
                case AnimalSpecies.Pangolin:
                    return ApplyLifeStage(new AnimalCompanionProfile { followDistance = 2.4f, runDistance = 6f, moveSpeed = 2.8f, detectionRadius = 8f, attackDamage = 5f, attackRange = 1.35f, attackInterval = 2f, threatConfidenceBonus = 0.04f, incomingDamageMultiplier = 0.62f, staminaRecoveryPerSecond = 6f }, lifeStage);
                case AnimalSpecies.Cat:
                    return ApplyLifeStage(new AnimalCompanionProfile { followDistance = 2.8f, runDistance = 8f, moveSpeed = 4.6f, detectionRadius = 16f, attackDamage = 5f, attackRange = 1.4f, attackInterval = 1.65f, threatConfidenceBonus = 0.18f, incomingDamageMultiplier = 0.9f, staminaRecoveryPerSecond = 5f }, lifeStage);
                default: return default;
            }
        }

        private static AnimalCompanionProfile ApplyLifeStage(AnimalCompanionProfile profile, AnimalLifeStage stage)
        {
            switch (stage)
            {
                case AnimalLifeStage.Young:
                    profile.moveSpeed *= 0.78f;
                    profile.detectionRadius *= 0.72f;
                    profile.attackDamage *= 0.65f;
                    profile.staminaRecoveryPerSecond *= 1.2f;
                    break;
                case AnimalLifeStage.Adolescent:
                    profile.moveSpeed *= 0.92f;
                    profile.detectionRadius *= 0.9f;
                    profile.attackDamage *= 0.85f;
                    break;
                case AnimalLifeStage.Senior:
                    profile.moveSpeed *= 0.78f;
                    profile.detectionRadius *= 0.88f;
                    profile.attackDamage *= 0.8f;
                    profile.incomingDamageMultiplier *= 1.12f;
                    profile.staminaRecoveryPerSecond *= 0.72f;
                    break;
            }
            return profile;
        }
    }
}
