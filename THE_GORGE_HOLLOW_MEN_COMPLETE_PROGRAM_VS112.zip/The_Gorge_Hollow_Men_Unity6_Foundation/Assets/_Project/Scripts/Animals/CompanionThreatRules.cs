namespace GorgeHollow
{
    /// <summary>Pure targeting gates for monsters retaliating against a companion.</summary>
    public static class CompanionThreatRules
    {
        public static bool CanMonsterTargetCompanion(bool monsterHasDirectPlayerSight, bool ownerMatchesVisiblePlayer,
            bool companionHasConfirmedThisMonster, bool companionOperational, float distance, float attackRange)
        {
            if (!monsterHasDirectPlayerSight || !ownerMatchesVisiblePlayer || !companionHasConfirmedThisMonster || !companionOperational)
                return false;
            if (float.IsNaN(distance) || float.IsInfinity(distance) || float.IsNaN(attackRange) || float.IsInfinity(attackRange))
                return false;
            return distance >= 0f && attackRange > 0f && distance <= attackRange;
        }

        public static bool CanResolveCompanionAttack(bool companionOperational, bool companionStillThreatening,
            bool monsterStillSeesOwner, float distance, float maximumResolveDistance)
        {
            if (!companionOperational || !companionStillThreatening || !monsterStillSeesOwner) return false;
            if (float.IsNaN(distance) || float.IsInfinity(distance) || float.IsNaN(maximumResolveDistance) || float.IsInfinity(maximumResolveDistance))
                return false;
            return distance >= 0f && maximumResolveDistance > 0f && distance <= maximumResolveDistance;
        }
    }
}
