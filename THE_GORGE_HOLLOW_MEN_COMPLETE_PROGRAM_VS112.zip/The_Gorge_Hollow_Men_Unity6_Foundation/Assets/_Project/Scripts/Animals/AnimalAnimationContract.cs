using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Shared animation values for all player-selectable animal rigs.</summary>
    public static class AnimalAnimationContract
    {
        public const string Speed = "Speed";
        public const string IsMoving = "IsMoving";
        public const string IsRunning = "IsRunning";
        public const string IsBracing = "IsBracing";
        public const string IsForaging = "IsForaging";
        public const string IsLuring = "IsLuring";
        public const string IsObserving = "IsObserving";
        public const string IsIncapacitated = "IsIncapacitated";
        public const string IsDead = "IsDead";
        public const string Species = "Species";
        public const string Attack = "Attack";

        public static float NormalizeSpeed(float worldSpeed, float maximumSpeed)
        {
            if (float.IsNaN(worldSpeed) || float.IsInfinity(worldSpeed) || worldSpeed < 0f) worldSpeed = 0f;
            if (float.IsNaN(maximumSpeed) || float.IsInfinity(maximumSpeed) || maximumSpeed < 0.01f) maximumSpeed = 1f;
            return Mathf.Clamp01(worldSpeed / maximumSpeed);
        }

        public static bool IsRunning(float normalizedSpeed, float threshold = 0.9f)
        {
            if (float.IsNaN(normalizedSpeed) || float.IsInfinity(normalizedSpeed)) return false;
            if (float.IsNaN(threshold) || float.IsInfinity(threshold)) threshold = 0.9f;
            return normalizedSpeed >= Mathf.Clamp(threshold, 0.1f, 1f);
        }

        public static int SpeciesIndex(AnimalSpecies species) => (int)species;
    }
}
