namespace GorgeHollow
{
    /// <summary>
    /// Bond growth from working together (VS80). Before this, bond only rose through feeding and resting
    /// (+1 each) while Bond Resonance costs 4 and needs 35, so Resonance was very slow to reach.
    /// Successful ability uses now grant a small, rate-limited bond gain.
    /// </summary>
    public static class AnimalBondGrowthRules
    {
        public const int MaxBond = 100;
        public static int BondPerAbilityUse => 1;
        public static float MinSecondsBetweenGains => 45f;

        public static bool CanGain(AnimalStatus status, int bond, float now, float nextAllowedAt)
        {
            if (status != AnimalStatus.Alive) return false;
            if (bond >= MaxBond) return false;
            if (float.IsNaN(now) || float.IsInfinity(now)) return false;
            return now >= nextAllowedAt;
        }

        public static int BondAfterGain(int bond)
        {
            if (bond < 0) bond = 0;
            int next = bond + BondPerAbilityUse;
            return next > MaxBond ? MaxBond : next;
        }

        public static float NextAllowedAt(float now) => now + MinSecondsBetweenGains;

        /// <summary>True only on the gain that first lifts bond to the Resonance requirement.</summary>
        public static bool CrossedResonanceThreshold(int before, int after)
        {
            int need = AnimalSpeciesTactics.BondResonanceMinimumBond;
            return before < need && after >= need;
        }

        public static string FormatResonanceReadyToast(string displayName)
        {
            string name = string.IsNullOrWhiteSpace(displayName) ? "Your companion" : displayName;
            return name + " trusts you enough for Bond Resonance";
        }
    }
}
