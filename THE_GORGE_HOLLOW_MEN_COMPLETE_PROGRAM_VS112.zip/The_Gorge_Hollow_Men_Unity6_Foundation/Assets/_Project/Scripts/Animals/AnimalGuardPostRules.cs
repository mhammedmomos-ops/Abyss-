namespace GorgeHollow
{
    /// <summary>
    /// Deterministic rules for Guard Post (VS76) — hold position with elevated awareness.
    /// </summary>
    public static class AnimalGuardPostRules
    {
        public static bool CanIssueGuard(AnimalStatus status, bool alreadyGuarding)
        {
            if (status != AnimalStatus.Alive) return false;
            if (alreadyGuarding) return false;
            return true;
        }

        public static float DetectionRadiusWhileGuarding(float baseRadius, bool isGuarding)
        {
            if (!isGuarding || baseRadius <= 0f) return baseRadius;
            return baseRadius * AnimalSpeciesTactics.GuardPostDetectionMultiplier;
        }

        /// <summary>VS78: guard detection including the Steady Post veteran ability.</summary>
        public static float DetectionRadiusWhileGuarding(float baseRadius, bool isGuarding,
            System.Collections.Generic.List<string> learnedAbilities)
        {
            float radius = DetectionRadiusWhileGuarding(baseRadius, isGuarding);
            if (!isGuarding || radius <= 0f) return radius;
            return radius * AnimalExperienceRules.GuardDetectionMultiplier(learnedAbilities);
        }

        public static bool ShouldReportThreat(
            bool isGuarding,
            bool hasConfirmedThreat,
            float threatConfidence,
            bool alreadyReportedThisGuard)
        {
            if (!isGuarding) return false;
            if (!hasConfirmedThreat) return false;
            if (alreadyReportedThisGuard) return false;
            if (threatConfidence < AnimalSpeciesTactics.GuardPostMinConfidenceForReport) return false;
            return true;
        }

        public static string FormatGuardToast(string displayName, AnimalSpecies species)
        {
            string name = string.IsNullOrWhiteSpace(displayName) ? species.ToString() : displayName;
            return name + " is on guard — threat spotted!";
        }

        public static string FormatStartToast(string displayName, AnimalSpecies species)
        {
            string name = string.IsNullOrWhiteSpace(displayName) ? species.ToString() : displayName;
            return name + " holding guard post";
        }
    }
}
