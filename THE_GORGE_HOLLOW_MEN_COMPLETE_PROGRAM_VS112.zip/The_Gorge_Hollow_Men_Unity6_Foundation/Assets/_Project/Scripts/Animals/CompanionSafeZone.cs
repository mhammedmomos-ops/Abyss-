using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Trigger-backed authority for companion rest; player presence is not caller-supplied.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider))]
    public sealed class CompanionSafeZone : MonoBehaviour
    {
        [SerializeField] private Transform playerRoot;
        private readonly HashSet<Collider> ownerColliders = new HashSet<Collider>();
        private Collider triggerCollider;

        public bool IsOwnerInside => playerRoot != null && ownerColliders.Count > 0;

        private void Awake()
        {
            triggerCollider = GetComponent<Collider>();
            if (triggerCollider != null) triggerCollider.isTrigger = true;
        }

        public void SetPlayerRoot(Transform root)
        {
            playerRoot = root;
            ownerColliders.Clear();
        }

        private void OnTriggerEnter(Collider other)
        {
            if (IsPlayerCollider(other)) ownerColliders.Add(other);
        }

        private void OnTriggerExit(Collider other)
        {
            if (other != null) ownerColliders.Remove(other);
        }

        private bool IsPlayerCollider(Collider other)
        {
            return other != null && playerRoot != null &&
                   (other.transform == playerRoot || other.transform.IsChildOf(playerRoot));
        }

        private void OnDisable() => ownerColliders.Clear();
    }
}
