namespace GorgeHollow
{
    /// <summary>Validates a player-selected pet and preserves the exact chosen display name.</summary>
    public static class AnimalSelectionRules
    {
        public const int MaximumDisplayNameLength = 24;

        public static bool TryCreate(string identity, string displayName, AnimalSpecies species, out AnimalRecord record, out string error)
        {
            record = null;
            error = null;
            if (string.IsNullOrWhiteSpace(identity)) { error = "A stable pet identity is required."; return false; }
            if (!AnimalBehaviourFactory.IsSupported(species)) { error = "The selected pet species is not in the approved roster."; return false; }
            string cleanName = (displayName ?? string.Empty).Trim();
            if (cleanName.Length == 0) { error = "Enter a name for the selected pet."; return false; }
            if (cleanName.Length > MaximumDisplayNameLength) { error = "Pet names cannot exceed 24 characters."; return false; }
            for (int i = 0; i < cleanName.Length; i++)
            {
                char c = cleanName[i];
                if (char.IsControl(c)) { error = "Pet names cannot contain control characters."; return false; }
            }
            record = new AnimalRecord
            {
                identity = identity.Trim(), displayName = cleanName, species = species,
                lifeStage = AnimalLifeStage.Adult, status = AnimalStatus.Alive,
                fictionalAgeDays = 365, experience = 0, health = 100, stamina = 100,
                bond = 0, learnedAbilities = new System.Collections.Generic.List<string>()
            };
            return true;
        }


        public static bool TrySelectOrCreate(System.Collections.Generic.List<AnimalRecord> roster, string displayName,
            AnimalSpecies species, out AnimalRecord selected, out string error)
        {
            selected = null;
            if (roster == null) { error = "The campaign pet roster is unavailable."; return false; }
            string cleanName = (displayName ?? string.Empty).Trim();
            if (cleanName.Length == 0 || cleanName.Length > MaximumDisplayNameLength)
            { error = cleanName.Length == 0 ? "Enter a name for the selected pet." : "Pet names cannot exceed 24 characters."; return false; }
            for (int i = 0; i < cleanName.Length; i++)
                if (char.IsControl(cleanName[i])) { error = "Pet names cannot contain control characters."; return false; }
            if (!AnimalBehaviourFactory.IsSupported(species)) { error = "The selected pet species is not in the approved roster."; return false; }
            for (int i = 0; i < roster.Count; i++)
            {
                AnimalRecord existing = roster[i];
                if (existing == null || existing.species != species) continue;
                if (existing.status != AnimalStatus.Alive || existing.health <= 0)
                { error = existing.status == AnimalStatus.Dead ? "This pet has permanently died in this campaign and cannot be selected again." : "This pet is missing. Find its recovery location and recover it before selecting it again."; return false; }
                existing.displayName = cleanName;
                selected = existing;
                error = null;
                return true;
            }
            if (!TryCreate(System.Guid.NewGuid().ToString("N"), cleanName, species, out selected, out error)) return false;
            roster.Add(selected);
            return true;
        }

        public static string GetDisplayName(AnimalRecord record)
        {
            if (record == null) return "No companion";
            if (!string.IsNullOrWhiteSpace(record.displayName)) return record.displayName.Trim();
            return record.species.ToString();
        }
    }
}
