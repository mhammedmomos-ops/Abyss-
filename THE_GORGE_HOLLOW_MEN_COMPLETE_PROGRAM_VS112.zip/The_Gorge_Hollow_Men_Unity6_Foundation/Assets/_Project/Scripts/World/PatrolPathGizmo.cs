using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Editor/debug polyline for monster patrol points (runtime optional draw).
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class PatrolPathGizmo : MonoBehaviour
    {
        [SerializeField] private Transform[] waypoints;
        [SerializeField] private Color color = Color.yellow;
        [SerializeField] private bool drawRuntime;

        private void OnDrawGizmos()
        {
            if (waypoints == null || waypoints.Length < 2) return;
            Gizmos.color = color;
            for (int i = 0; i < waypoints.Length - 1; i++)
            {
                if (waypoints[i] == null || waypoints[i + 1] == null) continue;
                Gizmos.DrawLine(waypoints[i].position, waypoints[i + 1].position);
            }
        }

        private void Update()
        {
            if (!drawRuntime || waypoints == null) return;
            for (int i = 0; i < waypoints.Length - 1; i++)
            {
                if (waypoints[i] == null || waypoints[i + 1] == null) continue;
                Debug.DrawLine(waypoints[i].position, waypoints[i + 1].position, color);
            }
        }
    }
}
