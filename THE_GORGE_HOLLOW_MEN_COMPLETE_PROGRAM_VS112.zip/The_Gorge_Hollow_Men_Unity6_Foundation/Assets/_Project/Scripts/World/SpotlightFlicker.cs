using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Flickers a light for damaged base power / horror mood.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SpotlightFlicker : MonoBehaviour
    {
        [SerializeField] private MonsterLocalAwareness localAwareness;
        [SerializeField] private Light targetLight;
        [SerializeField] private float minIntensity = 0.2f;
        [SerializeField] private float maxIntensity = 1.4f;
        [SerializeField] private float speed = 12f;
        [SerializeField] private bool onlyDuringThreat = true;
        private bool threat;

        private void Awake()
        {
            if (targetLight == null) targetLight = GetComponent<Light>();
            if (localAwareness == null) localAwareness = FindFirstObjectByType<MonsterLocalAwareness>();
        }

        private void OnEnable()
        {
            if (localAwareness != null) localAwareness.AwarenessChanged += OnLocalAwarenessChanged;
            threat = localAwareness != null && localAwareness.HasLocalContact;
        }

        private void OnDisable()
        {
            if (localAwareness != null) localAwareness.AwarenessChanged -= OnLocalAwarenessChanged;
        }

        private void OnLocalAwarenessChanged(int visibleHostiles, bool heardMovement)
        {
            threat = visibleHostiles > 0 || heardMovement;
        }

        private void Update()
        {
            if (targetLight == null) return;
            if (onlyDuringThreat && !threat)
            {
                targetLight.intensity = maxIntensity;
                return;
            }
            float n = Mathf.PerlinNoise(Time.time * speed, 0.3f);
            targetLight.intensity = Mathf.Lerp(minIntensity, maxIntensity, n);
        }
    }
}
