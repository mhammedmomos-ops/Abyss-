using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Raises ambient wind volume during threat phases and high bridges.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class WindAudioModulator : MonoBehaviour
    {
        [SerializeField] private MonsterLocalAwareness localAwareness;
        [SerializeField] private AudioSource windSource;
        [SerializeField] private float calmVolume = 0.15f;
        [SerializeField] private float threatVolume = 0.4f;
        [SerializeField] private float blendSeconds = 2f;
        private float blend;
        private bool threat;

        private void Awake()
        {
            if (localAwareness == null) localAwareness = FindFirstObjectByType<MonsterLocalAwareness>();
        }

        private void OnEnable()
        {
            if (localAwareness != null) localAwareness.AwarenessChanged += OnLocalAwarenessChanged;
            threat = localAwareness != null && localAwareness.HasLocalContact;
        }

        private void OnDisable()
        {
            if (localAwareness != null) localAwareness.AwarenessChanged -= OnLocalAwarenessChanged;
        }

        private void OnLocalAwarenessChanged(int visibleHostiles, bool heardMovement)
        {
            threat = visibleHostiles > 0 || heardMovement;
        }

        private void Update()
        {
            if (windSource == null) return;
            if (!windSource.isPlaying) windSource.Play();
            float target = threat ? 1f : 0f;
            float speed = blendSeconds > 0.05f ? 1f / blendSeconds : 10f;
            blend = Mathf.MoveTowards(blend, target, Time.deltaTime * speed);
            windSource.volume = Mathf.Lerp(calmVolume, threatVolume, blend);
        }
    }
}
