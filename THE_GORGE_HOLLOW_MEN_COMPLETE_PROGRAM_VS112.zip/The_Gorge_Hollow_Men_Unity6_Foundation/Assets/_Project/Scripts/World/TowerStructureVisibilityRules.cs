namespace GorgeHollow
{
    /// <summary>Pure presentation policy: only the physically occupied tower's detailed structures render.</summary>
    public static class TowerStructureVisibilityRules
    {
        public static bool ShouldRenderTower(string towerId, string localTowerId)
        {
            if (string.IsNullOrWhiteSpace(towerId) || string.IsNullOrWhiteSpace(localTowerId)) return false;
            if (towerId != "tower_a" && towerId != "tower_b") return false;
            return towerId == localTowerId;
        }
    }
}
