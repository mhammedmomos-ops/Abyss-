using UnityEngine;
using UnityEngine.Events;

namespace GorgeHollow
{
    /// <summary>
    /// Fires events when the player enters/exits a pressure plate volume.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider))]
    public sealed class PressurePlateTrigger : MonoBehaviour
    {
        [SerializeField] private UnityEvent onPressed;
        [SerializeField] private UnityEvent onReleased;
        [SerializeField] private bool once;
        [SerializeField] private string playerTag = "Player";
        private bool pressed;
        private bool done;

        private void Reset()
        {
            var col = GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (done || !IsPlayer(other) || pressed) return;
            pressed = true;
            onPressed?.Invoke();
            SimpleAudioCuePlayer.PlayCue(AudioCueId.UIClick);
            MobileHaptics.PlayImpact(MobileHapticStrength.Light);
            if (once) done = true;
        }

        private void OnTriggerExit(Collider other)
        {
            if (!IsPlayer(other) || !pressed) return;
            pressed = false;
            if (!once) onReleased?.Invoke();
        }

        private bool IsPlayer(Collider other)
        {
            if (other == null) return false;
            if (!string.IsNullOrEmpty(playerTag) && other.CompareTag(playerTag)) return true;
            return other.GetComponentInParent<PlayerVitals>() != null;
        }
    }
}
