using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Cover prop that hides/disables when its DamageableHealth is destroyed.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class BreakableCover : MonoBehaviour
    {
        [SerializeField] private DamageableHealth health;
        [SerializeField] private GameObject intactRoot;
        [SerializeField] private GameObject destroyedRoot;
        [SerializeField] private float trauma = 0.2f;

        private void Awake()
        {
            if (health == null) health = GetComponent<DamageableHealth>();
            if (intactRoot == null) intactRoot = gameObject;
            if (destroyedRoot != null) destroyedRoot.SetActive(false);
        }

        private void OnEnable()
        {
            if (health != null) health.Killed += OnKilled;
        }

        private void OnDisable()
        {
            if (health != null) health.Killed -= OnKilled;
        }

        private void OnKilled(GameObject source)
        {
            if (intactRoot != null) intactRoot.SetActive(false);
            if (destroyedRoot != null) destroyedRoot.SetActive(true);
            CameraShake.Shake(trauma);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.BridgeCollapse);
        }
    }
}
