using System;
using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Visible, damageable convoy that follows authored route waypoints and persists its cargo, health and progress.</summary>
    [DisallowMultipleComponent]
    public sealed class SupplyConvoyController : MonoBehaviour, IDamageable
    {
        private static readonly List<SupplyConvoyController> active = new List<SupplyConvoyController>(8);
        public static IReadOnlyList<SupplyConvoyController> ActiveConvoys => active;

        [Header("Campaign identity and destination")]
        [SerializeField] private string convoyIdentity = "supply_convoy_01";
        [SerializeField] private string destinationTowerId = "tower_a";
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private MonsterLocalAwareness localAwareness;
        [Header("Inter-tower transfer bridge gate (required for transfer records)")]
        [SerializeField] private BridgeSpanController transferBridge;
        [SerializeField] private Rigidbody transferRigidbody;
        [SerializeField] private SupplyTransferEscortController transferEscort;
        [Header("Authored route")]
        [SerializeField] private Transform[] routeWaypoints;
        [SerializeField, Min(0.1f)] private float movementSpeed = 2.2f;
        [SerializeField, Min(0.25f)] private float saveInterval = 2f;
        [SerializeField, Min(1)] private int maximumHealth = 120;
        [Header("Cargo") ]
        [SerializeField, Min(0)] private int scrap = 12;
        [SerializeField, Min(0)] private int timber = 8;
        [SerializeField, Min(0)] private int mechanicalParts = 2;
        [SerializeField, Min(0)] private int electricalComponents;
        [SerializeField, Min(0)] private int ammunition = 12;
        [SerializeField, Min(0)] private int medicalSupplies = 2;
        [SerializeField, Min(0)] private int petFood;
        [SerializeField, Min(0)] private int reagent;
        [Header("Perception") ]
        [SerializeField, Min(0f)] private float damageStimulusLoudness = 9f;

        private int waypointIndex;
        private float nextSaveAt;
        private bool initialized;
        private bool terminal;
        private bool persistenceBlocked;
        private SupplyConvoyRecord Record => bootstrap != null && bootstrap.Campaign != null && bootstrap.Campaign.supplyConvoys != null
            ? bootstrap.Campaign.supplyConvoys.Find(x => x != null && x.identity == convoyIdentity) : null;

        public bool IsAttackable => initialized && !terminal && Record != null && Record.status == SupplyConvoyStatus.Travelling;
        public bool IsInterTowerTransfer => Record != null && Record.isInterTowerTransfer;
        public string ConvoyIdentity => convoyIdentity;
        public string DestinationTowerId => destinationTowerId;
        public SupplyConvoyCommand TacticalCommand => Record != null ? Record.tacticalCommand : SupplyConvoyCommand.Advance;
        public bool IsHeld => TacticalCommand == SupplyConvoyCommand.Hold;
        public bool TryIssueCommand(SupplyConvoyCommand command, out string error)
        {
            if (bootstrap == null) { error = "Campaign bootstrap is unavailable."; return false; }
            return bootstrap.TrySetSupplyConvoyCommand(convoyIdentity, command, out error);
        }
        public float HealthFraction => Record != null && Record.maximumHealth > 0 ? Mathf.Clamp01((float)Record.currentHealth / Record.maximumHealth) : 0f;
        public float SiegePriority => 1.25f;
        public int CurrentHealth => Record != null ? Record.currentHealth : 0;
        public event Action Destroyed;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            if (localAwareness == null) localAwareness = FindFirstObjectByType<MonsterLocalAwareness>();
        }

        private void OnEnable()
        {
            if (!active.Contains(this)) active.Add(this);
        }

        private void OnDisable() => active.Remove(this);

        private void Start()
        {
            if (bootstrap == null || bootstrap.Campaign == null || string.IsNullOrWhiteSpace(convoyIdentity) ||
                string.IsNullOrWhiteSpace(destinationTowerId) || routeWaypoints == null || routeWaypoints.Length == 0)
            { Debug.LogError("Supply convoy requires GameBootstrap, identity, destination and at least one route waypoint.", this); enabled = false; return; }

            SupplyConvoyRecord record = Record;
            if (record == null)
            {
                record = new SupplyConvoyRecord { identity = convoyIdentity, destinationTowerId = destinationTowerId,
                    status = SupplyConvoyStatus.Travelling, worldPosition = transform.position, routeWaypointIndex = 0,
                    currentHealth = Mathf.Max(1, maximumHealth), maximumHealth = Mathf.Max(1, maximumHealth),
                    scrap = Mathf.Max(0, scrap), timber = Mathf.Max(0, timber), mechanicalParts = Mathf.Max(0, mechanicalParts),
                    electricalComponents = Mathf.Max(0, electricalComponents), ammunition = Mathf.Max(0, ammunition),
                    medicalSupplies = Mathf.Max(0, medicalSupplies), petFood = Mathf.Max(0, petFood), reagent = Mathf.Max(0, reagent) };
                if (!bootstrap.TryRegisterSupplyConvoy(record, out string error))
                { Debug.LogError("Supply convoy could not be registered: " + error, this); enabled = false; return; }
            }
            if (record.status != SupplyConvoyStatus.Travelling) { terminal = true; gameObject.SetActive(false); return; }
            if (!string.Equals(record.destinationTowerId, destinationTowerId, StringComparison.Ordinal))
            { Debug.LogError("Authored convoy destination does not match its saved campaign record.", this); enabled = false; return; }
            if (record.isInterTowerTransfer && (transferBridge == null || record.bridgeCrossingEndWaypointIndex > routeWaypoints.Length ||
                record.bridgeCrossingStartWaypointIndex >= record.bridgeCrossingEndWaypointIndex))
            { Debug.LogError("Inter-tower transfer requires a live BridgeSpanController and authored crossing waypoint range.", this); enabled = false; return; }
            if (record.isInterTowerTransfer) transferBridge.SpanStateChanged += OnTransferBridgeStateChanged;
            waypointIndex = Mathf.Clamp(record.routeWaypointIndex, 0, routeWaypoints.Length);
            transform.position = record.worldPosition;
            initialized = true;
            if (record.isInterTowerTransfer && waypointIndex > record.bridgeCrossingStartWaypointIndex &&
                waypointIndex <= record.bridgeCrossingEndWaypointIndex && !transferBridge.IsTraversable)
            { FallAndLoseCargo(); return; }
            nextSaveAt = Time.time + Mathf.Max(0.25f, saveInterval);
        }

        private void OnDisable()
        {
            if (transferBridge != null) transferBridge.SpanStateChanged -= OnTransferBridgeStateChanged;
        }

        private void OnTransferBridgeStateChanged(BridgeSpanController bridge, BridgeSpanState previous, BridgeSpanState current)
        {
            SupplyConvoyRecord record = Record;
            if (record == null || !record.isInterTowerTransfer || terminal) return;
            if (bridge.IsTraversable)
            {
                if (persistenceBlocked && waypointIndex < record.bridgeCrossingEndWaypointIndex) persistenceBlocked = false;
                return;
            }
            if (waypointIndex > record.bridgeCrossingStartWaypointIndex && waypointIndex <= record.bridgeCrossingEndWaypointIndex)
                FallAndLoseCargo();
        }

        private void FallAndLoseCargo()
        {
            if (terminal) return;
            if (!bootstrap.TryDamageSupplyConvoy(convoyIdentity, int.MaxValue, out bool destroyed, out string error) || !destroyed)
            { persistenceBlocked = true; Debug.LogError("Bridge-collapse cargo-loss transaction failed; carrier movement halted: " + error, this); return; }
            terminal = true;
            if (transferRigidbody == null) transferRigidbody = GetComponent<Rigidbody>();
            if (transferRigidbody == null) transferRigidbody = gameObject.AddComponent<Rigidbody>();
            transferRigidbody.isKinematic = false;
            transferRigidbody.useGravity = true;
            transferRigidbody.velocity = Vector3.down * 2f;
            transferRigidbody.constraints = RigidbodyConstraints.None;
            Destroyed?.Invoke();
            if (CanPlayerObserveConvoy())
                GenericToastUI.Show("Bridge collapsed. Transfer carrier and cargo lost in the gorge.", 4f);
        }

        private void Update()
        {
            if (!initialized || terminal || persistenceBlocked) return;
            SupplyConvoyRecord record = Record;
            if (record == null || record.status != SupplyConvoyStatus.Travelling) { terminal = true; return; }
            if (record.tacticalCommand == SupplyConvoyCommand.Hold) return;
            if (waypointIndex >= routeWaypoints.Length) { TryCompleteDelivery(); return; }
            if (record.isInterTowerTransfer && waypointIndex >= record.bridgeCrossingStartWaypointIndex &&
                waypointIndex < record.bridgeCrossingEndWaypointIndex && !InterTowerSupplyTransferRules.CanEnterBridge(record, transferBridge))
            { persistenceBlocked = true; Debug.LogWarning("Transfer paused: bridge is not traversable. No bridge entry is permitted.", this); return; }
            Transform target = routeWaypoints[waypointIndex];
            if (target == null) { persistenceBlocked = true; Debug.LogError("Supply convoy route contains a missing waypoint; convoy paused safely.", this); return; }

            float commandSpeed = SupplyConvoyCommandRules.MovementMultiplier(record.tacticalCommand);
            transform.position = Vector3.MoveTowards(transform.position, target.position, Mathf.Max(0.1f, movementSpeed) * commandSpeed * Time.deltaTime);
            if (Vector3.SqrMagnitude(transform.position - target.position) <= 0.04f)
            {
                waypointIndex++;
                if (!PersistProgress()) return;
                if (waypointIndex >= routeWaypoints.Length) TryCompleteDelivery();
                return;
            }
            if (Time.time >= nextSaveAt) PersistProgress();
        }

        private bool PersistProgress()
        {
            if (!bootstrap.TryUpdateSupplyConvoyProgress(convoyIdentity, transform.position, waypointIndex, out string error))
            {
                SupplyConvoyRecord saved = Record;
                if (saved != null) transform.position = saved.worldPosition;
                persistenceBlocked = true;
                Debug.LogError("Convoy paused because route progress could not be saved: " + error, this);
                return false;
            }
            nextSaveAt = Time.time + Mathf.Max(0.25f, saveInterval);
            return true;
        }

        private void TryCompleteDelivery()
        {
            if (terminal) return;
            if (!bootstrap.TryDeliverSupplyConvoy(convoyIdentity, out string error))
            { persistenceBlocked = true; Debug.LogError("Convoy reached its destination but delivery could not be committed: " + error, this); return; }
            terminal = true;
            if (CanPlayerObserveConvoy())
            {
                GenericToastUI.Show("Supply convoy delivered.", 3f);
                SimpleAudioCuePlayer.PlayCue(AudioCueId.Scavenge);
            }
            gameObject.SetActive(false);
        }

        private bool CanPlayerObserveConvoy()
        {
            return localAwareness != null && localAwareness.CanObserveWorldObject(transform);
        }

        public void ApplyDamage(float amount, Vector3 hitPoint, Vector3 hitDirection, GameObject source)
        {
            if (!IsAttackable || amount <= 0f || float.IsNaN(amount) || float.IsInfinity(amount)) return;
            MonsterStimulusBus.Emit(MonsterStimulusKind.ConvoyUnderAttack, hitPoint, damageStimulusLoudness, gameObject);
            float mitigatedDamage = IsInterTowerTransfer && transferEscort != null ? amount * transferEscort.IncomingDamageMultiplier : amount;
            if (!bootstrap.TryDamageSupplyConvoy(convoyIdentity, mitigatedDamage, out bool destroyed, out string error))
            { Debug.LogWarning("Convoy damage was not committed: " + error, this); return; }
            if (destroyed)
            {
                terminal = true;
                Destroyed?.Invoke();
                if (CanPlayerObserveConvoy())
                {
                    GenericToastUI.Show("Supply convoy destroyed. Its cargo is lost.", 3f);
                    SimpleAudioCuePlayer.PlayCue(AudioCueId.RaidAlarm);
                }
            }
        }
    }
}
