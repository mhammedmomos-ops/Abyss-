using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Adjusts RenderSettings.fog density by shared fictional time of day.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class FogDensityController : MonoBehaviour
    {
        [SerializeField] private float calmDensity = 0.008f;
        [SerializeField] private float raidDensity = 0.035f;
        [SerializeField] private float blendSeconds = 3f;
        [SerializeField] private GameBootstrap bootstrap;
        private float blend;
        private bool night;
        private float nextClockRefresh;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        private void Update()
        {
            if (Time.unscaledTime >= nextClockRefresh)
            {
                nextClockRefresh = Time.unscaledTime + 1f;
                if (bootstrap != null && bootstrap.Campaign != null)
                    night = bootstrap.Campaign.fictionalHour >= 19 || bootstrap.Campaign.fictionalHour < 6;
            }
            float target = night ? 1f : 0f;
            float speed = blendSeconds > 0.05f ? 1f / blendSeconds : 10f;
            blend = Mathf.MoveTowards(blend, target, Time.deltaTime * speed);
            RenderSettings.fog = true;
            RenderSettings.fogDensity = Mathf.Lerp(calmDensity, raidDensity, blend);
        }
    }
}
