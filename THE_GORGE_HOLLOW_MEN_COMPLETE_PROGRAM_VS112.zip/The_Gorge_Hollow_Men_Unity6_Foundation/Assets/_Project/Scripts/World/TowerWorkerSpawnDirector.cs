using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>
    /// Optional scene component that materializes campaign workforce records as visible actors.
    /// Assign both tower roots. A worker prefab is optional; a simple capsule placeholder is used otherwise.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class TowerWorkerSpawnDirector : MonoBehaviour
    {
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private TowerLocalAccessTracker localAccess;
        [SerializeField] private TowerWorkerActor workerPrefab;
        [SerializeField] private Transform towerARoot;
        [SerializeField] private Transform towerBRoot;
        [Header("Tower A work destinations — keep all points inside Tower A")]
        [SerializeField] private Transform towerAProduction;
        [SerializeField] private Transform towerASalvage;
        [SerializeField] private Transform towerAGuard;
        [SerializeField] private Transform towerARest;
        [Header("Tower B work destinations — keep all points inside Tower B")]
        [SerializeField] private Transform towerBProduction;
        [SerializeField] private Transform towerBSalvage;
        [SerializeField] private Transform towerBGuard;
        [SerializeField] private Transform towerBRest;
        [SerializeField, Min(0.25f)] private float spawnSpacing = 1.1f;
        [SerializeField] private Vector3 localSpawnOrigin = new Vector3(0f, 1f, -1.5f);
        private readonly Dictionary<string, TowerWorkerActor> spawned = new Dictionary<string, TowerWorkerActor>();
        [SerializeField, Min(0.1f)] private float visibilityRefreshSeconds = 0.35f;
        private float nextVisibilityRefresh;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            if (localAccess == null) localAccess = FindFirstObjectByType<TowerLocalAccessTracker>();
        }

        private void OnEnable()
        {
            CampaignEvents.CampaignReplaced += HandleCampaignReplaced;
        }

        private void Start()
        {
            Synchronize(bootstrap != null ? bootstrap.Campaign : null);
        }

        private void OnDisable()
        {
            CampaignEvents.CampaignReplaced -= HandleCampaignReplaced;
        }

        private void HandleCampaignReplaced(CampaignState campaign) => Synchronize(campaign);

        private void Update()
        {
            if (Time.unscaledTime < nextVisibilityRefresh) return;
            nextVisibilityRefresh = Time.unscaledTime + Mathf.Max(0.1f, visibilityRefreshSeconds);
            string localTower = localAccess != null ? localAccess.CurrentTowerId : null;
            foreach (KeyValuePair<string, TowerWorkerActor> pair in spawned)
            {
                TowerWorkerRecord record = TowerWorkerRules.Find(bootstrap != null ? bootstrap.Campaign : null, pair.Key);
                if (pair.Value != null) pair.Value.SetLocalVisibility(record != null && record.towerId == localTower);
            }
        }

        public void Synchronize(CampaignState campaign)
        {
            if (campaign == null || campaign.towerWorkers == null) return;
            var liveIds = new HashSet<string>();
            for (int i = 0; i < campaign.towerWorkers.Count; i++)
            {
                TowerWorkerRecord worker = campaign.towerWorkers[i];
                if (worker == null || string.IsNullOrWhiteSpace(worker.identity)) continue;
                liveIds.Add(worker.identity);
                if (spawned.TryGetValue(worker.identity, out TowerWorkerActor existing) && existing != null)
                {
                    if (!existing.gameObject.activeSelf) existing.gameObject.SetActive(true);
                    ConfigureActor(existing, worker.towerId);
                    // The actor hides its presentation for dead/captured states without disabling its update loop.
                    continue;
                }
                if (worker.status == TowerWorkerStatus.Dead || worker.status == TowerWorkerStatus.Captured)
                    continue;
                TowerWorkerActor preAuthoredActor = FindExistingActor(worker.identity);
                if (preAuthoredActor != null)
                {
                    spawned[worker.identity] = preAuthoredActor;
                    ConfigureActor(preAuthoredActor, worker.towerId);
                    continue;
                }
                Transform towerRoot = ResolveTowerRoot(worker.towerId);
                if (towerRoot == null)
                {
                    Debug.LogWarning("Cannot spawn worker '" + worker.identity + "': assign the matching tower root on TowerWorkerSpawnDirector.", this);
                    continue;
                }
                Vector3 position = CalculateSpawnPosition(campaign, towerRoot, worker.towerId, i);
                TowerWorkerActor actor = CreateActor(position, towerRoot, worker);
                if (actor == null) continue;
                actor.Bind(worker.identity);
                ConfigureActor(actor, worker.towerId);
                spawned[worker.identity] = actor;
            }

            // Remove stale actor references after campaign replacement without touching saved records.
            var stale = new List<string>();
            foreach (KeyValuePair<string, TowerWorkerActor> pair in spawned)
                if (!liveIds.Contains(pair.Key) || pair.Value == null) stale.Add(pair.Key);
            for (int i = 0; i < stale.Count; i++)
            {
                if (spawned[stale[i]] != null) Destroy(spawned[stale[i]].gameObject);
                spawned.Remove(stale[i]);
            }
        }

        private static TowerWorkerActor FindExistingActor(string identity)
        {
            TowerWorkerActor[] actors = FindObjectsByType<TowerWorkerActor>(FindObjectsSortMode.None);
            for (int i = 0; i < actors.Length; i++)
                if (actors[i] != null && actors[i].WorkerIdentity == identity) return actors[i];
            return null;
        }

        private void ConfigureActor(TowerWorkerActor actor, string towerId)
        {
            if (actor == null) return;
            if (towerId == "tower_a")
                actor.ConfigureWorkTargets(towerAProduction, towerASalvage, towerAGuard, towerARest);
            else if (towerId == "tower_b")
                actor.ConfigureWorkTargets(towerBProduction, towerBSalvage, towerBGuard, towerBRest);
        }

        private Transform ResolveTowerRoot(string towerId)
        {
            if (towerId == "tower_a") return towerARoot;
            if (towerId == "tower_b") return towerBRoot;
            return null;
        }

        private Vector3 CalculateSpawnPosition(CampaignState campaign, Transform root, string towerId, int campaignIndex)
        {
            int withinTower = 0;
            if (campaign != null && campaign.towerWorkers != null)
            {
                for (int i = 0; i < campaignIndex; i++)
                {
                    TowerWorkerRecord prior = campaign.towerWorkers[i];
                    if (prior != null && prior.towerId == towerId && prior.status != TowerWorkerStatus.Dead && prior.status != TowerWorkerStatus.Captured)
                        withinTower++;
                }
            }
            float side = withinTower % 2 == 0 ? -1f : 1f;
            float row = withinTower / 2;
            Vector3 local = localSpawnOrigin + new Vector3(side * spawnSpacing * (0.5f + row * 0.35f), 0f, row * spawnSpacing);
            return root.TransformPoint(local);
        }

        private TowerWorkerActor CreateActor(Vector3 position, Transform parent, TowerWorkerRecord worker)
        {
            if (workerPrefab != null)
            {
                TowerWorkerActor instance = Instantiate(workerPrefab, position, parent.rotation, parent);
                instance.gameObject.name = "Worker_" + worker.displayName;
                if (instance.GetComponent<NavMeshAgent>() == null)
                {
                    NavMeshAgent addedAgent = instance.gameObject.AddComponent<NavMeshAgent>();
                    addedAgent.radius = 0.28f;
                    addedAgent.height = 1.8f;
                    addedAgent.speed = 2.4f;
                    addedAgent.acceleration = 8f;
                    addedAgent.angularSpeed = 360f;
                    addedAgent.stoppingDistance = 0.45f;
                    addedAgent.autoBraking = true;
                    addedAgent.autoTraverseOffMeshLink = false;
                }
                return instance;
            }

            GameObject placeholder = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            placeholder.name = "Worker_" + worker.displayName + "_Greybox";
            placeholder.transform.SetParent(parent, true);
            placeholder.transform.position = position;
            placeholder.transform.localScale = new Vector3(0.55f, 0.9f, 0.55f);
            NavMeshAgent agent = placeholder.AddComponent<NavMeshAgent>();
            agent.radius = 0.28f;
            agent.height = 1.8f;
            agent.speed = 2.4f;
            agent.acceleration = 8f;
            agent.angularSpeed = 360f;
            agent.stoppingDistance = 0.45f;
            agent.autoBraking = true;
            Renderer renderer = placeholder.GetComponent<Renderer>();
            if (renderer != null)
            {
                var properties = new MaterialPropertyBlock();
                renderer.GetPropertyBlock(properties);
                Color roleColor = worker.role == TowerWorkerRole.Mechanic ? new Color(0.25f, 0.55f, 0.9f) :
                    worker.role == TowerWorkerRole.Guard ? new Color(0.78f, 0.28f, 0.2f) :
                    worker.role == TowerWorkerRole.Medic ? new Color(0.25f, 0.72f, 0.45f) :
                    new Color(0.78f, 0.65f, 0.25f);
                properties.SetColor("_Color", roleColor);
                properties.SetColor("_BaseColor", roleColor);
                renderer.SetPropertyBlock(properties);
            }
            return placeholder.AddComponent<TowerWorkerActor>();
        }
    }
}
