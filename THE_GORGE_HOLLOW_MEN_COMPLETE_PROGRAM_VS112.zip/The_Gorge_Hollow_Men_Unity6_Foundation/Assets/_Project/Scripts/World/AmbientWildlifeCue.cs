using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Occasionally plays ambient one-shots during calm phases.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AmbientWildlifeCue : MonoBehaviour
    {
        [SerializeField] private MonsterLocalAwareness localAwareness;
        [SerializeField] private AudioSource source;
        [SerializeField] private AudioClip[] clips;
        [SerializeField] private Vector2 intervalRange = new Vector2(12f, 28f);
        [SerializeField] private bool onlyDuringCalm = true;
        private float nextAt;
        private bool calm = true;

        private void Awake()
        {
            if (localAwareness == null) localAwareness = FindFirstObjectByType<MonsterLocalAwareness>();
        }

        private void OnEnable() => Schedule();

        private void Update()
        {
            calm = localAwareness == null || !localAwareness.HasLocalContact;
            if (onlyDuringCalm && !calm) return;
            if (clips == null || clips.Length == 0 || source == null) return;
            if (Time.time < nextAt) return;
            var clip = clips[Random.Range(0, clips.Length)];
            if (clip != null) source.PlayOneShot(clip, 0.5f);
            Schedule();
        }

        private void Schedule()
        {
            nextAt = Time.time + Random.Range(intervalRange.x, intervalRange.y);
        }
    }
}
