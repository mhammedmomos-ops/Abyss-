using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Destructible barrel that damages nearby DamageableHealth / PlayerVitals on death.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ExplodingBarrelHazard : MonoBehaviour
    {
        [SerializeField] private DamageableHealth health;
        [SerializeField] private float radius = 4f;
        [SerializeField] private float damage = 40f;
        [SerializeField] private float injury = 10f;
        [SerializeField] private float trauma = 0.55f;
        [SerializeField] private GameObject explosionVfx;
        private bool exploded;

        private void Awake()
        {
            if (health == null) health = GetComponent<DamageableHealth>();
        }

        private void OnEnable()
        {
            if (health != null) health.Killed += OnKilled;
        }

        private void OnDisable()
        {
            if (health != null) health.Killed -= OnKilled;
        }

        private void OnKilled(GameObject source)
        {
            if (exploded) return;
            exploded = true;
            if (explosionVfx != null) Instantiate(explosionVfx, transform.position, Quaternion.identity);
            CameraShake.Shake(trauma);
            MobileHaptics.PlayImpact(MobileHapticStrength.Heavy);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.BridgeCollapse);
            Collider[] hits = Physics.OverlapSphere(transform.position, radius);
            for (int i = 0; i < hits.Length; i++)
            {
                if (hits[i] == null) continue;
                var vitals = hits[i].GetComponentInParent<PlayerVitals>();
                if (vitals != null && !vitals.IsDead)
                {
                    vitals.ApplyDamage(damage, injury);
                    DamageDirectionIndicator.HitFrom(transform.position);
                    continue;
                }
                var dmg = hits[i].GetComponentInParent<DamageableHealth>();
                if (dmg != null && dmg != health && !dmg.IsDead)
                    dmg.ApplyDamage(damage, hits[i].ClosestPoint(transform.position), Vector3.up, gameObject);
            }
            gameObject.SetActive(false);
        }
    }
}
