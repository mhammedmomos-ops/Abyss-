using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Teleports the player to an authored destination (base fast-travel pad).
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class TeleportPadInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private Transform destination;
        [SerializeField] private string prompt = "Travel";
        [SerializeField] private float cooldownSeconds = 2f;
        [SerializeField] private bool fade = true;
        private float nextAllowed;

        public string InteractionPrompt => prompt;

        public bool CanInteract(GameObject interactor)
        {
            return destination != null && Time.time >= nextAllowed &&
                   interactor != null && interactor.GetComponentInParent<PlayerVitals>() != null;
        }

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            nextAllowed = Time.time + cooldownSeconds;
            var vitals = interactor.GetComponentInParent<PlayerVitals>();
            var cc = interactor.GetComponentInParent<CharacterController>();
            var movement = interactor.GetComponentInParent<PlayerMovement>();

            System.Action doTeleport = () =>
            {
                if (cc != null) cc.enabled = false;
                vitals.transform.position = destination.position;
                vitals.transform.rotation = destination.rotation;
                if (cc != null) cc.enabled = true;
                if (movement != null) movement.ResetAfterTeleport();
                SimpleAudioCuePlayer.PlayCue(AudioCueId.UIClick);
                MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
            };

            if (fade) SceneFadeOverlay.Fade(0.5f, doTeleport);
            else doTeleport();
        }
    }
}
