using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Damage adapter for worker actors. Can be included in a monster's authored siege-target list.</summary>
    [DisallowMultipleComponent]
    public sealed class TowerWorkerDamageable : MonoBehaviour, IDamageable
    {
        [SerializeField] private TowerWorkforceController workforce;
        [SerializeField] private string workerIdentity;
        public string WorkerIdentity => workerIdentity;

        private void Awake()
        {
            if (workforce == null) workforce = FindFirstObjectByType<TowerWorkforceController>();
        }

        public void Bind(string identity) => workerIdentity = identity;

        public void ApplyDamage(float amount, Vector3 hitPoint, Vector3 hitDirection, GameObject source)
        {
            if (amount <= 0f || float.IsNaN(amount) || float.IsInfinity(amount) || string.IsNullOrWhiteSpace(workerIdentity)) return;
            if (workforce == null) workforce = FindFirstObjectByType<TowerWorkforceController>();
            if (workforce == null) return;
            int damage = amount >= int.MaxValue ? int.MaxValue : Mathf.Max(1, Mathf.CeilToInt(amount));
            if (!workforce.ApplyDamage(workerIdentity, damage, out string error))
                Debug.LogWarning("Worker damage was not committed: " + error, this);
        }
    }
}
