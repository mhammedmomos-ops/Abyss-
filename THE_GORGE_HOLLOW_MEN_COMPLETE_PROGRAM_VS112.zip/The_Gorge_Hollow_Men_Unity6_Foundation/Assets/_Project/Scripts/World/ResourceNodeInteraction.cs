using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Multi-hit resource node (scrap pile / timber cache) before depletion.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ResourceNodeInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string prompt = "Gather";
        [SerializeField] private int hitsRemaining = 3;
        [SerializeField] private int scrapPerHit = 2;
        [SerializeField] private int timberPerHit = 1;
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private GameObject depleteRoot;

        public string InteractionPrompt => prompt + " (" + hitsRemaining + ")";

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        public bool CanInteract(GameObject interactor) => hitsRemaining > 0 && isActiveAndEnabled;

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            hitsRemaining--;
            if (bootstrap != null && bootstrap.Campaign != null)
            {
                var delta = new ResourceDelta { scrap = scrapPerHit, timber = timberPerHit };
                string tx = "node:" + gameObject.name + ":" + hitsRemaining + ":" + System.Guid.NewGuid().ToString("N");
                if (bootstrap.Transactions != null)
                {
                    if (bootstrap.Transactions.TryApply(bootstrap.Campaign, tx, delta, out string error))
                    {
                        bootstrap.SaveCampaign();
                        CampaignEvents.RaiseTransactionCommitted(tx);
                    }
                    else Debug.Log("Node gather failed: " + error, this);
                }
                else
                {
                    bootstrap.Campaign.scrap += scrapPerHit;
                    bootstrap.Campaign.timber += timberPerHit;
                    bootstrap.SaveCampaign();
                }
            }
            CampaignEvents.RaiseScavengeCompleted(gameObject.name);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.Scavenge);
            MobileHaptics.PlayImpact(MobileHapticStrength.Light);
            GenericToastUI.Show("+" + scrapPerHit + " scrap", 1f);
            if (hitsRemaining <= 0)
            {
                var root = depleteRoot != null ? depleteRoot : gameObject;
                root.SetActive(false);
            }
        }
    }
}
