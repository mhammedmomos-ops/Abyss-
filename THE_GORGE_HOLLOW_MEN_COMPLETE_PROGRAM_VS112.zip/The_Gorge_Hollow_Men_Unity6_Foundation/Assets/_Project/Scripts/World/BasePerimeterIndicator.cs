using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Optional ring/mesh that fades based on player distance to a base anchor.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class BasePerimeterIndicator : MonoBehaviour
    {
        [SerializeField] private Transform player;
        [SerializeField] private float safeRadius = 25f;
        [SerializeField] private float fadeStart = 18f;
        [SerializeField] private Renderer ringRenderer;
        [SerializeField] private string colorProperty = "_BaseColor";

        private MaterialPropertyBlock block;
        private static readonly int ColorId = Shader.PropertyToID("_BaseColor");

        private void Awake()
        {
            if (player == null)
            {
                var vitals = FindFirstObjectByType<PlayerVitals>();
                if (vitals != null) player = vitals.transform;
            }
            block = new MaterialPropertyBlock();
        }

        private void LateUpdate()
        {
            if (player == null || ringRenderer == null) return;
            float dist = Vector3.Distance(player.position, transform.position);
            float alpha;
            if (dist <= fadeStart) alpha = 0.15f;
            else if (dist >= safeRadius) alpha = 0.7f;
            else alpha = Mathf.Lerp(0.15f, 0.7f, (dist - fadeStart) / Mathf.Max(0.01f, safeRadius - fadeStart));

            ringRenderer.GetPropertyBlock(block);
            Color c = block.GetColor(ColorId);
            if (c.a <= 0f && c.r <= 0f) c = Color.cyan;
            c.a = alpha;
            block.SetColor(ColorId, c);
            // Also try common URP property name variants
            block.SetColor(colorProperty, c);
            ringRenderer.SetPropertyBlock(block);
        }
    }
}
