using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Simple oscillating or toggle elevator platform for multi-level bases.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ElevatorPlatform : MonoBehaviour
    {
        [SerializeField] private Vector3 localPointA;
        [SerializeField] private Vector3 localPointB = new Vector3(0f, 3f, 0f);
        [SerializeField] private float speed = 1.5f;
        [SerializeField] private bool autoOscillate = true;
        [SerializeField] private bool startAtA = true;
        private float t;
        private int dir = 1;
        private Vector3 worldA;
        private Vector3 worldB;

        private void Awake()
        {
            worldA = transform.TransformPoint(localPointA);
            worldB = transform.TransformPoint(localPointB);
            t = startAtA ? 0f : 1f;
        }

        public void GoToA() { dir = -1; autoOscillate = false; }
        public void GoToB() { dir = 1; autoOscillate = false; }
        public void Toggle() { dir = -dir; }

        private void Update()
        {
            t += dir * (speed * Time.deltaTime) / Mathf.Max(0.01f, Vector3.Distance(worldA, worldB));
            if (autoOscillate)
            {
                if (t >= 1f) { t = 1f; dir = -1; }
                if (t <= 0f) { t = 0f; dir = 1; }
            }
            else
            {
                t = Mathf.Clamp01(t);
            }
            transform.position = Vector3.Lerp(worldA, worldB, Mathf.SmoothStep(0f, 1f, t));
        }
    }
}
