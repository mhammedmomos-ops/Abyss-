using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Passive regeneration while standing near a campfire (stacks lightly with rest sites).
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider))]
    public sealed class CampfireRestZone : MonoBehaviour
    {
        [SerializeField] private float staminaPerSecond = 12f;
        [SerializeField] private float injuryPerSecond = 1.5f;
        [SerializeField] private float healPerSecond;
        [SerializeField] private string playerTag = "Player";
        private PlayerVitals inside;

        private void Reset()
        {
            var col = GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            var v = Resolve(other);
            if (v != null) inside = v;
        }

        private void OnTriggerExit(Collider other)
        {
            var v = Resolve(other);
            if (v != null && v == inside) inside = null;
        }

        private void Update()
        {
            if (inside == null || inside.IsDead) return;
            float dt = Time.deltaTime;
            if (staminaPerSecond > 0f) inside.RecoverStamina(staminaPerSecond * dt / 18f);
            if (injuryPerSecond > 0f) inside.TreatInjury(injuryPerSecond * dt);
            if (healPerSecond > 0f) inside.Heal(healPerSecond * dt);
        }

        private PlayerVitals Resolve(Collider other)
        {
            if (other == null) return null;
            return other.GetComponentInParent<PlayerVitals>();
        }
    }
}
