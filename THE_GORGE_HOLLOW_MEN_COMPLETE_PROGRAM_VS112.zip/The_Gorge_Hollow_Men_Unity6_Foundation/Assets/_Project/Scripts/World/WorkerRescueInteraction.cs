using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Placed on a rescued survivor in the world. Interaction recruits that specific survivor once.</summary>
    [DisallowMultipleComponent]
    public sealed class WorkerRescueInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private string workerIdentity;
        [SerializeField] private string workerDisplayName = "Survivor";
        [SerializeField] private string towerId = "tower_a";
        [SerializeField] private TowerWorkerRole role = TowerWorkerRole.Scavenger;
        [SerializeField, Range(0, 100)] private int startingSkill = 25;
        [SerializeField] private TowerWorkerActor workerActor;
        [SerializeField] private TowerWorkerDamageable workerDamageable;
        public string InteractionPrompt => "Rescue survivor";

        private void Awake() { if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>(); }
        public bool CanInteract(GameObject interactor) => bootstrap != null && bootstrap.Campaign != null &&
            !string.IsNullOrWhiteSpace(workerIdentity) && TowerWorkerRules.Find(bootstrap.Campaign, workerIdentity) == null &&
            isActiveAndEnabled;

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            TowerWorkerRecord rescued = new TowerWorkerRecord
            {
                identity = workerIdentity, displayName = workerDisplayName, towerId = towerId,
                role = role, skill = startingSkill, status = TowerWorkerStatus.Active,
                assignment = TowerWorkerAssignment.Idle, health = 100
            };
            if (!TowerWorkerRules.TryRecruit(bootstrap.Campaign, rescued, out string error))
            { Debug.LogWarning("Survivor recruitment rejected: " + error, this); return; }
            if (!bootstrap.SaveCampaign())
            {
                bootstrap.Campaign.towerWorkers.Remove(rescued);
                Debug.LogWarning("Survivor recruitment was rolled back because the campaign save failed.", this);
                return;
            }
            if (workerActor != null) workerActor.Bind(workerIdentity);
            if (workerDamageable != null) workerDamageable.Bind(workerIdentity);
            CampaignEvents.RaiseCampaignReplaced(bootstrap.Campaign);
            enabled = false;
            GenericToastUI.Show(workerDisplayName + " joined " + (towerId == "tower_a" ? "Tower A" : "Tower B"), 2f);
            MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
        }
    }
}
