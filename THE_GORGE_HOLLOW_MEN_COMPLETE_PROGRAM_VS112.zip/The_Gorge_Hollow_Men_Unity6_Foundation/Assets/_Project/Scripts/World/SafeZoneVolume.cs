using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Marks a base/safe area. Can suppress raid banner urgency and show toast on enter.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider))]
    public sealed class SafeZoneVolume : MonoBehaviour
    {
        [SerializeField] private string enterMessage = "Safe zone";
        [SerializeField] private string exitMessage = "Leaving safe zone";
        [SerializeField] private string playerTag = "Player";
        public static bool PlayerInSafeZone { get; private set; }

        private void Reset()
        {
            var col = GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (!IsPlayer(other)) return;
            PlayerInSafeZone = true;
            if (!string.IsNullOrEmpty(enterMessage))
                GenericToastUI.Show(enterMessage, 1.5f);
        }

        private void OnTriggerExit(Collider other)
        {
            if (!IsPlayer(other)) return;
            PlayerInSafeZone = false;
            if (!string.IsNullOrEmpty(exitMessage))
                GenericToastUI.Show(exitMessage, 1.5f);
        }

        private bool IsPlayer(Collider other)
        {
            if (other == null) return false;
            if (!string.IsNullOrEmpty(playerTag) && other.CompareTag(playerTag)) return true;
            return other.GetComponentInParent<PlayerVitals>() != null;
        }
    }
}
