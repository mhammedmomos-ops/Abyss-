using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Proximity mine that explodes once when the player (or optionally monsters) enter.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider))]
    public sealed class ExplosiveMineHazard : MonoBehaviour
    {
        [SerializeField] private float radius = 3.5f;
        [SerializeField] private float damage = 35f;
        [SerializeField] private float injury = 8f;
        [SerializeField] private bool triggerOnPlayer = true;
        [SerializeField] private bool triggerOnMonster = true;
        [SerializeField] private float trauma = 0.45f;
        [SerializeField] private GameObject explosionVfx;
        private bool exploded;

        private void Reset()
        {
            var col = GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (exploded || other == null) return;
            bool player = other.GetComponentInParent<PlayerVitals>() != null;
            bool monster = other.GetComponentInParent<DamageableHealth>() != null && !player;
            if ((player && triggerOnPlayer) || (monster && triggerOnMonster))
                Explode();
        }

        private void Explode()
        {
            if (exploded) return;
            exploded = true;
            if (explosionVfx != null) Instantiate(explosionVfx, transform.position, Quaternion.identity);
            CameraShake.Shake(trauma);
            MobileHaptics.PlayImpact(MobileHapticStrength.Heavy);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.BridgeCollapse);
            var hits = Physics.OverlapSphere(transform.position, radius);
            for (int i = 0; i < hits.Length; i++)
            {
                if (hits[i] == null) continue;
                var vitals = hits[i].GetComponentInParent<PlayerVitals>();
                if (vitals != null && !vitals.IsDead)
                {
                    vitals.ApplyDamage(damage, injury);
                    DamageDirectionIndicator.HitFrom(transform.position);
                    continue;
                }
                var dmg = hits[i].GetComponentInParent<DamageableHealth>();
                if (dmg != null && !dmg.IsDead)
                    dmg.ApplyDamage(damage, hits[i].ClosestPoint(transform.position), Vector3.up, gameObject);
            }
            gameObject.SetActive(false);
        }
    }
}
