using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// One-shot container that grants a mixed resource bundle.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class LootContainerInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string prompt = "Open cache";
        [SerializeField] private int scrap = 5;
        [SerializeField] private int timber = 2;
        [SerializeField] private int ammo = 6;
        [SerializeField] private int medical;
        [SerializeField] private int petFood = 1;
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private GameObject openVisual;
        [SerializeField] private GameObject closedVisual;
        private bool opened;

        public string InteractionPrompt => opened ? "Empty" : prompt;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            if (openVisual != null) openVisual.SetActive(false);
            if (closedVisual != null) closedVisual.SetActive(true);
        }

        public bool CanInteract(GameObject interactor) => !opened;

        public void Interact(GameObject interactor)
        {
            if (opened) return;
            opened = true;
            if (bootstrap != null && bootstrap.Campaign != null)
            {
                var delta = new ResourceDelta
                {
                    scrap = scrap,
                    timber = timber,
                    ammunition = ammo,
                    medicalSupplies = medical,
                    petFood = Mathf.Max(0, petFood)
                };
                string tx = "cache:" + gameObject.name + ":" + System.Guid.NewGuid().ToString("N");
                if (bootstrap.Transactions != null &&
                    bootstrap.Transactions.TryApply(bootstrap.Campaign, tx, delta, out _))
                {
                    bootstrap.SaveCampaign();
                    CampaignEvents.RaiseTransactionCommitted(tx);
                }
                else
                {
                    bootstrap.Campaign.scrap += scrap;
                    bootstrap.Campaign.timber += timber;
                    bootstrap.Campaign.ammunition += ammo;
                    bootstrap.Campaign.medicalSupplies += medical;
                    bootstrap.Campaign.petFood += Mathf.Max(0, petFood);
                    bootstrap.SaveCampaign();
                }
            }
            CampaignEvents.RaiseScavengeCompleted(gameObject.name);
            if (closedVisual != null) closedVisual.SetActive(false);
            if (openVisual != null) openVisual.SetActive(true);
            GenericToastUI.Show("Cache looted", 1.3f);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.Scavenge);
            MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
        }
    }
}
