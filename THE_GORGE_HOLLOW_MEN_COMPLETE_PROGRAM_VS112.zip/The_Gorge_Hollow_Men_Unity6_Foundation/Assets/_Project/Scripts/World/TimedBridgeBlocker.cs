using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Temporarily enables a NavMeshObstacle / collider after a bridge collapses,
    /// then clears after a delay for scripted clearances.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class TimedBridgeBlocker : MonoBehaviour
    {
        [SerializeField] private BridgeSpanController span;
        [SerializeField] private GameObject blockerRoot;
        [SerializeField] private float blockSeconds = 20f;
        private Coroutine routine;

        private void OnEnable()
        {
            if (span == null) span = GetComponentInParent<BridgeSpanController>();
            if (span != null) span.SpanStateChanged += OnSpan;
            if (blockerRoot != null) blockerRoot.SetActive(false);
        }

        private void OnDisable()
        {
            if (span != null) span.SpanStateChanged -= OnSpan;
        }

        private void OnSpan(BridgeSpanController s, BridgeSpanState prev, BridgeSpanState next)
        {
            if (next != BridgeSpanState.Collapsed || prev == BridgeSpanState.Collapsed) return;
            if (blockerRoot != null) blockerRoot.SetActive(true);
            if (routine != null) StopCoroutine(routine);
            routine = StartCoroutine(ClearAfter());
        }

        private System.Collections.IEnumerator ClearAfter()
        {
            yield return new WaitForSeconds(Mathf.Max(0.5f, blockSeconds));
            if (blockerRoot != null) blockerRoot.SetActive(false);
            routine = null;
        }
    }
}
