using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Runs only for the tower the player currently occupies and only on local hostile awareness.</summary>
    [DisallowMultipleComponent]
    public sealed class SirenAlertController : MonoBehaviour
    {
        [SerializeField] private MonsterLocalAwareness localAwareness;
        [SerializeField] private TowerLocalAccessTracker localAccess;
        [SerializeField] private string sirenTowerId;
        [SerializeField] private AudioSource sirenSource;
        [SerializeField] private float raidVolume = 0.5f;

        private void Awake()
        {
            if (localAwareness == null) localAwareness = FindFirstObjectByType<MonsterLocalAwareness>();
            if (localAccess == null) localAccess = FindFirstObjectByType<TowerLocalAccessTracker>();
        }

        private void OnEnable()
        {
            if (localAwareness != null) localAwareness.AwarenessChanged += OnAwarenessChanged;
            Apply(HasLocalTowerContact());
        }

        private void OnDisable()
        {
            if (localAwareness != null) localAwareness.AwarenessChanged -= OnAwarenessChanged;
            if (sirenSource != null && sirenSource.isPlaying) sirenSource.Stop();
        }

        private void OnAwarenessChanged(int visibleHostiles, bool heardMovement)
        {
            Apply((visibleHostiles > 0 || heardMovement) && IsPlayerAtThisTower());
        }

        private void Update() => Apply(HasLocalTowerContact());

        private bool HasLocalTowerContact()
        {
            return localAwareness != null && localAwareness.HasLocalContact && IsPlayerAtThisTower();
        }

        private bool IsPlayerAtThisTower()
        {
            return localAccess != null && localAccess.IsConfigured &&
                   !string.IsNullOrWhiteSpace(sirenTowerId) && localAccess.CurrentTowerId == sirenTowerId;
        }

        private void Apply(bool localContact)
        {
            if (sirenSource == null) return;
            if (localContact)
            {
                sirenSource.volume = Mathf.Clamp01(raidVolume);
                if (!sirenSource.isPlaying) sirenSource.Play();
            }
            else if (sirenSource.isPlaying) sirenSource.Stop();
        }
    }
}
