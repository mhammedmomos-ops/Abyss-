using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// One-shot or repeating damage zone for placed traps / environmental hazards.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider))]
    public sealed class SimpleTrapHazard : MonoBehaviour
    {
        [SerializeField] private float damage = 18f;
        [SerializeField] private float injury = 4f;
        [SerializeField] private bool damagePlayer = true;
        [SerializeField] private bool damageMonsters = true;
        [SerializeField] private bool oneShot = true;
        [SerializeField] private float rearmSeconds = 4f;
        [SerializeField] private float cameraTrauma = 0.25f;

        private bool armed = true;
        private float rearmAt;

        private void Reset()
        {
            var col = GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
        }

        private void Update()
        {
            if (!armed && Time.time >= rearmAt) armed = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (!armed || other == null) return;
            bool hit = false;

            if (damagePlayer)
            {
                var vitals = other.GetComponentInParent<PlayerVitals>();
                if (vitals != null && !vitals.IsDead)
                {
                    vitals.ApplyDamage(damage, injury);
                    hit = true;
                }
            }

            if (damageMonsters)
            {
                var health = other.GetComponentInParent<DamageableHealth>();
                if (health != null && !health.IsDead && other.GetComponentInParent<PlayerVitals>() == null)
                {
                    health.ApplyDamage(damage, other.ClosestPoint(transform.position), Vector3.up, gameObject);
                    hit = true;
                }
            }

            if (!hit) return;
            CameraShake.Shake(cameraTrauma);
            MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
            if (oneShot) { armed = false; rearmAt = Time.time + Mathf.Max(0.1f, rearmSeconds); }
        }
    }
}
