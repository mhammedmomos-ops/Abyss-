using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Soft emissive/scale pulse to make scavengable props readable on mobile.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class LootGlowPulse : MonoBehaviour
    {
        [SerializeField] private Renderer targetRenderer;
        [SerializeField] private float pulseSpeed = 2.2f;
        [SerializeField] private float minIntensity = 0.2f;
        [SerializeField] private float maxIntensity = 1.1f;
        [SerializeField] private bool pulseScale;
        [SerializeField] private Vector3 baseScale = Vector3.one;

        private MaterialPropertyBlock block;
        private static readonly int EmissionId = Shader.PropertyToID("_EmissionColor");

        private void Awake()
        {
            if (targetRenderer == null) targetRenderer = GetComponentInChildren<Renderer>();
            block = new MaterialPropertyBlock();
            baseScale = transform.localScale;
        }

        private void Update()
        {
            float wave = (Mathf.Sin(Time.time * pulseSpeed) + 1f) * 0.5f;
            float intensity = Mathf.Lerp(minIntensity, maxIntensity, wave);
            if (targetRenderer != null)
            {
                targetRenderer.GetPropertyBlock(block);
                block.SetColor(EmissionId, Color.white * intensity);
                targetRenderer.SetPropertyBlock(block);
            }
            if (pulseScale)
            {
                float s = Mathf.Lerp(0.97f, 1.04f, wave);
                transform.localScale = baseScale * s;
            }
        }
    }
}
