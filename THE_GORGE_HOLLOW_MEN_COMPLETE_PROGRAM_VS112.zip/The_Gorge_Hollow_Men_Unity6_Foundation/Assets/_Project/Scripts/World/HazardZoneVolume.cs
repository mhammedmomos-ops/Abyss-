using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Continuous environmental hazard (bloom exposure, damage over time).
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider))]
    public sealed class HazardZoneVolume : MonoBehaviour
    {
        [SerializeField] private float damagePerSecond = 4f;
        [SerializeField] private float bloomPerSecond = 3f;
        [SerializeField] private float tickInterval = 0.5f;
        [SerializeField] private string playerTag = "Player";
        private PlayerVitals inside;
        private float tick;

        private void Reset()
        {
            var col = GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            var v = Resolve(other);
            if (v != null) inside = v;
        }

        private void OnTriggerExit(Collider other)
        {
            var v = Resolve(other);
            if (v != null && v == inside) inside = null;
        }

        private void Update()
        {
            if (inside == null || inside.IsDead) return;
            tick += Time.deltaTime;
            if (tick < tickInterval) return;
            float dt = tick;
            tick = 0f;
            if (damagePerSecond > 0f) inside.ApplyDamage(damagePerSecond * dt, 0f);
            if (bloomPerSecond > 0f) inside.AddBloom(bloomPerSecond * dt);
        }

        private PlayerVitals Resolve(Collider other)
        {
            if (other == null) return null;
            if (!string.IsNullOrEmpty(playerTag) && other.CompareTag(playerTag))
                return other.GetComponentInParent<PlayerVitals>();
            return other.GetComponentInParent<PlayerVitals>();
        }
    }
}
