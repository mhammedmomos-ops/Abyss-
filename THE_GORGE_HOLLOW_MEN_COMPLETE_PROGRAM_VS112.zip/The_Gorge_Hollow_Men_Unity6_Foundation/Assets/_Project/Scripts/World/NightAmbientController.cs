using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Adjusts ambient light / optional fog color from the shared fictional time of day, never raid phase.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class NightAmbientController : MonoBehaviour
    {
        [SerializeField] private Light sunOrMoon;
        [SerializeField] private float dayIntensity = 1.1f;
        [SerializeField] private float nightIntensity = 0.25f;
        [SerializeField] private Color dayAmbient = new Color(0.55f, 0.6f, 0.65f);
        [SerializeField] private Color nightAmbient = new Color(0.08f, 0.1f, 0.16f);
        [SerializeField] private float blendSeconds = 2.5f;
        [SerializeField] private bool driveFog;
        [SerializeField] private Color dayFog = new Color(0.7f, 0.75f, 0.8f);
        [SerializeField] private Color nightFog = new Color(0.05f, 0.06f, 0.1f);

        [SerializeField] private GameBootstrap bootstrap;
        private float blend;
        private bool targetNight;
        private float nextClockRefresh;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        private void Update()
        {
            if (Time.unscaledTime >= nextClockRefresh)
            {
                nextClockRefresh = Time.unscaledTime + 1f;
                if (bootstrap != null && bootstrap.Campaign != null)
                    targetNight = bootstrap.Campaign.fictionalHour >= 19 || bootstrap.Campaign.fictionalHour < 6;
            }
            float target = targetNight ? 1f : 0f;
            float speed = blendSeconds > 0.05f ? (1f / blendSeconds) : 10f;
            blend = Mathf.MoveTowards(blend, target, Time.deltaTime * speed);
            ApplyBlend(blend);
        }

        private void ApplyBlend(float t)
        {
            if (sunOrMoon != null)
                sunOrMoon.intensity = Mathf.Lerp(dayIntensity, nightIntensity, t);
            RenderSettings.ambientLight = Color.Lerp(dayAmbient, nightAmbient, t);
            if (driveFog)
                RenderSettings.fogColor = Color.Lerp(dayFog, nightFog, t);
        }


    }
}
