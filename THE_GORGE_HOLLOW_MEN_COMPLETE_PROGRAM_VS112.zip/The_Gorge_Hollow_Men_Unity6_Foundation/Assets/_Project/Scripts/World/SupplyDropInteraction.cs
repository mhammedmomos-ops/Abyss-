using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Scripted supply drop crate: richer loot than a standard cache, one-shot.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SupplyDropInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string prompt = "Claim supply drop";
        [SerializeField] private int scrap = 12;
        [SerializeField] private int timber = 6;
        [SerializeField] private int ammo = 20;
        [SerializeField] private int medical = 4;
        [SerializeField] private int parts = 2;
        [SerializeField] private int petFood = 5;
        [SerializeField] private GameBootstrap bootstrap;
        private bool claimed;

        public string InteractionPrompt => claimed ? "Claimed" : prompt;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        public bool CanInteract(GameObject interactor) => !claimed;

        public void Interact(GameObject interactor)
        {
            if (claimed) return;
            claimed = true;
            if (bootstrap != null && bootstrap.Campaign != null)
            {
                var delta = new ResourceDelta
                {
                    scrap = scrap,
                    timber = timber,
                    ammunition = ammo,
                    medicalSupplies = medical,
                    mechanicalParts = parts,
                    petFood = Mathf.Max(0, petFood)
                };
                string tx = "drop:" + System.Guid.NewGuid().ToString("N");
                if (bootstrap.Transactions != null &&
                    bootstrap.Transactions.TryApply(bootstrap.Campaign, tx, delta, out _))
                {
                    bootstrap.SaveCampaign();
                    CampaignEvents.RaiseTransactionCommitted(tx);
                }
                else
                {
                    bootstrap.Campaign.scrap += scrap;
                    bootstrap.Campaign.timber += timber;
                    bootstrap.Campaign.ammunition += ammo;
                    bootstrap.Campaign.medicalSupplies += medical;
                    bootstrap.Campaign.mechanicalParts += parts;
                    bootstrap.Campaign.petFood += Mathf.Max(0, petFood);
                    bootstrap.SaveCampaign();
                }
            }
            CampaignEvents.RaiseScavengeCompleted("supply_drop");
            AchievementTracker tracker = FindFirstObjectByType<AchievementTracker>();
            GenericToastUI.Show("Supply drop claimed", 2f);
            KillFeedUI.Post("Supply drop");
            SimpleAudioCuePlayer.PlayCue(AudioCueId.Scavenge);
            MobileHaptics.PlayImpact(MobileHapticStrength.Heavy);
            gameObject.SetActive(false);
        }
    }
}
