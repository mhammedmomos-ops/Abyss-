using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Authored overrun volume. A living monster entering while workers occupy the same volume can capture
    /// those workers. Place only in exposed tower interiors; never on the bridge or across tower routes.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider), typeof(Rigidbody))]
    public sealed class TowerWorkerCaptureVolume : MonoBehaviour
    {
        [SerializeField] private TowerWorkforceController workforce;
        [SerializeField] private MonsterRaidDirector raidDirector;
        [SerializeField] private LayerMask monsterLayers;
        [SerializeField] private TowerWorkerActor[] workers;
        private readonly System.Collections.Generic.Dictionary<MonsterAIController, int> monsterColliderCounts = new System.Collections.Generic.Dictionary<MonsterAIController, int>();
        private readonly HashSet<Collider> monsterCollidersInside = new HashSet<Collider>();
        private readonly HashSet<TowerWorkerActor> workersInside = new HashSet<TowerWorkerActor>();
        [SerializeField, Min(0.25f)] private float captureCheckInterval = 1f;
        private float nextCaptureCheck;

        private void Awake()
        {
            if (workforce == null) workforce = FindFirstObjectByType<TowerWorkforceController>();
            if (raidDirector == null) raidDirector = FindFirstObjectByType<MonsterRaidDirector>();
            Collider volume = GetComponent<Collider>();
            volume.isTrigger = true;
            Rigidbody body = GetComponent<Rigidbody>();
            body.isKinematic = true;
            body.useGravity = false;
        }

        private void Update()
        {
            if (Time.unscaledTime < nextCaptureCheck) return;
            nextCaptureCheck = Time.unscaledTime + Mathf.Max(0.25f, captureCheckInterval);
            TryCaptureOverrunWorkers();
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other == null) return;
            TowerWorkerActor worker = other.GetComponentInParent<TowerWorkerActor>();
            if (worker != null) workersInside.Add(worker);
            if (IsMonsterLayer(other.gameObject.layer) || IsMonsterLayer(other.transform.root.gameObject.layer))
            {
                MonsterAIController monster = other.GetComponentInParent<MonsterAIController>();
                if (monster != null && monsterCollidersInside.Add(other))
                {
                    monsterColliderCounts.TryGetValue(monster, out int count);
                    monsterColliderCounts[monster] = count + 1;
                }
            }
            TryCaptureOverrunWorkers();
        }

        private void OnTriggerExit(Collider other)
        {
            if (other == null) return;
            TowerWorkerActor worker = other.GetComponentInParent<TowerWorkerActor>();
            if (worker != null) workersInside.Remove(worker);
            MonsterAIController monster = other.GetComponentInParent<MonsterAIController>();
            if (monster != null && monsterCollidersInside.Remove(other) && monsterColliderCounts.TryGetValue(monster, out int count))
            {
                if (count <= 1) monsterColliderCounts.Remove(monster);
                else monsterColliderCounts[monster] = count - 1;
            }
        }

        private bool IsMonsterLayer(int layer) => (monsterLayers.value & (1 << layer)) != 0;

        private void TryCaptureOverrunWorkers()
        {
            if (workforce == null || raidDirector == null || !raidDirector.IsRaidActive) return;
            var expired = new List<MonsterAIController>();
            foreach (KeyValuePair<MonsterAIController, int> entry in monsterColliderCounts)
            {
                MonsterAIController monster = entry.Key;
                DamageableHealth health = monster != null ? monster.GetComponent<DamageableHealth>() : null;
                if (monster == null || !monster.gameObject.activeInHierarchy || (health != null && health.IsDead)) expired.Add(monster);
            }
            for (int i = 0; i < expired.Count; i++) monsterColliderCounts.Remove(expired[i]);
            monsterCollidersInside.RemoveWhere(x => x == null);
            if (monsterColliderCounts.Count == 0) return;
            foreach (TowerWorkerActor actor in workersInside)
            {
                if (actor == null || (workers != null && workers.Length > 0 && !ContainsWorker(actor))) continue;
                TowerWorkerDamageable damageable = actor.GetComponent<TowerWorkerDamageable>();
                string identity = damageable != null ? damageable.WorkerIdentity : null;
                if (string.IsNullOrWhiteSpace(identity)) continue;
                if (workforce.CaptureWorker(identity, out string error)) actor.gameObject.SetActive(false);
                else if (!string.IsNullOrEmpty(error)) Debug.LogWarning("Worker capture was not committed: " + error, this);
            }
            workersInside.RemoveWhere(x => x == null || !x.gameObject.activeInHierarchy);
        }

        private bool ContainsWorker(TowerWorkerActor actor)
        {
            for (int i = 0; i < workers.Length; i++) if (workers[i] == actor) return true;
            return false;
        }

        private void OnDisable() { monsterColliderCounts.Clear(); monsterCollidersInside.Clear(); workersInside.Clear(); }
    }
}
