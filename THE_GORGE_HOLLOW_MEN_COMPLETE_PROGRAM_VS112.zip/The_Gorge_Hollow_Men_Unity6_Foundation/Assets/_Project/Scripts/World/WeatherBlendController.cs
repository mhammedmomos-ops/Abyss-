using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Scales particle emission using fictional day/night, not hidden encounter state.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class WeatherBlendController : MonoBehaviour
    {
        [SerializeField] private ParticleSystem[] systems;
        [SerializeField] private float dayRate = 5f;
        [SerializeField] private float nightRate = 20f;
        [SerializeField] private float blendSeconds = 3f;

        [SerializeField] private GameBootstrap bootstrap;
        private float blend;
        private bool targetNight;
        private float nextClockRefresh;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }

        private void Update()
        {
            if (Time.unscaledTime >= nextClockRefresh)
            {
                nextClockRefresh = Time.unscaledTime + 1f;
                if (bootstrap != null && bootstrap.Campaign != null)
                    targetNight = bootstrap.Campaign.fictionalHour >= 19 || bootstrap.Campaign.fictionalHour < 6;
            }
            float target = targetNight ? 1f : 0f;
            float speed = blendSeconds > 0.05f ? 1f / blendSeconds : 10f;
            blend = Mathf.MoveTowards(blend, target, Time.deltaTime * speed);
            float rate = Mathf.Lerp(dayRate, nightRate, blend);
            if (systems == null) return;
            for (int i = 0; i < systems.Length; i++)
            {
                if (systems[i] == null) continue;
                var emission = systems[i].emission;
                emission.rateOverTime = rate;
            }
        }
    }
}
