using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Disables a blocking collider when approached from the allowed direction.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class OneWayBarrier : MonoBehaviour
    {
        [SerializeField] private Collider barrierCollider;
        [SerializeField] private Vector3 allowedLocalDirection = Vector3.forward;
        [SerializeField] private float dotThreshold = 0.25f;

        private void Awake()
        {
            if (barrierCollider == null) barrierCollider = GetComponent<Collider>();
        }

        private void OnTriggerStay(Collider other)
        {
            if (barrierCollider == null || other == null) return;
            var vitals = other.GetComponentInParent<PlayerVitals>();
            if (vitals == null) return;
            Vector3 worldAllowed = transform.TransformDirection(allowedLocalDirection).normalized;
            Vector3 toPlayer = (vitals.transform.position - transform.position).normalized;
            bool allowed = Vector3.Dot(worldAllowed, toPlayer) >= dotThreshold;
            barrierCollider.enabled = !allowed;
        }

        private void OnTriggerExit(Collider other)
        {
            if (barrierCollider != null) barrierCollider.enabled = true;
        }
    }
}
