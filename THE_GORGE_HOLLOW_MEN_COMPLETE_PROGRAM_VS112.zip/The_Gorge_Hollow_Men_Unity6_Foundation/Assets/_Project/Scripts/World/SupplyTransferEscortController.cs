using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Optional scene-authored escort team for an inter-tower carrier. Escorts follow the carrier,
    /// attack nearby MonsterAIController targets, and provide a bounded mitigation value for the
    /// convoy damage integration. This component does not alter bridge access or convoy transactions.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SupplyTransferEscortController : MonoBehaviour
    {
        [SerializeField] private SupplyConvoyController convoy;
        [SerializeField] private Transform[] escortUnits;
        [SerializeField, Min(1f)] private float followDistance = 3.2f;
        [SerializeField, Min(1f)] private float detectionRadius = 10f;
        [SerializeField, Min(1f)] private float attackRange = 7f;
        [SerializeField, Min(0.1f)] private float attackInterval = 1.1f;
        [SerializeField, Min(0f)] private float damagePerAttack = 8f;
        [SerializeField] private LayerMask hostileMask = ~0;
        private readonly Collider[] scanBuffer = new Collider[32];
        private readonly HashSet<MonsterAIController> seenMonsters = new HashSet<MonsterAIController>();
        private float nextAttackAt;
        private float nextScanAt;
        private Transform currentTarget;
        private const float ScanInterval = 0.3f;

        public int OperationalEscortCount
        {
            get
            {
                if (escortUnits == null) return 0;
                int count = 0;
                for (int i = 0; i < escortUnits.Length; i++) if (escortUnits[i] != null && escortUnits[i].gameObject.activeInHierarchy) count++;
                return count;
            }
        }
        public float IncomingDamageMultiplier => SupplyTransferThreatRules.EscortDamageMultiplier(OperationalEscortCount, escortUnits == null ? 0 : escortUnits.Length);
        public SupplyRouteThreatLevel CurrentThreat { get; private set; } = SupplyRouteThreatLevel.Clear;
        public string TacticalStatus => CurrentThreat.ToString().ToUpperInvariant();

        private void Update()
        {
            if (convoy == null || !convoy.IsAttackable || !convoy.IsInterTowerTransfer || escortUnits == null || escortUnits.Length == 0) return;
            FollowCarrier();
            if (Time.time >= nextScanAt) { ScanThreats(); nextScanAt = Time.time + ScanInterval; }
            AttackTarget();
        }

        private void FollowCarrier()
        {
            Vector3 right = convoy.transform.right;
            int activeIndex = 0;
            for (int i = 0; i < escortUnits.Length; i++)
            {
                Transform unit = escortUnits[i];
                if (unit == null || !unit.gameObject.activeInHierarchy) continue;
                float side = (activeIndex % 2 == 0 ? 1f : -1f);
                int row = activeIndex / 2;
                Vector3 desired = convoy.transform.position - convoy.transform.forward * (followDistance + row * 1.4f) + right * side * (1.2f + row * 0.4f);
                unit.position = Vector3.MoveTowards(unit.position, desired, 4f * Time.deltaTime);
                Vector3 look = convoy.transform.position - unit.position;
                look.y = 0f;
                if (look.sqrMagnitude > 0.05f) unit.rotation = Quaternion.Slerp(unit.rotation, Quaternion.LookRotation(look), 6f * Time.deltaTime);
                activeIndex++;
            }
        }

        private void ScanThreats()
        {
            int count = Physics.OverlapSphereNonAlloc(convoy.transform.position, detectionRadius, scanBuffer, hostileMask, QueryTriggerInteraction.Ignore);
            int hostiles = 0;
            int attackers = 0;
            seenMonsters.Clear();
            float nearest = float.MaxValue;
            currentTarget = null;
            float nearestTargetSqr = float.MaxValue;
            for (int i = 0; i < count; i++)
            {
                Collider hit = scanBuffer[i];
                if (hit == null) continue;
                MonsterAIController monster = hit.GetComponentInParent<MonsterAIController>();
                if (monster == null || !monster.gameObject.activeInHierarchy || !seenMonsters.Add(monster)) continue;
                Vector3 delta = monster.transform.position - convoy.transform.position;
                float distance = delta.magnitude;
                hostiles++;
                if (distance < nearest) nearest = distance;
                if (distance <= attackRange) attackers++;
                float sqr = delta.sqrMagnitude;
                if (sqr < nearestTargetSqr && monster.GetComponent<DamageableHealth>() != null && !monster.GetComponent<DamageableHealth>().IsDead)
                { nearestTargetSqr = sqr; currentTarget = monster.transform; }
            }
            float health = convoy.HealthFraction;
            CurrentThreat = SupplyTransferThreatRules.Evaluate(hostiles, attackers, hostiles == 0 ? detectionRadius : nearest, detectionRadius, health);
            for (int i = 0; i < scanBuffer.Length; i++) scanBuffer[i] = null;
        }

        private void AttackTarget()
        {
            if (currentTarget == null || Time.time < nextAttackAt) return;
            float rangeSqr = attackRange * attackRange;
            int applied = 0;
            for (int i = 0; i < escortUnits.Length; i++)
            {
                Transform unit = escortUnits[i];
                if (unit == null || !unit.gameObject.activeInHierarchy || applied >= OperationalEscortCount) continue;
                if ((currentTarget.position - unit.position).sqrMagnitude > rangeSqr) continue;
                DamageableHealth health = currentTarget.GetComponent<DamageableHealth>();
                if (health == null || health.IsDead) { currentTarget = null; return; }
                float commandDamage = SupplyConvoyCommandRules.EscortDamageMultiplier(convoy.TacticalCommand);
                health.ApplyDamage(damagePerAttack * commandDamage, currentTarget.position, (currentTarget.position - unit.position).normalized, unit.gameObject);
                applied++;
            }
            if (applied > 0) nextAttackAt = Time.time + attackInterval;
        }

        private void OnDrawGizmosSelected()
        {
            if (convoy != null) Gizmos.DrawWireSphere(convoy.transform.position, detectionRadius);
        }
    }
}
