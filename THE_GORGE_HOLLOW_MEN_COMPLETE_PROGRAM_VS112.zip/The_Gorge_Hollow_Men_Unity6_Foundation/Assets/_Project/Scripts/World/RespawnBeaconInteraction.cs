using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Sets a soft respawn position used by death/retry flows if present.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class RespawnBeaconInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string prompt = "Set respawn beacon";
        [SerializeField] private Transform beaconPoint;
        public static Vector3? BeaconPosition { get; private set; }
        public static Quaternion? BeaconRotation { get; private set; }

        public string InteractionPrompt => prompt;

        public bool CanInteract(GameObject interactor) => true;

        public void Interact(GameObject interactor)
        {
            Transform t = beaconPoint != null ? beaconPoint : transform;
            BeaconPosition = t.position;
            BeaconRotation = t.rotation;
            GenericToastUI.Show("Respawn beacon set", 1.4f);
            SimpleAudioCuePlayer.PlayCue(AudioCueId.UISave);
            MobileHaptics.PlayImpact(MobileHapticStrength.Light);
        }
    }
}
