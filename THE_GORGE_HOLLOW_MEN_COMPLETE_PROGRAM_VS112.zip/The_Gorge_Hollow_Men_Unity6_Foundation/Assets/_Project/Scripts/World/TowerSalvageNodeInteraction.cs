using UnityEngine;
namespace GorgeHollow
{
    [DisallowMultipleComponent]
    public sealed class TowerSalvageNodeInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string nodeIdentity;
        [SerializeField] private string towerId = "tower_a";
        [SerializeField] private int scrapReward = 4;
        [SerializeField] private int timberReward;
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private GameObject depletedVisual;
        public string InteractionPrompt => "Recover salvage";
        private void Awake() { if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>(); RefreshVisual(); }
        public bool CanInteract(GameObject interactor) => bootstrap != null && bootstrap.Campaign != null && !string.IsNullOrWhiteSpace(nodeIdentity) && !TowerSalvageRules.IsRecovered(bootstrap.Campaign, nodeIdentity) && isActiveAndEnabled;
        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            TowerDepotRecord depot = TowerDepotRules.Find(bootstrap.Campaign, towerId);
            if (depot == null) { Debug.LogWarning("Salvage node has no matching tower depot.", this); return; }
            int actualScrap = scrapReward + TowerWorkerRules.SalvageBonus(bootstrap.Campaign, towerId, scrapReward);
            int actualTimber = timberReward + TowerWorkerRules.SalvageBonus(bootstrap.Campaign, towerId, timberReward);
            int oldScrap = depot.scrap, oldTimber = depot.timber;
            if (!TowerSalvageRules.TryRecover(bootstrap.Campaign, towerId, nodeIdentity, actualScrap, actualTimber, out string error)) { Debug.LogWarning("Salvage recovery rejected: " + error, this); return; }
            if (!bootstrap.SaveCampaign())
            {
                depot.scrap = oldScrap; depot.timber = oldTimber; bootstrap.Campaign.campaignFlags.Remove("vs101_salvaged:" + nodeIdentity);
                Debug.LogWarning("Salvage recovery was rolled back because the campaign save failed.", this); return;
            }
            RefreshVisual(); GenericToastUI.Show("Recovered " + actualScrap + " scrap, " + actualTimber + " timber", 1.5f); MobileHaptics.PlayImpact(MobileHapticStrength.Light);
        }
        private void RefreshVisual() { if (depletedVisual != null && bootstrap != null && bootstrap.Campaign != null) depletedVisual.SetActive(!TowerSalvageRules.IsRecovered(bootstrap.Campaign, nodeIdentity)); }
    }
}
