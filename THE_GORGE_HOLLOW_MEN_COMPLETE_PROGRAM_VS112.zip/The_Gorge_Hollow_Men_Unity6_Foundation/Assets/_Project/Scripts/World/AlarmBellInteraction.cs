using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Manual alarm bell that raises a local raid-style alert feedback.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AlarmBellInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private string prompt = "Ring alarm";
        [SerializeField] private float cooldown = 15f;
        [SerializeField] private float trauma = 0.25f;
        private float nextAllowed;

        public string InteractionPrompt => prompt;

        public bool CanInteract(GameObject interactor) => Time.time >= nextAllowed;

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            nextAllowed = Time.time + cooldown;
            SimpleAudioCuePlayer.PlayCue(AudioCueId.RaidAlarm);
            CameraShake.Shake(trauma);
            MobileHaptics.PlayImpact(MobileHapticStrength.Heavy);
            GenericToastUI.Show("Alarm sounded", 1.5f);
            KillFeedUI.Post("Alarm");
        }
    }
}
