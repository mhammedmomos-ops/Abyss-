using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow
{
    /// <summary>Scene representation of a persistent worker. Requires authored NavMesh and assignment targets for movement.</summary>
    [DisallowMultipleComponent]
    public sealed class TowerWorkerActor : MonoBehaviour
    {
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private string workerIdentity;
        [SerializeField] private NavMeshAgent agent;
        [SerializeField] private Transform productionPoint;
        [SerializeField] private Transform salvagePoint;
        [SerializeField] private Transform guardPoint;
        [SerializeField] private Transform restPoint;
        [SerializeField, Min(0.1f)] private float destinationRefreshSeconds = 1f;
        private float nextRefresh;
        private Vector3 lastDestination;
        private bool hasDestination;
        private Transform tacticalDestination;
        private bool hasTacticalDestination;
        private bool locallyVisible = true;
        private Renderer[] cachedRenderers;
        private Collider[] cachedColliders;

        public void SetTacticalDestination(Transform target)
        {
            if (hasTacticalDestination && tacticalDestination == target) return;
            if (!hasTacticalDestination && target == null) return;
            tacticalDestination = target;
            hasTacticalDestination = target != null;
            hasDestination = false;
            RefreshBinding();
        }

        public void ClearTacticalDestination()
        {
            if (!hasTacticalDestination) return;
            tacticalDestination = null;
            hasTacticalDestination = false;
            hasDestination = false;
            RefreshBinding();
        }

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            if (agent == null) agent = GetComponent<NavMeshAgent>();
            cachedRenderers = GetComponentsInChildren<Renderer>(true);
            cachedColliders = GetComponentsInChildren<Collider>(true);
        }

        public string WorkerIdentity => workerIdentity;

        /// <summary>Hides remote-tower worker presentation without changing campaign state or simulation identity.</summary>
        public void SetLocalVisibility(bool visible)
        {
            if (locallyVisible == visible) return;
            locallyVisible = visible;
            RefreshBinding();
        }

        /// <summary>Assigns destinations authored inside this worker's own tower courtyard.</summary>
        public void ConfigureWorkTargets(Transform production, Transform salvage, Transform guard, Transform rest)
        {
            productionPoint = production;
            salvagePoint = salvage;
            guardPoint = guard;
            restPoint = rest;
            if (agent == null) agent = GetComponent<NavMeshAgent>();
            if (agent != null)
            {
                agent.autoTraverseOffMeshLink = false;
                // The generated bridge is baked as the built-in Jump area. Workers cannot use it,
                // even if the scene NavMesh is otherwise connected from one tower to the other.
                int bridgeArea = NavMesh.GetAreaFromName("Jump");
                if (bridgeArea >= 0) agent.areaMask &= ~(1 << bridgeArea);
            }
            hasDestination = false;
            RefreshBinding();
        }

        public void Bind(string identity)
        {
            workerIdentity = identity;
            tacticalDestination = null;
            hasTacticalDestination = false;
            hasDestination = false;
            RefreshBinding();
        }
        private void Update()
        {
            if (Time.unscaledTime < nextRefresh) return;
            nextRefresh = Time.unscaledTime + Mathf.Max(0.1f, destinationRefreshSeconds);
            RefreshBinding();
        }

        private void RefreshBinding()
        {
            TowerWorkerRecord worker = TowerWorkerRules.Find(bootstrap != null ? bootstrap.Campaign : null, workerIdentity);
            if (worker == null) return; // An unrescued survivor must remain available for interaction.
            if (worker.status == TowerWorkerStatus.Captured || worker.status == TowerWorkerStatus.Dead)
            {
                if (agent != null && agent.enabled && agent.isOnNavMesh) agent.isStopped = true;
                SetPresentationVisible(false);
                return;
            }
            SetPresentationVisible(locallyVisible);
            // Injury overrides ordinary work routing without mutating the active raid destination.
            Transform target = hasTacticalDestination && tacticalDestination != null ? tacticalDestination :
                worker.status == TowerWorkerStatus.Injured && restPoint != null ? restPoint :
                worker.assignment == TowerWorkerAssignment.Production ? productionPoint :
                worker.assignment == TowerWorkerAssignment.Salvage ? salvagePoint :
                worker.assignment == TowerWorkerAssignment.Guard ? guardPoint :
                worker.assignment == TowerWorkerAssignment.Rest ? restPoint : null;
            if (agent == null || !agent.enabled || !agent.isOnNavMesh) return;
            if (target == null) { agent.isStopped = true; hasDestination = false; return; }
            if (!hasDestination || (target.position - lastDestination).sqrMagnitude > 0.25f)
            {
                if (agent.SetDestination(target.position)) { lastDestination = target.position; hasDestination = true; }
            }
            agent.isStopped = false;
        }

        private void SetPresentationVisible(bool visible)
        {
            if (cachedRenderers != null)
                for (int i = 0; i < cachedRenderers.Length; i++)
                    if (cachedRenderers[i] != null) cachedRenderers[i].enabled = visible;
            if (cachedColliders != null)
                for (int i = 0; i < cachedColliders.Length; i++)
                    if (cachedColliders[i] != null) cachedColliders[i].enabled = visible;
        }
    }
}
