using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Hides all detailed presentation belonging to the non-local tower. The gorge, bridge,
    /// terrain and other world-level geography are deliberately outside these tower roots.
    /// This is a presentation boundary, not a multiplayer security boundary.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class TowerStructureVisibilityController : MonoBehaviour
    {
        [SerializeField] private TowerLocalAccessTracker localAccess;
        [SerializeField] private Transform towerARoot;
        [SerializeField] private Transform towerBRoot;
        [SerializeField, Min(0.05f)] private float refreshSeconds = 0.15f;

        private TowerPresentationCache towerA;
        private TowerPresentationCache towerB;
        private float nextRefresh;
        private string lastLocalTower;

        private sealed class TowerPresentationCache
        {
            public Renderer[] renderers;
            public Canvas[] canvases;
            public Light[] lights;
            public AudioSource[] audioSources;
            public bool[] rendererOriginallyForcedOff;
            public bool[] canvasOriginallyEnabled;
            public bool[] lightOriginallyEnabled;
            public bool[] audioOriginallyMuted;
        }

        private void Awake()
        {
            if (localAccess == null) localAccess = FindFirstObjectByType<TowerLocalAccessTracker>();
            towerA = BuildCache(towerARoot);
            towerB = BuildCache(towerBRoot);
            ApplyVisibility(null);
        }

        private void OnEnable()
        {
            nextRefresh = 0f;
            lastLocalTower = null;
        }

        private void Update()
        {
            if (Time.unscaledTime < nextRefresh) return;
            nextRefresh = Time.unscaledTime + Mathf.Max(0.05f, refreshSeconds);
            string localTower = localAccess != null ? localAccess.CurrentTowerId : null;
            if (localTower == lastLocalTower) return;
            ApplyVisibility(localTower);
            lastLocalTower = localTower;
        }

        private void OnDisable()
        {
            // Restore authored component states if this controller is disabled or removed at runtime.
            ApplyCache(towerA, true);
            ApplyCache(towerB, true);
        }

        private void ApplyVisibility(string localTowerId)
        {
            ApplyCache(towerA, TowerStructureVisibilityRules.ShouldRenderTower("tower_a", localTowerId));
            ApplyCache(towerB, TowerStructureVisibilityRules.ShouldRenderTower("tower_b", localTowerId));
        }

        private static TowerPresentationCache BuildCache(Transform root)
        {
            if (root == null) return null;
            var cache = new TowerPresentationCache
            {
                renderers = root.GetComponentsInChildren<Renderer>(true),
                canvases = root.GetComponentsInChildren<Canvas>(true),
                lights = root.GetComponentsInChildren<Light>(true),
                audioSources = root.GetComponentsInChildren<AudioSource>(true)
            };
            cache.rendererOriginallyForcedOff = new bool[cache.renderers.Length];
            cache.canvasOriginallyEnabled = new bool[cache.canvases.Length];
            cache.lightOriginallyEnabled = new bool[cache.lights.Length];
            cache.audioOriginallyMuted = new bool[cache.audioSources.Length];
            for (int i = 0; i < cache.renderers.Length; i++)
                cache.rendererOriginallyForcedOff[i] = cache.renderers[i] != null && cache.renderers[i].forceRenderingOff;
            for (int i = 0; i < cache.canvases.Length; i++)
                cache.canvasOriginallyEnabled[i] = cache.canvases[i] != null && cache.canvases[i].enabled;
            for (int i = 0; i < cache.lights.Length; i++)
                cache.lightOriginallyEnabled[i] = cache.lights[i] != null && cache.lights[i].enabled;
            for (int i = 0; i < cache.audioSources.Length; i++)
                cache.audioOriginallyMuted[i] = cache.audioSources[i] != null && cache.audioSources[i].mute;
            return cache;
        }

        private static void ApplyCache(TowerPresentationCache cache, bool visible)
        {
            if (cache == null) return;
            for (int i = 0; i < cache.renderers.Length; i++)
                if (cache.renderers[i] != null)
                    cache.renderers[i].forceRenderingOff = !visible || cache.rendererOriginallyForcedOff[i];
            for (int i = 0; i < cache.canvases.Length; i++)
                if (cache.canvases[i] != null)
                    cache.canvases[i].enabled = visible && cache.canvasOriginallyEnabled[i];
            for (int i = 0; i < cache.lights.Length; i++)
                if (cache.lights[i] != null)
                    cache.lights[i].enabled = visible && cache.lightOriginallyEnabled[i];
            for (int i = 0; i < cache.audioSources.Length; i++)
                if (cache.audioSources[i] != null)
                    cache.audioSources[i].mute = !visible || cache.audioOriginallyMuted[i];
        }
    }
}
