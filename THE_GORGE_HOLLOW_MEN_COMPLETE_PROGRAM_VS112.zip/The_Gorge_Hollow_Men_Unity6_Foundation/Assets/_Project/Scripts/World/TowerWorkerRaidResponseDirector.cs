using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    [System.Serializable]
    public sealed class TowerWorkerTacticalBinding
    {
        public string workerIdentity;
        public TowerWorkerActor actor;
        public Transform coverPoint;
        public Transform defensivePoint;
        public Transform evacuationPoint;
    }

    /// <summary>
    /// Per-tower raid response coordinator. It never invents routes: every destination is an authored point
    /// on the same tower's NavMesh. Player assignment orders take precedence until the raid ends.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class TowerWorkerRaidResponseDirector : MonoBehaviour
    {
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private MonsterRaidDirector raidDirector;
        [SerializeField] private TowerWorkforceController workforce;
        [SerializeField] private string towerId = "tower_a";
        [SerializeField] private TowerWorkerTacticalBinding[] bindings;
        [SerializeField, Min(0.25f)] private float refreshSeconds = 1f;
        [SerializeField, Min(0.5f)] private float arrivalDistance = 1.75f;
        [SerializeField, Min(1f)] private float fieldAidIntervalSeconds = 5f;
        private float nextRefresh;
        private float nextAid;
        private bool lastRaidActive;

        private void Awake()
        {
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
            if (raidDirector == null) raidDirector = FindFirstObjectByType<MonsterRaidDirector>();
            if (workforce == null) workforce = FindFirstObjectByType<TowerWorkforceController>();
            if (towerId != "tower_a" && towerId != "tower_b") enabled = false;
        }

        private void Update()
        {
            if (Time.unscaledTime < nextRefresh) return;
            nextRefresh = Time.unscaledTime + Mathf.Max(0.25f, refreshSeconds);
            if (bootstrap == null || bootstrap.Campaign == null || raidDirector == null || workforce == null) return;
            bool active = raidDirector.IsRaidActive;
            if (active != lastRaidActive)
            {
                if (!active)
                {
                    if (!workforce.ApplyRaidOrders(null, false, out string resetError))
                        Debug.LogWarning("Worker raid posture reset was not saved: " + resetError, this);
                    ClearAllDestinations();
                }
                lastRaidActive = active;
            }
            if (!active)
            {
                bool stalePosture = false;
                if (bootstrap.Campaign.towerWorkers != null)
                    foreach (TowerWorkerRecord worker in bootstrap.Campaign.towerWorkers)
                        if (worker != null && (worker.tacticalState != TowerWorkerTacticalState.Normal || worker.playerOverrideDuringRaid)) { stalePosture = true; break; }
                if (stalePosture && !workforce.ApplyRaidOrders(null, false, out string staleError))
                    Debug.LogWarning("Stale raid posture could not be cleared: " + staleError, this);
                return;
            }
            ApplyAutomaticOrders();
            UpdateDestinationsAndAid();
        }

        private void ApplyAutomaticOrders()
        {
            CampaignState campaign = bootstrap.Campaign;
            List<TowerWorkerRaidOrder> orders = TowerWorkerRaidRules.BuildOrders(campaign.towerWorkers, towerId);
            if (!workforce.ApplyRaidOrders(orders, true, out string error))
                Debug.LogWarning("Worker raid response could not be saved: " + error, this);
        }

        private void UpdateDestinationsAndAid()
        {
            CampaignState campaign = bootstrap.Campaign;
            if (bindings == null) return;
            for (int i = 0; i < bindings.Length; i++)
            {
                TowerWorkerTacticalBinding binding = bindings[i];
                if (binding == null || binding.actor == null || string.IsNullOrWhiteSpace(binding.workerIdentity)) continue;
                TowerWorkerRecord worker = TowerWorkerRules.Find(campaign, binding.workerIdentity);
                if (worker == null || worker.status == TowerWorkerStatus.Dead || worker.status == TowerWorkerStatus.Captured || worker.playerOverrideDuringRaid)
                {
                    binding.actor.ClearTacticalDestination();
                    continue;
                }
                Transform destination = ResolveDestination(worker, binding, campaign);
                binding.actor.SetTacticalDestination(destination);
                if (worker.tacticalState == TowerWorkerTacticalState.Evacuating && destination != null &&
                    Vector3.Distance(binding.actor.transform.position, destination.position) <= arrivalDistance)
                    SetSheltered(worker);
                if (worker.role == TowerWorkerRole.Medic && worker.tacticalState == TowerWorkerTacticalState.AssistingInjured &&
                    Time.unscaledTime >= nextAid && destination != null && Vector3.Distance(binding.actor.transform.position, destination.position) <= arrivalDistance)
                {
                    TowerWorkerRecord patient = TowerWorkerRaidRules.FindMostInjured(campaign.towerWorkers, towerId);
                    if (patient != null && workforce.ApplyFieldAid(worker.identity, patient.identity, out _))
                        nextAid = Time.unscaledTime + Mathf.Max(1f, fieldAidIntervalSeconds);
                }
            }
        }

        private Transform ResolveDestination(TowerWorkerRecord worker, TowerWorkerTacticalBinding binding, CampaignState campaign)
        {
            if (worker.tacticalState == TowerWorkerTacticalState.Defending)
                return binding.defensivePoint != null ? binding.defensivePoint : binding.coverPoint;
            if (worker.tacticalState == TowerWorkerTacticalState.AssistingInjured)
            {
                TowerWorkerRecord patient = TowerWorkerRaidRules.FindMostInjured(campaign.towerWorkers, towerId);
                if (patient != null)
                {
                    TowerWorkerTacticalBinding patientBinding = FindBinding(patient.identity);
                    if (patientBinding != null && patientBinding.actor != null) return patientBinding.actor.transform;
                }
                return binding.coverPoint;
            }
            if (worker.tacticalState == TowerWorkerTacticalState.Evacuating || worker.tacticalState == TowerWorkerTacticalState.Sheltered)
                return binding.evacuationPoint != null ? binding.evacuationPoint : binding.coverPoint;
            return null;
        }

        private TowerWorkerTacticalBinding FindBinding(string identity)
        {
            if (bindings == null) return null;
            for (int i = 0; i < bindings.Length; i++)
                if (bindings[i] != null && bindings[i].workerIdentity == identity) return bindings[i];
            return null;
        }

        private void SetSheltered(TowerWorkerRecord worker)
        {
            if (worker.tacticalState != TowerWorkerTacticalState.Evacuating) return;
            var order = new List<TowerWorkerRaidOrder> { new TowerWorkerRaidOrder(worker.identity, TowerWorkerTacticalState.Sheltered) };
            if (!workforce.ApplyRaidOrders(order, true, out string error))
                Debug.LogWarning("Shelter arrival could not be saved: " + error, this);
        }

        private void ClearAllDestinations()
        {
            if (bindings == null) return;
            for (int i = 0; i < bindings.Length; i++)
                if (bindings[i] != null && bindings[i].actor != null) bindings[i].actor.ClearTacticalDestination();
        }

        private void OnDisable() { ClearAllDestinations(); }
    }
}
