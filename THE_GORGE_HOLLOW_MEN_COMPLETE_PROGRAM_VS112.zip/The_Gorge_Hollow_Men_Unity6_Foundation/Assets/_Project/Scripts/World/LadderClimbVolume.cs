using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Simple vertical climb assist while the player stays inside the trigger.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Collider))]
    public sealed class LadderClimbVolume : MonoBehaviour
    {
        [SerializeField] private float climbSpeed = 2.8f;
        [SerializeField] private string playerTag = "Player";
        private CharacterController climber;

        private void Reset()
        {
            var col = GetComponent<Collider>();
            if (col != null) col.isTrigger = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            var cc = Resolve(other);
            if (cc != null) climber = cc;
        }

        private void OnTriggerExit(Collider other)
        {
            var cc = Resolve(other);
            if (cc != null && cc == climber) climber = null;
        }

        private void Update()
        {
            if (climber == null) return;
            float input = MobileInputState.Move.y;
#if ENABLE_LEGACY_INPUT_MANAGER
            input += Input.GetAxisRaw("Vertical");
#endif
            if (Mathf.Abs(input) < 0.1f) return;
            climber.Move(Vector3.up * (input * climbSpeed * Time.deltaTime));
        }

        private CharacterController Resolve(Collider other)
        {
            if (other == null) return null;
            if (!string.IsNullOrEmpty(playerTag) && !other.CompareTag(playerTag) &&
                other.GetComponentInParent<PlayerVitals>() == null)
                return null;
            return other.GetComponentInParent<CharacterController>();
        }
    }
}
