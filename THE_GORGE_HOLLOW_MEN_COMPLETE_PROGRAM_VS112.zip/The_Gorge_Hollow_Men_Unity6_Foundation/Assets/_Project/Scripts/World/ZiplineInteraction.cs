using System.Collections;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Moves the player along a zipline from start to end over a fixed duration.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ZiplineInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private Transform startPoint;
        [SerializeField] private Transform endPoint;
        [SerializeField] private float duration = 2.5f;
        [SerializeField] private string prompt = "Use zipline";
        [SerializeField] private bool oneWay = true;
        private bool busy;
        private bool usedForward = true;

        public string InteractionPrompt => prompt;

        public bool CanInteract(GameObject interactor)
        {
            return !busy && startPoint != null && endPoint != null &&
                   interactor != null && interactor.GetComponentInParent<CharacterController>() != null;
        }

        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            var cc = interactor.GetComponentInParent<CharacterController>();
            var movement = interactor.GetComponentInParent<PlayerMovement>();
            Transform from = usedForward ? startPoint : endPoint;
            Transform to = usedForward ? endPoint : startPoint;
            StartCoroutine(Ride(cc, movement, from.position, to.position));
            if (!oneWay) usedForward = !usedForward;
        }

        private IEnumerator Ride(CharacterController cc, PlayerMovement movement, Vector3 from, Vector3 to)
        {
            busy = true;
            if (cc != null) cc.enabled = false;
            float t = 0f;
            float d = Mathf.Max(0.1f, duration);
            while (t < 1f)
            {
                t += Time.deltaTime / d;
                if (cc != null)
                    cc.transform.position = Vector3.Lerp(from, to, Mathf.SmoothStep(0f, 1f, t));
                yield return null;
            }
            if (cc != null)
            {
                cc.transform.position = to;
                cc.enabled = true;
            }
            if (movement != null) movement.ResetAfterTeleport();
            SimpleAudioCuePlayer.PlayCue(AudioCueId.UIClick);
            MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
            busy = false;
        }
    }
}
