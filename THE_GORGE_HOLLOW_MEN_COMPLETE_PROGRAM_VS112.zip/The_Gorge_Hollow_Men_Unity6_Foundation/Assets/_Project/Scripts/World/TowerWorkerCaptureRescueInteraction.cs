using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Placed at a captive holding point. Releasing a captive restores the existing worker identity.</summary>
    [DisallowMultipleComponent]
    public sealed class TowerWorkerCaptureRescueInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private TowerWorkforceController workforce;
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private string workerIdentity;
        [SerializeField] private TowerWorkerActor workerActor;
        [SerializeField] private TowerWorkerDamageable workerDamageable;
        public string InteractionPrompt => "Rescue captured worker";
        private void Awake()
        {
            if (workforce == null) workforce = FindFirstObjectByType<TowerWorkforceController>();
            if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>();
        }
        public bool CanInteract(GameObject interactor)
        {
            TowerWorkerRecord worker = workforce != null ? TowerWorkerRules.Find(FindCampaign(), workerIdentity) : null;
            return workforce != null && worker != null && worker.status == TowerWorkerStatus.Captured && isActiveAndEnabled;
        }
        private CampaignState FindCampaign() => bootstrap != null ? bootstrap.Campaign : null;
        public void Interact(GameObject interactor)
        {
            if (!CanInteract(interactor)) return;
            if (!workforce.ReleaseCapturedWorker(workerIdentity, out string error))
            { Debug.LogWarning("Captured worker rescue rejected: " + error, this); return; }
            if (workerActor != null) { workerActor.gameObject.SetActive(true); workerActor.Bind(workerIdentity); }
            if (workerDamageable != null) { workerDamageable.gameObject.SetActive(true); workerDamageable.Bind(workerIdentity); }
            enabled = false;
            GenericToastUI.Show("Worker rescued", 2f);
            MobileHaptics.PlayImpact(MobileHapticStrength.Medium);
        }
    }
}
