using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Resolves which tower the player is physically close enough to access.
    /// It deliberately exposes only one local tower and never reports remote tower state.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class TowerLocalAccessTracker : MonoBehaviour
    {
        [SerializeField] private Transform player;
        [SerializeField] private Transform towerARoot;
        [SerializeField] private Transform towerBRoot;
        [SerializeField, Min(1f)] private float accessRadius = 18f;
        [SerializeField] private bool useLocalFootprintBounds;
        [SerializeField] private Vector2 footprintHalfExtents = new Vector2(9f, 9f);
        [SerializeField] private float footprintMinimumLocalHeight = 0.5f;
        [SerializeField] private float footprintMaximumLocalHeight = 12f;

        public string CurrentTowerId
        {
            get
            {
                if (player == null || towerARoot == null || towerBRoot == null) return null;
                if (useLocalFootprintBounds)
                    return ResolveLocalTowerIdInFootprints(towerARoot.InverseTransformPoint(player.position),
                        towerBRoot.InverseTransformPoint(player.position), footprintHalfExtents,
                        footprintMinimumLocalHeight, footprintMaximumLocalHeight);
                return ResolveLocalTowerId(player.position, towerARoot.position, towerBRoot.position, accessRadius);
            }
        }

        public Transform PlayerTransform => player;
        public bool IsConfigured => player != null && towerARoot != null && towerBRoot != null;
        public bool HasLocalTowerAccess => !string.IsNullOrEmpty(CurrentTowerId);

        public static string ResolveLocalTowerId(Vector3 playerPosition, Vector3 towerAPosition,
            Vector3 towerBPosition, float radius)
        {
            float safeRadius = Mathf.Max(1f, radius);
            float a = HorizontalDistance(playerPosition, towerAPosition);
            float b = HorizontalDistance(playerPosition, towerBPosition);
            bool inA = a <= safeRadius;
            bool inB = b <= safeRadius;
            if (inA && inB) return a <= b ? "tower_a" : "tower_b";
            if (inA) return "tower_a";
            if (inB) return "tower_b";
            return null;
        }

        public static string ResolveLocalTowerIdInFootprints(Vector3 playerLocalToA, Vector3 playerLocalToB,
            Vector2 halfExtents, float minimumLocalHeight, float maximumLocalHeight)
        {
            bool inA = IsInsideFootprint(playerLocalToA, halfExtents, minimumLocalHeight, maximumLocalHeight);
            bool inB = IsInsideFootprint(playerLocalToB, halfExtents, minimumLocalHeight, maximumLocalHeight);
            if (inA && inB)
            {
                float a = new Vector2(playerLocalToA.x, playerLocalToA.z).sqrMagnitude;
                float b = new Vector2(playerLocalToB.x, playerLocalToB.z).sqrMagnitude;
                return a <= b ? "tower_a" : "tower_b";
            }
            if (inA) return "tower_a";
            if (inB) return "tower_b";
            return null;
        }

        private static bool IsInsideFootprint(Vector3 localPosition, Vector2 halfExtents,
            float minimumLocalHeight, float maximumLocalHeight)
        {
            float halfX = Mathf.Max(0.1f, Mathf.Abs(halfExtents.x));
            float halfZ = Mathf.Max(0.1f, Mathf.Abs(halfExtents.y));
            float minY = Mathf.Min(minimumLocalHeight, maximumLocalHeight);
            float maxY = Mathf.Max(minimumLocalHeight, maximumLocalHeight);
            return Mathf.Abs(localPosition.x) <= halfX && Mathf.Abs(localPosition.z) <= halfZ &&
                   localPosition.y >= minY && localPosition.y <= maxY;
        }

        public static float HorizontalDistance(Vector3 first, Vector3 second)
        {
            first.y = 0f;
            second.y = 0f;
            return Vector3.Distance(first, second);
        }
    }
}
