using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Door that slides along a local axis between closed and open positions.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SlidingDoorInteraction : MonoBehaviour, IInteractable
    {
        [SerializeField] private Transform doorLeaf;
        [SerializeField] private Vector3 closedLocalPosition;
        [SerializeField] private Vector3 openLocalPosition = new Vector3(0f, 0f, 2f);
        [SerializeField] private float speed = 3f;
        [SerializeField] private string openPrompt = "Open";
        [SerializeField] private string closePrompt = "Close";
        [SerializeField] private Collider blockingCollider;

        private bool open;
        private Vector3 target;

        public string InteractionPrompt => open ? closePrompt : openPrompt;

        private void Awake()
        {
            if (doorLeaf == null) doorLeaf = transform;
            closedLocalPosition = doorLeaf.localPosition;
            target = closedLocalPosition;
        }

        public bool CanInteract(GameObject interactor) => doorLeaf != null;

        public void Interact(GameObject interactor)
        {
            open = !open;
            target = open ? openLocalPosition : closedLocalPosition;
            if (blockingCollider != null) blockingCollider.enabled = !open;
            SimpleAudioCuePlayer.PlayCue(AudioCueId.UIClick);
            MobileHaptics.PlayImpact(MobileHapticStrength.Light);
        }

        private void Update()
        {
            if (doorLeaf == null) return;
            doorLeaf.localPosition = Vector3.MoveTowards(
                doorLeaf.localPosition, target, speed * Time.deltaTime);
        }
    }
}
