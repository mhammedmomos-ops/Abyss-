using UnityEngine;

namespace GorgeHollow
{
    public enum AudioCueId
    {
        None,
        UIClick,
        UISave,
        WeaponFire,
        WeaponReload,
        PlayerHurt,
        PlayerDeath,
        BridgeCollapse,
        BridgeRepaired,
        Scavenge,
        RaidAlarm
    }

    /// <summary>
    /// Lightweight one-shot cue table. Assign clips in the inspector; missing clips are skipped.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SimpleAudioCuePlayer : MonoBehaviour
    {
        [System.Serializable]
        public struct CueEntry
        {
            public AudioCueId id;
            public AudioClip clip;
            [Range(0f, 1f)] public float volume;
        }

        [SerializeField] private AudioSource source;
        [SerializeField] private CueEntry[] cues;

        public static SimpleAudioCuePlayer Instance { get; private set; }

        private void Awake()
        {
            if (source == null) source = GetComponent<AudioSource>();
            if (source == null) source = gameObject.AddComponent<AudioSource>();
            source.playOnAwake = false;
            Instance = this;
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        public void Play(AudioCueId id)
        {
            if (id == AudioCueId.None || cues == null || source == null) return;
            for (int i = 0; i < cues.Length; i++)
            {
                if (cues[i].id != id || cues[i].clip == null) continue;
                float vol = cues[i].volume <= 0f ? 1f : cues[i].volume;
                source.PlayOneShot(cues[i].clip, vol);
                return;
            }
        }

        public static void PlayCue(AudioCueId id)
        {
            if (Instance != null) Instance.Play(id);
        }
    }
}
