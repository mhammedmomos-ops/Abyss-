using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Plays footstep one-shots based on CharacterController motion.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(CharacterController))]
    public sealed class FootstepAudioPlayer : MonoBehaviour
    {
        [SerializeField] private AudioSource source;
        [SerializeField] private AudioClip[] clips;
        [SerializeField] private float stepInterval = 0.45f;
        [SerializeField] private float sprintInterval = 0.32f;
        [SerializeField] private float minSpeed = 0.6f;
        [SerializeField] private PlayerMovement movement;

        private CharacterController controller;
        private float timer;

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            if (source == null) source = GetComponent<AudioSource>();
            if (movement == null) movement = GetComponent<PlayerMovement>();
        }

        private void Update()
        {
            if (controller == null || clips == null || clips.Length == 0 || source == null) return;
            Vector3 horizontal = controller.velocity; horizontal.y = 0f;
            if (!controller.isGrounded || horizontal.magnitude < minSpeed)
            {
                timer = 0f;
                return;
            }
            float interval = movement != null && movement.IsSprinting ? sprintInterval : stepInterval;
            timer += Time.deltaTime;
            if (timer < interval) return;
            timer = 0f;
            var clip = clips[Random.Range(0, clips.Length)];
            if (clip != null) source.PlayOneShot(clip, 0.7f);
        }
    }
}
