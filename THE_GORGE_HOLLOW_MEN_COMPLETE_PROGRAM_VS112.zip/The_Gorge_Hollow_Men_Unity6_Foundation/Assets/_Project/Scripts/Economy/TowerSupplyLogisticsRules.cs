using System;
using System.Collections.Generic;

namespace GorgeHollow
{
    /// <summary>Pure planning rules for tower shortages and convoy dispatch suitability. Does not move resources.</summary>
    public static class TowerSupplyLogisticsRules
    {
        public const int DefaultRepairReserveScrap = 20;
        public const int DefaultRepairReserveTimber = 12;

        public static TowerSupplyShortage Evaluate(TowerDepotRecord depot, int reserveScrap, int reserveTimber,
            int reserveAmmunition, int reserveMedicalSupplies)
        {
            if (depot == null) return new TowerSupplyShortage("unknown", 0, 0, 0, 0, true);
            reserveScrap = Math.Max(0, reserveScrap); reserveTimber = Math.Max(0, reserveTimber);
            reserveAmmunition = Math.Max(0, reserveAmmunition); reserveMedicalSupplies = Math.Max(0, reserveMedicalSupplies);
            return new TowerSupplyShortage(depot.towerId,
                Math.Max(0, reserveScrap - depot.scrap), Math.Max(0, reserveTimber - depot.timber),
                Math.Max(0, reserveAmmunition - depot.ammunition), Math.Max(0, reserveMedicalSupplies - depot.medicalSupplies), false);
        }

        public static bool TryEvaluateDispatch(TowerDepotRecord destination, SupplyConvoyRecord proposedCargo,
            bool routeAuthoredAndReachable, out string reason)
        {
            reason = null;
            if (destination == null) { reason = "Destination tower depot does not exist."; return false; }
            if (!routeAuthoredAndReachable) { reason = "No validated physical route to this tower. Dispatch is blocked."; return false; }
            if (proposedCargo == null || proposedCargo.status != SupplyConvoyStatus.Travelling ||
                string.IsNullOrWhiteSpace(proposedCargo.identity) || proposedCargo.destinationTowerId != destination.towerId ||
                !SupplyConvoyRules.HasCargo(proposedCargo) || proposedCargo.scrap < 0 || proposedCargo.timber < 0 ||
                proposedCargo.mechanicalParts < 0 || proposedCargo.electricalComponents < 0 || proposedCargo.ammunition < 0 ||
                proposedCargo.medicalSupplies < 0 || proposedCargo.petFood < 0 || proposedCargo.reagent < 0)
            { reason = "Dispatch manifest is invalid or does not match the selected destination."; return false; }
            if (!CanAdd(destination.scrap, proposedCargo.scrap) || !CanAdd(destination.timber, proposedCargo.timber) ||
                !CanAdd(destination.mechanicalParts, proposedCargo.mechanicalParts) || !CanAdd(destination.electricalComponents, proposedCargo.electricalComponents) ||
                !CanAdd(destination.ammunition, proposedCargo.ammunition) || !CanAdd(destination.medicalSupplies, proposedCargo.medicalSupplies) ||
                !CanAdd(destination.petFood, proposedCargo.petFood) || !CanAdd(destination.reagent, proposedCargo.reagent))
            { reason = "Manifest would overflow the destination depot."; return false; }
            return true;
        }

        public static List<string> BuildWarnings(TowerSupplyShortage shortage)
        {
            var warnings = new List<string>();
            if (shortage == null) { warnings.Add("Depot data unavailable."); return warnings; }
            if (shortage.InvalidDepot) { warnings.Add("Depot data unavailable."); return warnings; }
            if (shortage.ScrapDeficit > 0) warnings.Add("Scrap short by " + shortage.ScrapDeficit + " (repair reserve)");
            if (shortage.TimberDeficit > 0) warnings.Add("Timber short by " + shortage.TimberDeficit + " (repair reserve)");
            if (shortage.AmmunitionDeficit > 0) warnings.Add("Ammunition short by " + shortage.AmmunitionDeficit);
            if (shortage.MedicalDeficit > 0) warnings.Add("Medical supplies short by " + shortage.MedicalDeficit);
            if (warnings.Count == 0) warnings.Add("Reserve targets met.");
            return warnings;
        }

        private static bool CanAdd(int current, int amount) => current >= 0 && amount >= 0 && current <= int.MaxValue - amount;
    }

    public sealed class TowerSupplyShortage
    {
        public string TowerId { get; }
        public int ScrapDeficit { get; }
        public int TimberDeficit { get; }
        public int AmmunitionDeficit { get; }
        public int MedicalDeficit { get; }
        public bool InvalidDepot { get; }
        public bool HasShortage => InvalidDepot || ScrapDeficit > 0 || TimberDeficit > 0 || AmmunitionDeficit > 0 || MedicalDeficit > 0;
        public TowerSupplyShortage(string towerId, int scrap, int timber, int ammunition, int medical, bool invalid)
        { TowerId = towerId; ScrapDeficit = scrap; TimberDeficit = timber; AmmunitionDeficit = ammunition; MedicalDeficit = medical; InvalidDepot = invalid; }
    }
}
