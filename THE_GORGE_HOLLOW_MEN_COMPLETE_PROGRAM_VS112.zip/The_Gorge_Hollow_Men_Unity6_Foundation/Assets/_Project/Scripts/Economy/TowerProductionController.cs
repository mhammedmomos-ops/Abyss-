using System.Collections.Generic;
using UnityEngine;

namespace GorgeHollow
{
    /// <summary>Scene adapter for enqueue, collection and cancellation. Production progress is advanced by GameBootstrap campaign time.</summary>
    [DisallowMultipleComponent]
    public sealed class TowerProductionController : MonoBehaviour
    {
        [SerializeField] private GameBootstrap bootstrap;
        [SerializeField] private string towerId = "tower_a";
        public string TowerId => towerId;
        private void Awake() { if (bootstrap == null) bootstrap = FindFirstObjectByType<GameBootstrap>(); }

        public bool Enqueue(TowerProductionJobRecord job, out string error)
        {
            if (!HasCampaign(out error)) return false;
            TowerDepotRecord depot = TowerDepotRules.Find(bootstrap.Campaign, towerId);
            if (depot == null) { error = "Tower depot is missing."; return false; }
            int[] before = SnapshotDepot(depot);
            if (!TowerProductionRules.TryEnqueue(bootstrap.Campaign, towerId, job, out error)) return false;
            if (bootstrap.SaveCampaign()) return true;
            RestoreDepot(depot, before); bootstrap.Campaign.towerProductionJobs.Remove(job);
            error = "Save failed; production enqueue was rolled back in memory."; return false;
        }

        public bool Collect(string jobId, out string error)
        {
            if (!HasCampaign(out error)) return false;
            TowerProductionJobRecord job = FindJob(jobId);
            TowerDepotRecord depot = job == null ? null : TowerDepotRules.Find(bootstrap.Campaign, job.towerId);
            if (job == null || depot == null) { error = "Production job or depot is missing."; return false; }
            int[] before = SnapshotDepot(depot); TowerProductionStatus oldStatus = job.status;
            if (!TowerProductionRules.TryCollect(bootstrap.Campaign, jobId, out error)) return false;
            if (bootstrap.SaveCampaign()) return true;
            RestoreDepot(depot, before); job.status = oldStatus;
            error = "Save failed; production collection was rolled back in memory."; return false;
        }

        public bool Cancel(string jobId, out string error)
        {
            if (!HasCampaign(out error)) return false;
            TowerProductionJobRecord job = FindJob(jobId);
            if (job == null) { error = "Production job is missing."; return false; }
            TowerProductionStatus oldStatus = job.status;
            if (!TowerProductionRules.TryCancel(bootstrap.Campaign, jobId, out error)) return false;
            if (bootstrap.SaveCampaign()) return true;
            job.status = oldStatus; error = "Save failed; cancellation was rolled back in memory."; return false;
        }

        private TowerProductionJobRecord FindJob(string id) => bootstrap.Campaign.towerProductionJobs.Find(x => x != null && x.identity == id);
        private bool HasCampaign(out string error) { error = null; if (bootstrap == null || bootstrap.Campaign == null) { error = "GameBootstrap and loaded campaign are required."; return false; } return true; }
        private static int[] SnapshotDepot(TowerDepotRecord d) => new[] { d.scrap,d.timber,d.mechanicalParts,d.electricalComponents,d.ammunition,d.medicalSupplies,d.petFood,d.reagent };
        private static void RestoreDepot(TowerDepotRecord d,int[] v) { d.scrap=v[0];d.timber=v[1];d.mechanicalParts=v[2];d.electricalComponents=v[3];d.ammunition=v[4];d.medicalSupplies=v[5];d.petFood=v[6];d.reagent=v[7]; }
        private sealed class JobSnapshot
        {
            private readonly TowerProductionJobRecord job; private readonly int remaining; private readonly TowerProductionStatus status;
            public JobSnapshot(TowerProductionJobRecord value) { job=value; remaining=value.remainingMinutes; status=value.status; }
            public void Restore() { job.remainingMinutes=remaining; job.status=status; }
        }
    }
}
