namespace GorgeHollow
{
    public enum SupplyRouteThreatLevel { Clear, Watch, Dangerous, Critical }

    /// <summary>Pure, allocation-free threat scoring for physical inter-tower supply routes.</summary>
    public static class SupplyTransferThreatRules
    {
        public static SupplyRouteThreatLevel Evaluate(int nearbyHostiles, int hostileAttackers, float nearestHostileDistance,
            float scanRadius, float carrierHealthFraction)
        {
            if (nearbyHostiles < 0 || hostileAttackers < 0 || hostileAttackers > nearbyHostiles ||
                float.IsNaN(nearestHostileDistance) || float.IsInfinity(nearestHostileDistance) ||
                float.IsNaN(scanRadius) || float.IsInfinity(scanRadius) || scanRadius <= 0f ||
                float.IsNaN(carrierHealthFraction) || float.IsInfinity(carrierHealthFraction))
                return SupplyRouteThreatLevel.Critical;
            if (nearbyHostiles == 0) return SupplyRouteThreatLevel.Clear;
            float health = carrierHealthFraction < 0f ? 0f : carrierHealthFraction > 1f ? 1f : carrierHealthFraction;
            bool close = nearestHostileDistance >= 0f && nearestHostileDistance <= scanRadius * 0.35f;
            if (hostileAttackers >= 2 || (close && health <= 0.35f) || nearbyHostiles >= 5)
                return SupplyRouteThreatLevel.Critical;
            if (hostileAttackers >= 1 || (close && health <= 0.65f) || nearbyHostiles >= 3)
                return SupplyRouteThreatLevel.Dangerous;
            return SupplyRouteThreatLevel.Watch;
        }

        public static float EscortDamageMultiplier(int operationalEscorts, int maximumEscorts)
        {
            if (maximumEscorts <= 0 || operationalEscorts <= 0) return 1f;
            if (operationalEscorts > maximumEscorts) operationalEscorts = maximumEscorts;
            // Each active escort provides a bounded 12% reduction; never grants immunity.
            float reduction = operationalEscorts * 0.12f;
            return reduction > 0.48f ? 0.52f : 1f - reduction;
        }

        public static float ApplyEscortMitigation(float incomingDamage, int operationalEscorts, int maximumEscorts)
        {
            if (incomingDamage <= 0f || float.IsNaN(incomingDamage) || float.IsInfinity(incomingDamage)) return 0f;
            return incomingDamage * EscortDamageMultiplier(operationalEscorts, maximumEscorts);
        }
    }
}
