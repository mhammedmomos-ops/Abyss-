namespace GorgeHollow
{
    /// <summary>Pure validation and presentation rules for persisted convoy tactical orders.</summary>
    public static class SupplyConvoyCommandRules
    {
        public static bool IsValid(SupplyConvoyCommand command) =>
            command == SupplyConvoyCommand.Advance || command == SupplyConvoyCommand.Hold ||
            command == SupplyConvoyCommand.FocusFire;

        public static string GetDescription(SupplyConvoyCommand command)
        {
            switch (command)
            {
                case SupplyConvoyCommand.Hold: return "HOLD — carrier stops; escorts remain active";
                case SupplyConvoyCommand.FocusFire: return "FOCUS FIRE — escorts hit harder; carrier advances cautiously";
                case SupplyConvoyCommand.Advance: return "ADVANCE — carrier resumes route movement";
                default: return "INVALID ORDER";
            }
        }

        public static float MovementMultiplier(SupplyConvoyCommand command)
        {
            switch (command)
            {
                case SupplyConvoyCommand.Hold: return 0f;
                case SupplyConvoyCommand.FocusFire: return 0.85f;
                case SupplyConvoyCommand.Advance: return 1.25f;
                default: return 0f;
            }
        }

        public static float EscortDamageMultiplier(SupplyConvoyCommand command) =>
            command == SupplyConvoyCommand.FocusFire ? 1.35f : 1f;
    }
}
