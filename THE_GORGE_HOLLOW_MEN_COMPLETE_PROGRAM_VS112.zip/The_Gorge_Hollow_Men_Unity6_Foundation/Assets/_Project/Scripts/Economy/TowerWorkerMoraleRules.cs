using System;

namespace GorgeHollow
{
    public enum WorkerMoraleEvent { ProtectedDuringRaid, RescuedFromCapture, Treated, AbandonedInOverrun, Captured, WitnessedWorkerDeath, CompletedDuty }

    /// <summary>Deterministic bounded morale, trust and stress. No random rolls and no resource creation.</summary>
    public static class TowerWorkerMoraleRules
    {
        public const int DangerousAssignmentMoraleFloor = 20;
        public const int DangerousAssignmentStressCeiling = 85;
        public const int DangerousAssignmentLoyaltyFloor = 15;
        public static int Clamp(int value) => Math.Max(0, Math.Min(100, value));

        public static void ApplyEvent(TowerWorkerRecord worker, WorkerMoraleEvent evt)
        {
            if (worker == null || worker.status == TowerWorkerStatus.Dead) return;
            switch (evt)
            {
                case WorkerMoraleEvent.ProtectedDuringRaid: Change(worker, 8, 5, -8); break;
                case WorkerMoraleEvent.RescuedFromCapture: Change(worker, 18, 12, -20); break;
                case WorkerMoraleEvent.Treated: Change(worker, 5, 2, -6); break;
                case WorkerMoraleEvent.AbandonedInOverrun: Change(worker, -12, -8, 18); break;
                case WorkerMoraleEvent.Captured: Change(worker, -15, -10, 25); break;
                case WorkerMoraleEvent.WitnessedWorkerDeath: Change(worker, -6, -3, 12); break;
                case WorkerMoraleEvent.CompletedDuty: Change(worker, 2, 1, -1); break;
            }
        }

        private static void Change(TowerWorkerRecord worker, int morale, int loyalty, int stress)
        {
            worker.morale = Clamp(worker.morale + morale);
            worker.loyalty = Clamp(worker.loyalty + loyalty);
            worker.stress = Clamp(worker.stress + stress);
        }

        public static bool ShouldRefuseDangerousAssignment(TowerWorkerRecord worker, out string reason)
        {
            reason = null;
            if (worker == null) { reason = "Worker record is unavailable."; return true; }
            if (worker.morale < DangerousAssignmentMoraleFloor)
            { reason = "Morale is too low for a dangerous assignment. Provide rest, protection or successful support."; return true; }
            if (worker.stress >= DangerousAssignmentStressCeiling)
            { reason = "Stress is too high for a dangerous assignment. Allow recovery before redeployment."; return true; }
            if (worker.loyalty < DangerousAssignmentLoyaltyFloor)
            { reason = "Trust is too low for a dangerous assignment. Rebuild trust through protection and successful support."; return true; }
            return false;
        }

        public static void AdvanceRecovery(TowerWorkerRecord worker, int elapsedMinutes)
        {
            if (worker == null || elapsedMinutes <= 0 || worker.status == TowerWorkerStatus.Dead || worker.status == TowerWorkerStatus.Captured) return;
            if (worker.assignment != TowerWorkerAssignment.Rest && worker.status != TowerWorkerStatus.Injured) return;
            long total = (long)worker.recoveryMinutes + elapsedMinutes;
            int intervals = (int)Math.Min(int.MaxValue, total / 60L);
            worker.recoveryMinutes = (int)(total % 60L);
            if (intervals <= 0) return;
            worker.stress = Clamp(worker.stress - intervals * 2);
            worker.morale = Clamp(worker.morale + intervals);
            if (worker.loyalty < 100 && worker.morale >= 60) worker.loyalty = Clamp(worker.loyalty + intervals / 4);
        }
    }
}
