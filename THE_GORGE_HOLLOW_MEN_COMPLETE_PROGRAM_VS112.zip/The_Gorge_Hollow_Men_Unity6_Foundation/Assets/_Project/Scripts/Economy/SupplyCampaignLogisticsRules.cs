using System;
using System.Collections.Generic;

namespace GorgeHollow
{
    public enum SupplyLogisticsPriority { Stable = 0, Monitor = 1, High = 2, Critical = 3 }

    [Serializable]
    public sealed class TowerLogisticsAssessment
    {
        public string towerId;
        public SupplyLogisticsPriority priority;
        public int score;
        public int scrapShortage;
        public int timberShortage;
        public int ammunitionShortage;
        public int medicalShortage;
        public int incomingTransfers;
        public string summary;
    }

    /// <summary>Read-only campaign dispatch planning. Incoming travelling cargo is counted to avoid duplicate dispatch recommendations.</summary>
    public static class SupplyCampaignLogisticsRules
    {
        public const int MaximumConcurrentInterTowerTransfers = 3;
        public const int ScrapReserve = 20;
        public const int TimberReserve = 12;
        public const int AmmunitionReserve = 20;
        public const int MedicalReserve = 5;

        public static int CountActiveTransfers(CampaignState campaign)
        {
            int count = 0;
            if (campaign?.supplyConvoys == null) return count;
            for (int i = 0; i < campaign.supplyConvoys.Count; i++)
            {
                SupplyConvoyRecord c = campaign.supplyConvoys[i];
                if (c != null && c.isInterTowerTransfer && c.status == SupplyConvoyStatus.Travelling) count++;
            }
            return count;
        }

        public static bool CanDispatchAnotherTransfer(CampaignState campaign, out string error)
        {
            error = null;
            if (campaign == null) { error = "Campaign state is unavailable."; return false; }
            if (CountActiveTransfers(campaign) >= MaximumConcurrentInterTowerTransfers)
            { error = "All three inter-tower transfer slots are occupied. Wait for a delivery or loss before dispatching another carrier."; return false; }
            return true;
        }

        public static List<TowerLogisticsAssessment> AssessBothTowers(CampaignState campaign)
        {
            var results = new List<TowerLogisticsAssessment>(2);
            AddAssessment(campaign, "tower_a", results);
            AddAssessment(campaign, "tower_b", results);
            results.Sort((a, b) => b.score.CompareTo(a.score));
            return results;
        }

        public static TowerLogisticsAssessment AssessTower(CampaignState campaign, string towerId)
        {
            var result = new List<TowerLogisticsAssessment>(1);
            AddAssessment(campaign, towerId, result);
            return result.Count == 0 ? null : result[0];
        }

        private static void AddAssessment(CampaignState campaign, string towerId, List<TowerLogisticsAssessment> output)
        {
            TowerDepotRecord depot = TowerDepotRules.Find(campaign, towerId);
            if (depot == null) return;
            int inScrap = 0, inTimber = 0, inAmmo = 0, inMedical = 0, incoming = 0;
            if (campaign.supplyConvoys != null)
                for (int i = 0; i < campaign.supplyConvoys.Count; i++)
                {
                    SupplyConvoyRecord c = campaign.supplyConvoys[i];
                    if (c == null || !c.isInterTowerTransfer || c.status != SupplyConvoyStatus.Travelling || c.destinationTowerId != towerId) continue;
                    incoming++; inScrap = SafeAdd(inScrap, c.scrap); inTimber = SafeAdd(inTimber, c.timber);
                    inAmmo = SafeAdd(inAmmo, c.ammunition); inMedical = SafeAdd(inMedical, c.medicalSupplies);
                }
            int scrap = Deficit(depot.scrap, inScrap, ScrapReserve);
            int timber = Deficit(depot.timber, inTimber, TimberReserve);
            int ammo = Deficit(depot.ammunition, inAmmo, AmmunitionReserve);
            int medical = Deficit(depot.medicalSupplies, inMedical, MedicalReserve);
            int score = scrap * 1 + timber * 2 + ammo * 2 + medical * 4;
            SupplyLogisticsPriority priority = score >= 60 ? SupplyLogisticsPriority.Critical :
                score >= 30 ? SupplyLogisticsPriority.High : score > 0 ? SupplyLogisticsPriority.Monitor : SupplyLogisticsPriority.Stable;
            output.Add(new TowerLogisticsAssessment { towerId = towerId, priority = priority, score = score,
                scrapShortage = scrap, timberShortage = timber, ammunitionShortage = ammo,
                medicalShortage = medical, incomingTransfers = incoming,
                summary = BuildSummary(priority, scrap, timber, ammo, medical, incoming) });
        }

        private static int Deficit(int stock, int incoming, int reserve)
        {
            long effective = (long)Math.Max(0, stock) + Math.Max(0, incoming);
            return (int)Math.Max(0L, reserve - Math.Min((long)int.MaxValue, effective));
        }
        private static int SafeAdd(int a, int b) => (int)Math.Min(int.MaxValue, (long)Math.Max(0, a) + Math.Max(0, b));
        private static string BuildSummary(SupplyLogisticsPriority p, int s, int t, int a, int m, int incoming)
        {
            if (p == SupplyLogisticsPriority.Stable) return incoming > 0 ? "Reserves covered, including inbound cargo." : "Reserve levels are stable.";
            return p.ToString().ToUpperInvariant() + " · shortages S" + s + " T" + t + " A" + a + " M" + m +
                (incoming > 0 ? " · " + incoming + " inbound transfer(s) counted" : " · no inbound transfer");
        }
    }
}
