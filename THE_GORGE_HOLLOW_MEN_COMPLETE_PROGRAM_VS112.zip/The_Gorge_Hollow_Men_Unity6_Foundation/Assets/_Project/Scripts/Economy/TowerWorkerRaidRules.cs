using System;
using System.Collections.Generic;

namespace GorgeHollow
{
    [Serializable]
    public sealed class TowerWorkerRaidOrder
    {
        public string workerIdentity;
        public TowerWorkerTacticalState state;
        public TowerWorkerRaidOrder(string identity, TowerWorkerTacticalState tacticalState)
        { workerIdentity = identity; state = tacticalState; }
    }

    /// <summary>Deterministic role-aware raid posture policy. Movement and threat geometry remain scene-authored.</summary>
    public static class TowerWorkerRaidRules
    {
        public static TowerWorkerTacticalState ChoosePosture(TowerWorkerRecord worker)
        {
            if (worker == null || worker.status == TowerWorkerStatus.Dead || worker.status == TowerWorkerStatus.Captured) return TowerWorkerTacticalState.Normal;
            if (worker.status == TowerWorkerStatus.Injured || worker.assignment == TowerWorkerAssignment.Rest || worker.fatigue >= 100)
                return TowerWorkerTacticalState.Evacuating;
            if (worker.role == TowerWorkerRole.Guard && worker.assignment == TowerWorkerAssignment.Guard)
                return TowerWorkerTacticalState.Defending;
            if (worker.role == TowerWorkerRole.Medic)
                return TowerWorkerTacticalState.AssistingInjured;
            if (worker.role == TowerWorkerRole.Mechanic || worker.role == TowerWorkerRole.Scavenger)
                return TowerWorkerTacticalState.Evacuating;
            return TowerWorkerTacticalState.Evacuating;
        }

        public static List<TowerWorkerRaidOrder> BuildOrders(IEnumerable<TowerWorkerRecord> workers, string towerId)
        {
            var result = new List<TowerWorkerRaidOrder>();
            if (workers == null || (towerId != "tower_a" && towerId != "tower_b")) return result;
            var snapshot = new List<TowerWorkerRecord>();
            foreach (TowerWorkerRecord worker in workers) snapshot.Add(worker);
            bool hasInjuredWorker = false;
            foreach (TowerWorkerRecord worker in snapshot)
                if (worker != null && worker.towerId == towerId && worker.status == TowerWorkerStatus.Injured) { hasInjuredWorker = true; break; }
            foreach (TowerWorkerRecord worker in snapshot)
            {
                if (worker == null || worker.towerId != towerId || worker.status == TowerWorkerStatus.Dead || worker.status == TowerWorkerStatus.Captured || worker.playerOverrideDuringRaid) continue;
                TowerWorkerTacticalState posture = worker.role == TowerWorkerRole.Medic && !hasInjuredWorker
                    ? TowerWorkerTacticalState.Evacuating : ChoosePosture(worker);
                result.Add(new TowerWorkerRaidOrder(worker.identity, posture));
            }
            return result;
        }

        public static TowerWorkerRecord FindMostInjured(IEnumerable<TowerWorkerRecord> workers, string towerId)
        {
            TowerWorkerRecord best = null;
            if (workers == null) return null;
            foreach (TowerWorkerRecord worker in workers)
            {
                if (worker == null || worker.towerId != towerId || worker.status != TowerWorkerStatus.Injured) continue;
                if (best == null || worker.health < best.health) best = worker;
            }
            return best;
        }
    }
}
