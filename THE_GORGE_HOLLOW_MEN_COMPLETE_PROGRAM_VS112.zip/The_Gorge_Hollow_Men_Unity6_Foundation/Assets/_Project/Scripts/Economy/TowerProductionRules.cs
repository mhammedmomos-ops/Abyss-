using System;
using System.Collections.Generic;
using System.Linq;

namespace GorgeHollow
{
    /// <summary>Deterministic tower-local production queue. Costs are paid at enqueue; outputs only on collection.</summary>
    public static class TowerProductionRules
    {
        public const int MaxQueuedJobsPerTower = 3;

        public static bool TryEnqueue(CampaignState campaign, string towerId, TowerProductionJobRecord job, out string error)
        {
            error = null;
            if (campaign == null || job == null || string.IsNullOrWhiteSpace(job.identity) ||
                (towerId != "tower_a" && towerId != "tower_b") || job.durationMinutes < 1 ||
                job.status != TowerProductionStatus.Queued || job.remainingMinutes != job.durationMinutes ||
                job.costScrap < 0 || job.costTimber < 0 || job.costMechanicalParts < 0 || job.costElectricalComponents < 0 ||
                job.costAmmunition < 0 || job.costMedicalSupplies < 0 || job.costPetFood < 0 || job.costReagent < 0 ||
                (job.costScrap == 0 && job.costTimber == 0 && job.costMechanicalParts == 0 && job.costElectricalComponents == 0 && job.costAmmunition == 0 && job.costMedicalSupplies == 0 && job.costPetFood == 0 && job.costReagent == 0) ||
                job.yieldScrap < 0 || job.yieldTimber < 0 || job.yieldMechanicalParts < 0 || job.yieldElectricalComponents < 0 ||
                job.yieldAmmunition < 0 || job.yieldMedicalSupplies < 0 || job.yieldPetFood < 0 || job.yieldReagent < 0 || !HasYield(job)) { error = "Production job definition is invalid."; return false; }
            if (campaign.towerProductionJobs == null) campaign.towerProductionJobs = new List<TowerProductionJobRecord>();
            if (campaign.towerProductionJobs.Any(x => x != null && x.identity == job.identity)) { error = "Production job identity already exists."; return false; }
            if (campaign.towerProductionJobs.Count(x => x != null && x.towerId == towerId &&
                (x.status == TowerProductionStatus.Queued || x.status == TowerProductionStatus.ReadyToCollect)) >= MaxQueuedJobsPerTower)
            { error = "This tower's production queue is full."; return false; }
            TowerDepotRecord depot = TowerDepotRules.Find(campaign, towerId);
            if (depot == null || !CanSpend(depot, job)) { error = "The local tower depot cannot afford this production recipe."; return false; }
            Spend(depot, job);
            job.towerId = towerId;
            campaign.towerProductionJobs.Add(job);
            return true;
        }

        public static int Advance(CampaignState campaign, string towerId, int elapsedMinutes)
        {
            if (campaign?.towerProductionJobs == null || elapsedMinutes <= 0) return 0;
            int completed = 0;
            float remainingElapsed = elapsedMinutes;
            foreach (var job in campaign.towerProductionJobs.Where(x => x != null && x.towerId == towerId && x.status == TowerProductionStatus.Queued).OrderBy(x => campaign.towerProductionJobs.IndexOf(x)))
            {
                if (remainingElapsed <= 0f) break;
                float rate = TowerWorkerRules.ProductionRate(campaign, towerId);
                float availableWork = job.workProgressMinutes + remainingElapsed * rate;
                int workDone = Math.Min(job.remainingMinutes, (int)Math.Floor(availableWork));
                job.remainingMinutes -= workDone;
                if (job.remainingMinutes == 0)
                {
                    float leftoverWork = availableWork - workDone;
                    job.workProgressMinutes = 0f;
                    job.status = TowerProductionStatus.ReadyToCollect;
                    completed++;
                    remainingElapsed = leftoverWork / rate;
                }
                else
                {
                    job.workProgressMinutes = availableWork - workDone;
                    remainingElapsed = 0f;
                }
            }
            return completed;
        }

        public static bool TryCollect(CampaignState campaign, string jobId, out string error)
        {
            error = null;
            var job = campaign?.towerProductionJobs?.FirstOrDefault(x => x != null && x.identity == jobId);
            if (job == null || job.status != TowerProductionStatus.ReadyToCollect) { error = "Production job is not ready for collection."; return false; }
            var depot = TowerDepotRules.Find(campaign, job.towerId);
            if (depot == null || !CanAdd(depot.scrap, job.yieldScrap) || !CanAdd(depot.timber, job.yieldTimber) ||
                !CanAdd(depot.mechanicalParts, job.yieldMechanicalParts) || !CanAdd(depot.electricalComponents, job.yieldElectricalComponents) ||
                !CanAdd(depot.ammunition, job.yieldAmmunition) || !CanAdd(depot.medicalSupplies, job.yieldMedicalSupplies) ||
                !CanAdd(depot.petFood, job.yieldPetFood) || !CanAdd(depot.reagent, job.yieldReagent))
            { error = "Destination depot lacks capacity; output remains ready and is not lost."; return false; }
            depot.scrap += job.yieldScrap; depot.timber += job.yieldTimber;
            depot.mechanicalParts += job.yieldMechanicalParts; depot.electricalComponents += job.yieldElectricalComponents;
            depot.ammunition += job.yieldAmmunition; depot.medicalSupplies += job.yieldMedicalSupplies;
            depot.petFood += job.yieldPetFood; depot.reagent += job.yieldReagent;
            job.status = TowerProductionStatus.Completed;
            return true;
        }

        public static bool TryCancel(CampaignState campaign, string jobId, out string error)
        {
            error = null;
            var job = campaign?.towerProductionJobs?.FirstOrDefault(x => x != null && x.identity == jobId);
            if (job == null || job.status != TowerProductionStatus.Queued) { error = "Only queued, not-yet-started production can be cancelled."; return false; }
            job.status = TowerProductionStatus.Cancelled;
            return true; // Inputs are consumed; cancellation does not mint a refund.
        }

        private static bool HasYield(TowerProductionJobRecord j) => j.yieldScrap > 0 || j.yieldTimber > 0 || j.yieldMechanicalParts > 0 || j.yieldElectricalComponents > 0 || j.yieldAmmunition > 0 || j.yieldMedicalSupplies > 0 || j.yieldPetFood > 0 || j.yieldReagent > 0;
        private static bool CanSpend(TowerDepotRecord d, TowerProductionJobRecord j) => d.scrap >= j.costScrap && d.timber >= j.costTimber && d.mechanicalParts >= j.costMechanicalParts && d.electricalComponents >= j.costElectricalComponents && d.ammunition >= j.costAmmunition && d.medicalSupplies >= j.costMedicalSupplies && d.petFood >= j.costPetFood && d.reagent >= j.costReagent;
        private static void Spend(TowerDepotRecord d, TowerProductionJobRecord j) { d.scrap-=j.costScrap; d.timber-=j.costTimber; d.mechanicalParts-=j.costMechanicalParts; d.electricalComponents-=j.costElectricalComponents; d.ammunition-=j.costAmmunition; d.medicalSupplies-=j.costMedicalSupplies; d.petFood-=j.costPetFood; d.reagent-=j.costReagent; }
        private static bool CanAdd(int a, int b) => a >= 0 && b >= 0 && a <= int.MaxValue - b;
    }
}
