using System;
using System.Collections.Generic;
using System.Linq;

namespace GorgeHollow
{
    /// <summary>Deterministic rules for isolated tower stockpiles.</summary>
    public static class TowerDepotRules
    {
        public static List<TowerDepotRecord> CreateStartingDepots() => new List<TowerDepotRecord>
        {
            new TowerDepotRecord { towerId = "tower_a" },
            new TowerDepotRecord { towerId = "tower_b" }
        };

        public static TowerDepotRecord Find(CampaignState campaign, string towerId) =>
            campaign?.towerDepots?.FirstOrDefault(x => x != null && x.towerId == towerId);

        public static bool TryDeposit(TowerDepotRecord depot, SupplyConvoyRecord convoy, out string error)
        {
            error = null;
            if (depot == null || convoy == null || convoy.status != SupplyConvoyStatus.Travelling ||
                string.IsNullOrWhiteSpace(convoy.destinationTowerId) || depot.towerId != convoy.destinationTowerId ||
                !SupplyConvoyRules.HasCargo(convoy))
            { error = "Convoy destination, status, or cargo does not match this tower depot."; return false; }
            if (!CanAdd(depot.scrap, convoy.scrap) || !CanAdd(depot.timber, convoy.timber) ||
                !CanAdd(depot.mechanicalParts, convoy.mechanicalParts) || !CanAdd(depot.electricalComponents, convoy.electricalComponents) ||
                !CanAdd(depot.ammunition, convoy.ammunition) || !CanAdd(depot.medicalSupplies, convoy.medicalSupplies) ||
                !CanAdd(depot.petFood, convoy.petFood) || !CanAdd(depot.reagent, convoy.reagent))
            { error = "Delivery would exceed this tower depot's resource limit."; return false; }
            depot.scrap += convoy.scrap; depot.timber += convoy.timber;
            depot.mechanicalParts += convoy.mechanicalParts; depot.electricalComponents += convoy.electricalComponents;
            depot.ammunition += convoy.ammunition; depot.medicalSupplies += convoy.medicalSupplies;
            depot.petFood += convoy.petFood; depot.reagent += convoy.reagent;
            return true;
        }

        public static bool TrySpendRepairMaterials(TowerDepotRecord depot, int scrap, int timber, out string error)
        {
            error = null;
            if (depot == null || scrap < 0 || timber < 0) { error = "A valid tower depot and non-negative repair costs are required."; return false; }
            if (depot.scrap < scrap || depot.timber < timber)
            { error = "This tower's depot lacks repair materials. Supplies at the other tower cannot be used."; return false; }
            depot.scrap -= scrap; depot.timber -= timber;
            return true;
        }

        private static bool CanAdd(int current, int amount) => current >= 0 && amount >= 0 && current <= int.MaxValue - amount;
    }
}
