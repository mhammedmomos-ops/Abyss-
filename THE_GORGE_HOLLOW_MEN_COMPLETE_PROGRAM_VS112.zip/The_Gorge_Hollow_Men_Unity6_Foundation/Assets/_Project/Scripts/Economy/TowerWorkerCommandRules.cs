using System.Collections.Generic;

namespace GorgeHollow
{
    /// <summary>Pure eligibility and roster filtering for the mobile workforce command panel.</summary>
    public static class TowerWorkerCommandRules
    {
        public static List<TowerWorkerRecord> GetCommandableWorkers(CampaignState campaign, string localTowerId)
        {
            var result = new List<TowerWorkerRecord>();
            if (campaign?.towerWorkers == null ||
                (localTowerId != "tower_a" && localTowerId != "tower_b")) return result;
            foreach (TowerWorkerRecord worker in campaign.towerWorkers)
            {
                if (worker == null || string.IsNullOrWhiteSpace(worker.identity) || worker.towerId != localTowerId ||
                    worker.status == TowerWorkerStatus.Dead || worker.status == TowerWorkerStatus.Captured)
                    continue;
                result.Add(worker);
            }
            return result;
        }

        public static bool CanAssign(CampaignState campaign, string workerIdentity, string localTowerId,
            TowerWorkerAssignment assignment, out string reason)
        {
            reason = null;
            if (localTowerId != "tower_a" && localTowerId != "tower_b")
            { reason = "You must be inside a tower to issue workforce orders."; return false; }
            TowerWorkerRecord worker = TowerWorkerRules.Find(campaign, workerIdentity);
            if (worker == null || worker.towerId != localTowerId)
            { reason = "You can only issue orders to workers at your current tower."; return false; }
            return CanAssign(campaign, workerIdentity, assignment, out reason);
        }

        public static bool CanAssign(CampaignState campaign, string workerIdentity,
            TowerWorkerAssignment assignment, out string reason)
        {
            reason = null;
            TowerWorkerRecord worker = TowerWorkerRules.Find(campaign, workerIdentity);
            if (worker == null || worker.status == TowerWorkerStatus.Dead ||
                worker.status == TowerWorkerStatus.Captured ||
                !System.Enum.IsDefined(typeof(TowerWorkerAssignment), assignment))
            { reason = "A living workforce member and valid assignment are required."; return false; }
            if (worker.status == TowerWorkerStatus.Injured && assignment != TowerWorkerAssignment.Rest)
            { reason = "An injured worker must remain on medical rest."; return false; }
            if (worker.fatigue >= 100 && assignment != TowerWorkerAssignment.Rest)
            { reason = "An exhausted worker must rest before returning to duty."; return false; }
            if ((assignment == TowerWorkerAssignment.Guard || assignment == TowerWorkerAssignment.Salvage) &&
                TowerWorkerMoraleRules.ShouldRefuseDangerousAssignment(worker, out reason)) return false;

            int assigned = 0;
            if (campaign.towerWorkers != null)
                foreach (TowerWorkerRecord other in campaign.towerWorkers)
                    if (other != null && other.identity != worker.identity && other.towerId == worker.towerId &&
                        other.status == TowerWorkerStatus.Active && other.assignment == assignment) assigned++;
            int limit = assignment == TowerWorkerAssignment.Production ? TowerWorkerRules.MaxProductionWorkers :
                assignment == TowerWorkerAssignment.Salvage ? TowerWorkerRules.MaxSalvageWorkers :
                assignment == TowerWorkerAssignment.Guard ? TowerWorkerRules.MaxGuardWorkers : int.MaxValue;
            if (assigned >= limit)
            { reason = "That tower has no available slot for this assignment."; return false; }
            return true;
        }
    }
}
