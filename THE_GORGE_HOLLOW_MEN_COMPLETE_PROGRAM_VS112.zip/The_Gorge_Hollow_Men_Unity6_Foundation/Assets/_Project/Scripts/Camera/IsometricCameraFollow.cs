using UnityEngine;

namespace GorgeHollow
{
    public sealed class IsometricCameraFollow : MonoBehaviour
    {
        [SerializeField] private Transform target;
        [SerializeField] private Vector3 offset = new Vector3(0f, 12f, -10f);
        [SerializeField] private float followSharpness = 8f;
        [SerializeField] private float lookHeight = 1.2f;
        [SerializeField, Min(0f)] private float aimForwardDistance;
        [SerializeField] private bool rotateWithTarget;
        private float yawOffset;
        public void AddYaw(float degrees) { yawOffset = Mathf.Repeat(yawOffset + degrees, 360f); }
        private void LateUpdate()
        {
            if (target == null) return;
            Quaternion yaw = Quaternion.Euler(0f, yawOffset, 0f);
            Vector3 desiredOffset = yaw * (rotateWithTarget ? target.rotation * offset : offset);
            Vector3 desiredPosition = target.position + desiredOffset;
            float blend = 1f - Mathf.Exp(-followSharpness * Time.deltaTime);
            transform.position = Vector3.Lerp(transform.position, desiredPosition, blend);
            Vector3 lookPoint = target.position + Vector3.up * lookHeight + target.forward * aimForwardDistance;
            Vector3 direction = lookPoint - transform.position;
            if (direction.sqrMagnitude > 0.001f) transform.rotation = Quaternion.LookRotation(direction.normalized, Vector3.up);
        }
        public void SetTarget(Transform newTarget) => target = newTarget;
    }
}
