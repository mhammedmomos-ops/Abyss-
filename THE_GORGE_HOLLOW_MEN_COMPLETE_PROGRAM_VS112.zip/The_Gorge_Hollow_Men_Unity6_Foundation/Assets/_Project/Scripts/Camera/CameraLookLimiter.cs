using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Optional pitch clamp helper for non-isometric camera modes.
    /// IsometricCameraFollow uses yaw only; this is for future FPS/hybrid aims.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class CameraLookLimiter : MonoBehaviour
    {
        [SerializeField] private float minPitch = -40f;
        [SerializeField] private float maxPitch = 70f;
        private float pitch;

        public void AddPitch(float delta)
        {
            pitch = Mathf.Clamp(pitch + delta, minPitch, maxPitch);
            var e = transform.localEulerAngles;
            e.x = pitch;
            transform.localEulerAngles = e;
        }

        public void SetPitch(float value)
        {
            pitch = Mathf.Clamp(value, minPitch, maxPitch);
        }
    }
}
