using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Temporary FOV zoom for watchtower / binocular use on mobile (hold button).
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class BinocularZoom : MonoBehaviour
    {
        [SerializeField] private Camera targetCamera;
        [SerializeField] private float normalFov = 60f;
        [SerializeField] private float zoomFov = 28f;
        [SerializeField] private float zoomSpeed = 8f;
        private bool zooming;

        private void Awake()
        {
            if (targetCamera == null) targetCamera = Camera.main;
            if (targetCamera != null) normalFov = targetCamera.fieldOfView;
        }

        public void SetZooming(bool value) => zooming = value;

        public void OnZoomDown() => zooming = true;
        public void OnZoomUp() => zooming = false;

        private void LateUpdate()
        {
            if (targetCamera == null) return;
            float target = zooming ? zoomFov : normalFov;
            targetCamera.fieldOfView = Mathf.Lerp(targetCamera.fieldOfView, target, 1f - Mathf.Exp(-zoomSpeed * Time.deltaTime));
        }

        private void OnDisable()
        {
            zooming = false;
            if (targetCamera != null) targetCamera.fieldOfView = normalFov;
        }
    }
}
