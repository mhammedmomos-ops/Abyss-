using UnityEngine;

namespace GorgeHollow
{
    /// <summary>
    /// Lightweight positional camera shake. Attach beside IsometricCameraFollow.
    /// </summary>
    [DisallowMultipleComponent]
    [DefaultExecutionOrder(100)]
    public sealed class CameraShake : MonoBehaviour
    {
        [SerializeField] private float traumaDecay = 1.4f;
        [SerializeField] private float maxOffset = 0.35f;
        [SerializeField] private float maxYaw = 2.5f;

        private float trauma;
        public static CameraShake Instance { get; private set; }

        private void Awake() => Instance = this;
        private void OnDestroy() { if (Instance == this) Instance = null; }

        public void AddTrauma(float amount)
        {
            trauma = Mathf.Clamp01(trauma + Mathf.Max(0f, amount));
        }

        public static void Shake(float amount)
        {
            if (Instance != null) Instance.AddTrauma(amount);
        }

        private void LateUpdate()
        {
            if (trauma <= 0f) return;
            float shake = trauma * trauma;
            float ox = (Mathf.PerlinNoise(Time.time * 18f, 0.1f) * 2f - 1f) * maxOffset * shake;
            float oy = (Mathf.PerlinNoise(0.3f, Time.time * 18f) * 2f - 1f) * maxOffset * shake;
            float yaw = (Mathf.PerlinNoise(Time.time * 14f, 0.7f) * 2f - 1f) * maxYaw * shake;
            transform.position += new Vector3(ox, oy, 0f);
            transform.rotation *= Quaternion.Euler(0f, yaw, 0f);
            trauma = Mathf.Max(0f, trauma - traumaDecay * Time.deltaTime);
        }
    }
}
