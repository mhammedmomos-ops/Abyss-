using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS64MissingCompanionSeparationTests
    {
        [Test]
        public void SeparatedCompanionCanBecomeMissingDuringRaidWhenNoCompleteRouteExists()
        {
            Assert.IsTrue(AnimalSeparationRules.ShouldAccumulate(CampaignPhase.ActiveRaid,
                AnimalStatus.Alive, AnimalCommand.Follow, true, false));
        }

        [Test]
        public void ThreatResolutionAlsoCountsAsDangerousExtractionPhase()
        {
            Assert.IsTrue(AnimalSeparationRules.ShouldAccumulate(CampaignPhase.ThreatResolution,
                AnimalStatus.Alive, AnimalCommand.Protect, true, false));
        }

        [TestCase(CampaignPhase.RecoveryPreparation)]
        [TestCase(CampaignPhase.ThreatDevelopment)]
        [TestCase(CampaignPhase.DawnReview)]
        [TestCase(CampaignPhase.Completed)]
        public void SeparationOutsideActiveRaidOrThreatResolutionNeverMarksPetMissing(CampaignPhase phase)
        {
            Assert.IsFalse(AnimalSeparationRules.ShouldAccumulate(phase,
                AnimalStatus.Alive, AnimalCommand.Follow, true, false));
        }

        [Test]
        public void InRangeOrReachablePetDoesNotBecomeMissing()
        {
            Assert.IsFalse(AnimalSeparationRules.ShouldAccumulate(CampaignPhase.ActiveRaid,
                AnimalStatus.Alive, AnimalCommand.Follow, false, false));
            Assert.IsFalse(AnimalSeparationRules.ShouldAccumulate(CampaignPhase.ActiveRaid,
                AnimalStatus.Alive, AnimalCommand.Follow, true, true));
        }

        [Test]
        public void IntentionallyStayedPetDoesNotBecomeMissing()
        {
            Assert.IsFalse(AnimalSeparationRules.ShouldAccumulate(CampaignPhase.ActiveRaid,
                AnimalStatus.Alive, AnimalCommand.Stay, true, false));
        }

        [TestCase(AnimalStatus.Missing)]
        [TestCase(AnimalStatus.Dead)]
        public void AlreadyMissingOrDeadPetCannotStartAnotherMissingTransition(AnimalStatus status)
        {
            Assert.IsFalse(AnimalSeparationRules.ShouldAccumulate(CampaignPhase.ActiveRaid,
                status, AnimalCommand.Follow, true, false));
        }

        [Test]
        public void PetGetsGracePeriodBeforeMissingTransition()
        {
            Assert.IsFalse(AnimalSeparationRules.ShouldMarkMissing(59.9f, 60f));
            Assert.IsTrue(AnimalSeparationRules.ShouldMarkMissing(60f, 60f));
            Assert.IsTrue(AnimalSeparationRules.ShouldMarkMissing(75f, 60f));
        }

        [Test]
        public void InvalidTimerValuesCannotTriggerMissingTransition()
        {
            Assert.IsFalse(AnimalSeparationRules.ShouldMarkMissing(float.NaN, 60f));
            Assert.IsFalse(AnimalSeparationRules.ShouldMarkMissing(float.PositiveInfinity, 60f));
            Assert.IsFalse(AnimalSeparationRules.ShouldMarkMissing(100f, 0f));
        }
    }
}
