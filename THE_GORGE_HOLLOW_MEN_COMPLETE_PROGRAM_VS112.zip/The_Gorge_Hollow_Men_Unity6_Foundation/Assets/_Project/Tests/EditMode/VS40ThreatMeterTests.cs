using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS40ThreatMeterTests
    {
        private static float PhaseToThreat(CampaignPhase phase)
        {
            switch (phase)
            {
                case CampaignPhase.RecoveryPreparation: return 0.1f;
                case CampaignPhase.ThreatDevelopment: return 0.45f;
                case CampaignPhase.ActiveRaid: return 1f;
                case CampaignPhase.ThreatResolution: return 0.6f;
                case CampaignPhase.DawnReview: return 0.15f;
                default: return 0f;
            }
        }

        [Test]
        public void ActiveRaidIsCritical()
            => Assert.AreEqual(1f, PhaseToThreat(CampaignPhase.ActiveRaid), 0.001f);

        [Test]
        public void RecoveryIsLow()
            => Assert.AreEqual(0.1f, PhaseToThreat(CampaignPhase.RecoveryPreparation), 0.001f);
    }
}
