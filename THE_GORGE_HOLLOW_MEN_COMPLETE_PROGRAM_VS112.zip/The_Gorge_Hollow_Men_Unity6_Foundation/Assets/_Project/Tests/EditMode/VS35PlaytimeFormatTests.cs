using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS35PlaytimeFormatTests
    {
        [Test]
        public void FormatMinutesSeconds()
        {
            int total = 125;
            int m = total / 60;
            int s = total % 60;
            string formatted = string.Format("{0:00}:{1:00}", m, s);
            Assert.AreEqual("02:05", formatted);
        }

        [Test]
        public void LowBatteryThreshold()
        {
            float level = 0.15f;
            bool low = level >= 0f && level <= 0.2f;
            Assert.IsTrue(low);
        }
    }
}
