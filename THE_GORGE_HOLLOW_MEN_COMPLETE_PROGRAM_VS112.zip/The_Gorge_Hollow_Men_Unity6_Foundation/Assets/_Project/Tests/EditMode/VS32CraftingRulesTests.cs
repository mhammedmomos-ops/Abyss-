using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS32CraftingRulesTests
    {
        [Test]
        public void CanCraftRequiresResourcesAndYield()
        {
            var state = new CampaignState { scrap = 5, timber = 2 };
            var cost = new ResourceDelta { scrap = 3, timber = 1 };
            var yield = new ResourceDelta { ammunition = 8 };
            Assert.IsTrue(CraftingRules.CanCraft(state, cost, yield));
            state.scrap = 1;
            Assert.IsFalse(CraftingRules.CanCraft(state, cost, yield));
        }

        [Test]
        public void CombineSubtractsCostAddsYield()
        {
            var cost = new ResourceDelta { scrap = 3, timber = 1 };
            var yield = new ResourceDelta { ammunition = 8 };
            var delta = CraftingRules.Combine(cost, yield);
            Assert.AreEqual(-3, delta.scrap);
            Assert.AreEqual(-1, delta.timber);
            Assert.AreEqual(8, delta.ammunition);
        }

        [Test]
        public void EmptyYieldRejected()
        {
            var state = new CampaignState { scrap = 10 };
            var cost = new ResourceDelta { scrap = 1 };
            var yield = new ResourceDelta();
            Assert.IsFalse(CraftingRules.CanCraft(state, cost, yield));
        }
    }
}
