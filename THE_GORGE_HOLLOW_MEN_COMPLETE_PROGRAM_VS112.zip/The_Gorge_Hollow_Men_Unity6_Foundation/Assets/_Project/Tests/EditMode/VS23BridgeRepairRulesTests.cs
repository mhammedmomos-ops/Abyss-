using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS23BridgeRepairRulesTests
    {
        [TestCase(BridgeSpanState.Stable, false)]
        [TestCase(BridgeSpanState.Strained, true)]
        [TestCase(BridgeSpanState.Collapsed, true)]
        [TestCase(BridgeSpanState.Unconfigured, false)]
        public void EligibilityMatchesSpanState(BridgeSpanState state, bool expected)
            => Assert.AreEqual(expected, BridgeRepairRules.IsEligible(state));

        [Test]
        public void ScaleCostZeroBaseProducesZero()
            => Assert.AreEqual(0, BridgeRepairRules.ScaleCost(0, 3, 2));

        [Test]
        public void ScaleCostNegativeCountsTreatedAsZero()
            => Assert.AreEqual(0, BridgeRepairRules.ScaleCost(10, -1, -4));

        [Test]
        public void ScaleCostCollapsedOnly()
            => Assert.AreEqual(30, BridgeRepairRules.ScaleCost(10, 0, 3));

        [Test]
        public void ScaleCostDamagedOnlyUsesHalfUnitsRoundedUp()
        {
            // 1 damaged -> 1 unit; 2 damaged -> 1 unit; 3 damaged -> 2 units
            Assert.AreEqual(10, BridgeRepairRules.ScaleCost(10, 1, 0));
            Assert.AreEqual(10, BridgeRepairRules.ScaleCost(10, 2, 0));
            Assert.AreEqual(20, BridgeRepairRules.ScaleCost(10, 3, 0));
        }

        [Test]
        public void ScaleCostMixedDamageAndCollapse()
        {
            // collapsed 2 + ceil(3/2)=2 → 4 work units * 5 = 20
            Assert.AreEqual(20, BridgeRepairRules.ScaleCost(5, 3, 2));
        }

        [Test]
        public void RestoreAmountIntactIsZero()
            => Assert.AreEqual(0, BridgeRepairRules.RestoreAmountForSupport(
                TowerStructuralSegmentState.Intact, 40, 25));

        [Test]
        public void RestoreAmountDamagedUsesBase()
            => Assert.AreEqual(40, BridgeRepairRules.RestoreAmountForSupport(
                TowerStructuralSegmentState.Damaged, 40, 25));

        [Test]
        public void RestoreAmountCollapsedUsesBasePlusBonus()
            => Assert.AreEqual(65, BridgeRepairRules.RestoreAmountForSupport(
                TowerStructuralSegmentState.Collapsed, 40, 25));

        [Test]
        public void RestoreAmountNegativeTuningClamped()
            => Assert.AreEqual(0, BridgeRepairRules.RestoreAmountForSupport(
                TowerStructuralSegmentState.Collapsed, -10, -5));
    }
}
