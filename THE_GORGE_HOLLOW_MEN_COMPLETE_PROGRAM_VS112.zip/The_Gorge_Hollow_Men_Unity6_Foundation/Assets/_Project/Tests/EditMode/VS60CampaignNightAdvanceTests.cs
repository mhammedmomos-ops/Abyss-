using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS60CampaignNightAdvanceTests
    {
        [Test]
        public void AdvanceIsOfferedOnlyAfterResolvedEncounterAndWhenRaidIsInactive()
        {
            Assert.IsFalse(CampaignNightAdvanceRules.CanOfferAdvance(false, false, CampaignPhase.ThreatResolution, 3, 3, false));
            Assert.IsFalse(CampaignNightAdvanceRules.CanOfferAdvance(true, true, CampaignPhase.ThreatResolution, 3, 3, false));
            Assert.IsTrue(CampaignNightAdvanceRules.CanOfferAdvance(true, false, CampaignPhase.ThreatResolution, 3, 3, false));
        }

        [Test]
        public void EncounterFromAnotherNightCannotAdvanceCurrentNight()
        {
            Assert.IsFalse(CampaignNightAdvanceRules.CanOfferAdvance(true, false, CampaignPhase.ThreatResolution, 4, 3, false));
        }

        [Test]
        public void SameNightCannotBeAdvancedTwiceByTheSameReadyState()
        {
            Assert.IsFalse(CampaignNightAdvanceRules.CanOfferAdvance(true, false, CampaignPhase.ThreatResolution, 4, 4, true));
        }

        [Test]
        public void FinalNightUsesCampaignCompletionLabel()
        {
            Assert.AreEqual("COMPLETE CAMPAIGN", CampaignNightAdvanceRules.GetActionLabel(20, 20));
            Assert.AreEqual("RETURN TO DAWN", CampaignNightAdvanceRules.GetActionLabel(19, 20));
        }

        [Test]
        public void AdvanceIsNotOfferedUntilThreatResolutionHasBeenPersisted()
        {
            Assert.IsFalse(CampaignNightAdvanceRules.CanOfferAdvance(true, false,
                CampaignPhase.ActiveRaid, 3, 3, false));
        }

        [Test]
        public void InvalidNightCannotOfferAdvance()
        {
            Assert.IsFalse(CampaignNightAdvanceRules.CanOfferAdvance(true, false, CampaignPhase.ThreatResolution, 0, 0, false));
        }
    }
}
