using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS103SaveMigrationTests
    {
        [Test]
        public void VersionElevenSavePreservesWorkersAndInitializesRaidPosture()
        {
            string dir = Path.Combine(Application.temporaryCachePath, "vs103_migration_" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            try
            {
                CampaignState old = CampaignStateFactory.CreateNew();
                old.saveVersion = 11;
                old.towerWorkers.Add(new TowerWorkerRecord
                {
                    identity = "legacy_guard", displayName = "Legacy Guard", towerId = "tower_a",
                    role = TowerWorkerRole.Guard, assignment = TowerWorkerAssignment.Guard,
                    status = TowerWorkerStatus.Active, health = 100, skill = 40
                });
                File.WriteAllText(Path.Combine(dir, "campaign.json"), JsonUtility.ToJson(old));
                CampaignState loaded = new CampaignSaveService(dir, "campaign.json").Load(out string error);
                Assert.IsNotNull(loaded, error);
                Assert.AreEqual(CampaignSaveService.CurrentSaveVersion, loaded.saveVersion);
                TowerWorkerRecord worker = TowerWorkerRules.Find(loaded, "legacy_guard");
                Assert.IsNotNull(worker);
                Assert.AreEqual(TowerWorkerAssignment.Guard, worker.assignment);
                Assert.AreEqual(TowerWorkerAssignment.Guard, worker.preRaidAssignment);
                Assert.AreEqual(TowerWorkerTacticalState.Normal, worker.tacticalState);
                Assert.IsFalse(worker.playerOverrideDuringRaid);
                Assert.AreEqual(70, worker.morale); Assert.AreEqual(50, worker.loyalty); Assert.AreEqual(0, worker.stress);
            }
            finally { if (Directory.Exists(dir)) Directory.Delete(dir, true); }
        }

        [Test]
        public void VersionTwelveSaveInitializesMoraleWithoutChangingWorkerAssignment()
        {
            string dir = Path.Combine(Application.temporaryCachePath, "vs104_migration_" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            try
            {
                CampaignState old = CampaignStateFactory.CreateNew();
                old.saveVersion = 12;
                old.towerWorkers.Add(new TowerWorkerRecord { identity = "v12_worker", displayName = "V12 Worker", towerId = "tower_b", role = TowerWorkerRole.Mechanic, assignment = TowerWorkerAssignment.Production });
                File.WriteAllText(Path.Combine(dir, "campaign.json"), JsonUtility.ToJson(old));
                CampaignState loaded = new CampaignSaveService(dir, "campaign.json").Load(out string error);
                Assert.IsNotNull(loaded, error); Assert.AreEqual(CampaignSaveService.CurrentSaveVersion, loaded.saveVersion);
                TowerWorkerRecord worker = TowerWorkerRules.Find(loaded, "v12_worker");
                Assert.AreEqual(TowerWorkerAssignment.Production, worker.assignment);
                Assert.AreEqual(70, worker.morale); Assert.AreEqual(50, worker.loyalty); Assert.AreEqual(0, worker.stress);
            }
            finally { if (Directory.Exists(dir)) Directory.Delete(dir, true); }
        }
    }
}
