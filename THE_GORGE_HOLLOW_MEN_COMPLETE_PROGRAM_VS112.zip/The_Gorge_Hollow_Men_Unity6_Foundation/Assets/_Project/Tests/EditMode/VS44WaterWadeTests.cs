using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS44WaterWadeTests
    {
        [Test]
        public void SpeedMultiplierClampedRange()
        {
            float mult = Mathf.Clamp(0.55f, 0.2f, 1f);
            Assert.AreEqual(0.55f, mult, 0.001f);
        }

        [Test]
        public void DefaultNotWading()
        {
            Assert.IsFalse(GorgeHollow.WaterWadeZone.PlayerWading);
            Assert.AreEqual(1f, GorgeHollow.WaterWadeZone.SpeedMultiplier, 0.001f);
        }
    }
}
