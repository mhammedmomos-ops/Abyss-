using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS58AnimalCareLifecycleTests
    {
        private static AnimalRecord NewAnimal(AnimalSpecies species = AnimalSpecies.Cat)
        {
            return new AnimalRecord { identity = "pet-1", displayName = "Miso", species = species,
                status = AnimalStatus.Alive, health = 50, stamina = 40, bond = 10,
                fictionalAgeDays = 365, lifeStage = AnimalLifeStage.Adult };
        }

        [Test]
        public void RestRequiresSafeLocationAndImprovesStaminaAndBond()
        {
            AnimalRecord animal = NewAnimal();
            Assert.IsFalse(AnimalCareRules.TryRest(animal, false));
            Assert.AreEqual(40, animal.stamina);
            Assert.IsTrue(AnimalCareRules.TryRest(animal, true));
            Assert.AreEqual(85, animal.stamina);
            Assert.AreEqual(11, animal.bond);
        }

        [Test]
        public void RestClampsValuesAndCannotBeRepeatedAtFullStamina()
        {
            AnimalRecord animal = NewAnimal(); animal.stamina = 90; animal.bond = 100;
            Assert.IsTrue(AnimalCareRules.TryRest(animal, true));
            Assert.AreEqual(100, animal.stamina);
            Assert.AreEqual(100, animal.bond);
            Assert.IsFalse(AnimalCareRules.TryRest(animal, true));
        }

        [Test]
        public void TreatmentConsumesMedicalSupplyAndRestoresHealth()
        {
            AnimalRecord animal = NewAnimal(); int supplies = 2;
            Assert.IsTrue(AnimalCareRules.TryTreat(animal, ref supplies));
            Assert.AreEqual(80, animal.health);
            Assert.AreEqual(1, supplies);
        }

        [Test]
        public void TreatmentCannotReviveDeadOrMissingPetOrRunWithoutSupplies()
        {
            AnimalRecord animal = NewAnimal(); int supplies = 1;
            animal.status = AnimalStatus.Dead; animal.health = 0;
            Assert.IsFalse(AnimalCareRules.TryTreat(animal, ref supplies));
            Assert.AreEqual(0, animal.health);
            animal.status = AnimalStatus.Missing; animal.health = 20;
            Assert.IsFalse(AnimalCareRules.TryTreat(animal, ref supplies));
            animal.status = AnimalStatus.Alive; supplies = 0;
            Assert.IsFalse(AnimalCareRules.TryTreat(animal, ref supplies));
        }

        [TestCase(AnimalSpecies.GermanShepherd, 3650)]
        [TestCase(AnimalSpecies.Falcon, 5475)]
        [TestCase(AnimalSpecies.Pangolin, 5475)]
        [TestCase(AnimalSpecies.Cat, 4380)]
        public void SpeciesSpecificAgeThresholdsResolveSeniorStage(AnimalSpecies species, int seniorAge)
        {
            Assert.AreEqual(AnimalLifeStage.Senior, AnimalLifecycleRules.ResolveLifeStage(species, seniorAge));
            Assert.AreEqual(AnimalLifeStage.Adult, AnimalLifecycleRules.ResolveLifeStage(species, seniorAge - 1));
        }

        [Test]
        public void AgeAdvancesOnlyForLivingOrMissingAnimalsAndSaturatesSafely()
        {
            AnimalRecord animal = NewAnimal();
            AnimalLifecycleRules.AdvanceDays(animal, 2);
            Assert.AreEqual(367, animal.fictionalAgeDays);
            Assert.AreEqual(AnimalLifeStage.Adult, animal.lifeStage);
            animal.status = AnimalStatus.Dead;
            AnimalLifecycleRules.AdvanceDays(animal, 100);
            Assert.AreEqual(367, animal.fictionalAgeDays);
            animal.status = AnimalStatus.Alive; animal.fictionalAgeDays = int.MaxValue;
            AnimalLifecycleRules.AdvanceDays(animal, 10);
            Assert.AreEqual(int.MaxValue, animal.fictionalAgeDays);
        }

        [Test]
        public void FictionalClockDayRolloverAdvancesPetAgeWithoutWallClockTime()
        {
            CampaignState state = CampaignStateFactory.CreateNew();
            AnimalRecord animal = NewAnimal();
            state.animals.Add(animal);
            CampaignClock clock = new CampaignClock(state);
            clock.AdvanceFictionalMinutes(24 * 60);
            Assert.AreEqual(366, animal.fictionalAgeDays);
            Assert.AreEqual(AnimalLifeStage.Adult, animal.lifeStage);
        }

        [Test]
        public void CompletingNightAdvancesLivingPetAgeButNotDeadPetAge()
        {
            CampaignState state = CampaignStateFactory.CreateNew();
            AnimalRecord living = NewAnimal();
            AnimalRecord dead = NewAnimal(AnimalSpecies.Falcon);
            dead.identity = "dead-pet";
            dead.status = AnimalStatus.Dead;
            dead.health = 0;
            dead.deathEventId = "death-1";
            state.animals.Add(living);
            state.animals.Add(dead);
            new CampaignClock(state).CompleteNight();
            Assert.AreEqual(366, living.fictionalAgeDays);
            Assert.AreEqual(365, dead.fictionalAgeDays);
        }
    }
}
