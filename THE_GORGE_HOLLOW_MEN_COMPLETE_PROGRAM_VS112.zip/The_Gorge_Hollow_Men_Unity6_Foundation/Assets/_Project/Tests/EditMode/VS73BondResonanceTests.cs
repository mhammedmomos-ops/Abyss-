using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS73BondResonanceTests
    {
        [Test]
        public void RequiresLivingCompanionHighBondConfirmedThreatAndCooldownReady()
        {
            Assert.IsTrue(AnimalBondResonanceRules.CanIssueResonate(
                AnimalStatus.Alive, 40, true, 0.7f, 10f, 0f, false));
            Assert.IsFalse(AnimalBondResonanceRules.CanIssueResonate(
                AnimalStatus.Dead, 40, true, 0.7f, 10f, 0f, false));
            Assert.IsFalse(AnimalBondResonanceRules.CanIssueResonate(
                AnimalStatus.Alive, 20, true, 0.7f, 10f, 0f, false));
            Assert.IsFalse(AnimalBondResonanceRules.CanIssueResonate(
                AnimalStatus.Alive, 40, false, 0.7f, 10f, 0f, false));
            Assert.IsFalse(AnimalBondResonanceRules.CanIssueResonate(
                AnimalStatus.Alive, 40, true, 0.3f, 10f, 0f, false));
            Assert.IsFalse(AnimalBondResonanceRules.CanIssueResonate(
                AnimalStatus.Alive, 40, true, 0.7f, 10f, 15f, false));
            Assert.IsFalse(AnimalBondResonanceRules.CanIssueResonate(
                AnimalStatus.Alive, 40, true, 0.7f, 10f, 0f, true));
        }

        [Test]
        public void BondCostIsAppliedAndClamped()
        {
            Assert.AreEqual(36, AnimalBondResonanceRules.BondAfterResonate(40));
            Assert.AreEqual(0, AnimalBondResonanceRules.BondAfterResonate(2));
            Assert.AreEqual(0, AnimalBondResonanceRules.BondAfterResonate(0));
        }

        [Test]
        public void DetectionBoostAppliesOnlyWhileResonating()
        {
            float baseR = 12f;
            float boosted = AnimalBondResonanceRules.DetectionRadiusWhileResonating(baseR, true);
            Assert.AreEqual(baseR * AnimalSpeciesTactics.BondResonanceDetectionMultiplier, boosted, 0.0001f);
            Assert.AreEqual(baseR, AnimalBondResonanceRules.DetectionRadiusWhileResonating(baseR, false), 0.0001f);
        }

        [Test]
        public void DurationAndCooldownAreDeterministic()
        {
            float start = 50f;
            float ends = AnimalBondResonanceRules.ResonanceEndsAt(start);
            Assert.AreEqual(start + AnimalSpeciesTactics.BondResonanceDurationSeconds, ends, 0.001f);
            float cool = AnimalBondResonanceRules.CooldownEndsAt(ends);
            Assert.AreEqual(ends + AnimalSpeciesTactics.BondResonanceCooldownSeconds, cool, 0.001f);
            Assert.IsTrue(AnimalBondResonanceRules.IsResonanceActive(start + 1f, ends));
            Assert.IsFalse(AnimalBondResonanceRules.IsResonanceActive(ends + 0.01f, ends));
        }

        [Test]
        public void ToastIsSpeciesFlavoredAndNonEmpty()
        {
            string shepherd = AnimalBondResonanceRules.FormatToast(AnimalSpecies.GermanShepherd, "Rex");
            string falcon = AnimalBondResonanceRules.FormatToast(AnimalSpecies.Falcon, "Sky");
            string pangolin = AnimalBondResonanceRules.FormatToast(AnimalSpecies.Pangolin, "Shell");
            string cat = AnimalBondResonanceRules.FormatToast(AnimalSpecies.Cat, "Shadow");
            Assert.IsTrue(shepherd.Contains("Rex"));
            Assert.IsTrue(falcon.Contains("Sky"));
            Assert.IsTrue(pangolin.Contains("Shell"));
            Assert.IsTrue(cat.Contains("Shadow"));
            Assert.IsFalse(string.IsNullOrWhiteSpace(AnimalBondResonanceRules.FormatToast(AnimalSpecies.Cat, null)));
        }

        [Test]
        public void ConstantsAreReasonable()
        {
            Assert.Greater(AnimalSpeciesTactics.BondResonanceMinimumBond, 0);
            Assert.Greater(AnimalSpeciesTactics.BondResonanceBondCost, 0);
            Assert.Less(AnimalSpeciesTactics.BondResonanceBondCost, AnimalSpeciesTactics.BondResonanceMinimumBond);
            Assert.Greater(AnimalSpeciesTactics.BondResonanceDetectionMultiplier, 1f);
            Assert.Greater(AnimalSpeciesTactics.BondResonanceDurationSeconds, 0f);
            Assert.Greater(AnimalSpeciesTactics.BondResonanceCooldownSeconds, AnimalSpeciesTactics.BondResonanceDurationSeconds);
        }
    }
}
