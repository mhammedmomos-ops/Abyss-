using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS11ArchetypeTacticsTests
    {
        [Test]
        public void AllRolesPrioritiseDirectPlayerSight()
        {
            foreach (MonsterArchetypeRole role in System.Enum.GetValues(typeof(MonsterArchetypeRole)))
                Assert.AreEqual(MonsterDecisionBranch.DirectContact, MonsterTacticalProfile.GetOrder(role)[0]);
        }

        [Test]
        public void BrutePrioritisesTowerSiegeOverSharedSquadContact()
        {
            var order = MonsterTacticalProfile.GetOrder(MonsterArchetypeRole.Brute);
            Assert.Less(IndexOf(order, MonsterDecisionBranch.Siege), IndexOf(order, MonsterDecisionBranch.SharedContact));
        }

        [Test]
        public void LurkerPrioritisesNestDefenceAndInvestigationOverSharedContact()
        {
            var order = MonsterTacticalProfile.GetOrder(MonsterArchetypeRole.Lurker);
            Assert.Less(IndexOf(order, MonsterDecisionBranch.GuardNest), IndexOf(order, MonsterDecisionBranch.SharedContact));
            Assert.Less(IndexOf(order, MonsterDecisionBranch.Investigate), IndexOf(order, MonsterDecisionBranch.SharedContact));
        }

        [Test]
        public void RoleProfilesDoNotShareMutableOrderArrays()
        {
            Assert.AreNotSame(MonsterTacticalProfile.GetOrder(MonsterArchetypeRole.Stalker),
                MonsterTacticalProfile.GetOrder(MonsterArchetypeRole.Brute));
        }

        private static int IndexOf(System.Collections.Generic.IReadOnlyList<MonsterDecisionBranch> order, MonsterDecisionBranch branch)
        {
            for (int i = 0; i < order.Count; i++) if (order[i] == branch) return i;
            return -1;
        }
    }
}
