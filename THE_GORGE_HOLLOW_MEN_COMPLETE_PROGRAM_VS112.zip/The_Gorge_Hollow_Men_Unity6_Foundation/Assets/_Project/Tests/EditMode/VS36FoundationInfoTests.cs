using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS36FoundationInfoTests
    {
        // VS79: the original test hard-coded "VS36" and had been failing since the constant moved on.
        // It now checks the shape of the tag and that both version constants agree.
        [Test]
        public void PackageVersionIsAVsTag()
        {
            Assert.IsTrue(GameFoundationInfo.PackageVersion.StartsWith("VS"));
            Assert.Greater(GameFoundationInfo.PackageVersion.Length, 2);
            Assert.IsTrue(int.TryParse(GameFoundationInfo.PackageVersion.Substring(2), out int number));
            Assert.GreaterOrEqual(number, 36);
        }

        [Test]
        public void FoundationInfoAndProgressReportAgreeOnVersion()
            => Assert.AreEqual(GameFoundationInfo.PackageVersion, FoundationProgressReport.PackageVersion);

        [Test]
        public void SummaryContainsProductName()
            => Assert.IsTrue(GameFoundationInfo.Summary.Contains("The Gorge"));
    }
}
