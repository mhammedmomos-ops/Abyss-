using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS77HoldCommandSeparationTests
    {
        [Test]
        public void StayAndGuardAreHoldCommands()
        {
            Assert.IsTrue(AnimalSeparationRules.IsHoldCommand(AnimalCommand.Stay));
            Assert.IsTrue(AnimalSeparationRules.IsHoldCommand(AnimalCommand.Guard));
        }

        [TestCase(AnimalCommand.Follow)]
        [TestCase(AnimalCommand.Search)]
        [TestCase(AnimalCommand.Alert)]
        [TestCase(AnimalCommand.Protect)]
        [TestCase(AnimalCommand.Forage)]
        [TestCase(AnimalCommand.Lure)]
        [TestCase(AnimalCommand.TrackScent)]
        [TestCase(AnimalCommand.Stalk)]
        [TestCase(AnimalCommand.Resonate)]
        [TestCase(AnimalCommand.Callout)]
        public void MovingCommandsAreNotHoldCommands(AnimalCommand command)
        {
            Assert.IsFalse(AnimalSeparationRules.IsHoldCommand(command));
        }

        [Test]
        public void GuardingPetDoesNotBecomeMissingDuringRaid()
        {
            Assert.IsFalse(AnimalSeparationRules.ShouldAccumulate(CampaignPhase.ActiveRaid,
                AnimalStatus.Alive, AnimalCommand.Guard, true, false));
            Assert.IsFalse(AnimalSeparationRules.ShouldAccumulate(CampaignPhase.ThreatResolution,
                AnimalStatus.Alive, AnimalCommand.Guard, true, false));
        }

        [Test]
        public void StayExemptionAndFollowAccumulationAreUnchanged()
        {
            Assert.IsFalse(AnimalSeparationRules.ShouldAccumulate(CampaignPhase.ActiveRaid,
                AnimalStatus.Alive, AnimalCommand.Stay, true, false));
            Assert.IsTrue(AnimalSeparationRules.ShouldAccumulate(CampaignPhase.ActiveRaid,
                AnimalStatus.Alive, AnimalCommand.Follow, true, false));
        }
    }
}
