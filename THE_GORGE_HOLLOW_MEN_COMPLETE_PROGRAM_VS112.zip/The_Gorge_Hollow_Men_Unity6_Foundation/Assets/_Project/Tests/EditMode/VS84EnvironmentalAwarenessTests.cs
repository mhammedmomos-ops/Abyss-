using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public class VS84EnvironmentalAwarenessTests
    {
        [Test]
        public void ShepherdUsesScentRichGroundWithoutExpandingVisualScan()
        {
            var context = new AnimalEnvironmentContext(false, false, false, true);
            var result = AnimalEnvironmentalAwarenessRules.Evaluate(
                AnimalSpecies.GermanShepherd, AnimalCommand.TrackScent, context);
            Assert.AreEqual(1f, result.ScanRadiusMultiplier, 0.001f);
            Assert.AreEqual(0.025f, result.ConfidenceBonus, 0.001f);
            Assert.AreEqual(1.15f, AnimalEnvironmentalAwarenessRules.ScentSearchRadiusMultiplier(context), 0.001f);
        }

        [Test]
        public void FalconBenefitsFromExplicitPerchMarkerOnly()
        {
            var perch = new AnimalEnvironmentContext(false, true, false, false);
            var ground = new AnimalEnvironmentContext(false, false, false, false);
            Assert.AreEqual(1.10f, AnimalEnvironmentalAwarenessRules.Evaluate(
                AnimalSpecies.Falcon, AnimalCommand.Follow, perch).ScanRadiusMultiplier, 0.001f);
            Assert.AreEqual(1f, AnimalEnvironmentalAwarenessRules.Evaluate(
                AnimalSpecies.Falcon, AnimalCommand.Follow, ground).ScanRadiusMultiplier, 0.001f);
        }

        [Test]
        public void PangolinGetsAssessmentBonusOnDefensiveGround()
        {
            var context = new AnimalEnvironmentContext(false, false, true, false);
            var result = AnimalEnvironmentalAwarenessRules.Evaluate(
                AnimalSpecies.Pangolin, AnimalCommand.Guard, context);
            Assert.AreEqual(0.07f, result.ConfidenceBonus, 0.001f);
            Assert.AreEqual(1f, result.ScanRadiusMultiplier, 0.001f);
        }

        [Test]
        public void CatUsesConcealmentOnlyWhileStalking()
        {
            var context = new AnimalEnvironmentContext(true, false, false, false);
            var stalking = AnimalEnvironmentalAwarenessRules.Evaluate(
                AnimalSpecies.Cat, AnimalCommand.Stalk, context);
            var following = AnimalEnvironmentalAwarenessRules.Evaluate(
                AnimalSpecies.Cat, AnimalCommand.Follow, context);
            Assert.AreEqual(1.08f, stalking.ScanRadiusMultiplier, 0.001f);
            Assert.AreEqual(0.05f, stalking.ConfidenceBonus, 0.001f);
            Assert.AreEqual(1f, following.ScanRadiusMultiplier, 0.001f);
            Assert.AreEqual(0f, following.ConfidenceBonus, 0.001f);
        }

        [Test]
        public void UnmarkedEnvironmentNeverGrantsBonuses()
        {
            var context = new AnimalEnvironmentContext(false, false, false, false);
            foreach (AnimalSpecies species in System.Enum.GetValues(typeof(AnimalSpecies)))
            {
                var result = AnimalEnvironmentalAwarenessRules.Evaluate(species, AnimalCommand.Follow, context);
                Assert.AreEqual(1f, result.ScanRadiusMultiplier, 0.001f, species.ToString());
                Assert.AreEqual(0f, result.ConfidenceBonus, 0.001f, species.ToString());
            }
            Assert.AreEqual(1f, AnimalEnvironmentalAwarenessRules.ScentSearchRadiusMultiplier(context), 0.001f);
        }

        [Test]
        public void IndependentEnvironmentalFeaturesCanCoexist()
        {
            var context = new AnimalEnvironmentContext(true, true, true, true);
            Assert.AreEqual(1.15f, AnimalEnvironmentalAwarenessRules.ScentSearchRadiusMultiplier(context), 0.001f);
            Assert.AreEqual(1.10f, AnimalEnvironmentalAwarenessRules.Evaluate(
                AnimalSpecies.Falcon, AnimalCommand.Follow, context).ScanRadiusMultiplier, 0.001f);
            Assert.AreEqual(1.08f, AnimalEnvironmentalAwarenessRules.Evaluate(
                AnimalSpecies.Cat, AnimalCommand.Stalk, context).ScanRadiusMultiplier, 0.001f);
        }
    }
}
