using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS8TerritoryRegressionTests
    {
        [Test]
        public void NestContainsPositionsWithinHorizontalTerritory()
        {
            var nestObject = new GameObject("Nest");
            try
            {
                var nest = nestObject.AddComponent<MonsterNest>();
                Assert.IsTrue(nest.Contains(new Vector3(10f, 50f, 0f)));
                Assert.IsFalse(nest.Contains(new Vector3(30f, 0f, 0f)));
            }
            finally { Object.DestroyImmediate(nestObject); }
        }

        [Test]
        public void GuardPositionsRemainDistinctBeyondSixSquadMembers()
        {
            var nestObject = new GameObject("Nest");
            try
            {
                var nest = nestObject.AddComponent<MonsterNest>();
                Vector3 first = nest.GetGuardPosition(0);
                Vector3 seventh = nest.GetGuardPosition(6);
                Assert.Greater((first - seventh).sqrMagnitude, 0.01f);
            }
            finally { Object.DestroyImmediate(nestObject); }
        }

        [Test]
        public void DisabledNestDoesNotClaimTerritory()
        {
            var nestObject = new GameObject("Nest");
            try
            {
                var nest = nestObject.AddComponent<MonsterNest>();
                nest.enabled = false;
                Assert.IsFalse(nest.Contains(Vector3.zero));
                Assert.IsFalse(nest.IsActive);
            }
            finally { Object.DestroyImmediate(nestObject); }
        }

        [Test]
        public void SpawnPointExposesOptionalNestReference()
        {
            var spawnObject = new GameObject("Spawn");
            try
            {
                var spawn = spawnObject.AddComponent<MonsterSpawnPoint>();
                Assert.IsNull(spawn.AssociatedNest);
                Assert.IsTrue(spawn.SpawnEnabled);
            }
            finally { Object.DestroyImmediate(spawnObject); }
        }
    }
}
