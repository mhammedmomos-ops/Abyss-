using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS26MobileSettingsRulesTests
    {
        [TestCase(0.18f, 0.18f)]
        [TestCase(0.01f, 0.05f)]
        [TestCase(2f, 1f)]
        [TestCase(-1f, 0.05f)]
        public void LookSensitivityClamped(float input, float expected)
            => Assert.AreEqual(expected, MobileSettingsRules.ClampLookSensitivity(input), 0.001f);

        [Test]
        public void LookSensitivityNonFiniteDefaults()
            => Assert.AreEqual(0.18f, MobileSettingsRules.ClampLookSensitivity(float.NaN), 0.001f);

        [TestCase(0.5f, 0.5f)]
        [TestCase(-0.2f, 0f)]
        [TestCase(1.5f, 1f)]
        public void VolumeClamped(float input, float expected)
            => Assert.AreEqual(expected, MobileSettingsRules.ClampMasterVolume(input), 0.001f);

        [Test]
        public void VolumeNonFiniteDefaults()
            => Assert.AreEqual(1f, MobileSettingsRules.ClampMasterVolume(float.PositiveInfinity), 0.001f);
    }
}
