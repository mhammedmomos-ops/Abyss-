using System.IO;
using NUnit.Framework;
using UnityEngine;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS13PersistentMonsterIntelligenceTests
    {
        [Test]
        public void NestStoresOnlyBoundedUniqueHazardEvidence()
        {
            GameObject host = new GameObject("nest_test");
            try
            {
                MonsterNest nest = host.AddComponent<MonsterNest>();
                Assert.IsTrue(nest.RecordLearnedHazard("trap_a", Vector3.one, 2f, 1f));
                Assert.IsFalse(nest.RecordLearnedHazard("trap_a", Vector3.one, 2f, 1f));
                for (int i = 0; i < 12; i++) nest.RecordLearnedHazard("trap_" + i, Vector3.right * i, 2f, 1f);
                Assert.AreEqual(MonsterNest.MaximumPersistedHazards, nest.LearnedHazardCount);
                Assert.AreEqual(MonsterNest.MaximumPersistedHazards, nest.Capture().learnedHazards.Count);
            }
            finally { Object.DestroyImmediate(host); }
        }

        [Test]
        public void NestRestoresKnownHazardsIntoNewMonsterMemory()
        {
            GameObject host = new GameObject("nest_test");
            try
            {
                MonsterNest nest = host.AddComponent<MonsterNest>();
                nest.RecordLearnedHazard("trap_a", new Vector3(4f, 0f, 2f), 3f, 2f);
                MonsterNestRecord saved = nest.Capture();
                nest.Restore(saved);
                var memory = new MonsterLearningMemory();
                nest.RestoreLearnedHazards(memory);
                Assert.AreEqual(1, memory.LearnedHazardCount);
                Assert.IsTrue(memory.TryGetBlockingHazard(Vector3.zero, new Vector3(8f, 0f, 4f), out LearnedHazard hazard));
                Assert.AreEqual("trap_a", hazard.Identity);
            }
            finally { Object.DestroyImmediate(host); }
        }

        [Test]
        public void InvalidPersistedHazardEvidenceFailsCampaignValidation()
        {
            var campaign = new CampaignState();
            campaign.monsterNests.Add(new MonsterNestRecord
            {
                identity = "nest_a", maxHealth = 10, currentHealth = 10,
                learnedHazards = new System.Collections.Generic.List<MonsterHazardRecord>
                {
                    new MonsterHazardRecord { identity = "trap_a", avoidanceRadius = -1f, observationCount = 1 }
                }
            });
            Assert.IsFalse(campaign.IsValid(out string reason));
            StringAssert.Contains("learned-hazard", reason);
        }

        [Test]
        public void SaveLoaderMigratesVersionTwoNestRecordsWithoutLosingHealth()
        {
            string directory = Path.Combine(Path.GetTempPath(), "GorgeHollow_VS13_" + System.Guid.NewGuid().ToString("N"));
            try
            {
                Directory.CreateDirectory(directory);
                var oldState = new CampaignState { saveVersion = 2 };
                oldState.monsterNests.Add(new MonsterNestRecord
                {
                    identity = "nest_old", maxHealth = 250, currentHealth = 117, alarmCount = 3
                });
                string versionTwoJson = JsonUtility.ToJson(oldState).Replace(",\"learnedHazards\":[]", string.Empty);
                File.WriteAllText(Path.Combine(directory, "campaign_save.json"), versionTwoJson);
                var saves = new CampaignSaveService(directory);
                CampaignState loaded = saves.Load(out string error);
                Assert.IsNotNull(loaded, error);
                Assert.AreEqual(CampaignSaveService.CurrentSaveVersion, loaded.saveVersion);
                Assert.AreEqual(117, loaded.monsterNests[0].currentHealth);
                Assert.IsNotNull(loaded.monsterNests[0].learnedHazards);
                Assert.AreEqual(0, loaded.monsterNests[0].learnedHazards.Count);
            }
            finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        }

        [Test]
        public void HazardMemoryRejectsNonFiniteEvidence()
        {
            var memory = new MonsterLearningMemory();
            Assert.IsFalse(memory.RecordHazard("bad", new Vector3(float.NaN, 0f, 0f), 2f, 1f, 0f));
            Assert.AreEqual(0, memory.LearnedHazardCount);
        }
    }
}
