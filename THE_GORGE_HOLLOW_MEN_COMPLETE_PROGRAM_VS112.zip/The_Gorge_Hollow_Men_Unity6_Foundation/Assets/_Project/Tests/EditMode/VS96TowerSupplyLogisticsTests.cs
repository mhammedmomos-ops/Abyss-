using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS96TowerSupplyLogisticsTests
    {
        private static TowerDepotRecord Depot(string id = "tower_a") => new TowerDepotRecord { towerId = id, scrap = 5, timber = 4, ammunition = 3, medicalSupplies = 1 };
        private static SupplyConvoyRecord Manifest(string id = "tower_a") => new SupplyConvoyRecord
        { identity = "vs96-manifest", destinationTowerId = id, status = SupplyConvoyStatus.Travelling, scrap = 2, timber = 1 };

        [Test] public void ShortageEvaluationReportsOnlyReserveDeficits()
        {
            var result = TowerSupplyLogisticsRules.Evaluate(Depot(), 10, 8, 5, 3);
            Assert.AreEqual(5, result.ScrapDeficit); Assert.AreEqual(4, result.TimberDeficit);
            Assert.AreEqual(2, result.AmmunitionDeficit); Assert.AreEqual(2, result.MedicalDeficit);
            Assert.IsTrue(result.HasShortage);
        }

        [Test] public void AdequateDepotMeetsReserveTargets()
        {
            var result = TowerSupplyLogisticsRules.Evaluate(Depot(), 5, 4, 3, 1);
            Assert.IsFalse(result.HasShortage);
            Assert.AreEqual("Reserve targets met.", TowerSupplyLogisticsRules.BuildWarnings(result)[0]);
        }

        [Test] public void DispatchBlockedWithoutValidatedPhysicalRoute()
        {
            Assert.IsFalse(TowerSupplyLogisticsRules.TryEvaluateDispatch(Depot(), Manifest(), false, out string reason));
            StringAssert.Contains("No validated physical route", reason);
        }

        [Test] public void DispatchRequiresMatchingDestination()
        {
            Assert.IsFalse(TowerSupplyLogisticsRules.TryEvaluateDispatch(Depot("tower_a"), Manifest("tower_b"), true, out _));
        }

        [Test] public void DispatchRejectsDepotOverflowBeforeDispatch()
        {
            var depot = Depot(); depot.scrap = int.MaxValue;
            Assert.IsFalse(TowerSupplyLogisticsRules.TryEvaluateDispatch(depot, Manifest(), true, out string reason));
            StringAssert.Contains("overflow", reason);
        }

        [Test] public void DispatchAcceptsValidManifestOnlyWhenRouteIsReachable()
        {
            Assert.IsTrue(TowerSupplyLogisticsRules.TryEvaluateDispatch(Depot(), Manifest(), true, out string reason), reason);
        }

        [Test] public void ShortageWarningDoesNotAlterDepotBalances()
        {
            var depot = Depot();
            TowerSupplyLogisticsRules.BuildWarnings(TowerSupplyLogisticsRules.Evaluate(depot, 50, 50, 50, 50));
            Assert.AreEqual(5, depot.scrap); Assert.AreEqual(4, depot.timber);
        }

        [Test] public void MissingDepotProducesExplicitInvalidStatus()
        {
            var result = TowerSupplyLogisticsRules.Evaluate(null, 1, 1, 1, 1);
            Assert.IsTrue(result.InvalidDepot); Assert.IsTrue(result.HasShortage);
        }
    }
}
