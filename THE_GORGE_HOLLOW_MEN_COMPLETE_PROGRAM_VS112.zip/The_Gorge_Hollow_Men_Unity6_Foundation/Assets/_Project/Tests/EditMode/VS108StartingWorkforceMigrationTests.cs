using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS108StartingWorkforceMigrationTests
    {
        [Test]
        public void EmptyVersionFourteenRosterReceivesFourStartingWorkers()
        {
            string dir = Path.Combine(Application.temporaryCachePath, "vs108_empty_roster_" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            try
            {
                CampaignState old = CampaignStateFactory.CreateNew();
                old.saveVersion = 14;
                old.towerWorkers.Clear();
                File.WriteAllText(Path.Combine(dir, "campaign.json"), JsonUtility.ToJson(old));

                CampaignState loaded = new CampaignSaveService(dir, "campaign.json").Load(out string error);
                Assert.IsNotNull(loaded, error);
                Assert.AreEqual(15, loaded.saveVersion);
                Assert.AreEqual(4, loaded.towerWorkers.Count);
                Assert.AreEqual(2, loaded.towerWorkers.FindAll(w => w.towerId == "tower_a").Count);
                Assert.AreEqual(2, loaded.towerWorkers.FindAll(w => w.towerId == "tower_b").Count);
            }
            finally { if (Directory.Exists(dir)) Directory.Delete(dir, true); }
        }

        [Test]
        public void ExistingVersionFourteenWorkerRecordsArePreservedWithoutStarterDuplication()
        {
            string dir = Path.Combine(Application.temporaryCachePath, "vs108_existing_roster_" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            try
            {
                CampaignState old = CampaignStateFactory.CreateNew();
                old.saveVersion = 14;
                old.towerWorkers.Clear();
                old.towerWorkers.Add(new TowerWorkerRecord
                {
                    identity = "legacy-survivor", displayName = "Legacy Survivor", towerId = "tower_b",
                    role = TowerWorkerRole.Medic, status = TowerWorkerStatus.Captured,
                    assignment = TowerWorkerAssignment.Rest, health = 21, morale = 34, loyalty = 41, stress = 66
                });
                File.WriteAllText(Path.Combine(dir, "campaign.json"), JsonUtility.ToJson(old));

                CampaignState loaded = new CampaignSaveService(dir, "campaign.json").Load(out string error);
                Assert.IsNotNull(loaded, error);
                Assert.AreEqual(1, loaded.towerWorkers.Count);
                TowerWorkerRecord worker = TowerWorkerRules.Find(loaded, "legacy-survivor");
                Assert.IsNotNull(worker);
                Assert.AreEqual(TowerWorkerStatus.Captured, worker.status);
                Assert.AreEqual(21, worker.health);
                Assert.AreEqual(34, worker.morale);
                Assert.AreEqual(41, worker.loyalty);
                Assert.AreEqual(66, worker.stress);
            }
            finally { if (Directory.Exists(dir)) Directory.Delete(dir, true); }
        }
    }
}
