using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS19DebrisRulesTests
    {
        [TestCase(5, 0, 12, 5)]
        [TestCase(5, 10, 12, 2)]
        [TestCase(5, 12, 12, 0)]
        [TestCase(0, 0, 12, 0)]
        [TestCase(5, 0, 0, 0)]
        [TestCase(-2, 0, 12, 0)]
        public void SpawnCountNeverExceedsActiveBudget(int requested, int active, int maximum, int expected)
        {
            Assert.AreEqual(expected, TowerDebrisRules.ResolveSpawnCount(requested, active, maximum));
        }

        [Test]
        public void LifetimeIsClampedToSafeRange()
        {
            Assert.AreEqual(2f, TowerDebrisRules.ResolveLifetime(0f, 2f, 6f));
            Assert.AreEqual(6f, TowerDebrisRules.ResolveLifetime(20f, 2f, 6f));
            Assert.AreEqual(2f, TowerDebrisRules.ResolveLifetime(float.NaN, 2f, 6f));
        }

        [Test]
        public void InvalidLifetimeBoundsAreNormalized()
        {
            Assert.AreEqual(0.1f, TowerDebrisRules.ResolveLifetime(0f, float.NaN, float.NegativeInfinity));
            Assert.AreEqual(3f, TowerDebrisRules.ResolveLifetime(5f, 3f, 1f));
        }

        [Test]
        public void NegativeOrNonFiniteForcesCannotProduceNegativeValues()
        {
            Assert.AreEqual(0f, TowerDebrisRules.ResolveNonNegative(-4f, 2f));
            Assert.AreEqual(2f, TowerDebrisRules.ResolveNonNegative(float.PositiveInfinity, 2f));
        }
    }
}
