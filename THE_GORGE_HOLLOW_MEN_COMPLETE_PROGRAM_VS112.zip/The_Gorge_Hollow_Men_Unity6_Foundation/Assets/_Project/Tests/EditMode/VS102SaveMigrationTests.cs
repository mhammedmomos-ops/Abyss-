using System.IO;
using NUnit.Framework;
using UnityEngine;
namespace GorgeHollow.Tests
{
    public sealed class VS102SaveMigrationTests
    {
        [Test] public void VersionTenSaveMigratesToElevenWithoutChangingProductionOrDepots()
        {
            string dir=Path.Combine(Application.temporaryCachePath,"vs102_migration_"+System.Guid.NewGuid().ToString("N")); Directory.CreateDirectory(dir);
            try
            {
                var old=CampaignStateFactory.CreateNew(); old.saveVersion=10; old.towerWorkers=null;
                TowerDepotRules.Find(old,"tower_a").scrap=19;
                old.towerProductionJobs.Add(new TowerProductionJobRecord { identity="legacy", towerId="tower_a", durationMinutes=20, remainingMinutes=12, costScrap=1, yieldMechanicalParts=1 });
                File.WriteAllText(Path.Combine(dir,"campaign.json"),JsonUtility.ToJson(old));
                var loaded=new CampaignSaveService(dir,"campaign.json").Load(out string error);
                Assert.IsNotNull(loaded,error); Assert.AreEqual(CampaignSaveService.CurrentSaveVersion,loaded.saveVersion); Assert.AreEqual(19,TowerDepotRules.Find(loaded,"tower_a").scrap);
                Assert.AreEqual(1,loaded.towerProductionJobs.Count); Assert.AreEqual(12,loaded.towerProductionJobs[0].remainingMinutes);
                Assert.AreEqual(4,loaded.towerWorkers.Count);
                Assert.AreEqual("Mara", loaded.towerWorkers[0].displayName);
            }
            finally { if(Directory.Exists(dir)) Directory.Delete(dir,true); }
        }
    }
}
