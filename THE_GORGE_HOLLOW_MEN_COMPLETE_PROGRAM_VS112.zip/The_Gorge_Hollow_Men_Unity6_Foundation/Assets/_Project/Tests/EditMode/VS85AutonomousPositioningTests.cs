using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public class VS85AutonomousPositioningTests
    {
        [Test]
        public void FalconUsesPerchesDuringFollowAndObservationCommands()
        {
            Assert.IsTrue(AnimalAutonomousPositioningRules.TryGetPreferredFeature(
                AnimalSpecies.Falcon, AnimalCommand.Follow, out AnimalEnvironmentFeature follow));
            Assert.AreEqual(AnimalEnvironmentFeature.ElevatedPerch, follow);
            Assert.IsTrue(AnimalAutonomousPositioningRules.TryGetPreferredFeature(
                AnimalSpecies.Falcon, AnimalCommand.Alert, out AnimalEnvironmentFeature alert));
            Assert.AreEqual(AnimalEnvironmentFeature.ElevatedPerch, alert);
        }

        [Test]
        public void PangolinOnlyRepositionsToDefensiveGroundWhenGuarding()
        {
            Assert.IsTrue(AnimalAutonomousPositioningRules.TryGetPreferredFeature(
                AnimalSpecies.Pangolin, AnimalCommand.Guard, out AnimalEnvironmentFeature guard));
            Assert.AreEqual(AnimalEnvironmentFeature.DefensiveGround, guard);
            Assert.IsFalse(AnimalAutonomousPositioningRules.TryGetPreferredFeature(
                AnimalSpecies.Pangolin, AnimalCommand.Follow, out _));
        }

        [Test]
        public void CatOnlyUsesConcealmentDuringStalk()
        {
            Assert.IsTrue(AnimalAutonomousPositioningRules.TryGetPreferredFeature(
                AnimalSpecies.Cat, AnimalCommand.Stalk, out AnimalEnvironmentFeature stalk));
            Assert.AreEqual(AnimalEnvironmentFeature.Concealment, stalk);
            Assert.IsFalse(AnimalAutonomousPositioningRules.TryGetPreferredFeature(
                AnimalSpecies.Cat, AnimalCommand.Follow, out _));
        }

        [Test]
        public void ShepherdUsesScentGroundOnlyWhenTracking()
        {
            Assert.IsTrue(AnimalAutonomousPositioningRules.TryGetPreferredFeature(
                AnimalSpecies.GermanShepherd, AnimalCommand.TrackScent, out AnimalEnvironmentFeature track));
            Assert.AreEqual(AnimalEnvironmentFeature.ScentRichGround, track);
            Assert.IsFalse(AnimalAutonomousPositioningRules.TryGetPreferredFeature(
                AnimalSpecies.GermanShepherd, AnimalCommand.Guard, out _));
        }

        [Test]
        public void EnvironmentalPositionsRemainTetheredAndBounded()
        {
            Assert.AreEqual(8f, AnimalAutonomousPositioningRules.MaximumOwnerTetherDistance(
                AnimalSpecies.Falcon, 3f), 0.001f);
            Assert.AreEqual(5.5f, AnimalAutonomousPositioningRules.MaximumOwnerTetherDistance(
                AnimalSpecies.Pangolin, 3f), 0.001f);
            Assert.AreEqual(13f, AnimalAutonomousPositioningRules.MaximumOwnerTetherDistance(
                AnimalSpecies.Falcon, 99f), 0.001f);
        }
    }
}
