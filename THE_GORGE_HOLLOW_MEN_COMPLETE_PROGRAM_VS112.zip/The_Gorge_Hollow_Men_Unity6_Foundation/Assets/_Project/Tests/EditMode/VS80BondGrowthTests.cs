using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS80BondGrowthTests
    {
        [Test]
        public void GainRequiresLivingCompanionBelowMaxAndCooldownElapsed()
        {
            Assert.IsTrue(AnimalBondGrowthRules.CanGain(AnimalStatus.Alive, 10, 100f, 100f));
            Assert.IsTrue(AnimalBondGrowthRules.CanGain(AnimalStatus.Alive, 10, 200f, 100f));
            Assert.IsFalse(AnimalBondGrowthRules.CanGain(AnimalStatus.Alive, 10, 99f, 100f));
            Assert.IsFalse(AnimalBondGrowthRules.CanGain(AnimalStatus.Dead, 10, 200f, 0f));
            Assert.IsFalse(AnimalBondGrowthRules.CanGain(AnimalStatus.Missing, 10, 200f, 0f));
            Assert.IsFalse(AnimalBondGrowthRules.CanGain(AnimalStatus.Alive, AnimalBondGrowthRules.MaxBond, 200f, 0f));
            Assert.IsFalse(AnimalBondGrowthRules.CanGain(AnimalStatus.Alive, 10, float.NaN, 0f));
        }

        [Test]
        public void BondAfterGainClampsToRange()
        {
            Assert.AreEqual(11, AnimalBondGrowthRules.BondAfterGain(10));
            Assert.AreEqual(AnimalBondGrowthRules.MaxBond, AnimalBondGrowthRules.BondAfterGain(AnimalBondGrowthRules.MaxBond));
            Assert.AreEqual(AnimalBondGrowthRules.BondPerAbilityUse, AnimalBondGrowthRules.BondAfterGain(-7));
        }

        [Test]
        public void CooldownIsPositiveAndAppliedFromNow()
        {
            Assert.Greater(AnimalBondGrowthRules.MinSecondsBetweenGains, 0f);
            Assert.AreEqual(10f + AnimalBondGrowthRules.MinSecondsBetweenGains,
                AnimalBondGrowthRules.NextAllowedAt(10f), 0.0001f);
        }

        [Test]
        public void ResonanceThresholdFiresOnlyOnTheCrossingGain()
        {
            int need = AnimalSpeciesTactics.BondResonanceMinimumBond;
            Assert.IsTrue(AnimalBondGrowthRules.CrossedResonanceThreshold(need - 1, need));
            Assert.IsFalse(AnimalBondGrowthRules.CrossedResonanceThreshold(need, need + 1));
            Assert.IsFalse(AnimalBondGrowthRules.CrossedResonanceThreshold(need - 5, need - 4));
        }

        [Test]
        public void SingleGainIsSmallerThanResonanceCost()
        {
            Assert.Greater(AnimalBondGrowthRules.BondPerAbilityUse, 0);
            Assert.Less(AnimalBondGrowthRules.BondPerAbilityUse, AnimalSpeciesTactics.BondResonanceBondCost);
        }

        [Test]
        public void ReadyToastIsNamedWithFallback()
        {
            Assert.IsTrue(AnimalBondGrowthRules.FormatResonanceReadyToast("Rex").Contains("Rex"));
            Assert.IsFalse(string.IsNullOrWhiteSpace(AnimalBondGrowthRules.FormatResonanceReadyToast(null)));
        }

        [Test]
        public void StatusLineWithBondAppendsClampedBond()
        {
            string line = AnimalStatusSummaryRules.FormatStatusLine("Rex", AnimalSpecies.GermanShepherd,
                90, 70, 3, true, 0, 2, "", 12, 1, 37);
            StringAssert.EndsWith("  BOND 37", line);
            StringAssert.Contains("ABILITIES 1/6", line);
            StringAssert.EndsWith("  BOND 100", AnimalStatusSummaryRules.FormatStatusLine("R", AnimalSpecies.Cat,
                1, 1, 0, true, 0, 2, "", 0, 0, 500));
            StringAssert.EndsWith("  BOND 0", AnimalStatusSummaryRules.FormatStatusLine("R", AnimalSpecies.Cat,
                1, 1, 0, true, 0, 2, "", 0, 0, -4));
        }
    }
}
