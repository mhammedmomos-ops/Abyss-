using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public class VS86AnimalTeamworkTests
    {
        [TestCase(AnimalSpecies.GermanShepherd, AnimalTeamworkRole.ShepherdInterception)]
        [TestCase(AnimalSpecies.Falcon, AnimalTeamworkRole.FalconDistraction)]
        [TestCase(AnimalSpecies.Pangolin, AnimalTeamworkRole.PangolinDefensiveAnchor)]
        [TestCase(AnimalSpecies.Cat, AnimalTeamworkRole.CatFlankDistraction)]
        public void EachSpeciesHasItsOwnTeamworkRole(AnimalSpecies species, AnimalTeamworkRole role)
        {
            Assert.IsTrue(AnimalTeamworkRules.CanContribute(species, role));
        }

        [Test]
        public void SpeciesCannotClaimAnotherSpeciesRole()
        {
            Assert.IsFalse(AnimalTeamworkRules.CanContribute(AnimalSpecies.Cat, AnimalTeamworkRole.ShepherdInterception));
            Assert.IsFalse(AnimalTeamworkRules.CanContribute(AnimalSpecies.Falcon, AnimalTeamworkRole.PangolinDefensiveAnchor));
        }

        [Test]
        public void EachApprovedCompanionCanOpenPlayerFollowThrough()
        {
            AnimalSpecies[] species = { AnimalSpecies.GermanShepherd, AnimalSpecies.Falcon,
                AnimalSpecies.Pangolin, AnimalSpecies.Cat };
            for (int i = 0; i < species.Length; i++)
            {
                int mask = AnimalTeamworkRules.AddSpecies(0, species[i]);
                Assert.AreEqual(1.08f, AnimalTeamworkRules.DamageMultiplier(mask), 0.001f);
            }
        }

        [Test]
        public void UnknownSpeciesCannotCreateDamageBonus()
        {
            Assert.AreEqual(1f, AnimalTeamworkRules.DamageMultiplier(0), 0.001f);
            Assert.AreEqual(1f, AnimalTeamworkRules.DamageMultiplier(-1 & ~15), 0.001f);
        }

        [Test]
        public void RepeatedContributionDoesNotStackThePlayerBonus()
        {
            int mask = AnimalTeamworkRules.AddSpecies(0, AnimalSpecies.Cat);
            mask = AnimalTeamworkRules.AddSpecies(mask, AnimalSpecies.Cat);
            Assert.AreEqual(1, AnimalTeamworkRules.SpeciesCount(mask));
            Assert.AreEqual(1.08f, AnimalTeamworkRules.DamageMultiplier(mask), 0.001f);
        }

        [Test]
        public void DamageBonusRequiresMatchingTargetAndLiveWindow()
        {
            int mask = AnimalTeamworkRules.AddSpecies(0, AnimalSpecies.Cat);
            mask = AnimalTeamworkRules.AddSpecies(mask, AnimalSpecies.Pangolin);
            Assert.AreEqual(20f, AnimalTeamworkRules.ApplyDamageMultiplier(20f, mask, false, 2f, 6f), 0.001f);
            Assert.AreEqual(20f, AnimalTeamworkRules.ApplyDamageMultiplier(20f, mask, true, 7f, 6f), 0.001f);
            Assert.AreEqual(21.6f, AnimalTeamworkRules.ApplyDamageMultiplier(20f, mask, true, 3f, 6f), 0.001f);
        }

        [Test]
        public void InvalidRoleAndNonFiniteTimeCannotRegister()
        {
            AnimalTeamworkState.ClearForTests();
            var target = new GameObject("teamwork-invalid-target");
            try
            {
                Assert.IsFalse(AnimalTeamworkState.Register(target.transform, AnimalSpecies.Cat,
                    AnimalTeamworkRole.ShepherdInterception, 1f));
                Assert.IsFalse(AnimalTeamworkState.Register(target.transform, AnimalSpecies.Cat,
                    AnimalTeamworkRole.CatFlankDistraction, float.NaN));
                Assert.AreEqual(0, AnimalTeamworkState.ActiveSpeciesCount(target.transform, 2f));
            }
            finally
            {
                AnimalTeamworkState.ClearForTests();
                Object.DestroyImmediate(target);
            }
        }

        [Test]
        public void ExpiredTargetWindowCanOpenAgainButDoesNotCarryOldBonus()
        {
            AnimalTeamworkState.ClearForTests();
            var target = new GameObject("teamwork-expiry-target");
            try
            {
                Assert.IsTrue(AnimalTeamworkState.Register(target.transform, AnimalSpecies.GermanShepherd,
                    AnimalTeamworkRole.ShepherdInterception, 1f));
                Assert.AreEqual(20f, AnimalTeamworkState.ModifyDamage(target.transform, 20f, 6f), 0.001f);
                Assert.IsTrue(AnimalTeamworkState.Register(target.transform, AnimalSpecies.GermanShepherd,
                    AnimalTeamworkRole.ShepherdInterception, 6f));
                Assert.AreEqual(21.6f, AnimalTeamworkState.ModifyDamage(target.transform, 20f, 6.1f), 0.001f);
            }
            finally
            {
                AnimalTeamworkState.ClearForTests();
                Object.DestroyImmediate(target);
            }
        }

        [Test]
        public void TargetLedgerOpensOnceAndIsIsolatedPerMonster()
        {
            AnimalTeamworkState.ClearForTests();
            var first = new GameObject("teamwork-target-a");
            var second = new GameObject("teamwork-target-b");
            try
            {
                Assert.IsTrue(AnimalTeamworkState.Register(first.transform, AnimalSpecies.Falcon,
                    AnimalTeamworkRole.FalconDistraction, 1f));
                Assert.IsFalse(AnimalTeamworkState.Register(first.transform, AnimalSpecies.Cat,
                    AnimalTeamworkRole.CatFlankDistraction, 2f));
                Assert.IsFalse(AnimalTeamworkState.Register(first.transform, AnimalSpecies.Cat,
                    AnimalTeamworkRole.CatFlankDistraction, 2.5f));
                Assert.AreEqual(2, AnimalTeamworkState.ActiveSpeciesCount(first.transform, 3f));
                Assert.AreEqual(0, AnimalTeamworkState.ActiveSpeciesCount(second.transform, 3f));
                Assert.AreEqual(21.6f, AnimalTeamworkState.ModifyDamage(first.transform, 20f, 3f), 0.001f);
                Assert.AreEqual(20f, AnimalTeamworkState.ModifyDamage(second.transform, 20f, 3f), 0.001f);
            }
            finally
            {
                AnimalTeamworkState.ClearForTests();
                Object.DestroyImmediate(first);
                Object.DestroyImmediate(second);
            }
        }
    }
}
