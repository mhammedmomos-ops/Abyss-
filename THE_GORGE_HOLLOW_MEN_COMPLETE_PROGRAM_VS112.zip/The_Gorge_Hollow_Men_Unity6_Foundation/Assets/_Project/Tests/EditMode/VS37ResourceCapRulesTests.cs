using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS37ResourceCapRulesTests
    {
        [Test]
        public void ApplyCapClampsToMax()
            => Assert.AreEqual(100, ResourceCapRules.ApplyCap(95, 20, 100));

        [Test]
        public void ApplyCapAllowsWithin()
            => Assert.AreEqual(50, ResourceCapRules.ApplyCap(40, 10, 100));

        [Test]
        public void ApplyCapNoCapUnlimited()
            => Assert.AreEqual(120, ResourceCapRules.ApplyCap(100, 20, 0));

        [Test]
        public void WouldExceedDetectsOverflow()
            => Assert.IsTrue(ResourceCapRules.WouldExceed(90, 15, 100));

        [Test]
        public void WouldExceedFalseWhenUnder()
            => Assert.IsFalse(ResourceCapRules.WouldExceed(90, 5, 100));
    }
}
