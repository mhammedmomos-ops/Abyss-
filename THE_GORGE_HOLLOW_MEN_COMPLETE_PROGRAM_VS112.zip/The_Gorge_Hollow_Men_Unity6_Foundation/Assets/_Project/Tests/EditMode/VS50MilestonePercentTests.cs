using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS50MilestonePercentTests
    {
        [Test]
        public void Night1IsZero()
            => Assert.AreEqual(0, MilestonePercentUtility.NightToPercent(1, 20));

        [Test]
        public void Night20Is100()
            => Assert.AreEqual(100, MilestonePercentUtility.NightToPercent(20, 20));

        [Test]
        public void MidCampaignScales()
            => Assert.AreEqual(50, MilestonePercentUtility.NightToPercent(11, 20));
    }
}
