using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS45ArmorPlateTests
    {
        [Test]
        public void AbsorbReducesDamageAndPlates()
        {
            float plates = 50f;
            float absorbFraction = 0.6f;
            float incoming = 20f;
            float absorbed = incoming * absorbFraction;
            absorbed = Mathf.Min(absorbed, plates);
            plates -= absorbed;
            float remaining = incoming - absorbed;
            Assert.AreEqual(12f, absorbed, 0.001f);
            Assert.AreEqual(8f, remaining, 0.001f);
            Assert.AreEqual(38f, plates, 0.001f);
        }

        [Test]
        public void ZeroPlatesPassesFullDamage()
        {
            float plates = 0f;
            float incoming = 15f;
            float result = plates <= 0f ? incoming : incoming * 0.4f;
            Assert.AreEqual(15f, result, 0.001f);
        }
    }
}
