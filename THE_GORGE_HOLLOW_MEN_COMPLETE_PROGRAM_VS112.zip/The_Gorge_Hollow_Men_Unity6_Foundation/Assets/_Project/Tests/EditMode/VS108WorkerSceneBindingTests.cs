using System.Reflection;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AI;

namespace GorgeHollow.Tests
{
    public sealed class VS108WorkerSceneBindingTests
    {
        [Test]
        public void WorkerActorAcceptsAllFourTowerLocalWorkTargets()
        {
            GameObject actorObject = new GameObject("worker-test");
            GameObject[] targets = new GameObject[4];
            try
            {
                TowerWorkerActor actor = actorObject.AddComponent<TowerWorkerActor>();
                for (int i = 0; i < targets.Length; i++) targets[i] = new GameObject("target-" + i);
                actor.ConfigureWorkTargets(targets[0].transform, targets[1].transform, targets[2].transform, targets[3].transform);

                Assert.AreSame(targets[0].transform, ReadTarget(actor, "productionPoint"));
                Assert.AreSame(targets[1].transform, ReadTarget(actor, "salvagePoint"));
                Assert.AreSame(targets[2].transform, ReadTarget(actor, "guardPoint"));
                Assert.AreSame(targets[3].transform, ReadTarget(actor, "restPoint"));
            }
            finally
            {
                Object.DestroyImmediate(actorObject);
                for (int i = 0; i < targets.Length; i++)
                    if (targets[i] != null) Object.DestroyImmediate(targets[i]);
            }
        }

        [Test]
        public void WorkerActorBindingRetainsStableWorkerIdentity()
        {
            GameObject actorObject = new GameObject("worker-test");
            try
            {
                TowerWorkerActor actor = actorObject.AddComponent<TowerWorkerActor>();
                actor.Bind("stable-worker-identity");
                Assert.AreEqual("stable-worker-identity", actor.WorkerIdentity);
            }
            finally { Object.DestroyImmediate(actorObject); }
        }


        [Test]
        public void WorkerAgentCannotUseBridgeJumpAreaOrOffMeshLinks()
        {
            GameObject actorObject = new GameObject("worker-agent-test");
            try
            {
                NavMeshAgent agent = actorObject.AddComponent<NavMeshAgent>();
                TowerWorkerActor actor = actorObject.AddComponent<TowerWorkerActor>();
                actor.ConfigureWorkTargets(null, null, null, null);
                int jumpArea = NavMesh.GetAreaFromName("Jump");
                Assert.GreaterOrEqual(jumpArea, 0);
                Assert.AreEqual(0, agent.areaMask & (1 << jumpArea));
                Assert.IsFalse(agent.autoTraverseOffMeshLink);
            }
            finally { Object.DestroyImmediate(actorObject); }
        }


        private static Transform ReadTarget(TowerWorkerActor actor, string fieldName)
        {
            FieldInfo field = typeof(TowerWorkerActor).GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(field, "Expected serialized worker target field: " + fieldName);
            return field.GetValue(actor) as Transform;
        }
    }
}
