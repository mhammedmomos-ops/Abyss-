using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS17TowerDamageStateTests
    {
        [Test]
        public void FullHealthIsHealthy()
        {
            Assert.AreEqual(TowerDamageStage.Healthy,
                TowerDamageStageRules.Evaluate(100, 100, 0.65f, 0.30f));
        }

        [Test]
        public void DamageAndCriticalThresholdsAreInclusive()
        {
            Assert.AreEqual(TowerDamageStage.Damaged,
                TowerDamageStageRules.Evaluate(65, 100, 0.65f, 0.30f));
            Assert.AreEqual(TowerDamageStage.Critical,
                TowerDamageStageRules.Evaluate(30, 100, 0.65f, 0.30f));
        }

        [Test]
        public void ZeroHealthAndInvalidMaximumAreDestroyed()
        {
            Assert.AreEqual(TowerDamageStage.Destroyed,
                TowerDamageStageRules.Evaluate(0, 100, 0.65f, 0.30f));
            Assert.AreEqual(TowerDamageStage.Destroyed,
                TowerDamageStageRules.Evaluate(10, 0, 0.65f, 0.30f));
        }

        [Test]
        public void ReversedThresholdsAreNormalized()
        {
            Assert.AreEqual(TowerDamageStage.Damaged,
                TowerDamageStageRules.Evaluate(50, 100, 0.30f, 0.65f));
            Assert.AreEqual(TowerDamageStage.Critical,
                TowerDamageStageRules.Evaluate(20, 100, 0.30f, 0.65f));
        }

        [Test]
        public void NonFiniteThresholdsUseSafeDefaults()
        {
            Assert.AreEqual(TowerDamageStage.Damaged,
                TowerDamageStageRules.Evaluate(60, 100, float.NaN, float.PositiveInfinity));
            Assert.AreEqual(TowerDamageStage.Critical,
                TowerDamageStageRules.Evaluate(20, 100, float.NaN, float.PositiveInfinity));
        }

        [Test]
        public void FunctionalModuleDisablesAtThresholdAndWhenDestroyed()
        {
            Assert.IsFalse(TowerDamageStageRules.IsModuleOffline(26, 100, 0.25f));
            Assert.IsTrue(TowerDamageStageRules.IsModuleOffline(25, 100, 0.25f));
            Assert.IsTrue(TowerDamageStageRules.IsModuleOffline(1, 0, 0.25f));
        }

        [Test]
        public void RepairedStructureBringsModuleBackOnline()
        {
            Assert.IsTrue(TowerDamageStageRules.IsModuleOffline(20, 100, 0.25f));
            Assert.IsFalse(TowerDamageStageRules.IsModuleOffline(80, 100, 0.25f));
        }

        [Test]
        public void ZeroOfflineThresholdOnlyDisablesAtDestruction()
        {
            Assert.IsFalse(TowerDamageStageRules.IsModuleOffline(1, 100, 0f));
            Assert.IsTrue(TowerDamageStageRules.IsModuleOffline(0, 100, 0f));
        }
    }
}
