using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS95TowerDepotRulesTests
    {
        private static SupplyConvoyRecord Convoy(string destination = "tower_a") => new SupplyConvoyRecord
        { identity = "vs95-convoy", destinationTowerId = destination, status = SupplyConvoyStatus.Travelling,
          currentHealth = 50, maximumHealth = 100, worldPosition = Vector3.zero, scrap = 10, timber = 6 };

        [Test] public void NewCampaignCreatesTwoIndependentEmptyDepots()
        {
            var state = CampaignStateFactory.CreateNew();
            Assert.AreEqual(2, state.towerDepots.Count);
            Assert.AreEqual(0, TowerDepotRules.Find(state, "tower_a").scrap);
            Assert.AreEqual(0, TowerDepotRules.Find(state, "tower_b").scrap);
        }

        [Test] public void DeliveryCreditsOnlyDesignatedTower()
        {
            var state = CampaignStateFactory.CreateNew(); var convoy = Convoy("tower_b");
            Assert.IsTrue(SupplyConvoyRules.TryDeliver(state, convoy, out string error), error);
            Assert.AreEqual(10, TowerDepotRules.Find(state, "tower_b").scrap);
            Assert.AreEqual(0, TowerDepotRules.Find(state, "tower_a").scrap);
            Assert.AreEqual(0, state.scrap);
        }

        [Test] public void MissingDestinationDepotRejectsDeliveryWithoutConsumingCargo()
        {
            var state = CampaignStateFactory.CreateNew(); var convoy = Convoy("tower_unknown");
            Assert.IsFalse(SupplyConvoyRules.TryDeliver(state, convoy, out _));
            Assert.AreEqual(SupplyConvoyStatus.Travelling, convoy.status);
            Assert.AreEqual(10, convoy.scrap);
        }

        [Test] public void DepotOverflowRejectsWholeDelivery()
        {
            var state = CampaignStateFactory.CreateNew(); var depot = TowerDepotRules.Find(state, "tower_a");
            depot.scrap = int.MaxValue; var convoy = Convoy();
            Assert.IsFalse(SupplyConvoyRules.TryDeliver(state, convoy, out _));
            Assert.AreEqual(int.MaxValue, depot.scrap); Assert.AreEqual(0, depot.timber);
            Assert.AreEqual(SupplyConvoyStatus.Travelling, convoy.status);
        }

        [Test] public void RepairCannotSpendMaterialsFromOtherTower()
        {
            var state = CampaignStateFactory.CreateNew();
            TowerDepotRules.Find(state, "tower_b").scrap = 50;
            Assert.IsFalse(TowerDepotRules.TrySpendRepairMaterials(TowerDepotRules.Find(state, "tower_a"), 1, 0, out _));
            Assert.AreEqual(50, TowerDepotRules.Find(state, "tower_b").scrap);
        }

        [Test] public void RepairSpendsOnlyLocalMaterials()
        {
            var state = CampaignStateFactory.CreateNew(); var a = TowerDepotRules.Find(state, "tower_a");
            a.scrap = 12; a.timber = 9; var b = TowerDepotRules.Find(state, "tower_b"); b.scrap = 30;
            Assert.IsTrue(TowerDepotRules.TrySpendRepairMaterials(a, 7, 4, out _));
            Assert.AreEqual(5, a.scrap); Assert.AreEqual(5, a.timber); Assert.AreEqual(30, b.scrap);
        }

        [Test] public void DepotRejectsNegativeBalancesDuringCampaignValidation()
        {
            var state = CampaignStateFactory.CreateNew(); TowerDepotRules.Find(state, "tower_a").timber = -1;
            Assert.IsFalse(state.IsValid(out _));
        }
    }
}
