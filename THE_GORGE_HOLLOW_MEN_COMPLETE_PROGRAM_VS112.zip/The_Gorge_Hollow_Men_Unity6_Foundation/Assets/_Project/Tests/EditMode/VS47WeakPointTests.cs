using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS47WeakPointTests
    {
        [Test]
        public void MultiplierAtLeastOne()
        {
            float multiplier = Mathf.Max(1f, 2f);
            Assert.AreEqual(2f, multiplier, 0.001f);
            Assert.AreEqual(1f, Mathf.Max(1f, 0.5f), 0.001f);
        }
    }
}
