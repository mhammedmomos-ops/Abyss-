using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS24InjuryRecoveryRulesTests
    {
        [Test]
        public void NoRecoveryWhenInjuryZero()
            => Assert.AreEqual(0f, InjuryRecoveryRules.CalculateRecoveryDelta(0f, 2f, 1f, 20f, 5f), 0.001f);

        [Test]
        public void NoRecoveryDuringLockout()
            => Assert.AreEqual(0f, InjuryRecoveryRules.CalculateRecoveryDelta(40f, 2f, 1f, 2f, 8f), 0.001f);

        [Test]
        public void RecoveryAppliesAfterLockout()
            => Assert.AreEqual(2f, InjuryRecoveryRules.CalculateRecoveryDelta(40f, 2f, 1f, 10f, 8f), 0.001f);

        [Test]
        public void RecoveryCannotExceedCurrentInjury()
            => Assert.AreEqual(1.5f, InjuryRecoveryRules.CalculateRecoveryDelta(1.5f, 5f, 1f, 20f, 0f), 0.001f);

        [Test]
        public void NonFiniteInputsProduceZero()
            => Assert.AreEqual(0f, InjuryRecoveryRules.CalculateRecoveryDelta(float.NaN, 2f, 1f, 10f, 0f), 0.001f);

        [Test]
        public void NegativeRateProducesZero()
            => Assert.AreEqual(0f, InjuryRecoveryRules.CalculateRecoveryDelta(50f, -3f, 1f, 20f, 0f), 0.001f);

        [TestCase(0f, 0.45f, 1f)]
        [TestCase(100f, 0.45f, 0.55f)]
        [TestCase(50f, 0.45f, 0.775f)]
        public void SpeedMultiplierMatchesInjuryPenalty(float injury, float penalty, float expected)
            => Assert.AreEqual(expected, InjuryRecoveryRules.SpeedMultiplierFromInjury(injury, penalty), 0.001f);

        [Test]
        public void SpeedMultiplierClampsNonFinite()
            => Assert.AreEqual(1f, InjuryRecoveryRules.SpeedMultiplierFromInjury(float.PositiveInfinity, 0.5f), 0.001f);
    }
}
