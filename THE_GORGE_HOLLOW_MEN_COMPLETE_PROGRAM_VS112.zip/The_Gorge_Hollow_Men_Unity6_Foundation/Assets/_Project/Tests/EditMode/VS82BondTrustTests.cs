using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS82BondTrustTests
    {
        [Test]
        public void TrustRanksUseInclusiveThresholdsAndClampBond()
        {
            Assert.AreEqual(0, AnimalBondTrustRules.RankForBond(0));
            Assert.AreEqual(1, AnimalBondTrustRules.RankForBond(25));
            Assert.AreEqual(2, AnimalBondTrustRules.RankForBond(50));
            Assert.AreEqual(3, AnimalBondTrustRules.RankForBond(75));
            Assert.AreEqual(4, AnimalBondTrustRules.RankForBond(100));
            Assert.AreEqual(0, AnimalBondTrustRules.RankForBond(-10));
            Assert.AreEqual(4, AnimalBondTrustRules.RankForBond(500));
        }

        [Test]
        public void AwarenessBonusIsMonotonicAndBounded()
        {
            float previous = 0f;
            for (int bond = 0; bond <= 100; bond++)
            {
                float multiplier = AnimalBondTrustRules.DetectionMultiplier(bond);
                Assert.GreaterOrEqual(multiplier, previous);
                Assert.GreaterOrEqual(multiplier, 1f);
                Assert.LessOrEqual(multiplier, 1.16f);
                previous = multiplier;
            }
            Assert.AreEqual(1f, AnimalBondTrustRules.DetectionMultiplier(0), 0.0001f);
            Assert.AreEqual(1.16f, AnimalBondTrustRules.DetectionMultiplier(100), 0.0001f);
        }

        [Test]
        public void SpendingBondCanLowerRankAndBonusImmediately()
        {
            int afterResonance = AnimalBondResonanceRules.BondAfterResonate(52);
            Assert.AreEqual(48, afterResonance);
            Assert.AreEqual(2, AnimalBondTrustRules.RankForBond(52));
            Assert.AreEqual(1, AnimalBondTrustRules.RankForBond(afterResonance));
            Assert.Less(AnimalBondTrustRules.DetectionMultiplier(afterResonance),
                AnimalBondTrustRules.DetectionMultiplier(52));
        }

        [Test]
        public void RankNamesAndStatusLineAreReadable()
        {
            Assert.AreEqual("NEW BOND", AnimalBondTrustRules.RankName(0));
            Assert.AreEqual("BONDING", AnimalBondTrustRules.RankName(25));
            Assert.AreEqual("TRUSTED", AnimalBondTrustRules.RankName(50));
            Assert.AreEqual("LOYAL", AnimalBondTrustRules.RankName(75));
            Assert.AreEqual("DEVOTED", AnimalBondTrustRules.RankName(100));
            string line = AnimalStatusSummaryRules.FormatStatusLine("Rex", AnimalSpecies.GermanShepherd,
                90, 70, 3, true, 0, 2, "GUARDING", 20, 2, 55);
            StringAssert.Contains("TRUSTED  BOND 55", line);
            StringAssert.EndsWith("BOND 55", line);
        }

        [Test]
        public void RankToastUsesNameFallbackAndCurrentRank()
        {
            StringAssert.Contains("Rex reached TRUSTED bond", AnimalBondTrustRules.FormatRankToast("Rex", 50));
            StringAssert.Contains("Your companion reached DEVOTED bond", AnimalBondTrustRules.FormatRankToast(null, 100));
        }
    }
}
