using System.Collections.Generic;
using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS103WorkerRaidResponseTests
    {
        private static TowerWorkerRecord Worker(string id, TowerWorkerRole role, TowerWorkerAssignment assignment)
        {
            return new TowerWorkerRecord
            {
                identity = id, displayName = id, towerId = "tower_a", role = role,
                assignment = assignment, status = TowerWorkerStatus.Active, health = 100, skill = 25
            };
        }

        [Test]
        public void MechanicEvacuatesDuringRaid()
        {
            Assert.AreEqual(TowerWorkerTacticalState.Evacuating,
                TowerWorkerRaidRules.ChoosePosture(Worker("m", TowerWorkerRole.Mechanic, TowerWorkerAssignment.Production)));
        }

        [Test]
        public void ScavengerEvacuatesDuringRaid()
        {
            Assert.AreEqual(TowerWorkerTacticalState.Evacuating,
                TowerWorkerRaidRules.ChoosePosture(Worker("s", TowerWorkerRole.Scavenger, TowerWorkerAssignment.Salvage)));
        }

        [Test]
        public void AssignedGuardTakesDefensivePosition()
        {
            Assert.AreEqual(TowerWorkerTacticalState.Defending,
                TowerWorkerRaidRules.ChoosePosture(Worker("g", TowerWorkerRole.Guard, TowerWorkerAssignment.Guard)));
        }

        [Test]
        public void MedicPrioritizesInjuredWorkerResponse()
        {
            Assert.AreEqual(TowerWorkerTacticalState.AssistingInjured,
                TowerWorkerRaidRules.ChoosePosture(Worker("med", TowerWorkerRole.Medic, TowerWorkerAssignment.Idle)));
        }

        [Test]
        public void InjuredOrRestingWorkerEvacuatesRegardlessOfRole()
        {
            TowerWorkerRecord worker = Worker("hurt", TowerWorkerRole.Guard, TowerWorkerAssignment.Rest);
            worker.status = TowerWorkerStatus.Injured;
            worker.health = 20;
            Assert.AreEqual(TowerWorkerTacticalState.Normal, TowerWorkerRaidRules.ChoosePosture(worker));
        }

        [Test]
        public void DeadWorkerHasNoRaidPosture()
        {
            TowerWorkerRecord worker = Worker("dead", TowerWorkerRole.Guard, TowerWorkerAssignment.Guard);
            worker.status = TowerWorkerStatus.Dead;
            worker.health = 0;
            worker.assignment = TowerWorkerAssignment.Idle;
            Assert.AreEqual(TowerWorkerTacticalState.Normal, TowerWorkerRaidRules.ChoosePosture(worker));
        }

        [Test]
        public void OrdersOnlyIncludeWorkersFromRequestedTowerAndRespectPlayerOverride()
        {
            TowerWorkerRecord a = Worker("a", TowerWorkerRole.Mechanic, TowerWorkerAssignment.Production);
            TowerWorkerRecord b = Worker("b", TowerWorkerRole.Guard, TowerWorkerAssignment.Guard);
            b.towerId = "tower_b";
            TowerWorkerRecord c = Worker("c", TowerWorkerRole.Scavenger, TowerWorkerAssignment.Salvage);
            c.playerOverrideDuringRaid = true;
            List<TowerWorkerRaidOrder> orders = TowerWorkerRaidRules.BuildOrders(new[] { a, b, c }, "tower_a");
            Assert.AreEqual(1, orders.Count);
            Assert.AreEqual("a", orders[0].workerIdentity);
        }

        [Test]
        public void MedicWithoutAnInjuredPatientEvacuatesToCover()
        {
            TowerWorkerRecord medic = Worker("med", TowerWorkerRole.Medic, TowerWorkerAssignment.Idle);
            List<TowerWorkerRaidOrder> orders = TowerWorkerRaidRules.BuildOrders(new[] { medic }, "tower_a");
            Assert.AreEqual(TowerWorkerTacticalState.Evacuating, orders[0].state);
        }

        [Test]
        public void MedicChoosesMostInjuredWorkerAtItsOwnTower()
        {
            TowerWorkerRecord lightly = Worker("light", TowerWorkerRole.Mechanic, TowerWorkerAssignment.Rest);
            lightly.status = TowerWorkerStatus.Injured; lightly.health = 20;
            TowerWorkerRecord critical = Worker("critical", TowerWorkerRole.Scavenger, TowerWorkerAssignment.Rest);
            critical.status = TowerWorkerStatus.Injured; critical.health = 7;
            TowerWorkerRecord otherTower = Worker("other", TowerWorkerRole.Guard, TowerWorkerAssignment.Rest);
            otherTower.status = TowerWorkerStatus.Injured; otherTower.health = 1; otherTower.towerId = "tower_b";
            Assert.AreEqual("critical", TowerWorkerRaidRules.FindMostInjured(new[] { lightly, critical, otherTower }, "tower_a").identity);
        }

        [Test]
        public void CapturedWorkerCannotBeAssignedOrActAsGuard()
        {
            TowerWorkerRecord worker = Worker("captive", TowerWorkerRole.Guard, TowerWorkerAssignment.Idle);
            worker.status = TowerWorkerStatus.Captured;
            Assert.AreEqual(TowerWorkerTacticalState.Normal, TowerWorkerRaidRules.ChoosePosture(worker));
            Assert.AreEqual(2, (int)TowerWorkerStatus.Dead, "VS102 save enum values must remain stable.");
            Assert.AreEqual(3, (int)TowerWorkerStatus.Captured);
            CampaignState campaign = CampaignStateFactory.CreateNew();
            campaign.towerWorkers.Clear();
            campaign.towerWorkers.Add(worker);
            Assert.IsTrue(campaign.IsValid(out string validationError), validationError);
            Assert.IsFalse(TowerWorkerRules.TryAssign(campaign, "captive", TowerWorkerAssignment.Guard, out _));
            Assert.AreEqual(1f, TowerWorkerRules.SiegeDamageMultiplier(campaign, "tower_a"));
        }
    }
}
