using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class CampaignStateFactoryTests
    {
        [Test]
        public void CreateNew_ReturnsValidRecoveryPreparationCampaign()
        {
            CampaignState state = CampaignStateFactory.CreateNew();

            Assert.IsNotNull(state);
            Assert.IsTrue(state.IsValid(out string error), error);
            Assert.AreEqual(CampaignPhase.RecoveryPreparation, state.phase);
            Assert.AreEqual(1, state.night);
            Assert.AreEqual(1, state.chapter);
            Assert.AreEqual(1, state.fictionalDay);
            Assert.AreEqual(6, state.fictionalHour);
            Assert.AreEqual(0, state.fictionalMinute);
        }

        [Test]
        public void CreateNew_UsesIndependentCampaignIdentityAndCollections()
        {
            CampaignState first = CampaignStateFactory.CreateNew();
            CampaignState second = CampaignStateFactory.CreateNew();

            Assert.AreNotEqual(first.campaignId, second.campaignId);
            Assert.AreNotSame(first.playerVitals, second.playerVitals);
            Assert.AreNotSame(first.towerStructures, second.towerStructures);
            Assert.AreNotSame(first.monsterNests, second.monsterNests);
            Assert.AreNotSame(first.animals, second.animals);
            Assert.AreNotSame(first.towerWorkers, second.towerWorkers);
            Assert.AreNotSame(first.workerRelationships, second.workerRelationships);
            Assert.AreNotSame(first.campaignFlags, second.campaignFlags);
            Assert.AreNotSame(first.eventHistory, second.eventHistory);
            first.campaignFlags.Add("test-only");
            first.towerWorkers[0].morale = 1;
            Assert.IsEmpty(second.campaignFlags);
            Assert.AreNotEqual(1, second.towerWorkers[0].morale);
        }

        [Test]
        public void CreateNew_StartsWithNoPriorCampaignProgress()
        {
            CampaignState state = CampaignStateFactory.CreateNew();

            Assert.IsEmpty(state.towerStructures);
            Assert.IsEmpty(state.monsterNests);
            Assert.IsEmpty(state.animals);
            Assert.IsEmpty(state.appliedTransactionIds);
            Assert.IsEmpty(state.campaignFlags);
            Assert.IsEmpty(state.eventHistory);
            Assert.AreEqual(0, state.scrap);
            Assert.AreEqual(0, state.timber);
        }
    }
}
