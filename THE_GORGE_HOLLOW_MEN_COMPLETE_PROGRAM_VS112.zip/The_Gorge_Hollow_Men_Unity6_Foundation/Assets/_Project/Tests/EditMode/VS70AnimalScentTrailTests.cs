using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS70AnimalScentTrailTests
    {
        [Test]
        public void TrailFreshnessDecaysToZeroAtConfiguredLifetime()
        {
            Assert.IsTrue(AnimalScentTrailRules.IsFresh(20f, 10f, 15f));
            Assert.AreEqual(1f, AnimalScentTrailRules.Freshness(10f, 10f, 15f), 0.001f);
            Assert.AreEqual(0.5f, AnimalScentTrailRules.Freshness(17.5f, 10f, 15f), 0.001f);
            Assert.IsFalse(AnimalScentTrailRules.IsFresh(26f, 10f, 15f));
        }

        [Test]
        public void FutureAndInvalidTrailTimesAreRejected()
        {
            Assert.IsFalse(AnimalScentTrailRules.IsFresh(10f, 11f, 30f));
            Assert.IsFalse(AnimalScentTrailRules.IsFresh(float.NaN, 1f, 30f));
            Assert.IsFalse(AnimalScentTrailRules.IsFresh(10f, 1f, 0f));
        }

        [Test]
        public void SamplesRequireBothElapsedIntervalAndPhysicalMovement()
        {
            Assert.IsFalse(AnimalScentTrailRules.ShouldRecord(Vector3.zero, Vector3.right * 2f, 4f, 5f, 1.6f));
            Assert.IsFalse(AnimalScentTrailRules.ShouldRecord(Vector3.zero, Vector3.right, 6f, 5f, 1.6f));
            Assert.IsTrue(AnimalScentTrailRules.ShouldRecord(Vector3.zero, Vector3.right * 2f, 6f, 5f, 1.6f));
        }

        [Test]
        public void RegistryReturnsLocalNearestTrailAndThenOlderSampleFromSameMonster()
        {
            MonsterScentTrailRegistry.ClearForTests();
            try
            {
                MonsterScentTrailRegistry.Record(101, new Vector3(1f, 0f, 0f), 10f, MonsterArchetypeRole.Brute);
                MonsterScentTrailRegistry.Record(101, new Vector3(3f, 0f, 0f), 8f, MonsterArchetypeRole.Brute);
                MonsterScentTrailRegistry.Record(202, new Vector3(4.2f, 0f, 0f), 11f, MonsterArchetypeRole.Lurker);
                Assert.IsTrue(MonsterScentTrailRegistry.TryFindNearest(Vector3.zero, 5f, 12f, 150f, out MonsterScentSample nearest));
                Assert.AreEqual(101, nearest.SourceId);
                Assert.AreEqual(10f, nearest.CreatedAt);
                Assert.IsTrue(MonsterScentTrailRegistry.TryGetPrevious(101, nearest.CreatedAt, 12f, 150f, out MonsterScentSample previous));
                Assert.AreEqual(8f, previous.CreatedAt);
                Assert.AreEqual(MonsterArchetypeRole.Brute, previous.Role);
            }
            finally
            {
                MonsterScentTrailRegistry.ClearForTests();
            }
        }


        [Test]
        public void RegistryNeverExceedsItsFixedSampleCapacity()
        {
            MonsterScentTrailRegistry.ClearForTests();
            try
            {
                for (int i = 0; i < 800; i++)
                    MonsterScentTrailRegistry.Record(401, new Vector3(i, 0f, 0f), 1f, MonsterArchetypeRole.Stalker);
                Assert.AreEqual(768, MonsterScentTrailRegistry.SampleCount);
            }
            finally
            {
                MonsterScentTrailRegistry.ClearForTests();
            }
        }

        [Test]
        public void RegistryRejectsOutOfRangeAndExpiredSamples()
        {
            MonsterScentTrailRegistry.ClearForTests();
            try
            {
                MonsterScentTrailRegistry.Record(301, Vector3.right * 20f, 1f, MonsterArchetypeRole.Stalker);
                Assert.IsFalse(MonsterScentTrailRegistry.TryFindNearest(Vector3.zero, 5f, 200f, 150f, out _));
                Assert.IsFalse(MonsterScentTrailRegistry.TryFindNearest(Vector3.zero, 5f, 2f, 150f, out _));
            }
            finally
            {
                MonsterScentTrailRegistry.ClearForTests();
            }
        }
    }
}
