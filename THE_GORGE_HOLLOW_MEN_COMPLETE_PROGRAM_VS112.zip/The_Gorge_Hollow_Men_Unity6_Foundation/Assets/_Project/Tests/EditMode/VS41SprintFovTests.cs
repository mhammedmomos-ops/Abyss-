using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS41SprintFovTests
    {
        [Test]
        public void SprintFovIsWiderThanNormal()
        {
            float normalFov = 60f;
            float sprintFov = 66f;
            Assert.Greater(sprintFov, normalFov);
        }

        [Test]
        public void MeleeCooldownPositive()
        {
            float cooldown = 0.7f;
            Assert.Greater(cooldown, 0f);
        }
    }
}
