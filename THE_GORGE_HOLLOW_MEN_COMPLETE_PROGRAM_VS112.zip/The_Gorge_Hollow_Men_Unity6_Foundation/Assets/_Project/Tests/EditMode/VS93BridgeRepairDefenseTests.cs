using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS93BridgeRepairDefenseTests
    {
        [TestCase(AnimalCommand.Guard, 3.5f)]
        [TestCase(AnimalCommand.Protect, 3.5f)]
        [TestCase(AnimalCommand.Follow, 0f)]
        public void ShepherdOnlyCoversFromProtectiveStances(AnimalCommand command, float expected)
            => Assert.AreEqual(expected, BridgeRepairDefenseRules.CoverSeconds(
                AnimalSpecies.GermanShepherd, command, false, false));

        [Test]
        public void PangolinGuardProvidesLongestDefensiveCover()
            => Assert.AreEqual(5f, BridgeRepairDefenseRules.CoverSeconds(
                AnimalSpecies.Pangolin, AnimalCommand.Guard, false, false));

        [Test]
        public void PangolinFollowingDoesNotProvideRepairCover()
            => Assert.AreEqual(0f, BridgeRepairDefenseRules.CoverSeconds(
                AnimalSpecies.Pangolin, AnimalCommand.Follow, false, false));

        [Test]
        public void CatOnlyCoversWhenLuring()
            => Assert.AreEqual(4f, BridgeRepairDefenseRules.CoverSeconds(
                AnimalSpecies.Cat, AnimalCommand.Lure, true, false));

        [Test]
        public void FalconProvidesBriefCoverWhileObserving()
            => Assert.AreEqual(1.5f, BridgeRepairDefenseRules.CoverSeconds(
                AnimalSpecies.Falcon, AnimalCommand.Follow, false, true));

        [Test]
        public void FalconWithoutObservationDoesNotCover()
            => Assert.AreEqual(0f, BridgeRepairDefenseRules.CoverSeconds(
                AnimalSpecies.Falcon, AnimalCommand.Follow, false, false));

        [Test]
        public void SuppliesMustCoverBothResourceTypes()
            => Assert.IsTrue(BridgeRepairDefenseRules.HasEnoughMaterials(16, 10, 16, 10));

        [Test]
        public void MissingTimberBlocksRepairEvenWhenScrapIsSufficient()
            => Assert.IsFalse(BridgeRepairDefenseRules.HasEnoughMaterials(100, 2, 16, 10));

        [Test]
        public void ShortageMessageReportsOnlyMissingAmounts()
            => Assert.AreEqual("Insufficient repair supplies. Missing 0 scrap and 8 timber.",
                BridgeRepairDefenseRules.ShortageMessage(100, 2, 16, 10));

        [Test]
        public void EverySpeciesHasARealCooldown()
        {
            Assert.Greater(BridgeRepairDefenseRules.CooldownSeconds(AnimalSpecies.GermanShepherd), 0f);
            Assert.Greater(BridgeRepairDefenseRules.CooldownSeconds(AnimalSpecies.Falcon), 0f);
            Assert.Greater(BridgeRepairDefenseRules.CooldownSeconds(AnimalSpecies.Pangolin), 0f);
            Assert.Greater(BridgeRepairDefenseRules.CooldownSeconds(AnimalSpecies.Cat), 0f);
        }
    }
}
