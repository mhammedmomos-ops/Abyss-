using System;
using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS42DailySeedTests
    {
        [Test]
        public void DailySeedUsesDateComponents()
        {
            var day = new DateTime(2026, 11, 3, 12, 0, 0, DateTimeKind.Utc);
            Assert.AreEqual(20261103, DailySeedUtility.GetUtcDailySeed(day));
        }

        [Test]
        public void MixIsDeterministic()
        {
            int a = DailySeedUtility.Mix(20261103, 42);
            int b = DailySeedUtility.Mix(20261103, 42);
            Assert.AreEqual(a, b);
            Assert.GreaterOrEqual(a, 0);
        }
    }
}
