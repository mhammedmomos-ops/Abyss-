using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS9NestPersistenceRegressionTests
    {
        [Test]
        public void NestDamagePersistsHealthAndDisablesTerritoryAtZero()
        {
            var go = new GameObject("Nest");
            try
            {
                var nest = go.AddComponent<MonsterNest>();
                Assert.IsTrue(nest.ApplyDamage(250, null));
                Assert.AreEqual(0, nest.CurrentHealth);
                Assert.IsTrue(nest.IsDestroyed);
                Assert.IsFalse(nest.IsActive);
                Assert.IsFalse(nest.Contains(Vector3.zero));
            }
            finally { Object.DestroyImmediate(go); }
        }

        [Test]
        public void NestRestoreClampsHealthAndRestoresAlarmCount()
        {
            var go = new GameObject("Nest");
            try
            {
                var nest = go.AddComponent<MonsterNest>();
                nest.Restore(new MonsterNestRecord { identity = nest.Identity, maxHealth = 300, currentHealth = 125, alarmCount = 4 });
                Assert.AreEqual(300, nest.MaximumHealth);
                Assert.AreEqual(125, nest.CurrentHealth);
                Assert.AreEqual(4, nest.AlarmCount);
                Assert.IsTrue(nest.IsActive);
            }
            finally { Object.DestroyImmediate(go); }
        }

        [Test]
        public void CampaignStateRejectsDuplicateNestIdentities()
        {
            var state = new CampaignState();
            state.monsterNests.Add(new MonsterNestRecord { identity = "nest_a" });
            state.monsterNests.Add(new MonsterNestRecord { identity = "nest_a" });
            Assert.IsFalse(state.IsValid(out string reason));
            StringAssert.Contains("unique", reason);
        }

        [Test]
        public void VersionOneSaveMigratesWithoutLosingCampaignProgress()
        {
            string folder = Path.Combine(Path.GetTempPath(), "GorgeHollow_VS9_Migration");
            if (Directory.Exists(folder)) Directory.Delete(folder, true);
            Directory.CreateDirectory(folder);
            try
            {
                File.WriteAllText(Path.Combine(folder, "campaign_save.json"),
                    "{\"saveVersion\":1,\"campaignId\":\"legacy_campaign\",\"chapter\":2,\"night\":7,\"animals\":[],\"appliedTransactionIds\":[],\"campaignFlags\":[],\"eventHistory\":[],\"towerStructures\":[]}");
                var service = new CampaignSaveService(folder);
                CampaignState loaded = service.Load(out string error);
                Assert.IsNotNull(loaded, error);
                Assert.AreEqual("legacy_campaign", loaded.campaignId);
                Assert.AreEqual(2, loaded.chapter);
                Assert.AreEqual(7, loaded.night);
                Assert.AreEqual(CampaignSaveService.CurrentSaveVersion, loaded.saveVersion);
                Assert.IsNotNull(loaded.monsterNests);
                Assert.AreEqual(0, loaded.monsterNests.Count);
            }
            finally { if (Directory.Exists(folder)) Directory.Delete(folder, true); }
        }
    }
}
