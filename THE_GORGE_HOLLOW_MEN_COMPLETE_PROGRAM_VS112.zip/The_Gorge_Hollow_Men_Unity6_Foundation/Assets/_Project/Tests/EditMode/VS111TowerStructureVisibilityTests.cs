using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS111TowerStructureVisibilityTests
    {
        [Test]
        public void PlayerAtTowerAOnlySeesTowerAStructures()
        {
            Assert.IsTrue(TowerStructureVisibilityRules.ShouldRenderTower("tower_a", "tower_a"));
            Assert.IsFalse(TowerStructureVisibilityRules.ShouldRenderTower("tower_b", "tower_a"));
        }

        [Test]
        public void PlayerAtTowerBOnlySeesTowerBStructures()
        {
            Assert.IsFalse(TowerStructureVisibilityRules.ShouldRenderTower("tower_a", "tower_b"));
            Assert.IsTrue(TowerStructureVisibilityRules.ShouldRenderTower("tower_b", "tower_b"));
        }

        [Test]
        public void PlayerOutsideBothTowersSeesNeitherTowerInDetail()
        {
            Assert.IsFalse(TowerStructureVisibilityRules.ShouldRenderTower("tower_a", null));
            Assert.IsFalse(TowerStructureVisibilityRules.ShouldRenderTower("tower_b", null));
            Assert.IsFalse(TowerStructureVisibilityRules.ShouldRenderTower("tower_a", string.Empty));
        }

        [Test]
        public void PlayerCanAccessOwnTowerAtPlatformCornersButNotOnceOnBridge()
        {
            UnityEngine.Vector2 halfExtents = new UnityEngine.Vector2(9f, 9f);
            Assert.AreEqual("tower_a", TowerLocalAccessTracker.ResolveLocalTowerIdInFootprints(
                new UnityEngine.Vector3(8.8f, 1f, 8.8f), new UnityEngine.Vector3(-37.2f, 1f, 8.8f),
                halfExtents, 0.5f, 12f));
            Assert.IsNull(TowerLocalAccessTracker.ResolveLocalTowerIdInFootprints(
                new UnityEngine.Vector3(9.1f, 1f, 0f), new UnityEngine.Vector3(-36.9f, 1f, 0f),
                halfExtents, 0.5f, 12f));
        }

        [Test]
        public void FootprintAccessRejectsPositionsOutsideVerticalTowerBounds()
        {
            Assert.IsNull(TowerLocalAccessTracker.ResolveLocalTowerIdInFootprints(
                new UnityEngine.Vector3(0f, 20f, 0f), new UnityEngine.Vector3(-46f, 20f, 0f),
                new UnityEngine.Vector2(9f, 9f), 0.5f, 12f));
        }

        [Test]
        public void UnknownTowerIdsFailClosed()
        {
            Assert.IsFalse(TowerStructureVisibilityRules.ShouldRenderTower("tower_c", "tower_c"));
            Assert.IsFalse(TowerStructureVisibilityRules.ShouldRenderTower("gorge", "tower_a"));
            Assert.IsFalse(TowerStructureVisibilityRules.ShouldRenderTower(null, "tower_a"));
        }

        [Test]
        public void LocalTowerComparisonIsExactAndCaseSensitive()
        {
            Assert.IsFalse(TowerStructureVisibilityRules.ShouldRenderTower("Tower_A", "tower_a"));
            Assert.IsFalse(TowerStructureVisibilityRules.ShouldRenderTower("tower_a", "TOWER_A"));
        }
    }
}
