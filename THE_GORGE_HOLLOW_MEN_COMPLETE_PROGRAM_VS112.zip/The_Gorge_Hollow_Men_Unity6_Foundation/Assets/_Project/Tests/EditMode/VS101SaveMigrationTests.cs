using System.IO;
using NUnit.Framework;
using UnityEngine;
namespace GorgeHollow.Tests
{
    public sealed class VS101SaveMigrationTests
    {
        [Test] public void VersionNineSaveMigratesToTenWithoutChangingDepotBalances()
        {
            string dir=Path.Combine(Application.temporaryCachePath,"vs101_migration_"+System.Guid.NewGuid().ToString("N")); Directory.CreateDirectory(dir);
            try { var old=CampaignStateFactory.CreateNew(); old.saveVersion=9; old.towerProductionJobs=null; TowerDepotRules.Find(old,"tower_a").scrap=17; File.WriteAllText(Path.Combine(dir,"campaign.json"),JsonUtility.ToJson(old)); var loaded=new CampaignSaveService(dir,"campaign.json").Load(out string error); Assert.IsNotNull(loaded,error); Assert.AreEqual(CampaignSaveService.CurrentSaveVersion,loaded.saveVersion); Assert.AreEqual(17,TowerDepotRules.Find(loaded,"tower_a").scrap); Assert.AreEqual(0,loaded.towerProductionJobs.Count); }
            finally { if(Directory.Exists(dir)) Directory.Delete(dir,true); }
        }
    }
}
