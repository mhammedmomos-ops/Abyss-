using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS97InterTowerSupplyTransferTests
    {
        private CampaignState CreateCampaign()
        {
            CampaignState c = CampaignStateFactory.CreateNew();
            c.towerDepots = TowerDepotRules.CreateStartingDepots();
            TowerDepotRules.Find(c, "tower_a").scrap = 40;
            TowerDepotRules.Find(c, "tower_a").timber = 25;
            return c;
        }
        private SupplyConvoyRecord Manifest() => new SupplyConvoyRecord
        {
            identity = "transfer_01", destinationTowerId = "tower_b", status = SupplyConvoyStatus.Travelling,
            worldPosition = Vector3.zero, currentHealth = 100, maximumHealth = 100, scrap = 12, timber = 8
        };

        [Test] public void DispatchDebitsSourceOnceAndPersistsCargo()
        {
            CampaignState c = CreateCampaign();
            Assert.IsTrue(InterTowerSupplyTransferRules.TryDispatch(c, "tower_a", Manifest(), 2, 5, true, out _));
            Assert.AreEqual(28, TowerDepotRules.Find(c, "tower_a").scrap);
            Assert.AreEqual(1, c.supplyConvoys.Count);
            Assert.IsTrue(c.supplyConvoys[0].isInterTowerTransfer);
            Assert.AreEqual(12, c.supplyConvoys[0].scrap);
        }
        [Test] public void DispatchRejectsUnverifiedRouteOrMissingStock()
        {
            CampaignState c = CreateCampaign();
            Assert.IsFalse(InterTowerSupplyTransferRules.TryDispatch(c, "tower_a", Manifest(), 2, 5, false, out _));
            SupplyConvoyRecord tooMuch = Manifest(); tooMuch.scrap = 1000;
            Assert.IsFalse(InterTowerSupplyTransferRules.TryDispatch(c, "tower_a", tooMuch, 2, 5, true, out _));
            Assert.AreEqual(40, TowerDepotRules.Find(c, "tower_a").scrap);
        }
        [Test] public void DispatchRejectsSameTowerAndDuplicateIdentity()
        {
            CampaignState c = CreateCampaign();
            SupplyConvoyRecord m = Manifest(); m.destinationTowerId = "tower_a";
            Assert.IsFalse(InterTowerSupplyTransferRules.TryDispatch(c, "tower_a", m, 2, 5, true, out _));
            Assert.IsTrue(InterTowerSupplyTransferRules.TryDispatch(c, "tower_a", Manifest(), 2, 5, true, out _));
            Assert.IsFalse(InterTowerSupplyTransferRules.TryDispatch(c, "tower_a", Manifest(), 2, 5, true, out _));
        }
        [Test] public void BridgeEntryRequiresLiveTraversableBridge()
        {
            CampaignState c = CreateCampaign();
            Assert.IsTrue(InterTowerSupplyTransferRules.TryDispatch(c, "tower_a", Manifest(), 2, 5, true, out _));
            Assert.IsFalse(InterTowerSupplyTransferRules.CanEnterBridge(c.supplyConvoys[0], null));
        }
        [Test] public void TransferRecordRejectsInvalidBridgeRange()
        {
            CampaignState c = CreateCampaign();
            Assert.IsFalse(InterTowerSupplyTransferRules.TryDispatch(c, "tower_a", Manifest(), 5, 2, true, out _));
        }
    }
}
