using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS34HoldConfirmTests
    {
        [Test]
        public void HoldProgressReachesOne()
        {
            float holdSeconds = 1.2f;
            float elapsed = 0f;
            elapsed += 1.2f;
            float fill = holdSeconds > 0f ? Mathf.Clamp01(elapsed / holdSeconds) : 1f;
            Assert.AreEqual(1f, fill, 0.001f);
        }

        [Test]
        public void SafeZoneFlagDefaultsFalse()
        {
            Assert.IsFalse(GorgeHollow.SafeZoneVolume.PlayerInSafeZone);
        }
    }
}
