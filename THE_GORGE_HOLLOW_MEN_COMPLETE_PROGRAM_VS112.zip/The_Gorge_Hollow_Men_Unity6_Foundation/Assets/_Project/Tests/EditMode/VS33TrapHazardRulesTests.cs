using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS33TrapHazardRulesTests
    {
        [Test]
        public void RearmDelayIsPositive()
        {
            float rearmSeconds = 4f;
            float rearmAt = 10f + Mathf.Max(0.1f, rearmSeconds);
            Assert.Greater(rearmAt, 10f);
        }

        [Test]
        public void PlaceDistanceForwardOffset()
        {
            Vector3 pos = Vector3.zero;
            Vector3 forward = Vector3.forward;
            float placeDistance = 2f;
            Vector3 placed = pos + forward * placeDistance;
            Assert.AreEqual(2f, placed.z, 0.001f);
        }
    }
}
