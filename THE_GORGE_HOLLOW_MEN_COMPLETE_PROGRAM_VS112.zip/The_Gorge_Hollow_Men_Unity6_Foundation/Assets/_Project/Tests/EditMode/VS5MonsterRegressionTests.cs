using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS5MonsterRegressionTests
    {
        [Test]
        public void GunfireLearningRequiresThreeAudibleObservations()
        {
            var memory = new MonsterLearningMemory();
            memory.RecordAudible(new MonsterStimulus(MonsterStimulusKind.Gunshot, Vector3.one, 20f, null));
            memory.RecordAudible(new MonsterStimulus(MonsterStimulusKind.Gunshot, Vector3.one, 20f, null));
            Assert.IsFalse(memory.IsCautiousAroundGunfire);
            memory.RecordAudible(new MonsterStimulus(MonsterStimulusKind.Gunshot, Vector3.one, 20f, null));
            Assert.IsTrue(memory.IsCautiousAroundGunfire);
        }

        [Test]
        public void SprintPatternRequiresRepeatedObservedEvidence()
        {
            var memory = new MonsterLearningMemory();
            memory.RecordVisibleSprint(Vector3.right);
            Assert.IsFalse(memory.RecognizesSprintPattern);
            memory.RecordVisibleSprint(Vector3.right * 2f);
            Assert.IsTrue(memory.RecognizesSprintPattern);
        }

        [Test]
        public void EvidenceIsBoundedAndStoresLastObservedLocation()
        {
            var memory = new MonsterLearningMemory();
            for (int i = 0; i < 20; i++)
                memory.RecordAudible(new MonsterStimulus(MonsterStimulusKind.SprintFootstep, new Vector3(i, 0f, 0f), 9f, null));
            Assert.AreEqual(8, memory.HeardSprintFootsteps);
            Assert.AreEqual(new Vector3(19f, 0f, 0f), memory.LastEvidencePosition);
        }

        [Test]
        public void ClearingMemoryRemovesLearnedEvidence()
        {
            var memory = new MonsterLearningMemory();
            memory.RecordAudible(new MonsterStimulus(MonsterStimulusKind.Gunshot, Vector3.one, 20f, null));
            memory.RecordVisibleSprint(Vector3.right);
            memory.Clear();
            Assert.AreEqual(0, memory.HeardGunshots);
            Assert.AreEqual(0, memory.SawPlayerSprint);
            Assert.IsFalse(memory.IsCautiousAroundGunfire);
        }

        [Test]
        public void ZeroLoudnessStimulusDoesNotBroadcast()
        {
            int received = 0;
            System.Action<MonsterStimulus> listener = _ => received++;
            MonsterStimulusBus.Emitted += listener;
            try
            {
                MonsterStimulusBus.Emit(MonsterStimulusKind.Gunshot, Vector3.zero, 0f, null);
                Assert.AreEqual(0, received);
                MonsterStimulusBus.Emit(MonsterStimulusKind.Gunshot, Vector3.zero, 1f, null);
                Assert.AreEqual(1, received);
            }
            finally { MonsterStimulusBus.Emitted -= listener; }
        }
    }
}
