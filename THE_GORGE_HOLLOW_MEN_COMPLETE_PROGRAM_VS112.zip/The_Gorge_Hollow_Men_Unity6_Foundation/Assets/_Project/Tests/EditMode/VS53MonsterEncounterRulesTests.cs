using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS53MonsterEncounterRulesTests
    {
        [Test]
        public void ValidEncounterBuildsRaidRequest()
        {
            bool valid = MonsterEncounterRules.TryCreateRequest(new Vector3(1f, 2f, 3f), 4, 2, 16f, 53053,
                out MonsterRaidRequest request, out string error);
            Assert.IsTrue(valid, error);
            Assert.NotNull(request);
            Assert.AreEqual(4, request.ThreatBudget);
            Assert.AreEqual(2, request.MaximumSpawnCount);
            Assert.AreEqual(53053, request.RandomSeed);
        }

        [TestCase(0)]
        [TestCase(-1)]
        public void NonPositiveThreatBudgetIsRejected(int budget)
        {
            Assert.IsFalse(MonsterEncounterRules.TryCreateRequest(Vector3.zero, budget, 1, 1f, 1,
                out MonsterRaidRequest request, out _));
            Assert.IsNull(request);
        }

        [TestCase(0)]
        [TestCase(-2)]
        public void NonPositiveSpawnCountIsRejected(int count)
        {
            Assert.IsFalse(MonsterEncounterRules.TryCreateRequest(Vector3.zero, 1, count, 1f, 1,
                out MonsterRaidRequest request, out _));
            Assert.IsNull(request);
        }

        [Test]
        public void NegativeMinimumDistanceIsRejected()
        {
            Assert.IsFalse(MonsterEncounterRules.TryCreateRequest(Vector3.zero, 1, 1, -0.1f, 1,
                out MonsterRaidRequest request, out _));
            Assert.IsNull(request);
        }

        [Test]
        public void NaNMinimumDistanceIsRejected()
        {
            Assert.IsFalse(MonsterEncounterRules.TryCreateRequest(Vector3.zero, 1, 1, float.NaN, 1,
                out MonsterRaidRequest request, out _));
            Assert.IsNull(request);
        }

        [Test]
        public void InfiniteTargetCoordinateIsRejected()
        {
            Assert.IsFalse(MonsterEncounterRules.TryCreateRequest(new Vector3(float.PositiveInfinity, 0f, 0f), 1, 1, 1f, 1,
                out MonsterRaidRequest request, out _));
            Assert.IsNull(request);
        }

        [Test]
        public void ConfiguredSeedIsDeterministicForEncounterIndex()
        {
            int first = MonsterEncounterRules.ResolveSeed(53053, 2);
            int second = MonsterEncounterRules.ResolveSeed(53053, 2);
            Assert.AreEqual(first, second);
            Assert.AreNotEqual(MonsterEncounterRules.ResolveSeed(53053, 1), first);
        }

        [Test]
        public void ZeroConfiguredSeedResolvesToNonZeroDeterministicSeed()
        {
            int first = MonsterEncounterRules.ResolveSeed(0, 0);
            int second = MonsterEncounterRules.ResolveSeed(0, 0);
            Assert.AreNotEqual(0, first);
            Assert.AreEqual(first, second);
        }


        [Test]
        public void GeneratedSpawnSockets_AreInsideEastTowerAndOutsideInitialSafetyRadius()
        {
            Assert.IsTrue(VerticalSliceLayout.IsValid(out string error), error);
            Assert.That(Vector3.Distance(VerticalSliceLayout.PlayerSpawn, VerticalSliceLayout.MonsterSpawnNorth), Is.GreaterThanOrEqualTo(16f));
            Assert.That(Vector3.Distance(VerticalSliceLayout.PlayerSpawn, VerticalSliceLayout.MonsterSpawnSouth), Is.GreaterThanOrEqualTo(16f));
        }

        [Test]
        public void EncounterTrigger_IsAtWestBridgeApproach()
        {
            Assert.That(VerticalSliceLayout.FirstEncounterTriggerPosition.x, Is.GreaterThan(VerticalSliceLayout.WestBridgeEnd.x));
            Assert.That(VerticalSliceLayout.FirstEncounterTriggerPosition.x, Is.LessThan(VerticalSliceLayout.EastBridgeEnd.x));
        }

        [Test]
        public void FiniteZeroDistanceIsValid()
        {
            Assert.IsTrue(MonsterEncounterRules.TryCreateRequest(Vector3.zero, 1, 1, 0f, 1,
                out MonsterRaidRequest request, out string error), error);
            Assert.NotNull(request);
            Assert.AreEqual(0f, request.MinimumPlayerDistance);
        }
    }
}
