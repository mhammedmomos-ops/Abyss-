using NUnit.Framework;
using UnityEngine;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS31AccessibilityScaleTests
    {
        [Test]
        public void LocFallsBackCleanly()
        {
            Assert.AreEqual("Hello", Loc.Get("ui.hello", "Hello"));
            Assert.AreEqual("ui.missing", Loc.Get("ui.missing"));
            Assert.AreEqual(string.Empty, Loc.Get(null));
        }

        [Test]
        public void TextScaleClamps()
        {
            float previous = AccessibilityTextScale.TextScale;
            AccessibilityTextScale.TextScale = 0.1f;
            Assert.GreaterOrEqual(AccessibilityTextScale.TextScale, 0.8f);
            AccessibilityTextScale.TextScale = 5f;
            Assert.LessOrEqual(AccessibilityTextScale.TextScale, 1.6f);
            AccessibilityTextScale.TextScale = previous;
        }
    }
}
