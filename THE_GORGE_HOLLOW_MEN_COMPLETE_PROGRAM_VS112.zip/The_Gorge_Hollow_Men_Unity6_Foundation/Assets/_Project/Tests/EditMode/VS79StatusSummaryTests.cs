using System.Collections.Generic;
using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS79StatusSummaryTests
    {
        [Test]
        public void TotalAbilityCountMatchesEveryUnlockableAbility()
        {
            var learned = new List<string>();
            AnimalExperienceRules.EvaluateNewUnlocks(int.MaxValue, learned);
            Assert.AreEqual(AnimalExperienceRules.TotalAbilityCount, learned.Count);
            Assert.AreEqual(AnimalExperienceRules.TotalAbilityCount,
                AnimalStatusSummaryRules.CountKnownAbilities(learned));
        }

        [Test]
        public void CountKnownAbilitiesHandlesNullEmptyAndUnknownIds()
        {
            Assert.AreEqual(0, AnimalStatusSummaryRules.CountKnownAbilities(null));
            Assert.AreEqual(0, AnimalStatusSummaryRules.CountKnownAbilities(new List<string>()));
            Assert.AreEqual(1, AnimalStatusSummaryRules.CountKnownAbilities(
                new List<string> { "keen_sense", "legacy_unknown_id" }));
        }

        [Test]
        public void TimedStatesOutrankPlainCommands()
        {
            Assert.AreEqual("CURLED", AnimalStatusSummaryRules.ActiveStateTag(AnimalCommand.Follow, true, true, true, true));
            Assert.AreEqual("RESONATING", AnimalStatusSummaryRules.ActiveStateTag(AnimalCommand.Stay, false, false, true, true));
            Assert.AreEqual("GUARDING", AnimalStatusSummaryRules.ActiveStateTag(AnimalCommand.Guard, false, false, false, true));
            Assert.AreEqual("GUARDING", AnimalStatusSummaryRules.ActiveStateTag(AnimalCommand.Guard, false, false, false, false));
            Assert.AreEqual("STALKING", AnimalStatusSummaryRules.ActiveStateTag(AnimalCommand.Stalk, false, true, false, false));
        }

        [Test]
        public void OrdinaryFollowingHasNoTag()
        {
            Assert.AreEqual(string.Empty, AnimalStatusSummaryRules.ActiveStateTag(AnimalCommand.Follow, false, false, false, false));
            Assert.AreEqual(string.Empty, AnimalStatusSummaryRules.ActiveStateTag(AnimalCommand.Return, false, false, false, false));
            Assert.AreEqual("STAYING", AnimalStatusSummaryRules.ActiveStateTag(AnimalCommand.Stay, false, false, false, false));
            Assert.AreEqual("FORAGING", AnimalStatusSummaryRules.ActiveStateTag(AnimalCommand.Forage, false, false, false, false));
        }

        [Test]
        public void StatusLineKeepsLegacyPrefixAndAppendsProgress()
        {
            string line = AnimalStatusSummaryRules.FormatStatusLine("Rex", AnimalSpecies.GermanShepherd,
                90, 70, 3, true, 0, 2, "GUARDING", 42, 4);
            StringAssert.StartsWith("Rex (GermanShepherd)  HP 90  HUNGER 70  FOOD 3", line);
            StringAssert.Contains("[GUARDING]", line);
            StringAssert.Contains("XP 42", line);
            StringAssert.Contains("ABILITIES 4/6", line);
            StringAssert.DoesNotContain("OUT OF COMMISSION", line);
            StringAssert.DoesNotContain("STARVATION", line);
        }

        [Test]
        public void StarvationAndOutOfCommissionAreReported()
        {
            string line = AnimalStatusSummaryRules.FormatStatusLine("Shell", AnimalSpecies.Pangolin,
                60, 0, 0, false, 1, 2, string.Empty, 0, 0);
            StringAssert.Contains("OUT OF COMMISSION", line);
            StringAssert.Contains("STARVATION 1/2 DAYS", line);
            StringAssert.DoesNotContain("[", line);
        }

        [Test]
        public void StatusLineClampsBadInputAndFallsBackToSpeciesName()
        {
            string line = AnimalStatusSummaryRules.FormatStatusLine("  ", AnimalSpecies.Falcon,
                10, 10, 0, true, 0, 2, null, -5, 99);
            StringAssert.StartsWith("Falcon (Falcon)", line);
            StringAssert.Contains("XP 0", line);
            StringAssert.Contains("ABILITIES 6/6", line);
        }
    }
}
