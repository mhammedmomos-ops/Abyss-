using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS99SupplyConvoyCommandTests
    {
        [TestCase(SupplyConvoyCommand.Advance)]
        [TestCase(SupplyConvoyCommand.Hold)]
        [TestCase(SupplyConvoyCommand.FocusFire)]
        public void AllDefinedCommandsAreValid(SupplyConvoyCommand command) =>
            Assert.IsTrue(SupplyConvoyCommandRules.IsValid(command));

        [Test]
        public void UnknownCommandFailsClosed()
        {
            Assert.IsFalse(SupplyConvoyCommandRules.IsValid((SupplyConvoyCommand)99));
            Assert.AreEqual(0f, SupplyConvoyCommandRules.MovementMultiplier((SupplyConvoyCommand)99));
        }

        [Test]
        public void HoldStopsCarrierButDoesNotRepresentDestruction() =>
            Assert.AreEqual(0f, SupplyConvoyCommandRules.MovementMultiplier(SupplyConvoyCommand.Hold));

        [Test]
        public void AdvanceIsFasterThanBaseMovement() =>
            Assert.Greater(SupplyConvoyCommandRules.MovementMultiplier(SupplyConvoyCommand.Advance), 1f);

        [Test]
        public void FocusFireTradesSpeedForEscortDamage()
        {
            Assert.Less(SupplyConvoyCommandRules.MovementMultiplier(SupplyConvoyCommand.FocusFire), 1f);
            Assert.Greater(SupplyConvoyCommandRules.EscortDamageMultiplier(SupplyConvoyCommand.FocusFire), 1f);
        }

        [Test]
        public void NormalOrdersDoNotBuffEscortDamage()
        {
            Assert.AreEqual(1f, SupplyConvoyCommandRules.EscortDamageMultiplier(SupplyConvoyCommand.Advance));
            Assert.AreEqual(1f, SupplyConvoyCommandRules.EscortDamageMultiplier(SupplyConvoyCommand.Hold));
        }

        [Test]
        public void EveryCommandHasPlayerFacingDescription()
        {
            Assert.IsNotEmpty(SupplyConvoyCommandRules.GetDescription(SupplyConvoyCommand.Advance));
            Assert.IsNotEmpty(SupplyConvoyCommandRules.GetDescription(SupplyConvoyCommand.Hold));
            Assert.IsNotEmpty(SupplyConvoyCommandRules.GetDescription(SupplyConvoyCommand.FocusFire));
        }
    }
}
