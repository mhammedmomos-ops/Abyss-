using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS15MobileReliabilityTests
    {
        [Test]
        public void LODMovesThroughTiersAsDistanceIncreases()
        {
            MonsterAILodTier tier = MonsterAILodPolicy.Evaluate(10f, MonsterAILodTier.Near, 28f, 58f, 92f, 7f);
            Assert.AreEqual(MonsterAILodTier.Near, tier);
            tier = MonsterAILodPolicy.Evaluate(45f, tier, 28f, 58f, 92f, 7f);
            Assert.AreEqual(MonsterAILodTier.Mid, tier);
            tier = MonsterAILodPolicy.Evaluate(80f, tier, 28f, 58f, 92f, 7f);
            Assert.AreEqual(MonsterAILodTier.Far, tier);
            tier = MonsterAILodPolicy.Evaluate(110f, tier, 28f, 58f, 92f, 7f);
            Assert.AreEqual(MonsterAILodTier.Suspended, tier);
        }

        [Test]
        public void LODHysteresisPreventsBoundaryChatter()
        {
            Assert.AreEqual(MonsterAILodTier.Near, MonsterAILodPolicy.Evaluate(34f, MonsterAILodTier.Near, 28f, 58f, 92f, 7f));
            Assert.AreEqual(MonsterAILodTier.Mid, MonsterAILodPolicy.Evaluate(22f, MonsterAILodTier.Mid, 28f, 58f, 92f, 7f));
        }

        [Test]
        public void InvalidDistancePreservesCurrentTier()
        {
            Assert.AreEqual(MonsterAILodTier.Far, MonsterAILodPolicy.Evaluate(float.NaN, MonsterAILodTier.Far, 28f, 58f, 92f, 7f));
            Assert.AreEqual(MonsterAILodTier.Mid, MonsterAILodPolicy.Evaluate(-1f, MonsterAILodTier.Mid, 28f, 58f, 92f, 7f));
        }

        [Test]
        public void SiegeExpectedDamageAccountsForStructureHealthCap()
        {
            Assert.AreEqual(2, MonsterSiegeEffectiveness.ExpectedDamage(20f, 0.5f, 2));
            Assert.AreEqual(10, MonsterSiegeEffectiveness.ExpectedDamage(20f, 0.5f, 10));
        }

        [Test]
        public void SiegeLearningUsesActualDamageNotAuthoredResistanceAlone()
        {
            int expected = MonsterSiegeEffectiveness.ExpectedDamage(20f, 0.0f, 100);
            Assert.AreEqual(1f, MonsterSiegeEffectiveness.CalculateEfficiency(20, expected), 0.001f);
            Assert.AreEqual(0.5f, MonsterSiegeEffectiveness.CalculateEfficiency(10, expected), 0.001f);
            Assert.AreEqual(0f, MonsterSiegeEffectiveness.CalculateEfficiency(0, expected), 0.001f);
        }

        [Test]
        public void SiegeEfficiencyRejectsDamageAboveExpected()
        {
            Assert.AreEqual(1f, MonsterSiegeEffectiveness.CalculateEfficiency(30, 20), 0.001f);
            Assert.AreEqual(0f, MonsterSiegeEffectiveness.CalculateEfficiency(5, 0), 0.001f);
        }
    }
}
