using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS28MobileQualityRulesTests
    {
        [TestCase(30, 30)]
        [TestCase(60, 60)]
        [TestCase(120, 120)]
        [TestCase(15, 30)]
        [TestCase(50, 60)]
        [TestCase(90, 120)]
        [TestCase(200, 120)]
        public void TargetFpsSnapsToMobileBuckets(int input, int expected)
            => Assert.AreEqual(expected, MobileQualityRules.ClampTargetFps(input));
    }
}
