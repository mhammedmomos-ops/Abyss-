using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS72CatStalkTests
    {
        [Test]
        public void OnlyLivingCatCanIssueStalk()
        {
            Assert.IsTrue(AnimalCatStalkRules.CanIssueStalk(AnimalSpecies.Cat, AnimalStatus.Alive, false));
            Assert.IsFalse(AnimalCatStalkRules.CanIssueStalk(AnimalSpecies.GermanShepherd, AnimalStatus.Alive, false));
            Assert.IsFalse(AnimalCatStalkRules.CanIssueStalk(AnimalSpecies.Cat, AnimalStatus.Dead, false));
            Assert.IsFalse(AnimalCatStalkRules.CanIssueStalk(AnimalSpecies.Cat, AnimalStatus.Alive, true));
        }

        [Test]
        public void StalkReducesMoveSpeedAndExpandsDetection()
        {
            float baseSpeed = 4.6f;
            float stalkSpeed = AnimalCatStalkRules.MoveSpeedWhileStalking(baseSpeed, true);
            Assert.AreEqual(baseSpeed * AnimalSpeciesTactics.CatStalkMoveSpeedMultiplier, stalkSpeed, 0.0001f);
            Assert.AreEqual(baseSpeed, AnimalCatStalkRules.MoveSpeedWhileStalking(baseSpeed, false), 0.0001f);

            float baseRadius = 16f;
            float stalkRadius = AnimalCatStalkRules.DetectionRadiusWhileStalking(baseRadius, true);
            Assert.AreEqual(baseRadius * AnimalSpeciesTactics.CatStalkDetectionRadiusMultiplier, stalkRadius, 0.0001f);
            Assert.AreEqual(baseRadius, AnimalCatStalkRules.DetectionRadiusWhileStalking(baseRadius, false), 0.0001f);
        }

        [Test]
        public void StalkSuppressesStimulusLoudness()
        {
            float loud = 25f;
            float quiet = AnimalCatStalkRules.StimulusLoudnessWhileStalking(loud, true);
            Assert.AreEqual(loud * AnimalSpeciesTactics.CatStalkStimulusLoudnessMultiplier, quiet, 0.0001f);
            Assert.AreEqual(loud, AnimalCatStalkRules.StimulusLoudnessWhileStalking(loud, false), 0.0001f);
            Assert.AreEqual(0f, AnimalCatStalkRules.StimulusLoudnessWhileStalking(0f, true), 0.0001f);
        }

        [Test]
        public void FirstAcquisitionBonusAppliesOnceAndClamps()
        {
            Assert.IsTrue(AnimalCatStalkRules.ShouldApplyFirstAcquisitionBonus(true, false));
            Assert.IsFalse(AnimalCatStalkRules.ShouldApplyFirstAcquisitionBonus(true, true));
            Assert.IsFalse(AnimalCatStalkRules.ShouldApplyFirstAcquisitionBonus(false, false));

            float boosted = AnimalCatStalkRules.ThreatConfidenceWithStalkBonus(0.8f, true, true);
            Assert.AreEqual(1f, boosted, 0.0001f); // 0.8 + 0.22 clamped
            float noBonus = AnimalCatStalkRules.ThreatConfidenceWithStalkBonus(0.8f, true, false);
            Assert.AreEqual(0.8f, noBonus, 0.0001f);
            float notStalking = AnimalCatStalkRules.ThreatConfidenceWithStalkBonus(0.5f, false, true);
            Assert.AreEqual(0.5f, notStalking, 0.0001f);
        }

        [Test]
        public void ConstantsAreReasonableForQuietHunter()
        {
            Assert.Less(AnimalSpeciesTactics.CatStalkMoveSpeedMultiplier, 1f);
            Assert.Greater(AnimalSpeciesTactics.CatStalkDetectionRadiusMultiplier, 1f);
            Assert.Greater(AnimalSpeciesTactics.CatStalkThreatConfidenceBonus, 0f);
            Assert.Less(AnimalSpeciesTactics.CatStalkStimulusLoudnessMultiplier, 0.5f);
        }
    }
}
