using System.Collections.Generic;
using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS63SpeciesTacticsTests
    {
        [TestCase(AnimalSpecies.GermanShepherd, CompanionThreatResponse.Engage)]
        [TestCase(AnimalSpecies.Falcon, CompanionThreatResponse.Observe)]
        [TestCase(AnimalSpecies.Pangolin, CompanionThreatResponse.HoldDefence)]
        [TestCase(AnimalSpecies.Cat, CompanionThreatResponse.Evade)]
        public void EveryApprovedSpeciesHasAnIndependentThreatResponse(AnimalSpecies species, CompanionThreatResponse expected)
        {
            Assert.AreEqual(expected, AnimalSpeciesTactics.ThreatResponse(species));
            Assert.AreEqual(expected == CompanionThreatResponse.Engage, AnimalSpeciesTactics.CanEngage(species));
        }

        [Test]
        public void OnlyGermanShepherdUsesDirectMeleeSupport()
        {
            Assert.IsTrue(AnimalSpeciesTactics.CanEngage(AnimalSpecies.GermanShepherd));
            Assert.IsFalse(AnimalSpeciesTactics.CanEngage(AnimalSpecies.Falcon));
            Assert.IsFalse(AnimalSpeciesTactics.CanEngage(AnimalSpecies.Pangolin));
            Assert.IsFalse(AnimalSpeciesTactics.CanEngage(AnimalSpecies.Cat));
        }

        [Test]
        public void ForageDurationsAreDistinctAndPositive()
        {
            var durations = new HashSet<float>
            {
                AnimalSpeciesTactics.ForageDurationSeconds(AnimalSpecies.GermanShepherd),
                AnimalSpeciesTactics.ForageDurationSeconds(AnimalSpecies.Falcon),
                AnimalSpeciesTactics.ForageDurationSeconds(AnimalSpecies.Pangolin),
                AnimalSpeciesTactics.ForageDurationSeconds(AnimalSpecies.Cat)
            };
            Assert.AreEqual(4, durations.Count);
            foreach (float duration in durations) Assert.Greater(duration, 0f);
        }

        [Test]
        public void FalconHasWidestForageSearchAndPangolinHasNarrowest()
        {
            Assert.Greater(AnimalSpeciesTactics.ForageSearchRadiusMultiplier(AnimalSpecies.Falcon),
                AnimalSpeciesTactics.ForageSearchRadiusMultiplier(AnimalSpecies.GermanShepherd));
            Assert.Less(AnimalSpeciesTactics.ForageSearchRadiusMultiplier(AnimalSpecies.Pangolin),
                AnimalSpeciesTactics.ForageSearchRadiusMultiplier(AnimalSpecies.Cat));
        }

        [Test]
        public void PangolinBraceHasBoundedPositiveCostAndDuration()
        {
            Assert.Greater(AnimalSpeciesTactics.PangolinBraceStaminaCost, 0);
            Assert.Greater(AnimalSpeciesTactics.PangolinBraceDurationSeconds, 0f);
            Assert.Greater(AnimalSpeciesTactics.PangolinBraceDamageMultiplier, 0f);
            Assert.Less(AnimalSpeciesTactics.PangolinBraceDamageMultiplier, 1f);
        }

        [Test]
        public void SpeciesObservationAndEvasionDistancesArePositive()
        {
            Assert.Greater(AnimalSpeciesTactics.FalconObservationDistance, 0f);
            Assert.Greater(AnimalSpeciesTactics.CatThreatAvoidanceDistance, 0f);
        }

        [Test]
        public void UnknownSpeciesFallsBackToNonAggressiveDefence()
        {
            Assert.AreEqual(CompanionThreatResponse.HoldDefence, AnimalSpeciesTactics.ThreatResponse((AnimalSpecies)999));
            Assert.IsFalse(AnimalSpeciesTactics.CanEngage((AnimalSpecies)999));
        }
    }
}
