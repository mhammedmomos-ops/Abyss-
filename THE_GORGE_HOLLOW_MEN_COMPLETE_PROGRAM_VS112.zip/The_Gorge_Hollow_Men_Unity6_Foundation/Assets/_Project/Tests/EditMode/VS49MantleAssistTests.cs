using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS49MantleAssistTests
    {
        [Test]
        public void LedgeHeightInRange()
        {
            float height = 0.8f;
            float min = 0.35f;
            float max = 1.1f;
            Assert.IsTrue(height >= min && height <= max);
        }

        [Test]
        public void ForwardIntentRequired()
        {
            float moveY = 0.5f;
            Assert.IsTrue(moveY >= 0.4f);
        }
    }
}
