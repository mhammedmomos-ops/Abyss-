using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public class VS87AdaptiveDistractionTests
    {
        [Test]
        public void FirstAndSecondDecoysRemainEffective()
        {
            Assert.AreEqual(AnimalDistractionRules.MonsterInvestigationSeconds,
                AnimalDistractionRules.InvestigationDurationFor(1));
            Assert.AreEqual(AnimalDistractionRules.MonsterInvestigationSeconds,
                AnimalDistractionRules.InvestigationDurationFor(2));
            Assert.IsFalse(AnimalDistractionRules.ShouldIgnoreRepeatedDecoy(2));
        }

        [Test]
        public void RepeatedDecoysBecomeShorterAndLessDistracting()
        {
            Assert.AreEqual(AnimalDistractionRules.SuspiciousInvestigationSeconds,
                AnimalDistractionRules.InvestigationDurationFor(3));
            Assert.AreEqual(1f, AnimalDistractionRules.InvestigationSpeedFor(3), 0.001f);
            Assert.IsFalse(AnimalDistractionRules.ShouldIgnoreRepeatedDecoy(4));
        }

        [Test]
        public void ExperiencedMonsterIgnoresFifthAcceptedDecoy()
        {
            Assert.IsTrue(AnimalDistractionRules.ShouldIgnoreRepeatedDecoy(5));
            Assert.IsTrue(AnimalDistractionRules.ShouldIgnoreRepeatedDecoy(6));
        }

        [Test]
        public void LearningCountsOnlySameSourceWithinSixtySeconds()
        {
            var memory = new MonsterLearningMemory();
            var first = new GameObject("falcon-decoy");
            var second = new GameObject("cat-decoy");
            try
            {
                Assert.AreEqual(1, memory.RecordAnimalDistraction(first, 1f));
                Assert.AreEqual(2, memory.RecordAnimalDistraction(first, 20f));
                Assert.AreEqual(1, memory.RecordAnimalDistraction(second, 21f));
                Assert.AreEqual(1, memory.RecordAnimalDistraction(first, 90f));
            }
            finally
            {
                Object.DestroyImmediate(first);
                Object.DestroyImmediate(second);
            }
        }

        [Test]
        public void InvalidSourceOrTimeDoesNotAdvanceLearning()
        {
            var memory = new MonsterLearningMemory();
            var source = new GameObject("valid-decoy");
            try
            {
                Assert.AreEqual(0, memory.RecordAnimalDistraction(null, 1f));
                Assert.AreEqual(0, memory.RecordAnimalDistraction(source, float.NaN));
                Assert.AreEqual(1, memory.RecordAnimalDistraction(source, 2f));
            }
            finally { Object.DestroyImmediate(source); }
        }

        [Test]
        public void ClearResetsDecoyLearning()
        {
            var memory = new MonsterLearningMemory();
            var source = new GameObject("decoy-reset");
            try
            {
                memory.RecordAnimalDistraction(source, 1f);
                memory.RecordAnimalDistraction(source, 2f);
                memory.Clear();
                Assert.AreEqual(0, memory.RepeatedAnimalDistractionCount);
                Assert.AreEqual(1, memory.RecordAnimalDistraction(source, 3f));
            }
            finally { Object.DestroyImmediate(source); }
        }
    }
}
