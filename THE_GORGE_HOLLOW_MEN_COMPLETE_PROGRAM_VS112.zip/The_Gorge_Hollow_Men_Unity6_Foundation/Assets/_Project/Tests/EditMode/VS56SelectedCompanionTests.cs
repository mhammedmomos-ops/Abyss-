using System.Collections.Generic;
using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS56SelectedCompanionTests
    {
        [TestCase(AnimalSpecies.GermanShepherd)]
        [TestCase(AnimalSpecies.Falcon)]
        [TestCase(AnimalSpecies.Pangolin)]
        [TestCase(AnimalSpecies.Cat)]
        public void EveryApprovedSpeciesHasAFactoryAndDistinctProfile(AnimalSpecies species)
        {
            Assert.IsNotNull(AnimalBehaviourFactory.Create(species));
            AnimalCompanionProfile profile = AnimalCompanionProfile.For(species);
            Assert.Greater(profile.moveSpeed, 0f);
            Assert.Greater(profile.detectionRadius, 0f);
            Assert.Greater(profile.attackDamage, 0f);
        }

        [Test]
        public void SpeciesProfilesHaveDistinctTacticalTuning()
        {
            var speeds = new System.Collections.Generic.HashSet<float>();
            speeds.Add(AnimalCompanionProfile.For(AnimalSpecies.GermanShepherd).moveSpeed);
            speeds.Add(AnimalCompanionProfile.For(AnimalSpecies.Falcon).moveSpeed);
            speeds.Add(AnimalCompanionProfile.For(AnimalSpecies.Pangolin).moveSpeed);
            speeds.Add(AnimalCompanionProfile.For(AnimalSpecies.Cat).moveSpeed);
            Assert.AreEqual(4, speeds.Count);
        }

        [Test]
        public void SelectionPreservesCustomNameAndReusesExistingSpeciesRecord()
        {
            var roster = new List<AnimalRecord>();
            Assert.IsTrue(AnimalSelectionRules.TrySelectOrCreate(roster, "  Shadow  ", AnimalSpecies.Cat, out AnimalRecord first, out string error), error);
            first.experience = 19;
            string identity = first.identity;
            Assert.IsTrue(AnimalSelectionRules.TrySelectOrCreate(roster, "Miso", AnimalSpecies.Cat, out AnimalRecord second, out error), error);
            Assert.AreEqual(1, roster.Count);
            Assert.AreSame(first, second);
            Assert.AreEqual(identity, second.identity);
            Assert.AreEqual("Miso", second.displayName);
            Assert.AreEqual(19, second.experience);
        }

        [Test]
        public void PermanentDeathPreventsReselectingSameSpeciesInCampaign()
        {
            var roster = new List<AnimalRecord>();
            Assert.IsTrue(AnimalSelectionRules.TrySelectOrCreate(roster, "Rook", AnimalSpecies.Falcon, out AnimalRecord bird, out string error), error);
            Assert.IsTrue(bird.MarkDead("death-001"));
            Assert.IsFalse(AnimalSelectionRules.TrySelectOrCreate(roster, "New Bird", AnimalSpecies.Falcon, out _, out error));
            StringAssert.Contains("permanently died", error);
        }

        [TestCase("")]
        [TestCase("   ")]
        [TestCase("This name is much too long for the companion")]
        public void InvalidPetNamesAreRejected(string name)
        {
            Assert.IsFalse(AnimalSelectionRules.TryCreate("stable-id", name, AnimalSpecies.Pangolin, out _, out _));
        }

        [Test]
        public void UnsupportedSpeciesCannotEnterApprovedRoster()
        {
            Assert.IsFalse(AnimalSelectionRules.TryCreate("bad-species", "Unknown", (AnimalSpecies)99, out _, out string error));
            StringAssert.Contains("approved roster", error);
        }

        [Test]
        public void DisplayNameComesFromSavedRecordNotSpeciesLabel()
        {
            var record = new AnimalRecord { displayName = "Copper", species = AnimalSpecies.Pangolin };
            Assert.AreEqual("Copper", AnimalSelectionRules.GetDisplayName(record));
            record.displayName = " ";
            Assert.AreEqual("Pangolin", AnimalSelectionRules.GetDisplayName(record));
        }
    }
}
