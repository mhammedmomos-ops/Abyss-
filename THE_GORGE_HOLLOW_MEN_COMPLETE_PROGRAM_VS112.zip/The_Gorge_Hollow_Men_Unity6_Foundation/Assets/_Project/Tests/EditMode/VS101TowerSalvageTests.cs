using NUnit.Framework;
namespace GorgeHollow.Tests
{
    public sealed class VS101TowerSalvageTests
    {
        [Test] public void SalvageCreditsOnlyAssignedTower() { var c=CampaignStateFactory.CreateNew(); Assert.IsTrue(TowerSalvageRules.TryRecover(c,"tower_b","cache_01",7,2,out _)); Assert.AreEqual(7,TowerDepotRules.Find(c,"tower_b").scrap); Assert.AreEqual(0,TowerDepotRules.Find(c,"tower_a").scrap); }
        [Test] public void SalvageNodeCannotBeCollectedTwice() { var c=CampaignStateFactory.CreateNew(); Assert.IsTrue(TowerSalvageRules.TryRecover(c,"tower_a","cache_02",4,0,out _)); Assert.IsFalse(TowerSalvageRules.TryRecover(c,"tower_a","cache_02",4,0,out _)); Assert.AreEqual(4,TowerDepotRules.Find(c,"tower_a").scrap); }
        [Test] public void OverflowRejectsSalvageWithoutPartialCredit() { var c=CampaignStateFactory.CreateNew(); var d=TowerDepotRules.Find(c,"tower_a"); d.scrap=int.MaxValue; Assert.IsFalse(TowerSalvageRules.TryRecover(c,"tower_a","cache_03",1,1,out _)); Assert.AreEqual(0,d.timber); }
        [Test] public void UnknownTowerCannotReceiveSalvage() { var c=CampaignStateFactory.CreateNew(); Assert.IsFalse(TowerSalvageRules.TryRecover(c,"tower_c","cache_04",1,0,out _)); }
        [Test] public void InvalidRewardIsRejected() { var c=CampaignStateFactory.CreateNew(); Assert.IsFalse(TowerSalvageRules.TryRecover(c,"tower_a","cache_05",0,0,out _)); Assert.IsFalse(TowerSalvageRules.TryRecover(c,"tower_a","cache_06",-1,2,out _)); }
    }
}
