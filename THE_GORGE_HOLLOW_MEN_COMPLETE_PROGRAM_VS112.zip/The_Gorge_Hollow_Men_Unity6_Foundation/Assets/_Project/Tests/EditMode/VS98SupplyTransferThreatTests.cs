using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS98SupplyTransferThreatTests
    {
        [Test] public void EmptyRouteIsClear() => Assert.AreEqual(SupplyRouteThreatLevel.Clear, SupplyTransferThreatRules.Evaluate(0, 0, 10f, 10f, 1f));
        [Test] public void SmallNearbyGroupRaisesWatch() => Assert.AreEqual(SupplyRouteThreatLevel.Watch, SupplyTransferThreatRules.Evaluate(1, 0, 8f, 10f, 1f));
        [Test] public void ActiveAttackerRaisesDanger() => Assert.AreEqual(SupplyRouteThreatLevel.Dangerous, SupplyTransferThreatRules.Evaluate(1, 1, 8f, 10f, 1f));
        [Test] public void MultipleAttackersRaiseCritical() => Assert.AreEqual(SupplyRouteThreatLevel.Critical, SupplyTransferThreatRules.Evaluate(2, 2, 8f, 10f, 1f));
        [Test] public void LargeGroupRaisesCritical() => Assert.AreEqual(SupplyRouteThreatLevel.Critical, SupplyTransferThreatRules.Evaluate(5, 0, 9f, 10f, 1f));
        [Test] public void InvalidObservationFailsClosed() => Assert.AreEqual(SupplyRouteThreatLevel.Critical, SupplyTransferThreatRules.Evaluate(-1, 0, 1f, 10f, 1f));
        [Test] public void EscortMitigationIsBoundedAndNeverImmune()
        {
            Assert.AreEqual(1f, SupplyTransferThreatRules.EscortDamageMultiplier(0, 4), 0.0001f);
            Assert.AreEqual(0.52f, SupplyTransferThreatRules.EscortDamageMultiplier(8, 4), 0.0001f);
            Assert.Greater(SupplyTransferThreatRules.ApplyEscortMitigation(10f, 4, 4), 0f);
        }
        [Test] public void InvalidDamageIsIgnored() => Assert.AreEqual(0f, SupplyTransferThreatRules.ApplyEscortMitigation(float.NaN, 2, 4));
    }
}
