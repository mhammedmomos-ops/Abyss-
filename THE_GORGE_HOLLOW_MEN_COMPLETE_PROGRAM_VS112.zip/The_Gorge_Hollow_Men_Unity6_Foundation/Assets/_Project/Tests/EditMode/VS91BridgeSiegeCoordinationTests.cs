using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS91BridgeSiegeCoordinationTests
    {
        [Test]
        public void BrutePrefersBridgeSupportTargets()
        {
            float brute = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Brute, 0, 1f);
            float stalker = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Stalker, 0, 1f);
            Assert.Less(brute, stalker);
        }

        [Test]
        public void BruteFocusesWeakenedSupportsMoreStrongly()
        {
            float healthy = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Brute, 0, 1f);
            float weakened = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Brute, 0, 0.2f);
            Assert.Less(weakened, healthy);
        }

        [Test]
        public void SkirmishersSpreadOutWhenAnotherAttackerHasCommitted()
        {
            float unclaimed = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Skirmisher, 0, 0.5f);
            float pressured = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Skirmisher, 2, 0.5f);
            Assert.Greater(pressured, unclaimed);
        }

        [Test]
        public void BrutesCanConcentrateOnSameWeakSupportDespitePressure()
        {
            float noPressure = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Brute, 0, 0.2f);
            float pressure = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Brute, 2, 0.2f);
            Assert.Greater(pressure, noPressure);
            Assert.Less(pressure, 40f);
        }

        [Test]
        public void LurkerHasAnchorFocusedBridgePriority()
        {
            float lurker = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Lurker, 0, 1f);
            float stalker = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Stalker, 0, 1f);
            Assert.Less(lurker, stalker);
        }

        [Test]
        public void InvalidBaseScoreIsRejected()
        {
            Assert.IsTrue(float.IsPositiveInfinity(MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(
                float.NaN, MonsterArchetypeRole.Brute, 0, 1f)));
        }

        [Test]
        public void NegativePressureCannotImproveTargetScore()
        {
            float normal = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Stalker, 0, 1f);
            float negative = MonsterBridgeSiegeRules.CalculateCoordinatedTargetScore(10f,
                MonsterArchetypeRole.Stalker, -5, 1f);
            Assert.AreEqual(normal, negative);
        }

        [Test]
        public void NonTraversableBridgeSupportRemainsInvalid()
        {
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, false, true, true, true, true, true));
        }

        [Test]
        public void MissingOrDestroyedSupportRemainsInvalid()
        {
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, true, true, false, true, true, true));
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, true, true, true, false, true, true));
        }

        [Test]
        public void BridgeSupportRequiresRangeAndLineOfSight()
        {
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, true, true, true, true, false, true));
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, true, true, true, true, true, false));
        }
    }
}
