using NUnit.Framework;
using System.IO;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS61CompanionFeedingTests
    {
        private static AnimalRecord Pet(AnimalStatus status = AnimalStatus.Alive)
        {
            return new AnimalRecord { identity = "pet-food-test", displayName = "Miso", species = AnimalSpecies.Cat,
                status = status, health = status == AnimalStatus.Dead ? 0 : 100, stamina = 70, hunger = 30, bond = 4 };
        }

        [Test]
        public void NewCampaignStartsWithTwoPetFoodUnits()
        {
            CampaignState state = CampaignStateFactory.CreateNew();
            Assert.AreEqual(2, state.petFood);
        }

        [Test]
        public void FeedingConsumesOneFoodRestoresHungerAndBond()
        {
            AnimalRecord pet = Pet(); int food = 2;
            Assert.IsTrue(AnimalCareRules.TryFeed(pet, ref food));
            Assert.AreEqual(1, food); Assert.AreEqual(90, pet.hunger); Assert.AreEqual(5, pet.bond);
        }

        [Test]
        public void FeedingClampsHungerAndCannotWasteFoodAtFullHunger()
        {
            AnimalRecord pet = Pet(); pet.hunger = 90; int food = 1;
            Assert.IsTrue(AnimalCareRules.TryFeed(pet, ref food));
            Assert.AreEqual(100, pet.hunger); Assert.AreEqual(0, food);
            Assert.IsFalse(AnimalCareRules.TryFeed(pet, ref food));
        }

        [TestCase(AnimalStatus.Dead)]
        [TestCase(AnimalStatus.Missing)]
        public void DeadOrMissingCompanionCannotBeFed(AnimalStatus status)
        {
            AnimalRecord pet = Pet(status); int food = 2;
            Assert.IsFalse(AnimalCareRules.TryFeed(pet, ref food)); Assert.AreEqual(2, food);
        }

        [Test]
        public void HungerFallsByFictionalDaysButNeverBelowZero()
        {
            AnimalRecord pet = Pet();
            AnimalCareRules.AdvanceHunger(pet, 1); Assert.AreEqual(12, pet.hunger);
            AnimalCareRules.AdvanceHunger(pet, 4); Assert.AreEqual(0, pet.hunger);
        }

        [Test]
        public void DeadCompanionDoesNotBecomeHungryFurther()
        {
            AnimalRecord pet = Pet(AnimalStatus.Dead); pet.hunger = 40;
            AnimalCareRules.AdvanceHunger(pet, 2); Assert.AreEqual(40, pet.hunger);
        }

        [Test]
        public void ResourceTransactionsApplyAndRejectNegativePetFoodBalances()
        {
            CampaignState state = CampaignStateFactory.CreateNew();
            var service = new ResourceTransactionService();
            Assert.IsTrue(service.TryApply(state, "food-add", new ResourceDelta { petFood = 3 }, out _));
            Assert.AreEqual(3, state.petFood);
            Assert.IsFalse(service.TryApply(state, "food-spend-too-much", new ResourceDelta { petFood = -4 }, out _));
            Assert.AreEqual(3, state.petFood);
        }

        [Test]
        public void VersionFourSaveMigratesCompanionsAsFedAndAddsEmptyFoodInventory()
        {
            string directory = Path.Combine(Path.GetTempPath(), "gorge-vs61-migration-" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            try
            {
                CampaignState legacy = CampaignStateFactory.CreateNew(); legacy.saveVersion = 4;
                AnimalRecord pet = Pet(); pet.hunger = 0; legacy.animals.Add(pet);
                File.WriteAllText(Path.Combine(directory, "campaign_save.json"), JsonUtility.ToJson(legacy, true));
                CampaignState loaded = new CampaignSaveService(directory).Load(out string error);
                Assert.IsNotNull(loaded, error); Assert.AreEqual(6, loaded.saveVersion);
                Assert.AreEqual(0, loaded.petFood); Assert.AreEqual(100, loaded.animals[0].hunger);
            }
            finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        }

        [Test]
        public void CampaignClockAdvancesPetHungerAlongsideAge()
        {
            CampaignState state = CampaignStateFactory.CreateNew();
            AnimalRecord pet = Pet(); pet.fictionalAgeDays = 400; pet.hunger = 100; state.animals.Add(pet);
            new CampaignClock(state).AdvanceFictionalMinutes(24 * 60);
            Assert.AreEqual(82, pet.hunger); Assert.AreEqual(401, pet.fictionalAgeDays);
        }
    }
}
