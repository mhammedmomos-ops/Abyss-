using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS48FogDensityTests
    {
        [Test]
        public void RaidDensityHigherThanCalm()
        {
            float calm = 0.008f;
            float raid = 0.035f;
            Assert.Greater(raid, calm);
        }

        [Test]
        public void LerpAtMidpoint()
        {
            float v = Mathf.Lerp(0.008f, 0.035f, 0.5f);
            Assert.AreEqual(0.0215f, v, 0.0001f);
        }
    }
}
