using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS39OneWayBarrierTests
    {
        [Test]
        public void DotThresholdAllowsAlignedApproach()
        {
            Vector3 allowed = Vector3.forward;
            Vector3 toPlayer = Vector3.forward;
            float dot = Vector3.Dot(allowed, toPlayer);
            Assert.GreaterOrEqual(dot, 0.25f);
        }

        [Test]
        public void DotThresholdBlocksOppositeApproach()
        {
            Vector3 allowed = Vector3.forward;
            Vector3 toPlayer = Vector3.back;
            float dot = Vector3.Dot(allowed, toPlayer);
            Assert.Less(dot, 0.25f);
        }
    }
}
