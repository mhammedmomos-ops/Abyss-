using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS112LocalMonsterAwarenessTests
    {
        [Test]
        public void HostileIsVisibleOnlyWhenWithinRangeInViewAndUnoccluded()
        {
            Assert.IsTrue(MonsterLocalAwarenessRules.CanSeeHostile(10f, 20f, true, true));
            Assert.IsFalse(MonsterLocalAwarenessRules.CanSeeHostile(10f, 20f, false, true));
            Assert.IsFalse(MonsterLocalAwarenessRules.CanSeeHostile(10f, 20f, true, false));
            Assert.IsFalse(MonsterLocalAwarenessRules.CanSeeHostile(21f, 20f, true, true));
        }

        [Test]
        public void HearingDoesNotRevealIdentityOrCountAndOnlyAppliesWhenNotVisible()
        {
            Assert.IsTrue(MonsterLocalAwarenessRules.CanHearHostile(8f, 11f, false));
            Assert.IsFalse(MonsterLocalAwarenessRules.CanHearHostile(8f, 11f, true));
            Assert.IsFalse(MonsterLocalAwarenessRules.CanHearHostile(12f, 11f, false));
        }

        [Test]
        public void PlayerInsideOneTowerCannotPerceiveHostilesInsideTheOtherTower()
        {
            Assert.IsTrue(MonsterLocalAwarenessRules.ShouldSuppressRemoteTowerObject(true, true));
            Assert.IsFalse(MonsterLocalAwarenessRules.ShouldSuppressRemoteTowerObject(true, false));
            Assert.IsFalse(MonsterLocalAwarenessRules.ShouldSuppressRemoteTowerObject(false, true));
        }

        [Test]
        public void LocalThreatIsZeroWhenNoHostileCanBePerceived()
        {
            Assert.AreEqual(0f, MonsterLocalAwarenessRules.CalculateLocalThreat(0, false));
        }

        [Test]
        public void NearbyUnseenMovementProducesOnlyLowLocalThreat()
        {
            Assert.AreEqual(0.18f, MonsterLocalAwarenessRules.CalculateLocalThreat(0, true), 0.0001f);
        }

        [Test]
        public void VisibleHostilesIncreaseThreatButNeverAboveOne()
        {
            Assert.AreEqual(0.28f, MonsterLocalAwarenessRules.CalculateLocalThreat(1, false), 0.0001f);
            Assert.AreEqual(1f, MonsterLocalAwarenessRules.CalculateLocalThreat(20, false), 0.0001f);
        }

        [Test]
        public void InvalidDistancesFailClosed()
        {
            Assert.IsFalse(MonsterLocalAwarenessRules.CanSeeHostile(float.NaN, 20f, true, true));
            Assert.IsFalse(MonsterLocalAwarenessRules.CanHearHostile(float.PositiveInfinity, 20f, false));
            Assert.IsFalse(MonsterLocalAwarenessRules.CanSeeHostile(-1f, 20f, true, true));
        }

        [Test]
        public void HearingAndSightRadiiCannotBecomeNegativeDetectionRanges()
        {
            Assert.IsFalse(MonsterLocalAwarenessRules.CanSeeHostile(0.1f, -1f, true, true));
            Assert.IsFalse(MonsterLocalAwarenessRules.CanHearHostile(0.1f, -1f, false));
        }
    }
}
