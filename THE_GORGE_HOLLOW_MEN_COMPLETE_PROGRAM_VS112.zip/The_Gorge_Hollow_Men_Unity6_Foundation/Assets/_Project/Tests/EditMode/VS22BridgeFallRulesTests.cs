using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS22BridgeFallRulesTests
    {
        [TestCase(0f, 3.5f, 12f, 100f, 0f)]
        [TestCase(3.5f, 3.5f, 12f, 100f, 0f)]
        [TestCase(4.5f, 3.5f, 12f, 100f, 12f)]
        [TestCase(20f, 3.5f, 12f, 100f, 100f)]
        [TestCase(-5f, 3.5f, 12f, 100f, 0f)]
        public void DamageUsesSafeDistanceAndCap(float distance, float safe, float rate, float cap, float expected)
            => Assert.AreEqual(expected, BridgeFallRules.CalculateDamage(distance, safe, rate, cap), 0.001f);

        [Test]
        public void InjuryIsBounded()
            => Assert.AreEqual(20f, BridgeFallRules.CalculateInjury(6f, 3.5f, 8f, 20f), 0.001f);

        [Test]
        public void NegativeTuningValuesCannotCreateNegativeImpact()
            => Assert.AreEqual(0f, BridgeFallRules.CalculateDamage(10f, -2f, -5f, -1f), 0.001f);

        [Test]
        public void NonFiniteInputFailsSafely()
            => Assert.AreEqual(0f, BridgeFallRules.CalculateDamage(float.NaN, 2f, 10f, 100f), 0.001f);

        [Test]
        public void ZeroMaximumDamageProducesNoDamage()
            => Assert.AreEqual(0f, BridgeFallRules.CalculateDamage(50f, 1f, 10f, 0f), 0.001f);
    }
}
