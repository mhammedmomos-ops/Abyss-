using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS30CameraShakeTraumaTests
    {
        [Test]
        public void TraumaClampsToUnitRange()
        {
            // Pure behavioural expectation documented for CameraShake.AddTrauma
            float trauma = 0f;
            trauma = Mathf.Clamp01(trauma + 0.4f);
            trauma = Mathf.Clamp01(trauma + 0.9f);
            Assert.AreEqual(1f, trauma, 0.001f);
            trauma = Mathf.Max(0f, trauma - 1.4f * 0.5f);
            Assert.AreEqual(0.3f, trauma, 0.001f);
        }
    }
}
