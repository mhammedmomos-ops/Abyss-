using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS10BehaviourTreeIntegrationTests
    {
        [Test]
        public void TacticalStatesRemainDistinctForExistingSystems()
        {
            Assert.AreNotEqual(MonsterTacticalState.HuntVisiblePlayer, MonsterTacticalState.HuntLastKnownContact);
            Assert.AreNotEqual(MonsterTacticalState.GuardNest, MonsterTacticalState.SiegeStructure);
            Assert.AreNotEqual(MonsterTacticalState.Retreat, MonsterTacticalState.Idle);
        }

        [Test]
        public void BehaviourTreeAdapterIsASeparateIntegrationLayer()
        {
            // The controller remains the owner of game rules; the adapter is a separate scheduler/decision layer.
            Assert.IsNotNull(typeof(MonsterAIController));
            Assert.IsNotNull(typeof(MonsterBehaviourTreeRunner));
        }
    }
}
