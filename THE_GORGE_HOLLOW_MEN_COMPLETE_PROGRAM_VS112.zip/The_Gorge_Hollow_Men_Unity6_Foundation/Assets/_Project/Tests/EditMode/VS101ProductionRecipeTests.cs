using NUnit.Framework;
namespace GorgeHollow.Tests
{
    public sealed class VS101ProductionRecipeTests
    {
        [Test] public void EveryRecipeConsumesInputsAndHasPositiveDuration() { var recipes=new[]{TowerProductionRecipeCatalog.ReclaimedMechanicalParts("r1"),TowerProductionRecipeCatalog.AmmunitionReload("r2"),TowerProductionRecipeCatalog.MedicalKitAssembly("r3")}; foreach(var r in recipes) { Assert.Greater(r.durationMinutes,0); Assert.Greater(r.costScrap+r.costTimber+r.costMechanicalParts+r.costElectricalComponents+r.costAmmunition+r.costMedicalSupplies+r.costPetFood+r.costReagent,0); } }
        [Test] public void RecipeCatalogueDoesNotMintAmmunitionWithoutInputs() { var c=CampaignStateFactory.CreateNew(); var d=TowerDepotRules.Find(c,"tower_a"); Assert.IsFalse(TowerProductionRules.TryEnqueue(c,"tower_a",TowerProductionRecipeCatalog.AmmunitionReload("ammo1"),out _)); Assert.AreEqual(0,d.ammunition); }
        [Test] public void ReclaimedPartsRecipeRequiresScrapAndProducesOnlyAfterWorkAndCollection() { var c=CampaignStateFactory.CreateNew(); var d=TowerDepotRules.Find(c,"tower_a"); d.scrap=6; Assert.IsTrue(TowerProductionRules.TryEnqueue(c,"tower_a",TowerProductionRecipeCatalog.ReclaimedMechanicalParts("parts1"),out _)); Assert.AreEqual(0,d.mechanicalParts); TowerProductionRules.Advance(c,"tower_a",20); Assert.AreEqual(0,d.mechanicalParts); Assert.IsTrue(TowerProductionRules.TryCollect(c,"parts1",out _)); Assert.AreEqual(2,d.mechanicalParts); }
    }
}
