using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS90MonsterBridgeFallRulesTests
    {
        [Test]
        public void EnemyOnBridgeWhenSpanCollapsesMustFallAndDie()
            => Assert.IsTrue(MonsterBridgeFallRules.MustFallAndDie(true, true));

        [Test]
        public void EnemyNotOnBridgeIsNotKilledByBridgeCollapse()
            => Assert.IsFalse(MonsterBridgeFallRules.MustFallAndDie(false, true));

        [Test]
        public void EnemyOnBridgeBeforeCollapseIsNotKilledWhileBridgeRemainsTraversable()
            => Assert.IsFalse(MonsterBridgeFallRules.MustFallAndDie(true, false));

        [Test]
        public void CollapseMustNeverReturnAnOccupantToEitherTower()
            => Assert.IsFalse(MonsterBridgeFallRules.MayReturnToTowerAfterCollapse(true, true));

        [Test]
        public void OrdinaryUnauthorizedEntryStillUsesAccessRejectionRatherThanFatalFall()
            => Assert.IsTrue(MonsterBridgeFallRules.MayReturnToTowerAfterCollapse(false, true));

        [Test]
        public void EmptyOrUnoccupiedBridgeCollapseDoesNotCreateADeath()
            => Assert.IsFalse(MonsterBridgeFallRules.MustFallAndDie(false, true));
    }
}
