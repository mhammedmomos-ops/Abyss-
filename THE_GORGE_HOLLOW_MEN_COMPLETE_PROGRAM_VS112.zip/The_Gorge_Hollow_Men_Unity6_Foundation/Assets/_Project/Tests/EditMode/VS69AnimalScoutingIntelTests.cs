using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS69AnimalScoutingIntelTests
    {
        [Test]
        public void ReportUsesObserverRelativeEightPointBearing()
        {
            GameObject observer = new GameObject("observer");
            GameObject threat = new GameObject("threat");
            try
            {
                observer.transform.position = Vector3.zero;
                observer.transform.rotation = Quaternion.identity;
                threat.transform.position = new Vector3(10f, 0f, 0f);
                AnimalScoutingReport report = AnimalScoutingIntelRules.Create(
                    observer.transform, threat.transform, MonsterArchetypeRole.Stalker, 12f);
                Assert.AreEqual("E", report.Bearing);
                Assert.AreEqual(10f, report.DistanceMetres, 0.01f);
                Assert.AreEqual(12f, report.ObservedAt);
            }
            finally
            {
                Object.DestroyImmediate(observer);
                Object.DestroyImmediate(threat);
            }
        }

        [Test]
        public void ReportFormattingContainsObservedRoleDistanceAndBearing()
        {
            AnimalScoutingReport report = new AnimalScoutingReport(
                Vector3.zero, 14.6f, MonsterArchetypeRole.Brute, 3f, "NW");
            string formatted = AnimalScoutingIntelRules.Format(report);
            StringAssert.Contains("Brute", formatted);
            StringAssert.Contains("15m", formatted);
            StringAssert.Contains("NW", formatted);
        }

        [Test]
        public void MissingTransformsProduceSafeUnknownReport()
        {
            AnimalScoutingReport report = AnimalScoutingIntelRules.Create(
                null, null, MonsterArchetypeRole.Stalker, 0f);
            Assert.AreEqual("unknown direction", report.Bearing);
            Assert.AreEqual(0f, report.DistanceMetres);
        }
    }
}
