using NUnit.Framework;
using GorgeHollow;
using System.Collections.Generic;

namespace GorgeHollow.Tests
{
    public sealed class VS25ObjectiveRulesTests
    {
        [Test]
        public void CompletionFlagIsPrefixedAndLowered()
            => Assert.AreEqual("objective_complete:repair_bridge_north",
                ObjectiveRules.CompletionFlag("Repair_Bridge_North"));

        [Test]
        public void InvalidIdProducesInvalidFlag()
            => Assert.AreEqual("objective_complete:invalid", ObjectiveRules.CompletionFlag("  "));

        [Test]
        public void MarkCompleteIsIdempotent()
        {
            var state = new CampaignState { campaignFlags = new List<string>() };
            Assert.IsTrue(ObjectiveRules.TryMarkComplete(state, "obj_a"));
            Assert.IsFalse(ObjectiveRules.TryMarkComplete(state, "obj_a"));
            Assert.IsTrue(ObjectiveRules.IsComplete(state, "obj_a"));
            Assert.AreEqual(1, state.campaignFlags.Count);
        }

        [Test]
        public void IsCompleteFalseWhenMissing()
        {
            var state = new CampaignState { campaignFlags = new List<string>() };
            Assert.IsFalse(ObjectiveRules.IsComplete(state, "missing"));
        }

        [Test]
        public void NullStateIsSafe()
        {
            Assert.IsFalse(ObjectiveRules.IsComplete(null, "x"));
            Assert.IsFalse(ObjectiveRules.TryMarkComplete(null, "x"));
        }

        [Test]
        public void ValidObjectiveIdBounds()
        {
            Assert.IsTrue(ObjectiveRules.IsValidObjectiveId("bridge_1"));
            Assert.IsFalse(ObjectiveRules.IsValidObjectiveId(""));
            Assert.IsFalse(ObjectiveRules.IsValidObjectiveId(new string('a', 65)));
        }
    }
}
