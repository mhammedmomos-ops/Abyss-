using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS52VerticalSliceLayoutTests
    {
        [Test]
        public void DefaultLayout_IsValid() => Assert.IsTrue(VerticalSliceLayout.IsValid(out _));

        [Test]
        public void TowerCenters_AreSymmetric()
        {
            Assert.That(VerticalSliceLayout.WestTowerCenter.x, Is.EqualTo(-VerticalSliceLayout.EastTowerCenter.x));
            Assert.That(VerticalSliceLayout.WestTowerCenter.z, Is.EqualTo(VerticalSliceLayout.EastTowerCenter.z));
        }

        [Test]
        public void BridgeSpan_CoversPlatformGap()
        {
            float gap = Mathf.Abs(VerticalSliceLayout.WestBridgeEnd.x - VerticalSliceLayout.EastBridgeEnd.x);
            Assert.That(VerticalSliceLayout.BridgeLength, Is.GreaterThanOrEqualTo(gap));
        }

        [Test]
        public void PlayerSpawn_IsAbovePlatform()
        {
            Assert.That(VerticalSliceLayout.PlayerSpawn.y, Is.GreaterThan(VerticalSliceLayout.PlatformTopY));
        }

        [Test]
        public void PlayerSpawn_IsInsideWestTowerPlatform()
        {
            Vector3 spawn = VerticalSliceLayout.PlayerSpawn;
            Vector3 center = VerticalSliceLayout.WestTowerCenter;
            Assert.That(spawn.x, Is.InRange(center.x - VerticalSliceLayout.TowerPlatformWidth * 0.5f, center.x + VerticalSliceLayout.TowerPlatformWidth * 0.5f));
            Assert.That(spawn.z, Is.InRange(-VerticalSliceLayout.TowerPlatformDepth * 0.5f, VerticalSliceLayout.TowerPlatformDepth * 0.5f));
        }

        [Test]
        public void GateClearance_CoversBridgeWidth() => Assert.That(VerticalSliceLayout.TowerGateClearance, Is.GreaterThanOrEqualTo(VerticalSliceLayout.BridgeWidth));

        [Test]
        public void GorgeFloor_IsBelowBridge()
        {
            Assert.That(VerticalSliceLayout.GorgeFloorY, Is.LessThan(VerticalSliceLayout.PlatformTopY));
        }
    }
}
