using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS71PangolinCurlTests
    {
        [Test]
        public void OnlyOperationalPangolinWithStaminaCanCurl()
        {
            Assert.IsTrue(AnimalPangolinCurlRules.CanIssueCurl(
                AnimalSpecies.Pangolin, AnimalStatus.Alive, 20, 80, 100, 10f, 0f, false));
            Assert.IsFalse(AnimalPangolinCurlRules.CanIssueCurl(
                AnimalSpecies.GermanShepherd, AnimalStatus.Alive, 20, 80, 100, 10f, 0f, false));
            Assert.IsFalse(AnimalPangolinCurlRules.CanIssueCurl(
                AnimalSpecies.Pangolin, AnimalStatus.Dead, 20, 80, 100, 10f, 0f, false));
            Assert.IsFalse(AnimalPangolinCurlRules.CanIssueCurl(
                AnimalSpecies.Pangolin, AnimalStatus.Alive, 5, 80, 100, 10f, 0f, false));
            Assert.IsFalse(AnimalPangolinCurlRules.CanIssueCurl(
                AnimalSpecies.Pangolin, AnimalStatus.Alive, 20, 80, 100, 10f, 0f, true));
        }

        [Test]
        public void CooldownBlocksReissueUntilExpired()
        {
            Assert.IsFalse(AnimalPangolinCurlRules.CanIssueCurl(
                AnimalSpecies.Pangolin, AnimalStatus.Alive, 30, 50, 100, 12f, 15f, false));
            Assert.IsTrue(AnimalPangolinCurlRules.CanIssueCurl(
                AnimalSpecies.Pangolin, AnimalStatus.Alive, 30, 50, 100, 16f, 15f, false));
        }

        [Test]
        public void CurlAppliesDeepDamageReduction()
        {
            float baseMult = 0.62f; // Pangolin profile incoming multiplier
            float whileCurled = AnimalPangolinCurlRules.DamageMultiplierWhileCurled(baseMult, true);
            Assert.AreEqual(baseMult * AnimalSpeciesTactics.PangolinCurlDamageMultiplier, whileCurled, 0.0001f);
            Assert.AreEqual(baseMult, AnimalPangolinCurlRules.DamageMultiplierWhileCurled(baseMult, false), 0.0001f);

            int mitigated = AnimalPangolinCurlRules.MitigatedDamage(20, baseMult, true);
            // 20 * 0.62 * 0.18 = 2.232 → ceil → 3
            Assert.AreEqual(3, mitigated);
            Assert.AreEqual(0, AnimalPangolinCurlRules.MitigatedDamage(0, baseMult, true));
        }

        [Test]
        public void DurationAndCooldownAreDeterministic()
        {
            float start = 40f;
            float ends = AnimalPangolinCurlRules.CurlEndsAt(start);
            Assert.AreEqual(start + AnimalSpeciesTactics.PangolinCurlDurationSeconds, ends, 0.001f);
            float cool = AnimalPangolinCurlRules.CooldownEndsAt(ends);
            Assert.AreEqual(ends + AnimalSpeciesTactics.PangolinCurlCooldownSeconds, cool, 0.001f);
            Assert.IsTrue(AnimalPangolinCurlRules.IsCurlActive(start + 1f, ends));
            Assert.IsFalse(AnimalPangolinCurlRules.IsCurlActive(ends + 0.01f, ends));
            Assert.IsTrue(AnimalPangolinCurlRules.IsOnCooldown(ends + 1f, cool));
            Assert.IsFalse(AnimalPangolinCurlRules.IsOnCooldown(cool + 0.01f, cool));
        }

        [Test]
        public void NearDeathHealthFloorBlocksCurl()
        {
            // Below the configured min health fraction
            Assert.IsFalse(AnimalPangolinCurlRules.CanIssueCurl(
                AnimalSpecies.Pangolin, AnimalStatus.Alive, 40, 2, 100, 5f, 0f, false));
            Assert.IsTrue(AnimalPangolinCurlRules.CanIssueCurl(
                AnimalSpecies.Pangolin, AnimalStatus.Alive, 40, 6, 100, 5f, 0f, false));
        }

        [Test]
        public void StaminaCostConstantIsPositiveAndDistinctFromBrace()
        {
            Assert.Greater(AnimalSpeciesTactics.PangolinCurlStaminaCost, AnimalSpeciesTactics.PangolinBraceStaminaCost);
            Assert.Greater(AnimalSpeciesTactics.PangolinCurlDurationSeconds, AnimalSpeciesTactics.PangolinBraceDurationSeconds);
            Assert.Less(AnimalSpeciesTactics.PangolinCurlDamageMultiplier, AnimalSpeciesTactics.PangolinBraceDamageMultiplier);
        }
    }
}
