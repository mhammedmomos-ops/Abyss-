using NUnit.Framework;
using System.Collections.Generic;

namespace GorgeHollow.Tests
{
    public sealed class VS100SupplyCampaignLogisticsTests
    {
        private CampaignState CreateCampaign()
        {
            return new CampaignState { towerDepots = new List<TowerDepotRecord> {
                new TowerDepotRecord { towerId = "tower_a", scrap = 20, timber = 12, ammunition = 20, medicalSupplies = 5 },
                new TowerDepotRecord { towerId = "tower_b" } }, supplyConvoys = new List<SupplyConvoyRecord>() };
        }

        [Test] public void ActiveTransferCountIgnoresDeliveredAndDestroyed()
        {
            CampaignState c = CreateCampaign();
            c.supplyConvoys.Add(new SupplyConvoyRecord { isInterTowerTransfer = true, status = SupplyConvoyStatus.Travelling });
            c.supplyConvoys.Add(new SupplyConvoyRecord { isInterTowerTransfer = true, status = SupplyConvoyStatus.Delivered });
            c.supplyConvoys.Add(new SupplyConvoyRecord { isInterTowerTransfer = true, status = SupplyConvoyStatus.Destroyed });
            Assert.AreEqual(1, SupplyCampaignLogisticsRules.CountActiveTransfers(c));
        }

        [Test] public void ThreeActiveTransfersBlockAnotherDispatch()
        {
            CampaignState c = CreateCampaign();
            for (int i = 0; i < 3; i++) c.supplyConvoys.Add(new SupplyConvoyRecord { isInterTowerTransfer = true, status = SupplyConvoyStatus.Travelling });
            Assert.IsFalse(SupplyCampaignLogisticsRules.CanDispatchAnotherTransfer(c, out _));
        }

        [Test] public void OneCompletedSlotAllowsDispatch()
        {
            CampaignState c = CreateCampaign();
            for (int i = 0; i < 2; i++) c.supplyConvoys.Add(new SupplyConvoyRecord { isInterTowerTransfer = true, status = SupplyConvoyStatus.Travelling });
            c.supplyConvoys.Add(new SupplyConvoyRecord { isInterTowerTransfer = true, status = SupplyConvoyStatus.Delivered });
            Assert.IsTrue(SupplyCampaignLogisticsRules.CanDispatchAnotherTransfer(c, out _));
        }

        [Test] public void InboundCargoReducesShortageRecommendation()
        {
            CampaignState c = CreateCampaign();
            TowerDepotRecord b = TowerDepotRules.Find(c, "tower_b"); b.scrap = 0;
            var before = SupplyCampaignLogisticsRules.AssessTower(c, "tower_b");
            c.supplyConvoys.Add(new SupplyConvoyRecord { isInterTowerTransfer = true, status = SupplyConvoyStatus.Travelling,
                destinationTowerId = "tower_b", scrap = 20 });
            var after = SupplyCampaignLogisticsRules.AssessTower(c, "tower_b");
            Assert.Less(after.scrapShortage, before.scrapShortage);
        }

        [Test] public void InboundCargoDoesNotDoubleCountNonTransferConvoy()
        {
            CampaignState c = CreateCampaign();
            c.supplyConvoys.Add(new SupplyConvoyRecord { isInterTowerTransfer = false, status = SupplyConvoyStatus.Travelling,
                destinationTowerId = "tower_b", scrap = 20 });
            Assert.AreEqual(20, SupplyCampaignLogisticsRules.AssessTower(c, "tower_b").scrapShortage);
        }

        [Test] public void CriticalMedicalShortageRanksAboveStableTower()
        {
            CampaignState c = CreateCampaign();
            Assert.AreEqual(SupplyLogisticsPriority.Critical, SupplyCampaignLogisticsRules.AssessTower(c, "tower_b").priority);
            Assert.AreEqual(SupplyLogisticsPriority.Stable, SupplyCampaignLogisticsRules.AssessTower(c, "tower_a").priority);
        }

        [Test] public void AssessmentsSortMostUrgentFirst()
        {
            CampaignState c = CreateCampaign();
            var list = SupplyCampaignLogisticsRules.AssessBothTowers(c);
            Assert.AreEqual("tower_b", list[0].towerId);
        }

        [Test] public void NullCampaignCannotDispatch()
        {
            Assert.IsFalse(SupplyCampaignLogisticsRules.CanDispatchAnotherTransfer(null, out _));
        }

        [Test] public void InboundOverflowArithmeticCannotWrap()
        {
            CampaignState c = CreateCampaign();
            TowerDepotRules.Find(c, "tower_b").scrap = int.MaxValue;
            c.supplyConvoys.Add(new SupplyConvoyRecord { isInterTowerTransfer = true, status = SupplyConvoyStatus.Travelling,
                destinationTowerId = "tower_b", scrap = int.MaxValue });
            Assert.AreEqual(0, SupplyCampaignLogisticsRules.AssessTower(c, "tower_b").scrapShortage);
        }
    }
}
