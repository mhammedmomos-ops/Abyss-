using NUnit.Framework;
namespace GorgeHollow.Tests
{
    public sealed class VS102TowerWorkforceTests
    {
        private static TowerWorkerRecord Worker(string id="w1", string tower="tower_a", TowerWorkerRole role=TowerWorkerRole.Mechanic, int skill=50) =>
            new TowerWorkerRecord { identity=id, displayName=id, towerId=tower, role=role, skill=skill };

        private static CampaignState NewEmptyWorkforceCampaign()
        {
            CampaignState campaign = CampaignStateFactory.CreateNew();
            campaign.towerWorkers.Clear();
            return campaign;
        }

        [Test] public void RescuedWorkerJoinsOnlyItsAssignedTower()
        {
            var c=NewEmptyWorkforceCampaign();
            Assert.IsTrue(TowerWorkerRules.TryRecruit(c,Worker(),out _));
            Assert.AreEqual(1,c.towerWorkers.Count); Assert.AreEqual(0,TowerWorkerRules.Find(c,"w1").fatigue);
            Assert.AreEqual(0,TowerWorkerRules.Find(c,"w1").health-100);
            Assert.AreEqual(0,TowerDepotRules.Find(c,"tower_a").scrap);
        }
        [Test] public void DuplicateRescueCannotDuplicateWorker()
        {
            var c=NewEmptyWorkforceCampaign(); TowerWorkerRules.TryRecruit(c,Worker(),out _);
            Assert.IsFalse(TowerWorkerRules.TryRecruit(c,Worker(),out _)); Assert.AreEqual(1,c.towerWorkers.Count);
        }
        [Test] public void TowerWorkforceCapacityIsBounded()
        {
            var c=NewEmptyWorkforceCampaign();
            for(int i=0;i<TowerWorkerRules.MaxWorkersPerTower;i++) Assert.IsTrue(TowerWorkerRules.TryRecruit(c,Worker("w"+i),out _));
            Assert.IsFalse(TowerWorkerRules.TryRecruit(c,Worker("overflow"),out _));
        }
        [Test] public void AssignmentSlotsAreBoundedPerTower()
        {
            var c=NewEmptyWorkforceCampaign();
            for(int i=0;i<4;i++) TowerWorkerRules.TryRecruit(c,Worker("w"+i),out _);
            for(int i=0;i<3;i++) Assert.IsTrue(TowerWorkerRules.TryAssign(c,"w"+i,TowerWorkerAssignment.Production,out _));
            Assert.IsFalse(TowerWorkerRules.TryAssign(c,"w3",TowerWorkerAssignment.Production,out _));
        }
        [Test] public void InjuredWorkerCannotReturnToDutyUntilRecovered()
        {
            var c=NewEmptyWorkforceCampaign(); TowerWorkerRules.TryRecruit(c,Worker(),out _);
            Assert.IsTrue(TowerWorkerRules.TryApplyDamage(c,"w1",75,out _));
            Assert.AreEqual(TowerWorkerStatus.Injured,TowerWorkerRules.Find(c,"w1").status);
            Assert.IsFalse(TowerWorkerRules.TryAssign(c,"w1",TowerWorkerAssignment.Guard,out _));
            TowerWorkerRules.Advance(c,120*11);
            Assert.AreEqual(TowerWorkerStatus.Active,TowerWorkerRules.Find(c,"w1").status);
        }
        [Test] public void LethalDamagePermanentlyKillsWorker()
        {
            var c=NewEmptyWorkforceCampaign(); TowerWorkerRules.TryRecruit(c,Worker(),out _);
            Assert.IsTrue(TowerWorkerRules.TryApplyDamage(c,"w1",100,out _));
            Assert.AreEqual(TowerWorkerStatus.Dead,TowerWorkerRules.Find(c,"w1").status);
            Assert.IsFalse(TowerWorkerRules.TryAssign(c,"w1",TowerWorkerAssignment.Rest,out _));
        }
        [Test] public void RestReducesFatigueAndRecoversHealth()
        {
            var c=NewEmptyWorkforceCampaign(); TowerWorkerRules.TryRecruit(c,Worker(),out _);
            TowerWorkerRules.TryAssign(c,"w1",TowerWorkerAssignment.Production,out _);
            TowerWorkerRules.Advance(c,300); var w=TowerWorkerRules.Find(c,"w1"); Assert.Greater(w.fatigue,0);
            TowerWorkerRules.TryApplyDamage(c,"w1",80,out _); int injuredHealth=w.health;
            TowerWorkerRules.Advance(c,120); Assert.Less(w.fatigue,10); Assert.Greater(w.health,injuredHealth);
        }
        [Test] public void MechanicStaffImprovesProductionWithoutChangingDepotOwnership()
        {
            var c=NewEmptyWorkforceCampaign(); float baseline=TowerWorkerRules.ProductionRate(c,"tower_a");
            TowerWorkerRules.TryRecruit(c,Worker(),out _); TowerWorkerRules.TryAssign(c,"w1",TowerWorkerAssignment.Production,out _);
            Assert.Greater(TowerWorkerRules.ProductionRate(c,"tower_a"),baseline);
            Assert.AreEqual(1f,TowerWorkerRules.ProductionRate(c,"tower_b"));
        }
        [Test] public void ScavengerBonusOnlyAppliesToItsOwnTower()
        {
            var c=NewEmptyWorkforceCampaign(); TowerWorkerRules.TryRecruit(c,Worker("s1","tower_a",TowerWorkerRole.Scavenger,100),out _);
            TowerWorkerRules.TryAssign(c,"s1",TowerWorkerAssignment.Salvage,out _);
            Assert.AreEqual(2,TowerWorkerRules.SalvageBonus(c,"tower_a",4));
            Assert.AreEqual(0,TowerWorkerRules.SalvageBonus(c,"tower_b",4));
        }
        [Test] public void GuardProtectionIsBoundedAndTowerLocal()
        {
            var c=NewEmptyWorkforceCampaign();
            for(int i=0;i<2;i++) { TowerWorkerRules.TryRecruit(c,Worker("g"+i,"tower_a",TowerWorkerRole.Guard,100),out _); TowerWorkerRules.TryAssign(c,"g"+i,TowerWorkerAssignment.Guard,out _); }
            Assert.Less(TowerWorkerRules.SiegeDamageMultiplier(c,"tower_a"),1f);
            Assert.AreEqual(1f,TowerWorkerRules.SiegeDamageMultiplier(c,"tower_b"));
            Assert.GreaterOrEqual(TowerWorkerRules.SiegeDamageMultiplier(c,"tower_a"),0.85f);
        }
        [Test] public void ProductionReceivesFractionalWorkCreditFromMechanic()
        {
            var c=NewEmptyWorkforceCampaign(); TowerDepotRules.Find(c,"tower_a").scrap=5;
            TowerWorkerRules.TryRecruit(c,Worker("m","tower_a",TowerWorkerRole.Mechanic,100),out _);
            TowerWorkerRules.TryAssign(c,"m",TowerWorkerAssignment.Production,out _);
            var job=new TowerProductionJobRecord { identity="p", durationMinutes=10, remainingMinutes=10, costScrap=5, yieldMechanicalParts=1 };
            Assert.IsTrue(TowerProductionRules.TryEnqueue(c,"tower_a",job,out _));
            TowerProductionRules.Advance(c,"tower_a",9);
            Assert.AreEqual(0,job.remainingMinutes); Assert.AreEqual(TowerProductionStatus.ReadyToCollect,job.status);
        }
        [Test] public void ProductionWithoutWorkersRetainsBaseRate()
        {
            var c=NewEmptyWorkforceCampaign(); TowerDepotRules.Find(c,"tower_a").scrap=5;
            var job=new TowerProductionJobRecord { identity="p", durationMinutes=10, remainingMinutes=10, costScrap=5, yieldMechanicalParts=1 };
            TowerProductionRules.TryEnqueue(c,"tower_a",job,out _); TowerProductionRules.Advance(c,"tower_a",9);
            Assert.AreEqual(1,job.remainingMinutes);
        }
        [Test] public void RestingMedicImprovesInjuredWorkersRecovery()
        {
            var c=NewEmptyWorkforceCampaign(); TowerWorkerRules.TryRecruit(c,Worker("inj"),out _); TowerWorkerRules.TryApplyDamage(c,"inj",80,out _);
            TowerWorkerRules.TryRecruit(c,Worker("med","tower_a",TowerWorkerRole.Medic),out _); TowerWorkerRules.TryAssign(c,"med",TowerWorkerAssignment.Rest,out _);
            TowerWorkerRules.Advance(c,60); Assert.AreEqual(21,TowerWorkerRules.Find(c,"inj").health);
        }
        [Test] public void WorkforceRecordsAreSaveValidated()
        {
            var c=NewEmptyWorkforceCampaign(); c.towerWorkers.Add(new TowerWorkerRecord { identity="", displayName="Invalid", towerId="tower_a" }); Assert.IsFalse(c.IsValid(out _));
            c.towerWorkers.Clear(); TowerWorkerRules.TryRecruit(c,Worker(),out _); Assert.IsTrue(c.IsValid(out _));
        }
        [Test] public void FractionalProductionWorkSurvivesCampaignValidation()
        {
            var c=NewEmptyWorkforceCampaign(); TowerDepotRules.Find(c,"tower_a").scrap=5;
            TowerWorkerRules.TryRecruit(c,Worker("m","tower_a",TowerWorkerRole.Mechanic,100),out _);
            TowerWorkerRules.TryAssign(c,"m",TowerWorkerAssignment.Production,out _);
            var job=new TowerProductionJobRecord { identity="fractional", durationMinutes=10, remainingMinutes=10, costScrap=5, yieldMechanicalParts=1 };
            TowerProductionRules.TryEnqueue(c,"tower_a",job,out _); TowerProductionRules.Advance(c,"tower_a",1);
            Assert.Greater(job.workProgressMinutes,0f); Assert.Less(job.workProgressMinutes,1f); Assert.IsTrue(c.IsValid(out string error),error);
        }
        [Test] public void ExhaustedWorkerAutomaticallyRests()
        {
            var c=NewEmptyWorkforceCampaign(); TowerWorkerRules.TryRecruit(c,Worker(),out _);
            TowerWorkerRules.TryAssign(c,"w1",TowerWorkerAssignment.Guard,out _); TowerWorkerRules.Advance(c,20*100);
            Assert.AreEqual(TowerWorkerAssignment.Rest,TowerWorkerRules.Find(c,"w1").assignment);
            Assert.AreEqual(100,TowerWorkerRules.Find(c,"w1").fatigue);
        }
        [Test] public void ExcessTimeAfterExhaustionIsSpentResting()
        {
            var c=NewEmptyWorkforceCampaign(); TowerWorkerRules.TryRecruit(c,Worker(),out _);
            TowerWorkerRules.TryAssign(c,"w1",TowerWorkerAssignment.Guard,out _); TowerWorkerRules.Advance(c,2100);
            var w=TowerWorkerRules.Find(c,"w1"); Assert.AreEqual(TowerWorkerAssignment.Rest,w.assignment); Assert.Less(w.fatigue,100);
        }
        [Test] public void RestingWorkerNeverProducesAutomaticResources()
        {
            var c=NewEmptyWorkforceCampaign(); TowerWorkerRules.TryRecruit(c,Worker(),out _); TowerWorkerRules.TryAssign(c,"w1",TowerWorkerAssignment.Rest,out _);
            TowerWorkerRules.Advance(c,10000); Assert.AreEqual(0,TowerDepotRules.Find(c,"tower_a").scrap);
        }
    }
}
