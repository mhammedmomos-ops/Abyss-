using System.Linq;
using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS54CombatAndRaidRewardTests
    {
        [TestCase(25f, 1f, 25f)]
        [TestCase(25f, 2f, 50f)]
        [TestCase(0f, 2f, 0f)]
        [TestCase(-5f, 2f, 0f)]
        [TestCase(25f, 0.5f, 25f)]
        [TestCase(25f, float.NaN, 25f)]
        [TestCase(float.PositiveInfinity, 2f, 0f)]
        public void DamageRulesSanitizeAndApplyWeakPointMultiplier(float baseDamage, float multiplier, float expected)
        {
            Assert.AreEqual(expected, CombatDamageRules.CalculateDamage(baseDamage, multiplier), 0.001f);
        }

        [TestCase(2, 2, true)]
        [TestCase(1, 1, true)]
        [TestCase(2, 1, false)]
        [TestCase(2, 0, false)]
        [TestCase(0, 0, false)]
        [TestCase(1, 2, false)]
        public void RaidRewardsRequireACompleteClear(int spawned, int killed, bool expected)
        {
            Assert.AreEqual(expected, MonsterRaidRewardRules.IsFullClear(spawned, killed));
        }

        [Test]
        public void FullClearRewardScalesByNumberOfMonsters()
        {
            ResourceDelta reward = MonsterRaidRewardRules.CreateFullClearReward(2, 2, 6, 3);
            Assert.NotNull(reward);
            Assert.AreEqual(12, reward.scrap);
            Assert.AreEqual(6, reward.ammunition);
        }

        [Test]
        public void PartialClearDoesNotCreateReward()
        {
            Assert.IsNull(MonsterRaidRewardRules.CreateFullClearReward(2, 1, 6, 3));
        }

        [Test]
        public void BrutePrioritizesSiegeBeforeInvestigation()
        {
            var order = MonsterTacticalProfile.GetOrder(MonsterArchetypeRole.Brute);
            Assert.Less(System.Array.IndexOf(order.ToArray(), MonsterDecisionBranch.Siege),
                System.Array.IndexOf(order.ToArray(), MonsterDecisionBranch.Investigate));
        }

        [Test]
        public void StalkerPrioritizesSharedContactBeforeSiege()
        {
            var order = MonsterTacticalProfile.GetOrder(MonsterArchetypeRole.Stalker);
            Assert.Less(System.Array.IndexOf(order.ToArray(), MonsterDecisionBranch.SharedContact),
                System.Array.IndexOf(order.ToArray(), MonsterDecisionBranch.Siege));
        }

        [Test]
        public void DistinctEncounterIdsProduceDistinctRewardTransactions()
        {
            string first = MonsterRaidRewardRules.BuildTransactionId("campaign", "raid-one");
            string second = MonsterRaidRewardRules.BuildTransactionId("campaign", "raid-two");
            Assert.AreNotEqual(first, second);
        }

        [Test]
        public void TransactionIdIncludesCampaignAndEncounterIdentity()
        {
            string id = MonsterRaidRewardRules.BuildTransactionId("campaignA", "encounterB");
            Assert.AreEqual("raid-clear:campaignA:encounterB", id);
            Assert.IsNull(MonsterRaidRewardRules.BuildTransactionId("", "encounterB"));
            Assert.IsNull(MonsterRaidRewardRules.BuildTransactionId("campaignA", null));
        }
    }
}
