using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS38LadderClimbTests
    {
        [Test]
        public void ClimbDeltaUsesInputAndSpeed()
        {
            float input = 1f;
            float climbSpeed = 2.8f;
            float dt = 0.1f;
            float dy = input * climbSpeed * dt;
            Assert.AreEqual(0.28f, dy, 0.001f);
        }

        [Test]
        public void LowAmmoThresholdInclusive()
        {
            int magazine = 3;
            int lowThreshold = 3;
            Assert.IsTrue(magazine <= lowThreshold);
        }
    }
}
