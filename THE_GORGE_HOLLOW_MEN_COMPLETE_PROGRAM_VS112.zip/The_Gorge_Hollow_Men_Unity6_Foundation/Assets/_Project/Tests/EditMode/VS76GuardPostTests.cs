using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS76GuardPostTests
    {
        [Test]
        public void OnlyLivingNonGuardingCompanionCanGuard()
        {
            Assert.IsTrue(AnimalGuardPostRules.CanIssueGuard(AnimalStatus.Alive, false));
            Assert.IsFalse(AnimalGuardPostRules.CanIssueGuard(AnimalStatus.Dead, false));
            Assert.IsFalse(AnimalGuardPostRules.CanIssueGuard(AnimalStatus.Missing, false));
            Assert.IsFalse(AnimalGuardPostRules.CanIssueGuard(AnimalStatus.Alive, true));
        }

        [Test]
        public void DetectionBoostAppliesOnlyWhileGuarding()
        {
            float baseR = 12f;
            float boosted = AnimalGuardPostRules.DetectionRadiusWhileGuarding(baseR, true);
            Assert.AreEqual(baseR * AnimalSpeciesTactics.GuardPostDetectionMultiplier, boosted, 0.0001f);
            Assert.AreEqual(baseR, AnimalGuardPostRules.DetectionRadiusWhileGuarding(baseR, false), 0.0001f);
            Assert.AreEqual(0f, AnimalGuardPostRules.DetectionRadiusWhileGuarding(0f, true), 0.0001f);
        }

        [Test]
        public void ThreatReportFiresOncePerGuardSession()
        {
            Assert.IsTrue(AnimalGuardPostRules.ShouldReportThreat(true, true, 0.7f, false));
            Assert.IsFalse(AnimalGuardPostRules.ShouldReportThreat(true, true, 0.7f, true));
            Assert.IsFalse(AnimalGuardPostRules.ShouldReportThreat(false, true, 0.7f, false));
            Assert.IsFalse(AnimalGuardPostRules.ShouldReportThreat(true, false, 0.7f, false));
            Assert.IsFalse(AnimalGuardPostRules.ShouldReportThreat(true, true, 0.3f, false));
        }

        [Test]
        public void ToastsAreNonEmpty()
        {
            Assert.IsFalse(string.IsNullOrWhiteSpace(
                AnimalGuardPostRules.FormatGuardToast("Rex", AnimalSpecies.GermanShepherd)));
            Assert.IsTrue(AnimalGuardPostRules.FormatStartToast("Shadow", AnimalSpecies.Cat).Contains("Shadow"));
            Assert.IsFalse(string.IsNullOrWhiteSpace(
                AnimalGuardPostRules.FormatStartToast(null, AnimalSpecies.Falcon)));
        }

        [Test]
        public void ConstantsAreReasonable()
        {
            Assert.Greater(AnimalSpeciesTactics.GuardPostDetectionMultiplier, 1f);
            Assert.Greater(AnimalSpeciesTactics.GuardPostMinConfidenceForReport, 0f);
            Assert.Less(AnimalSpeciesTactics.GuardPostMinConfidenceForReport, 1f);
        }
    }
}
