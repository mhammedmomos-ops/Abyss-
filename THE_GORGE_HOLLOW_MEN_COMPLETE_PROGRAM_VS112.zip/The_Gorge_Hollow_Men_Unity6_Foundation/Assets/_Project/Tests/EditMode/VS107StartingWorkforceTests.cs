using NUnit.Framework;
namespace GorgeHollow.Tests
{
    public sealed class VS107StartingWorkforceTests
    {
        [Test]
        public void NewCampaignStartsWithFourWorkersSplitAcrossBothTowers()
        {
            CampaignState campaign = CampaignStateFactory.CreateNew();
            Assert.AreEqual(4, campaign.towerWorkers.Count);
            Assert.AreEqual(2, campaign.towerWorkers.FindAll(x => x.towerId == "tower_a").Count);
            Assert.AreEqual(2, campaign.towerWorkers.FindAll(x => x.towerId == "tower_b").Count);
            Assert.IsTrue(campaign.IsValid(out string error), error);
        }

        [Test]
        public void EachTowerStartsWithAProductionMechanicAndAGuard()
        {
            CampaignState campaign = CampaignStateFactory.CreateNew();
            foreach (string tower in new[] { "tower_a", "tower_b" })
            {
                Assert.AreEqual(1, campaign.towerWorkers.FindAll(x => x.towerId == tower && x.role == TowerWorkerRole.Mechanic && x.assignment == TowerWorkerAssignment.Production).Count);
                Assert.AreEqual(1, campaign.towerWorkers.FindAll(x => x.towerId == tower && x.role == TowerWorkerRole.Guard && x.assignment == TowerWorkerAssignment.Guard).Count);
            }
        }

        [Test]
        public void StartingWorkersHaveUniqueStableIdentitiesAndNoRelationshipsUntilEventsOccur()
        {
            CampaignState campaign = CampaignStateFactory.CreateNew();
            Assert.AreEqual(4, new System.Collections.Generic.HashSet<string>(campaign.towerWorkers.ConvertAll(x => x.identity)).Count);
            Assert.AreEqual(0, campaign.workerRelationships.Count);
        }

        [Test]
        public void StartingWorkersLeaveRecruitmentCapacityForSurvivors()
        {
            CampaignState campaign = CampaignStateFactory.CreateNew();
            Assert.AreEqual(TowerWorkerRules.MaxWorkersPerTower - 2,
                TowerWorkerRules.MaxWorkersPerTower - campaign.towerWorkers.FindAll(x => x.towerId == "tower_a" && x.status != TowerWorkerStatus.Dead).Count);
            Assert.IsTrue(TowerWorkerRules.TryRecruit(campaign, new TowerWorkerRecord
            { identity = "rescued", displayName = "Rescued Survivor", towerId = "tower_a", role = TowerWorkerRole.Scavenger }, out _));
        }
    }
}
