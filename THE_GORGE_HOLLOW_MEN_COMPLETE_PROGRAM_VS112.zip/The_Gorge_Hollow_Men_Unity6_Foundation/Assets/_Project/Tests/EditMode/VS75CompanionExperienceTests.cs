using System.Collections.Generic;
using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS75CompanionExperienceTests
    {
        [Test]
        public void AwardXpClampsAndIgnoresNonPositive()
        {
            Assert.AreEqual(5, AnimalExperienceRules.AwardXp(5, 0));
            Assert.AreEqual(5, AnimalExperienceRules.AwardXp(5, -3));
            Assert.AreEqual(8, AnimalExperienceRules.AwardXp(5, 3));
            Assert.AreEqual(0, AnimalExperienceRules.AwardXp(-2, 5));
        }

        [Test]
        public void UnlocksAppearAtThresholdsAndOnlyOnce()
        {
            var learned = new List<string>();
            var none = AnimalExperienceRules.EvaluateNewUnlocks(0, learned);
            Assert.AreEqual(0, none.Count);

            var first = AnimalExperienceRules.EvaluateNewUnlocks(AnimalExperienceRules.XpForKeenSense, learned);
            Assert.AreEqual(1, first.Count);
            Assert.AreEqual(AnimalExperienceRules.AbilityKeenSense, first[0]);
            Assert.IsTrue(AnimalExperienceRules.HasAbility(learned, AnimalExperienceRules.AbilityKeenSense));

            var again = AnimalExperienceRules.EvaluateNewUnlocks(AnimalExperienceRules.XpForKeenSense, learned);
            Assert.AreEqual(0, again.Count);

            var second = AnimalExperienceRules.EvaluateNewUnlocks(AnimalExperienceRules.XpForHardy, learned);
            Assert.AreEqual(1, second.Count);
            Assert.AreEqual(AnimalExperienceRules.AbilityHardy, second[0]);

            var third = AnimalExperienceRules.EvaluateNewUnlocks(AnimalExperienceRules.XpForSeasoned, learned);
            Assert.AreEqual(1, third.Count);
            Assert.AreEqual(AnimalExperienceRules.AbilitySeasoned, third[0]);
            Assert.AreEqual(3, learned.Count);
        }

        [Test]
        public void PassiveMultipliersApplyOnlyWhenUnlocked()
        {
            var empty = new List<string>();
            Assert.AreEqual(1f, AnimalExperienceRules.DetectionMultiplier(empty), 0.0001f);
            Assert.AreEqual(1f, AnimalExperienceRules.IncomingDamageMultiplier(empty), 0.0001f);
            Assert.AreEqual(1f, AnimalExperienceRules.StaminaRecoveryMultiplier(empty), 0.0001f);
            Assert.AreEqual(0f, AnimalExperienceRules.ThreatConfidenceBonus(empty), 0.0001f);

            var keen = new List<string> { AnimalExperienceRules.AbilityKeenSense };
            Assert.AreEqual(AnimalExperienceRules.KeenSenseDetectionMultiplier,
                AnimalExperienceRules.DetectionMultiplier(keen), 0.0001f);

            var hardy = new List<string> { AnimalExperienceRules.AbilityHardy };
            Assert.AreEqual(AnimalExperienceRules.HardyIncomingDamageMultiplier,
                AnimalExperienceRules.IncomingDamageMultiplier(hardy), 0.0001f);

            var seasoned = new List<string> { AnimalExperienceRules.AbilitySeasoned };
            Assert.AreEqual(AnimalExperienceRules.SeasonedStaminaRecoveryMultiplier,
                AnimalExperienceRules.StaminaRecoveryMultiplier(seasoned), 0.0001f);
            Assert.AreEqual(AnimalExperienceRules.SeasonedThreatConfidenceBonus,
                AnimalExperienceRules.ThreatConfidenceBonus(seasoned), 0.0001f);
        }

        [Test]
        public void ThresholdsAreOrdered()
        {
            Assert.Less(AnimalExperienceRules.XpForKeenSense, AnimalExperienceRules.XpForHardy);
            Assert.Less(AnimalExperienceRules.XpForHardy, AnimalExperienceRules.XpForSeasoned);
            Assert.Greater(AnimalExperienceRules.XpForSuccessfulAbilityUse, 0);
            Assert.Greater(AnimalExperienceRules.XpForSuccessfulAttack, 0);
        }

        [Test]
        public void UnlockToastsAreNonEmpty()
        {
            Assert.IsFalse(string.IsNullOrWhiteSpace(
                AnimalExperienceRules.FormatUnlockToast(AnimalExperienceRules.AbilityKeenSense, "Rex")));
            Assert.IsTrue(AnimalExperienceRules.FormatUnlockToast(
                AnimalExperienceRules.AbilityHardy, "Shell").Contains("Shell"));
            Assert.IsFalse(string.IsNullOrWhiteSpace(
                AnimalExperienceRules.FormatUnlockToast(AnimalExperienceRules.AbilitySeasoned, null)));
        }
    }
}
