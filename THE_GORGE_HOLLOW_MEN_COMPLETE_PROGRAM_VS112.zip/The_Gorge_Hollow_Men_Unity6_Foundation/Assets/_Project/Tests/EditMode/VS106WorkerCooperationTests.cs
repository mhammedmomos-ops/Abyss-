using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS106WorkerCooperationTests
    {
        private static TowerWorkerRecord Worker(string id, string tower = "tower_a", TowerWorkerAssignment assignment = TowerWorkerAssignment.Production)
        {
            return new TowerWorkerRecord
            {
                identity = id, displayName = id, towerId = tower, role = TowerWorkerRole.Mechanic,
                status = TowerWorkerStatus.Active, assignment = assignment, health = 100, fatigue = 0
            };
        }

        private static CampaignState EmptyWorkforceCampaign()
        {
            CampaignState campaign = CampaignStateFactory.CreateNew();
            campaign.towerWorkers.Clear();
            return campaign;
        }

        [Test]
        public void ProductionTeamworkRequiresBothWorkersActiveAndAssignedAtSameTower()
        {
            CampaignState campaign = EmptyWorkforceCampaign();
            campaign.towerWorkers.Add(Worker("a"));
            campaign.towerWorkers.Add(Worker("b"));
            Assert.IsTrue(TowerWorkerRelationshipRules.TryCreate(campaign, "a", "b", out string reason), reason);
            TowerWorkerRelationshipRecord relationship = campaign.workerRelationships[0];
            relationship.bond = 100;
            Assert.AreEqual(0.05f, TowerWorkerRelationshipRules.GetProductionCooperationBonus(campaign, "tower_a"), 0.0001f);
            campaign.towerWorkers[1].assignment = TowerWorkerAssignment.Rest;
            Assert.AreEqual(0f, TowerWorkerRelationshipRules.GetProductionCooperationBonus(campaign, "tower_a"), 0.0001f);
            campaign.towerWorkers[1].assignment = TowerWorkerAssignment.Production;
            campaign.towerWorkers[1].status = TowerWorkerStatus.Injured;
            Assert.AreEqual(0f, TowerWorkerRelationshipRules.GetProductionCooperationBonus(campaign, "tower_a"), 0.0001f);
        }

        [Test]
        public void ProductionTeamworkIsTowerLocalAndCapped()
        {
            CampaignState campaign = EmptyWorkforceCampaign();
            for (int i = 0; i < 8; i++) campaign.towerWorkers.Add(Worker("w" + i));
            for (int i = 0; i < 4; i++)
            {
                Assert.IsTrue(TowerWorkerRelationshipRules.TryCreate(campaign, "w" + (i * 2), "w" + (i * 2 + 1), out string reason), reason);
                campaign.workerRelationships[i].bond = 100;
            }
            Assert.AreEqual(0.10f, TowerWorkerRelationshipRules.GetProductionCooperationBonus(campaign, "tower_a"), 0.0001f);
            Assert.AreEqual(0f, TowerWorkerRelationshipRules.GetProductionCooperationBonus(campaign, "tower_b"), 0.0001f);
        }

        [Test]
        public void ReadinessNeverCreatesProductionBonusWithoutRelationship()
        {
            CampaignState campaign = EmptyWorkforceCampaign();
            campaign.towerWorkers.Add(Worker("a"));
            campaign.towerWorkers.Add(Worker("b"));
            Assert.AreEqual(0f, TowerWorkerRelationshipRules.GetProductionCooperationBonus(campaign, "tower_a"), 0.0001f);
        }

        [Test]
        public void CooperationBonusIsAddedWithoutChangingExistingWorkerProductionCap()
        {
            CampaignState campaign = EmptyWorkforceCampaign();
            campaign.towerWorkers.Add(Worker("a"));
            campaign.towerWorkers.Add(Worker("b"));
            Assert.IsTrue(TowerWorkerRelationshipRules.TryCreate(campaign, "a", "b", out string reason), reason);
            campaign.workerRelationships[0].bond = 100;
            Assert.AreEqual(1.125f, TowerWorkerRules.ProductionRate(campaign, "tower_a"), 0.0001f);
        }
    }
}
