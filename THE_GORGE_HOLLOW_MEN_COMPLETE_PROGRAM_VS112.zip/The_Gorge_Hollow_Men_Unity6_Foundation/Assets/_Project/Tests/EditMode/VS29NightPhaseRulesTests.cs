using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS29NightPhaseRulesTests
    {
        // Mirrors NightAmbientController.IsNightPhase logic for regression safety.
        private static bool IsNightPhase(CampaignPhase phase)
        {
            return phase == CampaignPhase.ThreatDevelopment ||
                   phase == CampaignPhase.ActiveRaid ||
                   phase == CampaignPhase.ThreatResolution;
        }

        [TestCase(CampaignPhase.RecoveryPreparation, false)]
        [TestCase(CampaignPhase.ThreatDevelopment, true)]
        [TestCase(CampaignPhase.ActiveRaid, true)]
        [TestCase(CampaignPhase.ThreatResolution, true)]
        [TestCase(CampaignPhase.DawnReview, false)]
        [TestCase(CampaignPhase.Completed, false)]
        public void NightPhasesMatchExpected(CampaignPhase phase, bool expected)
            => Assert.AreEqual(expected, IsNightPhase(phase));
    }
}
