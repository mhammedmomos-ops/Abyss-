using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS43ResourceNodeTests
    {
        [Test]
        public void HitsDecrementToZero()
        {
            int hits = 3;
            hits--;
            hits--;
            hits--;
            Assert.AreEqual(0, hits);
        }

        [Test]
        public void PromptIncludesRemaining()
        {
            int hitsRemaining = 2;
            string prompt = "Gather (" + hitsRemaining + ")";
            Assert.AreEqual("Gather (2)", prompt);
        }
    }
}
