using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public class VS83CompanionIntelligenceTests
    {
        [Test]
        public void ShepherdPrioritisesProtectionWhenThreatIsCloserToOwner()
        {
            var result = AnimalCompanionIntelligenceRules.Evaluate(AnimalSpecies.GermanShepherd,
                AnimalCommand.Follow, 8f, 3f, false);
            Assert.AreEqual(1.08f, result.DetectionMultiplier, 0.001f);
            Assert.AreEqual(0.08f, result.ConfidenceBonus, 0.001f);
        }

        [Test]
        public void FalconUsesHeightAdvantageWithoutClaimingCertainty()
        {
            var result = AnimalCompanionIntelligenceRules.Evaluate(AnimalSpecies.Falcon,
                AnimalCommand.Follow, 12f, 10f, true);
            Assert.AreEqual(1.12f, result.DetectionMultiplier, 0.001f);
            Assert.AreEqual(0.06f, result.ConfidenceBonus, 0.001f);
            Assert.LessOrEqual(AnimalCompanionIntelligenceRules.ApplyConfidence(0.97f, result), 1f);
        }

        [Test]
        public void PangolinGetsDefensiveReadOnlyAtCloseRange()
        {
            var close = AnimalCompanionIntelligenceRules.Evaluate(AnimalSpecies.Pangolin,
                AnimalCommand.Guard, 3.5f, 4f, false);
            var far = AnimalCompanionIntelligenceRules.Evaluate(AnimalSpecies.Pangolin,
                AnimalCommand.Guard, 8f, 4f, false);
            Assert.AreEqual(0.09f, close.ConfidenceBonus, 0.001f);
            Assert.AreEqual(0f, far.ConfidenceBonus, 0.001f);
        }

        [Test]
        public void CatGetsQuietAssessmentOnlyWhileStalking()
        {
            var stalking = AnimalCompanionIntelligenceRules.Evaluate(AnimalSpecies.Cat,
                AnimalCommand.Stalk, 6f, 9f, false);
            var following = AnimalCompanionIntelligenceRules.Evaluate(AnimalSpecies.Cat,
                AnimalCommand.Follow, 6f, 9f, false);
            Assert.AreEqual(0.08f, stalking.ConfidenceBonus, 0.001f);
            Assert.AreEqual(0f, following.ConfidenceBonus, 0.001f);
        }

        [Test]
        public void FalconElevationAndCatStalkingExpandOnlyTheirOwnScanRadius()
        {
            Assert.AreEqual(1.12f, AnimalCompanionIntelligenceRules.ScanRadiusMultiplier(
                AnimalSpecies.Falcon, AnimalCommand.Follow, true), 0.001f);
            Assert.AreEqual(1.05f, AnimalCompanionIntelligenceRules.ScanRadiusMultiplier(
                AnimalSpecies.Cat, AnimalCommand.Stalk, false), 0.001f);
            Assert.AreEqual(1f, AnimalCompanionIntelligenceRules.ScanRadiusMultiplier(
                AnimalSpecies.Pangolin, AnimalCommand.Guard, true), 0.001f);
        }

        [Test]
        public void InvalidConfidenceAndDistancesAreSafe()
        {
            var result = AnimalCompanionIntelligenceRules.Evaluate(AnimalSpecies.GermanShepherd,
                AnimalCommand.Follow, float.NaN, float.PositiveInfinity, false);
            Assert.AreEqual(1f, result.DetectionMultiplier, 0.001f);
            Assert.AreEqual(0f, AnimalCompanionIntelligenceRules.ApplyConfidence(float.NaN, result), 0.001f);
        }
    }
}
