using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS46ProgressReportTests
    {
        [Test]
        public void SystemsPercentInRange()
        {
            Assert.GreaterOrEqual(FoundationProgressReport.SystemsFoundationPercent, 0);
            Assert.LessOrEqual(FoundationProgressReport.SystemsFoundationPercent, 100);
        }

        [Test]
        public void ShippablePercentLessThanSystems()
        {
            Assert.Less(FoundationProgressReport.ShippableGamePercent,
                FoundationProgressReport.SystemsFoundationPercent);
        }
    }
}
