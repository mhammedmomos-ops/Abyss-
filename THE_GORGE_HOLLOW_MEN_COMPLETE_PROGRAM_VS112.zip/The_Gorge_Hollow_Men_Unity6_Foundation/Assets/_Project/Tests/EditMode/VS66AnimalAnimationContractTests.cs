using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS66AnimalAnimationContractTests
    {
        [Test]
        public void NormalizedSpeedIsBoundedAndUsesTheConfiguredSpeciesSpeed()
        {
            Assert.AreEqual(0.5f, AnimalAnimationContract.NormalizeSpeed(2f, 4f), 0.0001f);
            Assert.AreEqual(1f, AnimalAnimationContract.NormalizeSpeed(8f, 4f), 0.0001f);
            Assert.AreEqual(0f, AnimalAnimationContract.NormalizeSpeed(-1f, 4f), 0.0001f);
        }

        [Test]
        public void InvalidSpeedInputsAreSanitized()
        {
            Assert.AreEqual(0f, AnimalAnimationContract.NormalizeSpeed(float.NaN, 4f));
            Assert.AreEqual(0f, AnimalAnimationContract.NormalizeSpeed(float.PositiveInfinity, 4f));
            Assert.AreEqual(1f, AnimalAnimationContract.NormalizeSpeed(1f, 0f));
        }

        [Test]
        public void RunningThresholdIsBoundedAndRejectsInvalidValues()
        {
            Assert.IsFalse(AnimalAnimationContract.IsRunning(0.89f));
            Assert.IsTrue(AnimalAnimationContract.IsRunning(0.9f));
            Assert.IsFalse(AnimalAnimationContract.IsRunning(float.NaN));
            Assert.IsFalse(AnimalAnimationContract.IsRunning(float.PositiveInfinity));
            Assert.IsFalse(AnimalAnimationContract.IsRunning(0.05f, -3f));
        }

        [Test]
        public void AllFourApprovedSpeciesHaveStableAnimationIndices()
        {
            Assert.AreEqual(0, AnimalAnimationContract.SpeciesIndex(AnimalSpecies.GermanShepherd));
            Assert.AreEqual(1, AnimalAnimationContract.SpeciesIndex(AnimalSpecies.Falcon));
            Assert.AreEqual(2, AnimalAnimationContract.SpeciesIndex(AnimalSpecies.Pangolin));
            Assert.AreEqual(3, AnimalAnimationContract.SpeciesIndex(AnimalSpecies.Cat));
        }

        [Test]
        public void AnimationContractExposesTheRequiredSharedParameters()
        {
            Assert.AreEqual("Speed", AnimalAnimationContract.Speed);
            Assert.AreEqual("IsBracing", AnimalAnimationContract.IsBracing);
            Assert.AreEqual("IsForaging", AnimalAnimationContract.IsForaging);
            Assert.AreEqual("IsLuring", AnimalAnimationContract.IsLuring);
            Assert.AreEqual("IsIncapacitated", AnimalAnimationContract.IsIncapacitated);
            Assert.AreEqual("Attack", AnimalAnimationContract.Attack);
        }
    }
}
