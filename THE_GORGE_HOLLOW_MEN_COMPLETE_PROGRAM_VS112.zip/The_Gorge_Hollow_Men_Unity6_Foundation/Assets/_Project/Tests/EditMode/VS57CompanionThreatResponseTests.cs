using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS57CompanionThreatResponseTests
    {
        [Test]
        public void MonsterCanTargetOnlyAnOperationalCompanionThreateningItselfNearVisibleOwner()
        {
            Assert.IsTrue(CompanionThreatRules.CanMonsterTargetCompanion(true, true, true, true, 1.2f, 1.65f));
        }

        [TestCase(false, true, true, true, 1f, 1.65f)]
        [TestCase(true, false, true, true, 1f, 1.65f)]
        [TestCase(true, true, false, true, 1f, 1.65f)]
        [TestCase(true, true, true, false, 1f, 1.65f)]
        [TestCase(true, true, true, true, 2f, 1.65f)]
        public void MonsterCannotTargetCompanionWithoutAllObservableEligibilityGates(bool seesOwner,
            bool ownerMatches, bool companionThreatens, bool operational, float distance, float range)
        {
            Assert.IsFalse(CompanionThreatRules.CanMonsterTargetCompanion(seesOwner, ownerMatches,
                companionThreatens, operational, distance, range));
        }

        [Test]
        public void PendingCompanionStrikeIsCancelledWhenThreatOrOwnerVisibilityIsLost()
        {
            Assert.IsFalse(CompanionThreatRules.CanResolveCompanionAttack(true, false, true, 1f, 2f));
            Assert.IsFalse(CompanionThreatRules.CanResolveCompanionAttack(true, true, false, 1f, 2f));
            Assert.IsFalse(CompanionThreatRules.CanResolveCompanionAttack(false, true, true, 1f, 2f));
        }

        [Test]
        public void PendingCompanionStrikeResolvesOnlyInsideBoundedRange()
        {
            Assert.IsTrue(CompanionThreatRules.CanResolveCompanionAttack(true, true, true, 1.8f, 2.3f));
            Assert.IsFalse(CompanionThreatRules.CanResolveCompanionAttack(true, true, true, 2.31f, 2.3f));
        }

        [Test]
        public void InvalidDistanceAndRangeNeverAuthorizeCompanionDamage()
        {
            Assert.IsFalse(CompanionThreatRules.CanMonsterTargetCompanion(true, true, true, true, float.NaN, 2f));
            Assert.IsFalse(CompanionThreatRules.CanMonsterTargetCompanion(true, true, true, true, 1f, float.PositiveInfinity));
            Assert.IsFalse(CompanionThreatRules.CanResolveCompanionAttack(true, true, true, float.NegativeInfinity, 2f));
        }
    }
}
