using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS27AudioCueIdTests
    {
        [Test]
        public void CueIdsAreStableEnums()
        {
            Assert.AreEqual(0, (int)AudioCueId.None);
            Assert.IsTrue((int)AudioCueId.RaidAlarm > 0);
        }

        [Test]
        public void HapticsToggleDoesNotThrow()
        {
            bool previous = MobileHaptics.Enabled;
            MobileHaptics.Enabled = false;
            Assert.DoesNotThrow(() => MobileHaptics.PlayImpact(MobileHapticStrength.Light));
            MobileHaptics.Enabled = previous;
        }
    }
}
