using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS109WorkerCommandRulesTests
    {
        [Test]
        public void CommandableRosterExcludesDeadAndCapturedWorkers()
        {
            var campaign = new CampaignState();
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "a", towerId = "tower_a", status = TowerWorkerStatus.Active });
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "b", towerId = "tower_a", status = TowerWorkerStatus.Dead });
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "c", towerId = "tower_a", status = TowerWorkerStatus.Captured });
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "d", towerId = "tower_a", status = TowerWorkerStatus.Injured });
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "remote", towerId = "tower_b", status = TowerWorkerStatus.Active });

            var result = TowerWorkerCommandRules.GetCommandableWorkers(campaign, "tower_a");

            Assert.AreEqual(2, result.Count);
            Assert.AreEqual("a", result[0].identity);
            Assert.AreEqual("d", result[1].identity);
        }


        [Test]
        public void LocalRosterNeverIncludesWorkersFromTheOtherTower()
        {
            var campaign = new CampaignState();
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "west_worker", towerId = "tower_a" });
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "east_worker", towerId = "tower_b" });

            var west = TowerWorkerCommandRules.GetCommandableWorkers(campaign, "tower_a");
            var east = TowerWorkerCommandRules.GetCommandableWorkers(campaign, "tower_b");

            Assert.AreEqual(1, west.Count);
            Assert.AreEqual("west_worker", west[0].identity);
            Assert.AreEqual(1, east.Count);
            Assert.AreEqual("east_worker", east[0].identity);
        }

        [Test]
        public void InvalidOrAbsentLocalTowerReturnsNoWorkers()
        {
            var campaign = new CampaignState();
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "worker", towerId = "tower_a" });

            Assert.AreEqual(0, TowerWorkerCommandRules.GetCommandableWorkers(campaign, null).Count);
            Assert.AreEqual(0, TowerWorkerCommandRules.GetCommandableWorkers(campaign, "gorge").Count);
        }

        [Test]
        public void PlayerOnlyGetsTowerAccessInsideThatTowersLocalRadius()
        {
            UnityEngine.Vector3 west = new UnityEngine.Vector3(-23f, 0f, 0f);
            UnityEngine.Vector3 east = new UnityEngine.Vector3(23f, 0f, 0f);
            Assert.AreEqual("tower_a", TowerLocalAccessTracker.ResolveLocalTowerId(
                new UnityEngine.Vector3(-19f, 0f, 0f), west, east, 8.5f));
            Assert.AreEqual("tower_b", TowerLocalAccessTracker.ResolveLocalTowerId(
                new UnityEngine.Vector3(19f, 0f, 0f), west, east, 8.5f));
            Assert.IsNull(TowerLocalAccessTracker.ResolveLocalTowerId(
                UnityEngine.Vector3.zero, west, east, 8.5f));
            Assert.IsNull(TowerLocalAccessTracker.ResolveLocalTowerId(
                new UnityEngine.Vector3(-14f, 0f, 0f), west, east, 8.5f));
        }

        [Test]
        public void LocalAccessDistanceIgnoresHeightAndUsesHorizontalPosition()
        {
            Assert.AreEqual(10f, TowerLocalAccessTracker.HorizontalDistance(
                new UnityEngine.Vector3(0f, 0f, 0f), new UnityEngine.Vector3(6f, 100f, 8f)), 0.001f);
        }


        [Test]
        public void LocalAssignmentRuleRejectsRemoteWorkerEvenWhenWorkerIsOtherwiseEligible()
        {
            var campaign = new CampaignState();
            campaign.towerWorkers.Add(new TowerWorkerRecord
            {
                identity = "east_worker", towerId = "tower_b", assignment = TowerWorkerAssignment.Idle
            });

            Assert.IsFalse(TowerWorkerCommandRules.CanAssign(campaign, "east_worker", "tower_a",
                TowerWorkerAssignment.Production, out string reason));
            Assert.That(reason, Does.Contain("current tower"));
            Assert.IsTrue(TowerWorkerCommandRules.CanAssign(campaign, "east_worker", "tower_b",
                TowerWorkerAssignment.Production, out _));
        }

        [Test]
        public void InjuredWorkerCanOnlyBeAssignedToRest()
        {
            var campaign = new CampaignState();
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "injured", status = TowerWorkerStatus.Injured });

            Assert.IsTrue(TowerWorkerCommandRules.CanAssign(campaign, "injured", TowerWorkerAssignment.Rest, out _));
            Assert.IsFalse(TowerWorkerCommandRules.CanAssign(campaign, "injured", TowerWorkerAssignment.Production, out _));
        }

        [Test]
        public void ExhaustedWorkerCanOnlyBeAssignedToRest()
        {
            var campaign = new CampaignState();
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "tired", fatigue = 100 });

            Assert.IsTrue(TowerWorkerCommandRules.CanAssign(campaign, "tired", TowerWorkerAssignment.Rest, out _));
            Assert.IsFalse(TowerWorkerCommandRules.CanAssign(campaign, "tired", TowerWorkerAssignment.Guard, out _));
        }

        [Test]
        public void AssignmentCapacityIsTowerLocal()
        {
            var campaign = new CampaignState();
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "a1", towerId = "tower_a", assignment = TowerWorkerAssignment.Guard });
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "a2", towerId = "tower_a", assignment = TowerWorkerAssignment.Guard });
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "a3", towerId = "tower_a", assignment = TowerWorkerAssignment.Guard });
            campaign.towerWorkers.Add(new TowerWorkerRecord { identity = "b1", towerId = "tower_b", assignment = TowerWorkerAssignment.Guard });

            Assert.IsFalse(TowerWorkerCommandRules.CanAssign(campaign, "a1", TowerWorkerAssignment.Guard, out _));
            Assert.IsTrue(TowerWorkerCommandRules.CanAssign(campaign, "b1", TowerWorkerAssignment.Guard, out _));
        }

        [Test]
        public void DangerousAssignmentRefusalIsRespectedByPanelRules()
        {
            var campaign = new CampaignState();
            campaign.towerWorkers.Add(new TowerWorkerRecord
            {
                identity = "worker", morale = 10, loyalty = 50, stress = 0,
                assignment = TowerWorkerAssignment.Idle
            });

            Assert.IsFalse(TowerWorkerCommandRules.CanAssign(campaign, "worker", TowerWorkerAssignment.Guard, out string reason));
            Assert.IsFalse(string.IsNullOrEmpty(reason));
        }

        [Test]
        public void AuthoritativeAssignmentUsesTheSameEligibilityRules()
        {
            var campaign = new CampaignState();
            var worker = new TowerWorkerRecord { identity = "worker", assignment = TowerWorkerAssignment.Idle };
            campaign.towerWorkers.Add(worker);

            Assert.IsTrue(TowerWorkerRules.TryAssign(campaign, "worker", TowerWorkerAssignment.Production, out _));
            Assert.AreEqual(TowerWorkerAssignment.Production, worker.assignment);
            worker.status = TowerWorkerStatus.Injured;
            Assert.IsFalse(TowerWorkerRules.TryAssign(campaign, "worker", TowerWorkerAssignment.Guard, out _));
            Assert.AreEqual(TowerWorkerAssignment.Production, worker.assignment);
        }

        [Test]
        public void CommandRulesDoNotMutateCampaignRecords()
        {
            var campaign = new CampaignState();
            var worker = new TowerWorkerRecord { identity = "worker", assignment = TowerWorkerAssignment.Idle, fatigue = 20 };
            campaign.towerWorkers.Add(worker);

            TowerWorkerCommandRules.CanAssign(campaign, "worker", TowerWorkerAssignment.Production, out _);

            Assert.AreEqual(TowerWorkerAssignment.Idle, worker.assignment);
            Assert.AreEqual(20, worker.fatigue);
        }
    }
}
