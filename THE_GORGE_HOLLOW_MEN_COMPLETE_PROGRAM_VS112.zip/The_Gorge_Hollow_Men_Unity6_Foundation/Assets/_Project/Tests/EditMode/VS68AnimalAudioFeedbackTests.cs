using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS68AnimalAudioFeedbackTests
    {
        [Test]
        public void AudioCueContractContainsDistinctGameplayFeedback()
        {
            Assert.AreEqual(7, System.Enum.GetValues(typeof(AnimalAudioCue)).Length);
            Assert.AreNotEqual(AnimalAudioCue.ThreatSpotted, AnimalAudioCue.Injury);
            Assert.AreNotEqual(AnimalAudioCue.Distraction, AnimalAudioCue.ForageComplete);
            Assert.AreNotEqual(AnimalAudioCue.Death, AnimalAudioCue.Missing);
        }

        [Test]
        public void AllApprovedCompanionSpeciesRemainSupportedByAudioContract()
        {
            Assert.AreEqual(0, (int)AnimalSpecies.GermanShepherd);
            Assert.AreEqual(1, (int)AnimalSpecies.Falcon);
            Assert.AreEqual(2, (int)AnimalSpecies.Pangolin);
            Assert.AreEqual(3, (int)AnimalSpecies.Cat);
        }
    }
}
