using System.Collections.Generic;
using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class CampaignAnimalRecordRulesTests
    {
        [Test]
        public void TryUpsert_AddsNewStableIdentity()
        {
            var records = new List<AnimalRecord>();
            var animal = new AnimalRecord { identity = "pet-01", health = 70 };

            Assert.IsTrue(CampaignAnimalRecordRules.TryUpsert(records, animal, out string error), error);
            Assert.AreEqual(1, records.Count);
            Assert.AreSame(animal, records[0]);
        }

        [Test]
        public void TryUpsert_ReplacesExistingRecordWithLiveState()
        {
            var oldRecord = new AnimalRecord { identity = "pet-01", health = 100 };
            var liveRecord = new AnimalRecord { identity = "pet-01", health = 42 };
            var records = new List<AnimalRecord> { oldRecord };

            Assert.IsTrue(CampaignAnimalRecordRules.TryUpsert(records, liveRecord, out string error), error);
            Assert.AreEqual(1, records.Count);
            Assert.AreSame(liveRecord, records[0]);
            Assert.AreEqual(42, records[0].health);
        }

        [Test]
        public void TryUpsert_RejectsDuplicateExistingIdentities()
        {
            var records = new List<AnimalRecord>
            {
                new AnimalRecord { identity = "pet-01" },
                new AnimalRecord { identity = "pet-01" }
            };
            var liveRecord = new AnimalRecord { identity = "pet-01", health = 10 };

            Assert.IsFalse(CampaignAnimalRecordRules.TryUpsert(records, liveRecord, out string error));
            StringAssert.Contains("Duplicate", error);
            Assert.AreEqual(2, records.Count);
            Assert.AreEqual(100, records[0].health);
        }

        [TestCase(null)]
        [TestCase("")]
        [TestCase("   ")]
        public void TryUpsert_RejectsMissingIdentity(string identity)
        {
            var records = new List<AnimalRecord>();
            var animal = new AnimalRecord { identity = identity };

            Assert.IsFalse(CampaignAnimalRecordRules.TryUpsert(records, animal, out string error));
            Assert.IsNotEmpty(error);
            Assert.IsEmpty(records);
        }
    }
}
