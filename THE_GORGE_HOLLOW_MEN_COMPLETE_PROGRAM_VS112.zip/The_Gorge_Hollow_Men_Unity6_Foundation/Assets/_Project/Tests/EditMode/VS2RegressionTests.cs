using NUnit.Framework;
using System;
using System.IO;
using UnityEngine;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS2RegressionTests
    {
        [Test]
        public void PlayerVitalsDefaultsAreValidAndAlive()
        {
            var data = new PlayerVitalsData();
            Assert.AreEqual(100f, data.health);
            Assert.AreEqual(100f, data.stamina);
            Assert.IsFalse(data.isDead);
        }

        [Test]
        public void CampaignAcceptsVitalsAndRejectsImpossibleDeadState()
        {
            var campaign = new CampaignState();
            Assert.IsTrue(campaign.IsValid(out _));
            campaign.playerVitals.isDead = true;
            campaign.playerVitals.health = 50f;
            Assert.IsFalse(campaign.IsValid(out _));
        }

        [Test]
        public void CampaignNormalizesMissingVitalsForFoundationSaveCompatibility()
        {
            var campaign = new CampaignState { playerVitals = null };
            Assert.IsTrue(campaign.IsValid(out _));
            Assert.IsNotNull(campaign.playerVitals);
        }

        [Test]
        public void WeaponDefinitionClampsUnsafeValues()
        {
            var weapon = ScriptableObject.CreateInstance<WeaponDefinition>();
            try
            {
                Assert.GreaterOrEqual(weapon.Damage, 0f);
                Assert.Greater(weapon.Range, 0f);
                Assert.Greater(weapon.ShotsPerSecond, 0f);
                Assert.GreaterOrEqual(weapon.MagazineCapacity, 1);
                Assert.Greater(weapon.ReloadDuration, 0f);
            }
            finally { UnityEngine.Object.DestroyImmediate(weapon); }
        }


        [Test]
        public void SaveReplacementKeepsPreviousValidSaveAsBackup()
        {
            string directory = Path.Combine(Path.GetTempPath(), "GorgeHollowTests_" + Guid.NewGuid().ToString("N"));
            try
            {
                var saves = new CampaignSaveService(directory, "campaign.json");
                var first = new CampaignState { scrap = 11 };
                Assert.IsTrue(saves.Save(first, out string firstError), firstError);
                var second = new CampaignState { campaignId = first.campaignId, scrap = 29 };
                Assert.IsTrue(saves.Save(second, out string secondError), secondError);
                File.WriteAllText(Path.Combine(directory, "campaign.json"), "{ broken json");
                CampaignState recovered = saves.Load(out string loadError);
                Assert.IsNotNull(recovered, loadError);
                Assert.AreEqual(11, recovered.scrap);
            }
            finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        }

        [Test]
        public void InvalidSaveDoesNotReplaceExistingPrimary()
        {
            string directory = Path.Combine(Path.GetTempPath(), "GorgeHollowTests_" + Guid.NewGuid().ToString("N"));
            try
            {
                var saves = new CampaignSaveService(directory, "campaign.json");
                var first = new CampaignState { scrap = 17 };
                Assert.IsTrue(saves.Save(first, out string firstError), firstError);
                var invalid = new CampaignState { campaignId = "", scrap = 99 };
                Assert.IsFalse(saves.Save(invalid, out _));
                CampaignState loaded = saves.Load(out string loadError);
                Assert.IsNotNull(loaded, loadError);
                Assert.AreEqual(17, loaded.scrap);
            }
            finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        }

        [Test]
        public void MobileInputStateClampsMovementAndConsumesOneShotActions()
        {
            MobileInputState.ResetAll();
            MobileInputState.SetMove(new Vector2(3f, 4f));
            Assert.AreEqual(1f, MobileInputState.Move.magnitude, 0.0001f);
            MobileInputState.PressReload();
            Assert.IsTrue(MobileInputState.ConsumeReload());
            Assert.IsFalse(MobileInputState.ConsumeReload());
            MobileInputState.ResetAll();
        }
    }
}
