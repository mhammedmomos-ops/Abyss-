using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS92BridgeRepairWorkRulesTests
    {
        [Test]
        public void DamagedSupportUsesShortRepairDuration()
            => Assert.AreEqual(4f, BridgeRepairWorkRules.DurationSeconds(
                TowerStructuralSegmentState.Damaged, 4f, 8f));

        [Test]
        public void CollapsedSupportUsesLongRepairDuration()
            => Assert.AreEqual(8f, BridgeRepairWorkRules.DurationSeconds(
                TowerStructuralSegmentState.Collapsed, 4f, 8f));

        [Test]
        public void IntactSupportCannotBeScheduledForRepair()
            => Assert.AreEqual(0f, BridgeRepairWorkRules.DurationSeconds(
                TowerStructuralSegmentState.Intact, 4f, 8f));

        [Test]
        public void InvalidDurationTuningUsesSafeDefaults()
            => Assert.AreEqual(8f, BridgeRepairWorkRules.DurationSeconds(
                TowerStructuralSegmentState.Collapsed, float.NaN, 0f));

        [Test]
        public void DamagedSupportUsesBaseMaterialCost()
            => Assert.AreEqual(8, BridgeRepairWorkRules.ResourceCost(
                8, TowerStructuralSegmentState.Damaged));

        [Test]
        public void CollapsedSupportCostsTwiceAsMuch()
            => Assert.AreEqual(16, BridgeRepairWorkRules.ResourceCost(
                8, TowerStructuralSegmentState.Collapsed));

        [Test]
        public void IntactSupportHasNoRepairMaterialCost()
            => Assert.AreEqual(0, BridgeRepairWorkRules.ResourceCost(
                8, TowerStructuralSegmentState.Intact));

        [Test]
        public void CollapsedSupportGetsBaseRestoreAndBonus()
            => Assert.AreEqual(65, BridgeRepairWorkRules.RestoreAmount(
                TowerStructuralSegmentState.Collapsed, 40, 25));

        [Test]
        public void DamagedSupportGetsBaseRestoreOnly()
            => Assert.AreEqual(40, BridgeRepairWorkRules.RestoreAmount(
                TowerStructuralSegmentState.Damaged, 40, 25));

        [Test]
        public void IntactSupportGetsNoRestore()
            => Assert.AreEqual(0, BridgeRepairWorkRules.RestoreAmount(
                TowerStructuralSegmentState.Intact, 40, 25));

        [Test]
        public void NegativeRestoreTuningIsClamped()
            => Assert.AreEqual(0, BridgeRepairWorkRules.RestoreAmount(
                TowerStructuralSegmentState.Collapsed, -10, -5));
    }
}
