using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public class VS88BridgeEnemyAccessTests
    {
        [Test]
        public void EnemySpawnOutsideBridgeZoneIsAllowed()
        {
            Assert.IsTrue(MonsterBridgeAccessRules.CanSpawnAt(false));
        }

        [Test]
        public void EnemySpawnInsideBridgeZoneIsAlwaysRejected()
        {
            Assert.IsFalse(MonsterBridgeAccessRules.CanSpawnAt(true));
        }

        [Test]
        public void MissingBridgeCannotBeEnteredEvenAfterPassingTowerGate()
        {
            Assert.IsFalse(MonsterBridgeAccessRules.CanEnterBridge(false, true));
        }

        [Test]
        public void CollapsedOrUnconfiguredBridgeCannotBeEntered()
        {
            Assert.IsFalse(MonsterBridgeAccessRules.CanEnterBridge(false, true));
        }

        [Test]
        public void ExistingBridgeStillRequiresTowerGateway()
        {
            Assert.IsFalse(MonsterBridgeAccessRules.CanEnterBridge(true, false));
        }

        [Test]
        public void ExistingBridgeAndPassedTowerGatewayAllowEntry()
        {
            Assert.IsTrue(MonsterBridgeAccessRules.CanEnterBridge(true, true));
        }

        [Test]
        public void BridgeAccessCannotBeGrantedBySpawnLocationAlone()
        {
            Assert.IsFalse(MonsterBridgeAccessRules.CanEnterBridge(true, false));
        }

        [Test]
        public void DestroyedBridgeBlocksPreviouslyUnauthorizedApproach()
        {
            Assert.IsFalse(MonsterBridgeAccessRules.CanEnterBridge(false, false));
        }
    }
}
