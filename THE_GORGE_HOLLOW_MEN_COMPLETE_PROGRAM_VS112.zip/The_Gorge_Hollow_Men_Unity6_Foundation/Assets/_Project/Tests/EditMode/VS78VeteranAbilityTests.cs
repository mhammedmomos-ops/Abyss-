using System.Collections.Generic;
using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS78VeteranAbilityTests
    {
        [Test]
        public void VeteranThresholdsAreOrderedAboveTheFirstTier()
        {
            Assert.Greater(AnimalExperienceRules.XpForSteadyPost, AnimalExperienceRules.XpForSeasoned);
            Assert.Less(AnimalExperienceRules.XpForSteadyPost, AnimalExperienceRules.XpForBondedVoice);
            Assert.Less(AnimalExperienceRules.XpForBondedVoice, AnimalExperienceRules.XpForSharpEye);
        }

        [Test]
        public void VeteranAbilitiesUnlockInOrderAndOnlyOnce()
        {
            var learned = new List<string>();
            var all = AnimalExperienceRules.EvaluateNewUnlocks(AnimalExperienceRules.XpForSharpEye, learned);
            Assert.AreEqual(6, all.Count);
            Assert.AreEqual(AnimalExperienceRules.AbilitySteadyPost, all[3]);
            Assert.AreEqual(AnimalExperienceRules.AbilityBondedVoice, all[4]);
            Assert.AreEqual(AnimalExperienceRules.AbilitySharpEye, all[5]);
            Assert.AreEqual(0, AnimalExperienceRules.EvaluateNewUnlocks(int.MaxValue, learned).Count);
        }

        [Test]
        public void FirstTierExperienceDoesNotGrantVeteranAbilities()
        {
            var learned = new List<string>();
            AnimalExperienceRules.EvaluateNewUnlocks(AnimalExperienceRules.XpForSeasoned, learned);
            Assert.AreEqual(3, learned.Count);
            Assert.IsFalse(AnimalExperienceRules.HasAbility(learned, AnimalExperienceRules.AbilitySteadyPost));
        }

        [Test]
        public void SteadyPostExtendsGuardDetectionOnlyWhileGuarding()
        {
            var none = new List<string>();
            var steady = new List<string> { AnimalExperienceRules.AbilitySteadyPost };
            float baseline = AnimalGuardPostRules.DetectionRadiusWhileGuarding(10f, true, none);
            float boosted = AnimalGuardPostRules.DetectionRadiusWhileGuarding(10f, true, steady);
            Assert.AreEqual(AnimalGuardPostRules.DetectionRadiusWhileGuarding(10f, true), baseline, 0.0001f);
            Assert.AreEqual(baseline * AnimalExperienceRules.SteadyPostGuardDetectionMultiplier, boosted, 0.0001f);
            Assert.AreEqual(10f, AnimalGuardPostRules.DetectionRadiusWhileGuarding(10f, false, steady), 0.0001f);
            Assert.AreEqual(0f, AnimalGuardPostRules.DetectionRadiusWhileGuarding(0f, true, steady), 0.0001f);
            Assert.AreEqual(baseline, AnimalGuardPostRules.DetectionRadiusWhileGuarding(10f, true, null), 0.0001f);
        }

        [Test]
        public void BondedVoiceShortensResonanceCooldown()
        {
            var voice = new List<string> { AnimalExperienceRules.AbilityBondedVoice };
            float normal = AnimalBondResonanceRules.CooldownEndsAt(100f, new List<string>());
            float shortened = AnimalBondResonanceRules.CooldownEndsAt(100f, voice);
            Assert.AreEqual(AnimalBondResonanceRules.CooldownEndsAt(100f), normal, 0.0001f);
            Assert.Less(shortened, normal);
            Assert.AreEqual(100f + AnimalSpeciesTactics.BondResonanceCooldownSeconds *
                AnimalExperienceRules.BondedVoiceCooldownMultiplier, shortened, 0.0001f);
            Assert.AreEqual(normal, AnimalBondResonanceRules.CooldownEndsAt(100f, null), 0.0001f);
        }

        [Test]
        public void SharpEyeShortensCalloutCooldown()
        {
            var eye = new List<string> { AnimalExperienceRules.AbilitySharpEye };
            float normal = AnimalWeakPointCalloutRules.CooldownEndsAt(50f, new List<string>());
            float shortened = AnimalWeakPointCalloutRules.CooldownEndsAt(50f, eye);
            Assert.AreEqual(AnimalWeakPointCalloutRules.CooldownEndsAt(50f), normal, 0.0001f);
            Assert.Less(shortened, normal);
            Assert.Greater(shortened, 50f);
        }

        [Test]
        public void MultipliersAreNeutralWithoutTheAbility()
        {
            Assert.AreEqual(1f, AnimalExperienceRules.GuardDetectionMultiplier(null), 0.0001f);
            Assert.AreEqual(1f, AnimalExperienceRules.ResonanceCooldownMultiplier(new List<string>()), 0.0001f);
            Assert.AreEqual(1f, AnimalExperienceRules.CalloutCooldownMultiplier(new List<string> { "keen_sense" }), 0.0001f);
            Assert.Greater(AnimalExperienceRules.SteadyPostGuardDetectionMultiplier, 1f);
            Assert.Less(AnimalExperienceRules.BondedVoiceCooldownMultiplier, 1f);
            Assert.Greater(AnimalExperienceRules.BondedVoiceCooldownMultiplier, 0f);
            Assert.Less(AnimalExperienceRules.SharpEyeCooldownMultiplier, 1f);
            Assert.Greater(AnimalExperienceRules.SharpEyeCooldownMultiplier, 0f);
        }

        [Test]
        public void VeteranToastsAreNamedAndNonEmpty()
        {
            Assert.IsTrue(AnimalExperienceRules.FormatUnlockToast(AnimalExperienceRules.AbilitySteadyPost, "Rex").Contains("Rex"));
            Assert.IsTrue(AnimalExperienceRules.FormatUnlockToast(AnimalExperienceRules.AbilityBondedVoice, "Kite").Contains("Kite"));
            Assert.IsFalse(string.IsNullOrWhiteSpace(
                AnimalExperienceRules.FormatUnlockToast(AnimalExperienceRules.AbilitySharpEye, null)));
        }
    }
}
