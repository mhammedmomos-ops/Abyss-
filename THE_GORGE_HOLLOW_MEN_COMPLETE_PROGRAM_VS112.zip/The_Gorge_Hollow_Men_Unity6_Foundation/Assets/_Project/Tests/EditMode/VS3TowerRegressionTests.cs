using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS3TowerRegressionTests
    {
        [Test]
        public void NewTowerPersistsAndDamageDoesNotResetOnRebind()
        {
            var campaign = new CampaignState();
            var service = new TowerMaintenanceService(new ResourceTransactionService());
            var first = service.GetOrCreate(campaign, "gate_a", "tower_a", "North Gate", 200);
            Assert.IsTrue(service.TryDamage(campaign, "gate_a", 75, "crawler", out int applied));
            Assert.AreEqual(75, applied);
            var rebound = service.GetOrCreate(campaign, "gate_a", "tower_a", "North Gate", 200);
            Assert.AreSame(first, rebound);
            Assert.AreEqual(125, rebound.currentHealth);
        }

        [Test]
        public void RepairChargesResourcesAndClampsToMaximum()
        {
            var campaign = new CampaignState { scrap = 20, timber = 10 };
            var service = new TowerMaintenanceService(new ResourceTransactionService());
            service.GetOrCreate(campaign, "wall", "tower_b", "Wall", 100);
            service.TryDamage(campaign, "wall", 90, "test", out _);
            Assert.IsTrue(service.TryRepair(campaign, "wall", 50,
                new ResourceDelta { scrap = -5, timber = -2 }, "repair-1", out int repaired, out string error), error);
            Assert.AreEqual(50, repaired);
            Assert.AreEqual(60, campaign.towerStructures[0].currentHealth);
            Assert.AreEqual(15, campaign.scrap);
            Assert.AreEqual(8, campaign.timber);
        }

        [Test]
        public void FailedRepairDoesNotChangeHealthOrSpendResources()
        {
            var campaign = new CampaignState { scrap = 1, timber = 1 };
            var service = new TowerMaintenanceService(new ResourceTransactionService());
            service.GetOrCreate(campaign, "wall", "tower_b", "Wall", 100);
            service.TryDamage(campaign, "wall", 40, "test", out _);
            Assert.IsFalse(service.TryRepair(campaign, "wall", 20,
                new ResourceDelta { scrap = -5 }, "repair-fail", out _, out _));
            Assert.AreEqual(60, campaign.towerStructures[0].currentHealth);
            Assert.AreEqual(1, campaign.scrap);
        }

        [Test]
        public void CampaignValidationRejectsDuplicateOrImpossibleTowerRecords()
        {
            var campaign = new CampaignState();
            campaign.towerStructures.Add(new TowerStructureRecord { identity = "x", towerId = "a", maxHealth = 10, currentHealth = 11 });
            Assert.IsFalse(campaign.IsValid(out _));
        }

        [Test]
        public void DestroyedStructureCanBeRepairedAndRestored()
        {
            var campaign = new CampaignState { scrap = 10, timber = 10 };
            var service = new TowerMaintenanceService(new ResourceTransactionService());
            service.GetOrCreate(campaign, "door", "tower_a", "Door", 30);
            Assert.IsTrue(service.TryDamage(campaign, "door", 99, "siege", out _));
            Assert.IsTrue(campaign.towerStructures[0].isDestroyed);
            Assert.IsTrue(service.TryRepair(campaign, "door", 10,
                new ResourceDelta { scrap = -1 }, "restore-1", out _, out string error), error);
            Assert.IsFalse(campaign.towerStructures[0].isDestroyed);
        }
    }
}
