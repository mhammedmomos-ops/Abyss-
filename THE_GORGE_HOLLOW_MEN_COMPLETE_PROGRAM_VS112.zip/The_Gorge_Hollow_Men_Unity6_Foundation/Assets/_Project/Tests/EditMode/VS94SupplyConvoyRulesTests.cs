using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS94SupplyConvoyRulesTests
    {
        private static SupplyConvoyRecord CreateConvoy() => new SupplyConvoyRecord
        { identity = "convoy-test-01", destinationTowerId = "tower_a", status = SupplyConvoyStatus.Travelling,
          worldPosition = new Vector3(1f, 2f, 3f), currentHealth = 100, maximumHealth = 100,
          scrap = 12, timber = 8, mechanicalParts = 2, ammunition = 10 };

        [Test] public void NewConvoyRequiresIdentityDestinationAndCargo()
            => Assert.IsTrue(SupplyConvoyRules.IsValidNewConvoy(CreateConvoy()));

        [Test] public void EmptyCargoCannotCreateConvoy()
        { var convoy = CreateConvoy(); convoy.scrap = convoy.timber = convoy.mechanicalParts = convoy.ammunition = 0;
          Assert.IsFalse(SupplyConvoyRules.IsValidNewConvoy(convoy)); }

        [Test] public void DamageReducesPersistentHealthWithoutDestroyingEarly()
        { var convoy = CreateConvoy(); Assert.IsTrue(SupplyConvoyRules.TryApplyDamage(convoy, 25f, out bool destroyed));
          Assert.IsFalse(destroyed); Assert.AreEqual(75, convoy.currentHealth); }

        [Test] public void LethalDamageDestroysConvoyAndLosesAllCargo()
        { var convoy = CreateConvoy(); Assert.IsTrue(SupplyConvoyRules.TryApplyDamage(convoy, 1000f, out bool destroyed));
          Assert.IsTrue(destroyed); Assert.AreEqual(SupplyConvoyStatus.Destroyed, convoy.status);
          Assert.AreEqual(0, convoy.currentHealth); Assert.IsTrue(SupplyConvoyRules.HasNoCargo(convoy)); }

        [Test] public void DeliveredConvoyAddsCargoAndClearsManifest()
        { var campaign = CampaignStateFactory.CreateNew(); var convoy = CreateConvoy();
          Assert.IsTrue(SupplyConvoyRules.TryDeliver(campaign, convoy, out string error), error);
          var depot = TowerDepotRules.Find(campaign, "tower_a");
          Assert.AreEqual(12, depot.scrap); Assert.AreEqual(8, depot.timber);
          Assert.AreEqual(2, depot.mechanicalParts); Assert.AreEqual(10, depot.ammunition);
          Assert.AreEqual(0, campaign.scrap);
          Assert.AreEqual(SupplyConvoyStatus.Delivered, convoy.status); Assert.IsTrue(SupplyConvoyRules.HasNoCargo(convoy)); }

        [Test] public void DeliveryCannotBeCommittedTwice()
        { var campaign = CampaignStateFactory.CreateNew(); var convoy = CreateConvoy();
          Assert.IsTrue(SupplyConvoyRules.TryDeliver(campaign, convoy, out _));
          Assert.IsFalse(SupplyConvoyRules.TryDeliver(campaign, convoy, out _)); Assert.AreEqual(12, TowerDepotRules.Find(campaign, "tower_a").scrap); }

        [Test] public void OverflowPreventsPartialDelivery()
        { var campaign = CampaignStateFactory.CreateNew(); TowerDepotRules.Find(campaign, "tower_a").scrap = int.MaxValue; var convoy = CreateConvoy();
          Assert.IsFalse(SupplyConvoyRules.TryDeliver(campaign, convoy, out _));
          Assert.AreEqual(int.MaxValue, TowerDepotRules.Find(campaign, "tower_a").scrap); Assert.AreEqual(SupplyConvoyStatus.Travelling, convoy.status); }

        [Test] public void DestroyedConvoyCannotReceiveMoreDamage()
        { var convoy = CreateConvoy(); SupplyConvoyRules.TryApplyDamage(convoy, 100f, out _);
          Assert.IsFalse(SupplyConvoyRules.TryApplyDamage(convoy, 10f, out _)); }

        [Test] public void InvalidPositionIsRejected()
        { var convoy = CreateConvoy(); convoy.worldPosition = new Vector3(float.NaN, 0f, 0f);
          Assert.IsFalse(SupplyConvoyRules.IsValidNewConvoy(convoy)); }

        [Test] public void NewCampaignInitializesConvoyManifest()
        { var campaign = CampaignStateFactory.CreateNew(); Assert.NotNull(campaign.supplyConvoys); }
    }
}
