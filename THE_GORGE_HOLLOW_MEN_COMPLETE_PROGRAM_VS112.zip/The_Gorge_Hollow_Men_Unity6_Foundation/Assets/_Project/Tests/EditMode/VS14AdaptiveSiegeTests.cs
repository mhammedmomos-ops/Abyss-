using System.IO;
using NUnit.Framework;
using UnityEngine;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS14AdaptiveSiegeTests
    {
        [Test]
        public void IneffectiveObservedSiegeMakesTargetLessAttractive()
        {
            float efficient = MonsterTargetScoring.Calculate(25f, 0.5f, 1f, 0.8f, 1f);
            float resistant = MonsterTargetScoring.Calculate(25f, 0.5f, 1f, 0.8f, 0.1f);
            Assert.Greater(resistant, efficient);
        }

        [Test]
        public void NestKeepsBoundedUniqueSiegeObservations()
        {
            GameObject host = new GameObject("nest_vs14_test");
            try
            {
                MonsterNest nest = host.AddComponent<MonsterNest>();
                Assert.IsTrue(nest.RecordSiegeObservation("gate_a", 0.25f));
                Assert.IsTrue(nest.RecordSiegeObservation("gate_a", 0.75f));
                Assert.IsTrue(nest.TryGetLearnedSiegeEfficiency("gate_a", out float efficiency));
                Assert.Greater(efficiency, 0.25f);
                for (int i = 0; i < 12; i++) nest.RecordSiegeObservation("structure_" + i, 0.5f);
                Assert.AreEqual(MonsterNest.MaximumPersistedSiegeTargets, nest.LearnedSiegeTargetCount);
                Assert.AreEqual(MonsterNest.MaximumPersistedSiegeTargets, nest.Capture().learnedSiegeTargets.Count);
            }
            finally { Object.DestroyImmediate(host); }
        }

        [Test]
        public void NestRestoresSiegeObservations()
        {
            GameObject host = new GameObject("nest_vs14_restore_test");
            try
            {
                MonsterNest nest = host.AddComponent<MonsterNest>();
                nest.RecordSiegeObservation("generator_a", 0.4f);
                MonsterNestRecord saved = nest.Capture();
                nest.Restore(saved);
                Assert.IsTrue(nest.TryGetLearnedSiegeEfficiency("generator_a", out float efficiency));
                Assert.AreEqual(0.4f, efficiency, 0.001f);
            }
            finally { Object.DestroyImmediate(host); }
        }

        [Test]
        public void CampaignRejectsInvalidSiegeObservation()
        {
            var campaign = new CampaignState();
            campaign.monsterNests.Add(new MonsterNestRecord
            {
                identity = "nest_a",
                learnedSiegeTargets = new System.Collections.Generic.List<MonsterSiegeObservationRecord>
                { new MonsterSiegeObservationRecord { structureIdentity = "gate_a", averageDamageEfficiency = 1.5f, observationCount = 1 } }
            });
            Assert.IsFalse(campaign.IsValid(out string reason));
            StringAssert.Contains("learned-siege", reason);
        }

        [Test]
        public void SaveLoaderMigratesVersionThreeNestRecords()
        {
            string directory = Path.Combine(Path.GetTempPath(), "GorgeHollow_VS14_" + System.Guid.NewGuid().ToString("N"));
            try
            {
                Directory.CreateDirectory(directory);
                var oldState = new CampaignState { saveVersion = 3 };
                oldState.monsterNests.Add(new MonsterNestRecord { identity = "nest_v3", maxHealth = 250, currentHealth = 101, alarmCount = 2 });
                string json = JsonUtility.ToJson(oldState).Replace(",\"learnedSiegeTargets\":[]", string.Empty);
                File.WriteAllText(Path.Combine(directory, "campaign_save.json"), json);
                CampaignState loaded = new CampaignSaveService(directory).Load(out string error);
                Assert.IsNotNull(loaded, error);
                Assert.AreEqual(CampaignSaveService.CurrentSaveVersion, loaded.saveVersion);
                Assert.AreEqual(101, loaded.monsterNests[0].currentHealth);
                Assert.IsNotNull(loaded.monsterNests[0].learnedSiegeTargets);
                Assert.AreEqual(0, loaded.monsterNests[0].learnedSiegeTargets.Count);
            }
            finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        }

        [Test]
        public void RoleStructureBiasIsDeterministicAndDistinct()
        {
            Assert.Less(MonsterTargetScoring.GetRoleStructureBias(MonsterArchetypeRole.Brute, TowerStructureKind.ReinforcedBarricade),
                MonsterTargetScoring.GetRoleStructureBias(MonsterArchetypeRole.Skirmisher, TowerStructureKind.ReinforcedBarricade));
            Assert.Less(MonsterTargetScoring.GetRoleStructureBias(MonsterArchetypeRole.Skirmisher, TowerStructureKind.Generator), 1f);
        }
    }
}
