using NUnit.Framework;
using System.Collections.Generic;

namespace GorgeHollow.Tests
{
    public sealed class VS62CompanionStarvationAndForagingTests
    {
        private static AnimalRecord Pet(AnimalStatus status = AnimalStatus.Alive)
        {
            return new AnimalRecord
            {
                identity = "vs62-pet-identity", displayName = "Miso", species = AnimalSpecies.Cat,
                lifeStage = AnimalLifeStage.Adult, status = status,
                health = status == AnimalStatus.Dead ? 0 : 80, stamina = 65, hunger = 0, bond = 12
            };
        }

        [Test]
        public void ZeroHungerPetCannotRestOrReceiveTreatmentButCanBeFed()
        {
            AnimalRecord pet = Pet();
            int food = 1;
            int medical = 2;
            Assert.IsFalse(AnimalCareRules.CanOperate(pet));
            Assert.IsFalse(AnimalCareRules.CanForage(pet));
            Assert.IsFalse(AnimalCareRules.CanRest(pet, true));
            Assert.IsFalse(AnimalCareRules.CanTreat(pet, medical));
            Assert.IsTrue(AnimalCareRules.CanFeed(pet, food));
            Assert.IsTrue(AnimalCareRules.TryFeed(pet, ref food));
            Assert.AreEqual(60, pet.hunger);
            Assert.AreEqual(0, food);
            Assert.IsTrue(AnimalCareRules.CanOperate(pet));
            Assert.IsTrue(AnimalCareRules.CanForage(pet));
        }

        [Test]
        public void StarvationDoesNotKillPetOrEraseItsSavedIdentity()
        {
            AnimalRecord pet = Pet();
            Assert.AreEqual(AnimalStatus.Alive, pet.status);
            Assert.AreEqual("vs62-pet-identity", pet.identity);
            Assert.AreEqual(80, pet.health);
            Assert.AreEqual(0, pet.hunger);
        }

        [Test]
        public void MissingPetRecoveryRestoresAliveStatusWithDiscoveryHungerRoll()
        {
            AnimalRecord pet = Pet(AnimalStatus.Missing);
            pet.hunger = 0;
            Assert.IsTrue(AnimalCareRules.TryRecoverMissing(pet, 47));
            Assert.AreEqual(AnimalStatus.Alive, pet.status);
            Assert.AreEqual(47, pet.hunger);
            Assert.AreEqual(80, pet.health);
        }

        [TestCase(20)]
        [TestCase(85)]
        public void MissingPetRecoveryAcceptsTheDocumentedRandomHungerBounds(int hunger)
        {
            AnimalRecord pet = Pet(AnimalStatus.Missing);
            Assert.IsTrue(AnimalCareRules.TryRecoverMissing(pet, hunger));
            Assert.That(pet.hunger, Is.InRange(20, 85));
        }

        [Test]
        public void DeadPetCannotBeMarkedMissingOrRecovered()
        {
            AnimalRecord pet = Pet(AnimalStatus.Dead);
            Assert.IsFalse(AnimalCareRules.TryMarkMissing(pet));
            Assert.IsFalse(AnimalCareRules.TryRecoverMissing(pet, 55));
            Assert.AreEqual(AnimalStatus.Dead, pet.status);
        }

        [Test]
        public void LivingPetCanBecomeMissingButCannotBeFedUntilRecovered()
        {
            AnimalRecord pet = Pet();
            pet.hunger = 50;
            int food = 2;
            Assert.IsTrue(AnimalCareRules.TryMarkMissing(pet));
            Assert.IsFalse(AnimalCareRules.TryFeed(pet, ref food));
            Assert.AreEqual(2, food);
            Assert.IsTrue(AnimalCareRules.TryRecoverMissing(pet, 36));
            Assert.IsTrue(AnimalCareRules.TryFeed(pet, ref food));
            Assert.AreEqual(96, pet.hunger);
        }

        [Test]
        public void RecoveredPetCanBeSelectedAgainWithoutCreatingAnotherSpeciesRecord()
        {
            var roster = new List<AnimalRecord>();
            AnimalRecord pet = Pet(AnimalStatus.Missing);
            pet.hunger = 33;
            roster.Add(pet);
            Assert.IsTrue(AnimalCareRules.TryRecoverMissing(pet, 61));
            Assert.IsTrue(AnimalSelectionRules.TrySelectOrCreate(roster, "Miso Returned", AnimalSpecies.Cat,
                out AnimalRecord selected, out string error), error);
            Assert.AreSame(pet, selected);
            Assert.AreEqual(1, roster.Count);
            Assert.AreEqual("Miso Returned", selected.displayName);
            Assert.AreEqual(61, selected.hunger);
        }

        [Test]
        public void ForageSourceCanBeHarvestedOnlyOncePerFictionalDay()
        {
            var flags = new List<string>();
            Assert.IsTrue(AnimalForageRules.IsAvailable(flags, "forest-edge-a", 4));
            Assert.IsTrue(AnimalForageRules.TryMarkHarvested(flags, "forest-edge-a", 4));
            Assert.IsFalse(AnimalForageRules.IsAvailable(flags, "forest-edge-a", 4));
            Assert.IsFalse(AnimalForageRules.TryMarkHarvested(flags, "forest-edge-a", 4));
            Assert.IsTrue(AnimalForageRules.IsAvailable(flags, "forest-edge-a", 5));
        }

        [Test]
        public void ForageSourcesRequireStableIdsAndValidCampaignDay()
        {
            var flags = new List<string>();
            Assert.IsFalse(AnimalForageRules.IsAvailable(flags, "", 1));
            Assert.IsFalse(AnimalForageRules.TryMarkHarvested(flags, "source", 0));
            Assert.AreEqual(0, flags.Count);
        }
    }
}
