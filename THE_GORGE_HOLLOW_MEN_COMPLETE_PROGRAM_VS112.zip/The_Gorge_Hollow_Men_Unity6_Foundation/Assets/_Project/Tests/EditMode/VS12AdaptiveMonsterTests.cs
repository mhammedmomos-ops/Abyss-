using NUnit.Framework;
using UnityEngine;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS12AdaptiveMonsterTests
    {
        [Test]
        public void MonsterRemembersVisibleTrapAsHazard()
        {
            var memory = new MonsterLearningMemory();
            memory.RecordHazard("trap_a", new Vector3(5f, 0f, 0f), 2f, 1f, 10f);
            Assert.AreEqual(1, memory.LearnedHazardCount);
            Assert.IsTrue(memory.TryGetBlockingHazard(Vector3.zero, new Vector3(10f, 0f, 0f), out LearnedHazard hazard));
            Assert.AreEqual("trap_a", hazard.Identity);
        }

        [Test]
        public void RepeatedObservationUpdatesSameHazardInsteadOfDuplicatingIt()
        {
            var memory = new MonsterLearningMemory();
            memory.RecordHazard("trap_a", Vector3.zero, 1f, 1f, 1f);
            memory.RecordHazard("trap_a", Vector3.right, 2f, 2f, 2f);
            Assert.AreEqual(1, memory.LearnedHazardCount);
            Assert.IsTrue(memory.TryGetBlockingHazard(Vector3.zero, Vector3.right * 2f, out LearnedHazard hazard));
            Assert.AreEqual(Vector3.right, hazard.Position);
            Assert.AreEqual(2f, hazard.AvoidanceRadius);
        }

        [Test]
        public void HazardMemoryIsBoundedAndClearable()
        {
            var memory = new MonsterLearningMemory();
            for (int i = 0; i < 20; i++)
                memory.RecordHazard("trap_" + i, new Vector3(i, 0f, 0f), 1f, 1f, i);
            Assert.AreEqual(8, memory.LearnedHazardCount);
            memory.Clear();
            Assert.AreEqual(0, memory.LearnedHazardCount);
        }

        [Test]
        public void DamagedStructuresBecomeMoreAttractiveSiegeTargets()
        {
            float healthy = MonsterTargetScoring.Calculate(100f, 1f, 1f, 0.85f);
            float damaged = MonsterTargetScoring.Calculate(100f, 0.2f, 1f, 0.85f);
            Assert.Less(damaged, healthy);
        }

        [Test]
        public void AuthoredSiegePriorityCanOutweighDistance()
        {
            float ordinary = MonsterTargetScoring.Calculate(100f, 1f, 1f, 0.4f);
            float critical = MonsterTargetScoring.Calculate(100f, 1f, 2f, 0.4f);
            Assert.Less(critical, ordinary);
        }

        [Test]
        public void InvalidDistanceCannotWinTargetSelection()
        {
            Assert.IsTrue(float.IsPositiveInfinity(MonsterTargetScoring.Calculate(float.NaN, 1f, 1f, 0.5f)));
            Assert.IsTrue(float.IsPositiveInfinity(MonsterTargetScoring.Calculate(-1f, 1f, 1f, 0.5f)));
        }
    }
}
