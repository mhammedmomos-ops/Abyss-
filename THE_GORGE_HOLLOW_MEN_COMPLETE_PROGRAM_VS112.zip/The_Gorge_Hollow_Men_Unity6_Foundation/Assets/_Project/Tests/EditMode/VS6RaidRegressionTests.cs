using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS6RaidRegressionTests
    {
        [Test]
        public void RaidRequestRejectsZeroThreatBudget()
        {
            var request = new MonsterRaidRequest { ThreatBudget = 0, MaximumSpawnCount = 2 };
            Assert.IsFalse(request.IsValid(out string reason));
            StringAssert.Contains("Threat budget", reason);
        }

        [Test]
        public void RaidRequestRejectsZeroSpawnLimit()
        {
            var request = new MonsterRaidRequest { ThreatBudget = 4, MaximumSpawnCount = 0 };
            Assert.IsFalse(request.IsValid(out string reason));
            StringAssert.Contains("Maximum spawn count", reason);
        }

        [Test]
        public void RaidRequestRejectsInvalidDistanceAndNonFinitePositions()
        {
            var request = new MonsterRaidRequest { ThreatBudget = 4, MaximumSpawnCount = 2, MinimumPlayerDistance = -1f };
            Assert.IsFalse(request.IsValid(out _));
            request.MinimumPlayerDistance = 5f;
            request.TargetPosition = new Vector3(float.NaN, 0f, 0f);
            Assert.IsFalse(request.IsValid(out _));
        }

        [Test]
        public void ValidRaidRequestAcceptsEventDrivenParameters()
        {
            var request = new MonsterRaidRequest
            {
                ThreatBudget = 8, MaximumSpawnCount = 4, MinimumPlayerDistance = 20f,
                PlayerPosition = Vector3.zero, TargetPosition = new Vector3(40f, 0f, 0f), RandomSeed = 1234
            };
            Assert.IsTrue(request.IsValid(out string reason), reason);
        }

        [Test]
        public void ArchetypeRequiresPrefabAndPositiveThreatCost()
        {
            var definition = ScriptableObject.CreateInstance<MonsterArchetypeDefinition>();
            try
            {
                Assert.IsFalse(definition.IsValid(out _));
                definition.prefab = new GameObject("TestMonster");
                definition.threatCost = 0;
                Assert.IsFalse(definition.IsValid(out _));
            }
            finally
            {
                if (definition.prefab != null) Object.DestroyImmediate(definition.prefab);
                Object.DestroyImmediate(definition);
            }
        }
    }
}
