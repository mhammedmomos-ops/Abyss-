using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS105WorkerRelationshipTests
    {
        private static TowerWorkerRecord Worker(string id, string tower = "tower_a") => new TowerWorkerRecord
        { identity = id, displayName = id, towerId = tower, role = TowerWorkerRole.Mechanic,
          status = TowerWorkerStatus.Active, assignment = TowerWorkerAssignment.Idle, health = 100 };

        [Test] public void CreatesCanonicalSameTowerRelationshipOnlyOnce()
        {
            CampaignState c = CampaignStateFactory.CreateNew(); c.towerWorkers.Add(Worker("b")); c.towerWorkers.Add(Worker("a"));
            Assert.IsTrue(TowerWorkerRelationshipRules.TryCreate(c, "b", "a", out string reason), reason);
            Assert.AreEqual("a", c.workerRelationships[0].workerAId); Assert.AreEqual("b", c.workerRelationships[0].workerBId);
            Assert.IsFalse(TowerWorkerRelationshipRules.TryCreate(c, "a", "b", out reason));
            Assert.AreEqual(1, c.workerRelationships.Count);
        }

        [Test] public void RejectsCrossTowerAndSelfRelationships()
        {
            CampaignState c = CampaignStateFactory.CreateNew(); c.towerWorkers.Add(Worker("a")); c.towerWorkers.Add(Worker("b", "tower_b"));
            Assert.IsFalse(TowerWorkerRelationshipRules.TryCreate(c, "a", "a", out _));
            Assert.IsFalse(TowerWorkerRelationshipRules.TryCreate(c, "a", "b", out _));
            Assert.AreEqual(0, c.workerRelationships.Count);
        }

        [Test] public void SocialInteractionsAreBoundedAndDeterministic()
        {
            CampaignState c = CampaignStateFactory.CreateNew(); c.towerWorkers.Add(Worker("a")); c.towerWorkers.Add(Worker("b"));
            Assert.IsTrue(TowerWorkerRelationshipRules.TryCreate(c, "a", "b", out _));
            var r = c.workerRelationships[0];
            Assert.IsTrue(TowerWorkerRelationshipRules.ApplyInteraction(c, "b", "a", WorkerSocialInteraction.ProtectedTogether));
            Assert.AreEqual(15, r.bond); Assert.AreEqual(0, r.friction); Assert.AreEqual(1, r.interactionCount);
            r.bond = 99; r.friction = 99;
            TowerWorkerRelationshipRules.ApplyInteraction(c, "a", "b", WorkerSocialInteraction.ProtectedTogether);
            Assert.AreEqual(100, r.bond); Assert.AreEqual(96, r.friction);
        }

        [Test] public void RelationshipReadinessBonusIsBoundedAndCannotBecomePenalty()
        {
            Assert.AreEqual(0, TowerWorkerRelationshipRules.GetCooperationReadinessBonus(null));
            Assert.AreEqual(0, TowerWorkerRelationshipRules.GetCooperationReadinessBonus(new TowerWorkerRelationshipRecord { bond = 0, friction = 100 }));
            Assert.AreEqual(10, TowerWorkerRelationshipRules.GetCooperationReadinessBonus(new TowerWorkerRelationshipRecord { bond = 100, friction = 0 }));
        }

        [Test] public void CampaignValidationRejectsUnknownOrCrossTowerRelationship()
        {
            CampaignState c = CampaignStateFactory.CreateNew(); c.towerWorkers.Add(Worker("a")); c.towerWorkers.Add(Worker("b"));
            Assert.IsTrue(TowerWorkerRelationshipRules.TryCreate(c, "a", "b", out _));
            Assert.IsTrue(c.IsValid(out string reason), reason);
            c.workerRelationships[0].workerBId = "missing";
            Assert.IsFalse(c.IsValid(out reason));
        }

        [Test] public void VersionThirteenSaveMigratesWithoutChangingWorkerProgress()
        {
            string dir = Path.Combine(Application.temporaryCachePath, "vs105_migration_" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            try
            {
                CampaignState old = CampaignStateFactory.CreateNew(); old.saveVersion = 13;
                old.towerWorkers.Add(Worker("legacy"));
                TowerWorkerRecord legacy = TowerWorkerRules.Find(old, "legacy");
                legacy.morale = 42; legacy.loyalty = 33; legacy.stress = 21;
                File.WriteAllText(Path.Combine(dir, "campaign.json"), JsonUtility.ToJson(old));
                CampaignState loaded = new CampaignSaveService(dir, "campaign.json").Load(out string error);
                Assert.IsNotNull(loaded, error); Assert.AreEqual(CampaignSaveService.CurrentSaveVersion, loaded.saveVersion);
                TowerWorkerRecord migrated = TowerWorkerRules.Find(loaded, "legacy");
                Assert.IsNotNull(migrated);
                Assert.AreEqual(42, migrated.morale); Assert.AreEqual(33, migrated.loyalty); Assert.AreEqual(21, migrated.stress);
                Assert.AreEqual(TowerWorkerPersonality.Balanced, migrated.personality);
                Assert.AreEqual(4, loaded.towerWorkers.FindAll(w => w.identity.StartsWith("starter_")).Count);
                Assert.AreEqual(0, loaded.workerRelationships.Count);
            }
            finally { if (Directory.Exists(dir)) Directory.Delete(dir, true); }
        }
    }
}
