using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS74WeakPointCalloutTests
    {
        [Test]
        public void RequiresLivingCompanionConfirmedThreatWeakPointAndCooldownReady()
        {
            Assert.IsTrue(AnimalWeakPointCalloutRules.CanIssueCallout(
                AnimalStatus.Alive, true, 0.7f, true, 10f, 0f));
            Assert.IsFalse(AnimalWeakPointCalloutRules.CanIssueCallout(
                AnimalStatus.Dead, true, 0.7f, true, 10f, 0f));
            Assert.IsFalse(AnimalWeakPointCalloutRules.CanIssueCallout(
                AnimalStatus.Alive, false, 0.7f, true, 10f, 0f));
            Assert.IsFalse(AnimalWeakPointCalloutRules.CanIssueCallout(
                AnimalStatus.Alive, true, 0.4f, true, 10f, 0f));
            Assert.IsFalse(AnimalWeakPointCalloutRules.CanIssueCallout(
                AnimalStatus.Alive, true, 0.7f, false, 10f, 0f));
            Assert.IsFalse(AnimalWeakPointCalloutRules.CanIssueCallout(
                AnimalStatus.Alive, true, 0.7f, true, 10f, 15f));
        }

        [Test]
        public void NullThreatHasNoWeakPoint()
        {
            Assert.IsFalse(AnimalWeakPointCalloutRules.ThreatHasWeakPoint(null));
        }

        [Test]
        public void PlayerDamageBonusAppliesOnlyWhileActive()
        {
            float baseDmg = 20f;
            float boosted = AnimalWeakPointCalloutRules.ApplyPlayerDamageBonus(baseDmg, true);
            Assert.AreEqual(baseDmg * AnimalSpeciesTactics.WeakPointCalloutPlayerDamageMultiplier, boosted, 0.0001f);
            Assert.AreEqual(baseDmg, AnimalWeakPointCalloutRules.ApplyPlayerDamageBonus(baseDmg, false), 0.0001f);
            Assert.AreEqual(0f, AnimalWeakPointCalloutRules.ApplyPlayerDamageBonus(0f, true), 0.0001f);
        }

        [Test]
        public void TimingHelpersAreDeterministic()
        {
            float start = 30f;
            float cool = AnimalWeakPointCalloutRules.CooldownEndsAt(start);
            Assert.AreEqual(start + AnimalSpeciesTactics.WeakPointCalloutCooldownSeconds, cool, 0.001f);
            float bonus = AnimalWeakPointCalloutRules.PlayerBonusEndsAt(start);
            Assert.AreEqual(start + AnimalSpeciesTactics.WeakPointCalloutPlayerDamageBonusSeconds, bonus, 0.001f);
            Assert.IsTrue(AnimalWeakPointCalloutRules.IsPlayerBonusActive(start + 1f, bonus));
            Assert.IsFalse(AnimalWeakPointCalloutRules.IsPlayerBonusActive(bonus + 0.01f, bonus));
        }

        [Test]
        public void StateHolderActivatesAndExpires()
        {
            AnimalWeakPointCalloutState.ClearForTests();
            Assert.IsFalse(AnimalWeakPointCalloutState.IsActive(10f));
            AnimalWeakPointCalloutState.Activate(10f);
            Assert.IsTrue(AnimalWeakPointCalloutState.IsActive(10.5f));
            Assert.IsFalse(AnimalWeakPointCalloutState.IsActive(10f + AnimalSpeciesTactics.WeakPointCalloutPlayerDamageBonusSeconds + 0.1f));
            float modified = AnimalWeakPointCalloutState.ModifyDamage(10f, 10.5f);
            Assert.Greater(modified, 10f);
            AnimalWeakPointCalloutState.ClearForTests();
        }

        [Test]
        public void ToastIsSpeciesFlavored()
        {
            Assert.IsTrue(AnimalWeakPointCalloutRules.FormatToast(AnimalSpecies.GermanShepherd, "Rex").Contains("Rex"));
            Assert.IsTrue(AnimalWeakPointCalloutRules.FormatToast(AnimalSpecies.Falcon, "Sky").Contains("Sky"));
            Assert.IsTrue(AnimalWeakPointCalloutRules.FormatToast(AnimalSpecies.Pangolin, "Shell").Contains("Shell"));
            Assert.IsTrue(AnimalWeakPointCalloutRules.FormatToast(AnimalSpecies.Cat, "Shadow").Contains("Shadow"));
            Assert.IsFalse(string.IsNullOrWhiteSpace(AnimalWeakPointCalloutRules.FormatToast(AnimalSpecies.Cat, null)));
        }
    }
}
