using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS18StructuralSegmentRulesTests
    {
        [Test]
        public void FullHealthIsIntact()
        {
            Assert.AreEqual(TowerStructuralSegmentState.Intact,
                TowerStructuralSegmentRules.Evaluate(100, 100, 0.65f, 0.15f));
        }

        [Test]
        public void DamagedThresholdIsInclusive()
        {
            Assert.AreEqual(TowerStructuralSegmentState.Damaged,
                TowerStructuralSegmentRules.Evaluate(65, 100, 0.65f, 0.15f));
        }

        [Test]
        public void CollapseThresholdIsInclusive()
        {
            Assert.AreEqual(TowerStructuralSegmentState.Collapsed,
                TowerStructuralSegmentRules.Evaluate(15, 100, 0.65f, 0.15f));
        }

        [Test]
        public void DestroyedOrInvalidStructureIsCollapsed()
        {
            Assert.AreEqual(TowerStructuralSegmentState.Collapsed,
                TowerStructuralSegmentRules.Evaluate(0, 100, 0.65f, 0.15f));
            Assert.AreEqual(TowerStructuralSegmentState.Collapsed,
                TowerStructuralSegmentRules.Evaluate(10, 0, 0.65f, 0.15f));
        }

        [Test]
        public void ReversedThresholdsAreNormalized()
        {
            Assert.AreEqual(TowerStructuralSegmentState.Damaged,
                TowerStructuralSegmentRules.Evaluate(50, 100, 0.15f, 0.65f));
            Assert.AreEqual(TowerStructuralSegmentState.Collapsed,
                TowerStructuralSegmentRules.Evaluate(10, 100, 0.15f, 0.65f));
        }

        [Test]
        public void NonFiniteThresholdsUseSafeDefaults()
        {
            Assert.AreEqual(TowerStructuralSegmentState.Damaged,
                TowerStructuralSegmentRules.Evaluate(50, 100, float.NaN, float.PositiveInfinity));
            Assert.AreEqual(TowerStructuralSegmentState.Collapsed,
                TowerStructuralSegmentRules.Evaluate(10, 100, float.NaN, float.PositiveInfinity));
        }

        [Test]
        public void RepairCanRestoreDerivedSectionState()
        {
            Assert.AreEqual(TowerStructuralSegmentState.Collapsed,
                TowerStructuralSegmentRules.Evaluate(10, 100, 0.65f, 0.15f));
            Assert.AreEqual(TowerStructuralSegmentState.Intact,
                TowerStructuralSegmentRules.Evaluate(100, 100, 0.65f, 0.15f));
        }
    }
}
