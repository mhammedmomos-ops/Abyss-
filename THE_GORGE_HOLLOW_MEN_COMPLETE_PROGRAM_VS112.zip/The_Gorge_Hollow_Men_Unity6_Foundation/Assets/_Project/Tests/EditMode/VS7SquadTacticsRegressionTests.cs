using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS7SquadTacticsRegressionTests
    {
        [Test]
        public void SquadRegistrationAssignsStableDistinctSlots()
        {
            var host = new GameObject("Squad");
            var first = new GameObject("First").AddComponent<MonsterAIController>();
            var second = new GameObject("Second").AddComponent<MonsterAIController>();
            try
            {
                var squad = host.AddComponent<MonsterSquadCoordinator>();
                Assert.AreEqual(0, squad.Register(first));
                Assert.AreEqual(1, squad.Register(second));
                Assert.AreEqual(0, squad.Register(first));
                Assert.AreEqual(2, squad.MemberCount);
            }
            finally { Object.DestroyImmediate(first.gameObject); Object.DestroyImmediate(second.gameObject); Object.DestroyImmediate(host); }
        }

        [Test]
        public void FlankSlotsProduceDifferentApproachPositions()
        {
            var host = new GameObject("Squad");
            var member = new GameObject("Member").AddComponent<MonsterAIController>();
            var target = new GameObject("Target");
            try
            {
                var squad = host.AddComponent<MonsterSquadCoordinator>();
                Vector3 a = squad.GetFlankDestination(member, target.transform.position, 0, 3);
                Vector3 b = squad.GetFlankDestination(member, target.transform.position, 1, 3);
                Assert.Greater((a - b).sqrMagnitude, 1f);
            }
            finally { Object.DestroyImmediate(member.gameObject); Object.DestroyImmediate(target); Object.DestroyImmediate(host); }
        }
    }
}
