using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class CampaignFoundationTests
    {
        [Test]
        public void NewCampaignStartsAtNightOne()
        {
            var state = new CampaignState();
            Assert.AreEqual(1, state.night);
            Assert.IsTrue(state.IsValid(out _));
        }

        [Test]
        public void ClockDoesNotAdvanceWithoutExplicitInstruction()
        {
            var state = new CampaignState();
            var clock = new CampaignClock(state);
            Assert.AreEqual(1, state.fictionalDay);
            Assert.AreEqual(0, state.fictionalHour);
            // Construction of the clock must not advance campaign time.
            Assert.AreEqual(1, state.fictionalDay);
            Assert.AreEqual(0, state.fictionalHour);
        }

        [Test]
        public void ResourceTransactionCannotBeAppliedTwice()
        {
            var state = new CampaignState { scrap = 20 };
            var service = new ResourceTransactionService();
            var delta = new ResourceDelta { scrap = -5 };

            Assert.IsTrue(service.TryApply(state, "repair-001", delta, out _));
            Assert.AreEqual(15, state.scrap);
            Assert.IsFalse(service.TryApply(state, "repair-001", delta, out _));
            Assert.AreEqual(15, state.scrap);
        }

        [Test]
        public void InsufficientResourcesDoNotPartiallyApply()
        {
            var state = new CampaignState { scrap = 2, timber = 10 };
            var service = new ResourceTransactionService();
            var delta = new ResourceDelta { scrap = -5, timber = -3 };

            Assert.IsFalse(service.TryApply(state, "build-001", delta, out _));
            Assert.AreEqual(2, state.scrap);
            Assert.AreEqual(10, state.timber);
            Assert.IsFalse(state.appliedTransactionIds.Contains("build-001"));
        }

        [Test]
        public void AnimalDeathIsPermanentInRecord()
        {
            var animal = new AnimalRecord
            {
                identity = "pet-001",
                species = AnimalSpecies.GermanShepherd
            };

            Assert.IsTrue(animal.MarkDead("death-event-001"));
            Assert.AreEqual(AnimalStatus.Dead, animal.status);
            Assert.IsFalse(animal.MarkDead("death-event-002"));
            Assert.AreEqual("death-event-001", animal.deathEventId);
        }


        [Test]
        public void ClockPreservesMinuteRemaindersAcrossCalls()
        {
            var state = new CampaignState();
            var clock = new CampaignClock(state);

            clock.AdvanceFictionalMinutes(40);
            clock.AdvanceFictionalMinutes(35);

            Assert.AreEqual(1, state.fictionalHour);
            Assert.AreEqual(15, state.fictionalMinute);
            Assert.AreEqual(1, state.fictionalDay);
        }

        [Test]
        public void NightProgressionUpdatesChapter()
        {
            var state = new CampaignState { night = 4, chapter = 1 };
            var clock = new CampaignClock(state);
            clock.CompleteNight();

            Assert.AreEqual(5, state.night);
            Assert.AreEqual(2, state.chapter);
        }
    }
}
