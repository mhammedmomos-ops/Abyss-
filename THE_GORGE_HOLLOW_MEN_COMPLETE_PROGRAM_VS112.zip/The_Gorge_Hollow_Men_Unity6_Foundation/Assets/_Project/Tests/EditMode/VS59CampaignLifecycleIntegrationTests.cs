using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS59CampaignLifecycleIntegrationTests
    {
        private int nightEvents;
        private int phaseEvents;

        [SetUp]
        public void SetUp()
        {
            nightEvents = 0;
            phaseEvents = 0;
            CampaignEvents.NightChanged += OnNight;
            CampaignEvents.PhaseChanged += OnPhase;
        }

        [TearDown]
        public void TearDown()
        {
            CampaignEvents.NightChanged -= OnNight;
            CampaignEvents.PhaseChanged -= OnPhase;
        }

        private void OnNight(int _) => nightEvents++;
        private void OnPhase(CampaignPhase _) => phaseEvents++;

        [Test]
        public void DeferredNightCompletionDoesNotPublishBeforeCallerCommitsSave()
        {
            CampaignState state = CampaignStateFactory.CreateNew();
            AnimalRecord pet = new AnimalRecord
            {
                identity = "selected-pet", displayName = "Miso", species = AnimalSpecies.Cat,
                status = AnimalStatus.Alive, health = 100, stamina = 100,
                fictionalAgeDays = 365, lifeStage = AnimalLifeStage.Adult
            };
            state.animals.Add(pet);

            new CampaignClock(state).CompleteNight(false);

            Assert.AreEqual(2, state.night);
            Assert.AreEqual(366, pet.fictionalAgeDays);
            Assert.AreEqual(0, nightEvents);
            Assert.AreEqual(0, phaseEvents);
        }

        [Test]
        public void NormalNightCompletionStillPublishesProgressionEvents()
        {
            CampaignState state = CampaignStateFactory.CreateNew();
            new CampaignClock(state).CompleteNight();
            Assert.AreEqual(1, nightEvents);
            Assert.AreEqual(1, phaseEvents);
        }

        [TestCase(AnimalSpecies.GermanShepherd)]
        [TestCase(AnimalSpecies.Falcon)]
        [TestCase(AnimalSpecies.Pangolin)]
        [TestCase(AnimalSpecies.Cat)]
        public void SeniorStageAppliesReducedMovementAndRecovery(AnimalSpecies species)
        {
            AnimalCompanionProfile adult = AnimalCompanionProfile.For(species, AnimalLifeStage.Adult);
            AnimalCompanionProfile senior = AnimalCompanionProfile.For(species, AnimalLifeStage.Senior);
            Assert.Less(senior.moveSpeed, adult.moveSpeed);
            Assert.Less(senior.staminaRecoveryPerSecond, adult.staminaRecoveryPerSecond);
            Assert.Greater(senior.incomingDamageMultiplier, adult.incomingDamageMultiplier);
        }

        [TestCase(AnimalSpecies.GermanShepherd)]
        [TestCase(AnimalSpecies.Falcon)]
        [TestCase(AnimalSpecies.Pangolin)]
        [TestCase(AnimalSpecies.Cat)]
        public void YoungAndAdolescentStagesAreNotTreatedAsAdult(AnimalSpecies species)
        {
            AnimalCompanionProfile adult = AnimalCompanionProfile.For(species, AnimalLifeStage.Adult);
            AnimalCompanionProfile young = AnimalCompanionProfile.For(species, AnimalLifeStage.Young);
            AnimalCompanionProfile adolescent = AnimalCompanionProfile.For(species, AnimalLifeStage.Adolescent);
            Assert.Less(young.moveSpeed, adolescent.moveSpeed);
            Assert.Less(adolescent.moveSpeed, adult.moveSpeed);
            Assert.Less(young.attackDamage, adult.attackDamage);
        }

        [Test]
        public void CampaignRecordReplacementPreservesSelectedPetsCurrentCommand()
        {
            AnimalRecord original = new AnimalRecord
            {
                identity = "same-pet", displayName = "Miso", species = AnimalSpecies.Cat,
                status = AnimalStatus.Alive, health = 100, stamina = 100
            };
            IAnimalBehaviour behaviour = AnimalBehaviourFactory.Create(AnimalSpecies.Cat);
            behaviour.Initialize(original);
            behaviour.ReceiveCommand(AnimalCommand.Protect);

            AnimalRecord replacement = new AnimalRecord
            {
                identity = "same-pet", displayName = "Miso", species = AnimalSpecies.Cat,
                status = AnimalStatus.Alive, health = 95, stamina = 90
            };
            behaviour.Initialize(replacement);

            Assert.AreEqual(AnimalCommand.Protect, ((AnimalBehaviourBase)behaviour).CurrentCommand);
        }
    }
}
