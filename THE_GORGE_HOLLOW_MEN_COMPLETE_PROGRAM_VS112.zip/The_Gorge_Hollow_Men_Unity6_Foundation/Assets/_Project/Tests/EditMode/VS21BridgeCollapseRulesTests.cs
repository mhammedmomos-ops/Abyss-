using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS21BridgeCollapseRulesTests
    {
        [TestCase(0f, 1f, 0f)]
        [TestCase(0.5f, 1f, 0.5f)]
        [TestCase(2f, 1f, 1f)]
        [TestCase(-1f, 1f, 0f)]
        public void SagProgressIsBounded(float elapsed, float duration, float expected) =>
            Assert.AreEqual(expected, BridgeCollapseRules.EvaluateSagProgress(elapsed, duration), 0.0001f);

        [Test]
        public void NonPositiveDurationCompletesImmediately() =>
            Assert.AreEqual(1f, BridgeCollapseRules.EvaluateSagProgress(0.1f, 0f));

        [Test]
        public void ReleaseScheduleIsStaggered()
        {
            Assert.IsFalse(BridgeCollapseRules.ShouldReleaseSection(0, 0.1f, 0.2f, 0.3f));
            Assert.IsTrue(BridgeCollapseRules.ShouldReleaseSection(0, 0.2f, 0.2f, 0.3f));
            Assert.IsFalse(BridgeCollapseRules.ShouldReleaseSection(1, 0.49f, 0.2f, 0.3f));
            Assert.IsTrue(BridgeCollapseRules.ShouldReleaseSection(1, 0.5f, 0.2f, 0.3f));
            Assert.IsTrue(BridgeCollapseRules.ShouldReleaseSection(2, 0.8f, 0.2f, 0.3f));
        }

        [Test]
        public void InvalidSectionIndexNeverReleases() =>
            Assert.IsFalse(BridgeCollapseRules.ShouldReleaseSection(-1, 10f, 0f, 0f));

        [Test]
        public void NegativeTimingIsClampedToImmediateRelease() =>
            Assert.IsTrue(BridgeCollapseRules.ShouldReleaseSection(0, 0f, -1f, -1f));

        [Test]
        public void InvalidElapsedTimeNeverReleases() =>
            Assert.IsFalse(BridgeCollapseRules.ShouldReleaseSection(0, float.NaN, 0f, 0f));
    }
}
