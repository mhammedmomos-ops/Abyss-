using NUnit.Framework;
using UnityEngine;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS16WeakPointSiegeTests
    {
        [Test]
        public void WeakPointMultiplierIncreasesExpectedDamageAndStillCapsAtHealth()
        {
            int ordinary = MonsterSiegeEffectiveness.ExpectedDamage(10f, 0.2f, 100);
            int weakPoint = MonsterSiegeEffectiveness.ExpectedDamage(10f, 0.2f, 100, 2f);
            int capped = MonsterSiegeEffectiveness.ExpectedDamage(10f, 0f, 7, 4f);
            Assert.AreEqual(8, ordinary);
            Assert.AreEqual(16, weakPoint);
            Assert.AreEqual(7, capped);
        }

        [Test]
        public void InvalidWeakPointMultiplierFallsBackToNeutral()
        {
            int neutral = MonsterSiegeEffectiveness.ExpectedDamage(12f, 0.25f, 100);
            int invalid = MonsterSiegeEffectiveness.ExpectedDamage(12f, 0.25f, 100, float.NaN);
            Assert.AreEqual(neutral, invalid);
        }

        [Test]
        public void ArchetypesPreferTheirRelevantWeakPointKinds()
        {
            Assert.Less(MonsterTargetScoring.GetWeakPointRoleBias(MonsterArchetypeRole.Brute, TowerWeakPointKind.GateHinge),
                MonsterTargetScoring.GetWeakPointRoleBias(MonsterArchetypeRole.Brute, TowerWeakPointKind.PowerCoupling));
            Assert.Less(MonsterTargetScoring.GetWeakPointRoleBias(MonsterArchetypeRole.Skirmisher, TowerWeakPointKind.SignalRelay),
                MonsterTargetScoring.GetWeakPointRoleBias(MonsterArchetypeRole.Skirmisher, TowerWeakPointKind.GateHinge));
            Assert.Less(MonsterTargetScoring.GetWeakPointRoleBias(MonsterArchetypeRole.Lurker, TowerWeakPointKind.CoreVent),
                MonsterTargetScoring.GetWeakPointRoleBias(MonsterArchetypeRole.Lurker, TowerWeakPointKind.PowerCoupling));
        }

        [Test]
        public void WeakPointResolvesItsOwningStructure()
        {
            GameObject structureObject = new GameObject("tower_structure_test");
            GameObject weakPointObject = new GameObject("gate_hinge_test");
            try
            {
                TowerStructure structure = structureObject.AddComponent<TowerStructure>();
                weakPointObject.transform.SetParent(structureObject.transform);
                TowerWeakPoint weakPoint = weakPointObject.AddComponent<TowerWeakPoint>();
                weakPoint.Configure("tower_a_gate_hinge", TowerWeakPointKind.GateHinge, 2f, 1.25f);
                Assert.AreSame(structure, weakPoint.Structure);
                Assert.IsTrue(weakPoint.IsAvailable);
                Assert.AreEqual(2f, weakPoint.DamageMultiplier, 0.001f);
            }
            finally
            {
                Object.DestroyImmediate(weakPointObject);
                Object.DestroyImmediate(structureObject);
            }
        }

        [Test]
        public void InvalidWeakPointConfigurationUsesNeutralTuning()
        {
            GameObject structureObject = new GameObject("tower_structure_invalid_tuning_test");
            GameObject weakPointObject = new GameObject("weakpoint_invalid_tuning_test");
            try
            {
                structureObject.AddComponent<TowerStructure>();
                weakPointObject.transform.SetParent(structureObject.transform);
                TowerWeakPoint weakPoint = weakPointObject.AddComponent<TowerWeakPoint>();
                weakPoint.Configure("invalid_tuning", TowerWeakPointKind.Generic, float.NaN, float.PositiveInfinity);
                Assert.AreEqual(1f, weakPoint.DamageMultiplier, 0.001f);
                Assert.AreEqual(1f, weakPoint.TargetPriority, 0.001f);
            }
            finally
            {
                Object.DestroyImmediate(weakPointObject);
                Object.DestroyImmediate(structureObject);
            }
        }

        [Test]
        public void RootStructureConfigurationExpandsToItsActiveWeakPoints()
        {
            GameObject structureObject = new GameObject("tower_structure_expansion_test");
            GameObject weakPointA = new GameObject("weakpoint_a");
            GameObject weakPointB = new GameObject("weakpoint_b");
            GameObject monsterObject = new GameObject("monster_expansion_test");
            try
            {
                structureObject.AddComponent<TowerStructure>();
                weakPointA.transform.SetParent(structureObject.transform);
                weakPointB.transform.SetParent(structureObject.transform);
                weakPointA.AddComponent<TowerWeakPoint>().Configure("weak_a", TowerWeakPointKind.GateHinge, 1.5f, 1f);
                weakPointB.AddComponent<TowerWeakPoint>().Configure("weak_b", TowerWeakPointKind.PowerCoupling, 1.75f, 1f);
                MonsterAIController controller = monsterObject.AddComponent<MonsterAIController>();
                controller.ConfigureSiegeTargets(new[] { structureObject.transform });
                var field = typeof(MonsterAIController).GetField("siegeTargets",
                    System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                Assert.IsNotNull(field);
                Transform[] expanded = (Transform[])field.GetValue(controller);
                Assert.AreEqual(2, expanded.Length);
                CollectionAssert.Contains(expanded, weakPointA.transform);
                CollectionAssert.Contains(expanded, weakPointB.transform);
            }
            finally
            {
                Object.DestroyImmediate(monsterObject);
                Object.DestroyImmediate(weakPointA);
                Object.DestroyImmediate(weakPointB);
                Object.DestroyImmediate(structureObject);
            }
        }

        [Test]
        public void SquadTargetPressureCountsOnlyOtherMembersAndCanBeCleared()
        {
            GameObject squadObject = new GameObject("squad_vs16_test");
            GameObject firstObject = new GameObject("monster_one_vs16_test");
            GameObject secondObject = new GameObject("monster_two_vs16_test");
            GameObject targetObject = new GameObject("weak_point_vs16_test");
            try
            {
                MonsterSquadCoordinator squad = squadObject.AddComponent<MonsterSquadCoordinator>();
                MonsterAIController first = firstObject.AddComponent<MonsterAIController>();
                MonsterAIController second = secondObject.AddComponent<MonsterAIController>();
                squad.Register(first);
                squad.Register(second);
                squad.ReportSiegeTarget(first, targetObject.transform);
                Assert.AreEqual(1, squad.GetSiegeTargetPressure(second, targetObject.transform));
                Assert.AreEqual(0, squad.GetSiegeTargetPressure(first, targetObject.transform));
                squad.ReportSiegeTarget(first, null);
                Assert.AreEqual(0, squad.GetSiegeTargetPressure(second, targetObject.transform));
            }
            finally
            {
                Object.DestroyImmediate(firstObject);
                Object.DestroyImmediate(secondObject);
                Object.DestroyImmediate(targetObject);
                Object.DestroyImmediate(squadObject);
            }
        }
    }
}
