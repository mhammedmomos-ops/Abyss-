using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS20BridgeSpanRulesTests
    {
        [Test]
        public void NoSupportsIsUnconfigured() =>
            Assert.AreEqual(BridgeSpanState.Unconfigured, BridgeSpanRules.Evaluate(0, 0, 0));

        [Test]
        public void AllHealthySupportsProduceStableSpan() =>
            Assert.AreEqual(BridgeSpanState.Stable, BridgeSpanRules.Evaluate(2, 0, 0));

        [Test]
        public void AnyDamagedSupportProducesStrainedSpan() =>
            Assert.AreEqual(BridgeSpanState.Strained, BridgeSpanRules.Evaluate(2, 1, 0));

        [Test]
        public void AnyCollapsedRequiredSupportCollapsesSpan() =>
            Assert.AreEqual(BridgeSpanState.Collapsed, BridgeSpanRules.Evaluate(2, 0, 1));

        [Test]
        public void CollapseTakesPriorityOverOtherDamagedSupports() =>
            Assert.AreEqual(BridgeSpanState.Collapsed, BridgeSpanRules.Evaluate(3, 1, 1));

        [TestCase(-1, 0, 0)]
        [TestCase(2, -1, 0)]
        [TestCase(2, 0, -1)]
        [TestCase(2, 2, 1)]
        [TestCase(2, 1, 2)]
        [TestCase(int.MaxValue, int.MaxValue, 1)]
        public void InvalidSupportCountsFailClosed(int total, int damaged, int collapsed) =>
            Assert.AreEqual(BridgeSpanState.Unconfigured,
                BridgeSpanRules.Evaluate(total, damaged, collapsed));

        [Test]
        public void RepairingSupportRestoresStableSpan() 
        {
            Assert.AreEqual(BridgeSpanState.Collapsed, BridgeSpanRules.Evaluate(2, 0, 1));
            Assert.AreEqual(BridgeSpanState.Stable, BridgeSpanRules.Evaluate(2, 0, 0));
        }
    }
}
