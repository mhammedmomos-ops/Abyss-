using System.IO;
using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class CampaignSaveServiceAvailabilityTests
    {
        private string directory;

        [SetUp]
        public void SetUp()
        {
            directory = Path.Combine(Path.GetTempPath(), "GorgeHollow_VS51_" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
        }

        [TearDown]
        public void TearDown()
        {
            if (Directory.Exists(directory)) Directory.Delete(directory, true);
        }

        [Test]
        public void HasValidSave_IsFalseBeforeFirstCommit()
        {
            var saves = new CampaignSaveService(directory, "campaign.json");
            Assert.IsFalse(saves.HasValidSave);
        }

        [Test]
        public void HasValidSave_BecomesTrueAfterSuccessfulCommit()
        {
            var saves = new CampaignSaveService(directory, "campaign.json");
            Assert.IsTrue(saves.Save(CampaignStateFactory.CreateNew(), out string error), error);
            Assert.IsTrue(saves.HasValidSave);
        }



        [Test]
        public void Save_RefusesToOverwriteNewerSchemaSave()
        {
            string primaryPath = Path.Combine(directory, "campaign.json");
            CampaignState newer = CampaignStateFactory.CreateNew();
            newer.saveVersion = CampaignSaveService.CurrentSaveVersion + 1;
            string original = UnityEngine.JsonUtility.ToJson(newer, true);
            File.WriteAllText(primaryPath, original);
            var saves = new CampaignSaveService(directory, "campaign.json");

            Assert.IsFalse(saves.Save(CampaignStateFactory.CreateNew(), out string error));
            StringAssert.Contains("newer game version", error);
            Assert.AreEqual(original, File.ReadAllText(primaryPath));
        }

        [Test]
        public void Save_PreservesValidBackupWhenPrimaryIsCorrupt()
        {
            var saves = new CampaignSaveService(directory, "campaign.json");
            Assert.IsTrue(saves.Save(CampaignStateFactory.CreateNew(), out string firstError), firstError);
            Assert.IsTrue(saves.Save(CampaignStateFactory.CreateNew(), out string secondError), secondError);
            File.WriteAllText(Path.Combine(directory, "campaign.json"), "corrupt primary");

            Assert.IsTrue(saves.Save(CampaignStateFactory.CreateNew(), out string thirdError), thirdError);
            Assert.IsTrue(saves.HasValidSave);
            Assert.IsNotNull(saves.Load(out string loadError), loadError);
        }

        [Test]
        public void HasValidSave_RecognizesLastKnownGoodBackup()
        {
            var saves = new CampaignSaveService(directory, "campaign.json");
            Assert.IsTrue(saves.Save(CampaignStateFactory.CreateNew(), out string firstError), firstError);
            Assert.IsTrue(saves.Save(CampaignStateFactory.CreateNew(), out string secondError), secondError);
            File.WriteAllText(Path.Combine(directory, "campaign.json"), "not valid json");
            Assert.IsTrue(saves.HasValidSave);
            CampaignState recovered = saves.Load(out string loadError);
            Assert.IsNotNull(recovered, loadError);
            StringAssert.Contains("backup", loadError.ToLowerInvariant());
        }
    }
}
