using NUnit.Framework;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS55DodgeAndTelegraphTests
    {
        [TestCase(100f, 24f, 1f, 1f, true)]
        [TestCase(23f, 24f, 1f, 1f, false)]
        [TestCase(100f, 24f, 0.9f, 1f, false)]
        [TestCase(100f, -1f, 2f, 1f, false)]
        [TestCase(float.NaN, 24f, 2f, 1f, false)]
        public void DodgeStartRequiresStaminaAndCooldown(float stamina, float cost, float now, float readyAt, bool expected)
        {
            Assert.AreEqual(expected, PlayerDodgeRules.CanStart(stamina, cost, now, readyAt));
        }

        [TestCase(1f, 1.2f, true)]
        [TestCase(1.2f, 1.2f, false)]
        [TestCase(float.NaN, 2f, false)]
        public void DodgeInvulnerabilityUsesExclusiveEndTime(float now, float until, bool expected)
        {
            Assert.AreEqual(expected, PlayerDodgeRules.IsInvulnerable(now, until));
        }

        [Test]
        public void DodgeDirectionIsPlanarAndFallsBackWhenNoInput()
        {
            Vector3 requested = PlayerDodgeRules.GetPlanarDirection(new Vector3(3f, 9f, 4f), Vector3.forward);
            Assert.AreEqual(0f, requested.y, 0.0001f);
            Assert.AreEqual(1f, requested.magnitude, 0.0001f);
            Vector3 fallback = PlayerDodgeRules.GetPlanarDirection(Vector3.zero, Vector3.right);
            Assert.AreEqual(Vector3.right, fallback);
            Vector3 malformed = PlayerDodgeRules.GetPlanarDirection(new Vector3(float.NaN, 0f, 1f), Vector3.left);
            Assert.AreEqual(Vector3.left, malformed);
        }

        [TestCase(0.48f, 0.48f)]
        [TestCase(0.88f, 0.88f)]
        [TestCase(-2f, 0f)]
        [TestCase(9f, 3f)]
        [TestCase(float.NaN, 0.55f)]
        [TestCase(float.PositiveInfinity, 0.55f)]
        public void MonsterAttackWindupIsBounded(float input, float expected)
        {
            Assert.AreEqual(expected, MonsterAttackRules.SanitizeWindup(input), 0.0001f);
        }
    }
}
