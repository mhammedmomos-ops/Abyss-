using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS89BridgeSiegeRulesTests
    {
        [Test]
        public void EnemyCanDamageRequiredSupportWhileBridgeExists()
        {
            Assert.IsTrue(MonsterBridgeSiegeRules.CanAttackSupport(true, true, true, true, true, true, true));
        }

        [Test]
        public void CollapsedOrMissingBridgeCannotBeSiegedAsTraversableSupport()
        {
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, false, true, true, true, true, true));
        }

        [Test]
        public void NonRequiredStructureCannotMasqueradeAsBridgeSupport()
        {
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, true, false, true, true, true, true));
        }

        [Test]
        public void CollapsedSupportCannotReceiveFurtherBridgeSiegeDamage()
        {
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, true, true, false, true, true, true));
        }

        [Test]
        public void DestroyedStructureCannotReceiveFurtherBridgeSiegeDamage()
        {
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, true, true, true, false, true, true));
        }

        [Test]
        public void BridgeSupportMustBeInRange()
        {
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, true, true, true, true, false, true));
        }

        [Test]
        public void BridgeSupportMustHaveLineOfSight()
        {
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(true, true, true, true, true, true, false));
        }


        [Test]
        public void NonBridgeStructureCannotUseBridgeSiegeMarker()
        {
            Assert.IsFalse(MonsterBridgeSiegeRules.CanAttackSupport(false, true, true, true, true, true, true));
        }

        [Test]
        public void StrainedButTraversableBridgeCanStillBeAttacked()
        {
            // The bridge controller maps both Stable and Strained to IsTraversable.
            Assert.IsTrue(MonsterBridgeSiegeRules.CanAttackSupport(true, true, true, true, true, true, true));
        }
    }
}
