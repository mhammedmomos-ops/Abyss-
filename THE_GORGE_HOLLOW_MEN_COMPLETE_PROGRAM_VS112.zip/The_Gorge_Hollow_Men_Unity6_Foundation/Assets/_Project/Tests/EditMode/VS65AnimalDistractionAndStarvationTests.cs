using NUnit.Framework;
using System.IO;
using UnityEngine;

namespace GorgeHollow.Tests
{
    public sealed class VS65AnimalDistractionAndStarvationTests
    {
        private static AnimalRecord Pet(AnimalSpecies species = AnimalSpecies.Cat, int hunger = 0,
            AnimalStatus status = AnimalStatus.Alive)
        {
            return new AnimalRecord
            {
                identity = "vs65-companion", displayName = "Miso", species = species,
                lifeStage = AnimalLifeStage.Adult, status = status,
                health = status == AnimalStatus.Dead ? 0 : 80,
                stamina = 70, hunger = hunger, bond = 10
            };
        }

        [Test]
        public void ReachingZeroHungerDoesNotImmediatelyStartTheTwoDayDeathClock()
        {
            AnimalRecord pet = Pet(hunger: 18);
            Assert.IsFalse(AnimalCareRules.AdvanceHunger(pet, 1));
            Assert.AreEqual(0, pet.hunger);
            Assert.AreEqual(0, pet.starvationDaysAtZero);
            Assert.AreEqual(AnimalStatus.Alive, pet.status);
        }

        [Test]
        public void TwoAdditionalCampaignDayAdvancesAtZeroCausePermanentDeath()
        {
            AnimalRecord pet = Pet();
            Assert.IsFalse(AnimalCareRules.AdvanceHunger(pet, 1));
            Assert.AreEqual(1, pet.starvationDaysAtZero);
            Assert.IsTrue(AnimalCareRules.AdvanceHunger(pet, 1));
            Assert.AreEqual(AnimalStatus.Dead, pet.status);
            Assert.AreEqual(0, pet.health);
            Assert.IsNotEmpty(pet.deathEventId);
        }

        [Test]
        public void FeedingDuringGracePeriodResetsStarvationClock()
        {
            AnimalRecord pet = Pet();
            Assert.IsFalse(AnimalCareRules.AdvanceHunger(pet, 1));
            int food = 1;
            Assert.IsTrue(AnimalCareRules.TryFeed(pet, ref food));
            Assert.AreEqual(60, pet.hunger);
            Assert.AreEqual(0, pet.starvationDaysAtZero);
            Assert.AreEqual(AnimalStatus.Alive, pet.status);
        }

        [Test]
        public void MissingPetDoesNotStarveWhileHuntingIndependently()
        {
            AnimalRecord pet = Pet(status: AnimalStatus.Missing);
            pet.starvationDaysAtZero = 1;
            Assert.IsFalse(AnimalCareRules.AdvanceHunger(pet, 20));
            Assert.AreEqual(0, pet.hunger);
            Assert.AreEqual(1, pet.starvationDaysAtZero);
            Assert.AreEqual(AnimalStatus.Missing, pet.status);
        }

        [Test]
        public void RecoveringMissingPetRestoresRandomHungerAndClearsStarvationClock()
        {
            AnimalRecord pet = Pet(status: AnimalStatus.Missing);
            pet.starvationDaysAtZero = 1;
            Assert.IsTrue(AnimalCareRules.TryRecoverMissing(pet, 53));
            Assert.AreEqual(53, pet.hunger);
            Assert.AreEqual(0, pet.starvationDaysAtZero);
            Assert.AreEqual(AnimalStatus.Alive, pet.status);
        }

        [Test]
        public void VersionFiveSaveMigratesWithFreshStarvationGracePeriod()
        {
            string directory = Path.Combine(Path.GetTempPath(), "gorge-vs65-migration-" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            try
            {
                CampaignState legacy = CampaignStateFactory.CreateNew();
                legacy.saveVersion = 5;
                AnimalRecord pet = Pet(hunger: 0);
                pet.starvationDaysAtZero = 0;
                legacy.animals.Add(pet);
                File.WriteAllText(Path.Combine(directory, "campaign_save.json"), JsonUtility.ToJson(legacy, true));
                CampaignState loaded = new CampaignSaveService(directory).Load(out string error);
                Assert.IsNotNull(loaded, error);
                Assert.AreEqual(6, loaded.saveVersion);
                Assert.AreEqual(0, loaded.animals[0].starvationDaysAtZero);
                Assert.AreEqual(AnimalStatus.Alive, loaded.animals[0].status);
            }
            finally
            {
                if (Directory.Exists(directory)) Directory.Delete(directory, true);
            }
        }

        [Test]
        public void DistractionCanOnlyBeEmittedByTheMatchingLivingOperationalSpecies()
        {
            Assert.IsTrue(AnimalDistractionRules.CanEmit(Pet(AnimalSpecies.Falcon, 20),
                AnimalSpecies.Falcon, 10f, 9f));
            Assert.IsTrue(AnimalDistractionRules.CanEmit(Pet(AnimalSpecies.Cat, 20),
                AnimalSpecies.Cat, 10f, 9f));
            Assert.IsFalse(AnimalDistractionRules.CanEmit(Pet(AnimalSpecies.Falcon, 0),
                AnimalSpecies.Falcon, 10f, 9f));
            Assert.IsFalse(AnimalDistractionRules.CanEmit(Pet(AnimalSpecies.Falcon, 20),
                AnimalSpecies.Cat, 10f, 9f));
        }

        [Test]
        public void DistractionEmissionRespectsCooldownAndTimeMustBeFinite()
        {
            AnimalRecord falcon = Pet(AnimalSpecies.Falcon, 40);
            Assert.IsFalse(AnimalDistractionRules.CanEmit(falcon, AnimalSpecies.Falcon, 9f, 10f));
            Assert.IsFalse(AnimalDistractionRules.CanEmit(falcon, AnimalSpecies.Falcon, float.NaN, 0f));
            Assert.IsFalse(AnimalDistractionRules.CanEmit(falcon, AnimalSpecies.Falcon, float.PositiveInfinity, 0f));
        }

        [Test]
        public void DistractionTimingAndLureDistancesArePositiveAndBounded()
        {
            Assert.Greater(AnimalDistractionRules.MonsterInvestigationSeconds, 0f);
            Assert.Greater(AnimalDistractionRules.MonsterAcceptanceCooldownSeconds, 0f);
            Assert.Greater(AnimalSpeciesTactics.FalconDistractionCooldownSeconds, 0f);
            Assert.Greater(AnimalSpeciesTactics.CatLureDistance, AnimalSpeciesTactics.CatThreatAvoidanceDistance);
            Assert.Greater(AnimalSpeciesTactics.CatLureDurationSeconds, 0f);
            Assert.Greater(AnimalSpeciesTactics.CatLurePulseIntervalSeconds, 0f);
        }

        [Test]
        public void CampaignClockReportsStarvationDeathOnlyAfterTheProgressionIsApplied()
        {
            CampaignState state = CampaignStateFactory.CreateNew();
            AnimalRecord pet = Pet();
            state.animals.Add(pet);
            CampaignClock clock = new CampaignClock(state);
            clock.AdvanceFictionalMinutes(2 * 24 * 60);
            Assert.AreEqual(AnimalStatus.Dead, pet.status);
            Assert.AreEqual(1, clock.StarvationDeaths.Count);
            Assert.AreEqual(pet.identity, clock.StarvationDeaths[0]);
        }
    }
}
