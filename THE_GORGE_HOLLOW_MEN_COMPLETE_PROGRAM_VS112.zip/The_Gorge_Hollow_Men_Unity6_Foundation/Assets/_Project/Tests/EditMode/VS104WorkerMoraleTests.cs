using NUnit.Framework;

namespace GorgeHollow.Tests
{
    public sealed class VS104WorkerMoraleTests
    {
        private static TowerWorkerRecord Worker(int morale = 70, int loyalty = 50, int stress = 0) => new TowerWorkerRecord
        { identity = "worker", displayName = "Worker", towerId = "tower_a", role = TowerWorkerRole.Guard,
          status = TowerWorkerStatus.Active, assignment = TowerWorkerAssignment.Idle, health = 100,
          morale = morale, loyalty = loyalty, stress = stress };

        [Test] public void EventsAreBoundedAtBothEnds()
        {
            TowerWorkerRecord w = Worker(98, 99, 98);
            TowerWorkerMoraleRules.ApplyEvent(w, WorkerMoraleEvent.ProtectedDuringRaid);
            Assert.AreEqual(100, w.morale); Assert.AreEqual(100, w.loyalty); Assert.AreEqual(90, w.stress);
            TowerWorkerMoraleRules.ApplyEvent(w, WorkerMoraleEvent.AbandonedInOverrun);
            Assert.AreEqual(88, w.morale); Assert.AreEqual(92, w.loyalty); Assert.AreEqual(100, w.stress);
        }

        [Test] public void RescueImprovesMoraleTrustAndReducesStress()
        {
            TowerWorkerRecord w = Worker(30, 20, 80);
            TowerWorkerMoraleRules.ApplyEvent(w, WorkerMoraleEvent.RescuedFromCapture);
            Assert.AreEqual(48, w.morale); Assert.AreEqual(32, w.loyalty); Assert.AreEqual(60, w.stress);
        }

        [Test] public void DangerousAssignmentsAreRefusedOnlyAtExplicitThresholds()
        {
            TowerWorkerRecord w = Worker(20, 15, 84);
            Assert.IsFalse(TowerWorkerMoraleRules.ShouldRefuseDangerousAssignment(w, out _));
            w.morale = 19;
            Assert.IsTrue(TowerWorkerMoraleRules.ShouldRefuseDangerousAssignment(w, out string reason));
            StringAssert.Contains("Morale", reason);
            w.morale = 50; w.loyalty = 50; w.stress = 85;
            Assert.IsTrue(TowerWorkerMoraleRules.ShouldRefuseDangerousAssignment(w, out reason));
            StringAssert.Contains("Stress", reason);
            w.stress = 0; w.loyalty = 14;
            Assert.IsTrue(TowerWorkerMoraleRules.ShouldRefuseDangerousAssignment(w, out reason));
            StringAssert.Contains("Trust", reason);
        }

        [Test] public void RecoveryIsDeterministicAndOnlyOccursAtRest()
        {
            TowerWorkerRecord w = Worker(40, 20, 50);
            TowerWorkerMoraleRules.AdvanceRecovery(w, 120);
            Assert.AreEqual(40, w.morale);
            w.assignment = TowerWorkerAssignment.Rest;
            TowerWorkerMoraleRules.AdvanceRecovery(w, 119);
            Assert.AreEqual(41, w.morale); Assert.AreEqual(46, w.stress); Assert.AreEqual(59, w.recoveryMinutes);
        }

        [Test] public void CampaignValidationRejectsOutOfRangeMoraleValues()
        {
            CampaignState campaign = CampaignStateFactory.CreateNew();
            campaign.towerWorkers.Add(Worker());
            Assert.IsTrue(campaign.IsValid(out string reason), reason);
            TowerWorkerRules.Find(campaign, "worker").stress = 101;
            Assert.IsFalse(campaign.IsValid(out reason));
        }

        [Test] public void AssignmentRuleReturnsReasonForLowMoraleDangerousWork()
        {
            CampaignState campaign = CampaignStateFactory.CreateNew();
            TowerWorkerRecord w = Worker(19, 50, 0);
            campaign.towerWorkers.Add(w);
            Assert.IsFalse(TowerWorkerRules.TryAssign(campaign, w.identity, TowerWorkerAssignment.Guard, out string reason));
            StringAssert.Contains("Morale", reason);
            Assert.IsTrue(TowerWorkerRules.TryAssign(campaign, w.identity, TowerWorkerAssignment.Production, out reason), reason);
        }

        [Test] public void CapturedWorkersDoNotRecover()
        {
            TowerWorkerRecord w = Worker(20, 10, 90);
            w.status = TowerWorkerStatus.Captured; w.assignment = TowerWorkerAssignment.Idle;
            TowerWorkerMoraleRules.AdvanceRecovery(w, 600);
            Assert.AreEqual(20, w.morale); Assert.AreEqual(90, w.stress);
        }

        [Test] public void CompletedDutyAndTreatmentUseSmallBoundedChanges()
        {
            TowerWorkerRecord w = Worker(70, 50, 10);
            TowerWorkerMoraleRules.ApplyEvent(w, WorkerMoraleEvent.CompletedDuty);
            TowerWorkerMoraleRules.ApplyEvent(w, WorkerMoraleEvent.Treated);
            Assert.AreEqual(77, w.morale); Assert.AreEqual(53, w.loyalty); Assert.AreEqual(3, w.stress);
        }
    }
}
