using NUnit.Framework;
using GorgeHollow;

namespace GorgeHollow.Tests
{
    public sealed class VS4ConstructionRegressionTests
    {
        [Test]
        public void ConstructionCreatesPersistentFullHealthRecordAndChargesOnce()
        {
            var campaign = new CampaignState { scrap = 10, timber = 30 };
            var service = new TowerConstructionService(new ResourceTransactionService());
            Assert.IsTrue(service.TryConstruct(campaign, "tower_a:slot_1", "tower_a", "Barricade", 120,
                new ResourceDelta { scrap = -2, timber = -12 }, "build-1", out var record, out string error), error);
            Assert.AreEqual(120, record.currentHealth);
            Assert.AreEqual(8, campaign.scrap);
            Assert.AreEqual(18, campaign.timber);
            Assert.IsTrue(record.isBuilt);
            Assert.IsTrue(service.HasStructure(campaign, "tower_a:slot_1"));
        }

        [Test]
        public void DuplicateConstructionCannotChargeTwice()
        {
            var campaign = new CampaignState { timber = 30 };
            var service = new TowerConstructionService(new ResourceTransactionService());
            Assert.IsTrue(service.TryConstruct(campaign, "slot", "tower_a", "Wall", 100,
                new ResourceDelta { timber = -10 }, "build-a", out _, out _));
            Assert.IsFalse(service.TryConstruct(campaign, "slot", "tower_a", "Wall", 100,
                new ResourceDelta { timber = -10 }, "build-b", out _, out _));
            Assert.AreEqual(20, campaign.timber);
            Assert.AreEqual(1, campaign.towerStructures.Count);
        }

        [Test]
        public void InsufficientConstructionResourcesDoNotCreateRecord()
        {
            var campaign = new CampaignState { timber = 2 };
            var service = new TowerConstructionService(new ResourceTransactionService());
            Assert.IsFalse(service.TryConstruct(campaign, "slot", "tower_a", "Wall", 100,
                new ResourceDelta { timber = -10 }, "build-fail", out _, out _));
            Assert.AreEqual(2, campaign.timber);
            Assert.AreEqual(0, campaign.towerStructures.Count);
        }

        [Test]
        public void UpgradeIncreasesMaximumAndCurrentHealthAndChargesResources()
        {
            var campaign = new CampaignState { scrap = 20, timber = 20, mechanicalParts = 4 };
            var service = new TowerConstructionService(new ResourceTransactionService());
            Assert.IsTrue(service.TryConstruct(campaign, "slot", "tower_a", "Wall", 100,
                new ResourceDelta(), "build", out var record, out _));
            Assert.IsTrue(service.TryUpgrade(campaign, "slot", 40, 3,
                new ResourceDelta { scrap = -5, timber = -3, mechanicalParts = -1 }, "upgrade-1", out string error), error);
            Assert.AreEqual(140, record.maxHealth);
            Assert.AreEqual(140, record.currentHealth);
            Assert.AreEqual(2, record.upgradeLevel);
            Assert.AreEqual(15, campaign.scrap);
        }

        [Test]
        public void DestroyedStructureMustBeRepairedBeforeUpgrade()
        {
            var campaign = new CampaignState();
            var service = new TowerConstructionService(new ResourceTransactionService());
            Assert.IsTrue(service.TryConstruct(campaign, "slot", "tower_a", "Wall", 10,
                new ResourceDelta(), "build", out _, out _));
            var maintenance = new TowerMaintenanceService(new ResourceTransactionService());
            Assert.IsTrue(maintenance.TryDamage(campaign, "slot", 99, "siege", out _));
            Assert.IsFalse(service.TryUpgrade(campaign, "slot", 10, 3, new ResourceDelta(), "upgrade", out _));
        }

        [Test]
        public void CampaignValidationAcceptsLegacyStructureDefaultsAndRejectsInvalidUpgradeLevel()
        {
            var campaign = new CampaignState();
            campaign.towerStructures.Add(new TowerStructureRecord { identity = "old", towerId = "tower_a", maxHealth = 10, currentHealth = 10 });
            Assert.IsTrue(campaign.IsValid(out string reason), reason);
            campaign.towerStructures[0].upgradeLevel = 0;
            Assert.IsFalse(campaign.IsValid(out _));
        }

        [Test]
        public void UpgradeAtMaximumLevelDoesNotSpendResources()
        {
            var campaign = new CampaignState { scrap = 10 };
            var service = new TowerConstructionService(new ResourceTransactionService());
            Assert.IsTrue(service.TryConstruct(campaign, "slot", "tower_a", "Wall", 10,
                new ResourceDelta(), "build", out _, out _));
            Assert.IsTrue(service.TryUpgrade(campaign, "slot", 5, 2, new ResourceDelta(), "upgrade", out _));
            Assert.IsFalse(service.TryUpgrade(campaign, "slot", 5, 2,
                new ResourceDelta { scrap = -5 }, "upgrade-max", out _));
            Assert.AreEqual(10, campaign.scrap);
        }
    }
}
