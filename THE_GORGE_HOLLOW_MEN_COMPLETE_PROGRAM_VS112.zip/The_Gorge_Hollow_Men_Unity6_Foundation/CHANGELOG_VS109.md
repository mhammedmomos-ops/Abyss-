# VS109 — Mobile Workforce Command Panel

## Added
- Touch-friendly workforce command panel generated in the greybox vertical-slice HUD.
- Cycle through living, uncaptured workers from both towers and inspect role, tower, assignment, status, health, fatigue and morale.
- Issue Production, Salvage, Guard and Rest assignments through the existing transactional `TowerWorkforceController`.
- Pure `TowerWorkerCommandRules` roster filtering and assignment eligibility checks, including local tower capacity, injury, exhaustion and dangerous-duty refusal rules.
- Seven EditMode regression tests for roster filtering, assignment restrictions, tower-local capacity, refusal rules, authoritative assignment and non-mutation.
- `TowerWorkerRules.TryAssign` delegates to the same eligibility rules used by the panel, preventing UI/controller rule drift.

## Preserved
- Existing save schema v15; no persisted model changes or migration required.
- Existing role/assignment rules remain authoritative in `TowerWorkerRules` and `TowerWorkforceController`.
- Existing bridge access restrictions remain unchanged. This UI issues tower-local workforce assignments only; it adds no bridge route or bridge access token.

## Known limitations
- The panel is included in the editor-generated greybox scene. Existing hand-authored scenes need the panel and references added manually.
- Commands change worker assignments and their existing scene actors route to authored destinations. They do not yet create bespoke repair, salvage-node or combat animation sequences.
- The panel uses Unity's legacy UGUI `Text` and `Button` components, consistent with the current project HUD. A future UI Toolkit/Input System migration is not part of this phase.
