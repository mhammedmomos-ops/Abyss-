# VS70 third-party research and reuse decision

Research checked Unity 6's existing NavMeshAgent API and Unity's NavMesh path-validation guidance before implementation:

- Unity 6 NavMeshAgent reference: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/ai/navmeshagent
- Unity 6 NavMeshAgent.Raycast/path API reference: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/ai/navmeshagent
- Unity AI Navigation 2.0 documentation is already part of the project package set; no additional package is required.

The implementation uses the existing NavMeshAgent.CalculatePath and NavMeshPathStatus.PathComplete checks to reject unreachable scent points. It uses a bounded in-project registry because a scent breadcrumb store is a small domain-specific runtime data structure; adding a third-party dependency would add maintenance and package weight without improving this use case.

No external source code or package was added. Unity's official API documentation informed the navigation integration; the registry and gameplay rules are original project code.
