# VS99 Mobile Command Panel Guide

## Purpose
Give the player three tactical choices for an active physical inter-tower carrier without allowing instant transfers or bypassing bridge rules.

## Orders
- **ADVANCE:** resumes travel and uses 1.25x authored carrier movement speed.
- **HOLD:** pauses waypoint movement. The carrier remains in the world, remains attackable, and can still be damaged. Escorts continue to follow/defend it.
- **FOCUS FIRE:** carrier moves at 0.85x speed while escorts deal 1.35x their configured damage per attack.

## Setup
- Add a Canvas using Screen Space - Overlay (or the project's established overlay canvas).
- Add a horizontal/vertical command group with three Buttons. Keep them within device safe-area margins and use a Canvas Scaler in Scale With Screen Size mode.
- Attach `SupplyConvoyCommandPanel` to the command group or a Canvas controller object.
- Assign the active `SupplyConvoyController`, matching escort controller, and the three buttons.
- Assign optional status Text fields. The panel refreshes at a low frequency and writes only UI text/interactable states.
- Configure the scene EventSystem for the active input backend. Unity's Input System UI module is required for uGUI when using the Input System; do not install a second competing module.

## Gameplay notes
- Hold is not a safe pause: enemies can attack the carrier and the bridge can collapse.
- If Hold is issued while crossing, bridge collapse still triggers the existing fall-and-cargo-loss transaction.
- Advance does not skip waypoints or bridge validation.
- Focus Fire does not make escorts invulnerable and does not create new escorts.
- Commands are saved to the campaign before the live campaign object is replaced. A failed save leaves the previous order active.
