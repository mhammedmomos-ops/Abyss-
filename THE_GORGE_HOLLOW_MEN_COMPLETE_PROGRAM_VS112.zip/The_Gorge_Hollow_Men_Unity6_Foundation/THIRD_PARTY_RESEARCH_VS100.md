# VS100 Third-Party Research

Reviewed Unity's official guidance before implementation:

- Unity 6 serialization best practices: https://docs.unity.com/en-us/engine/6000.6/manual/programming-environment/code-reload-serialization/script-serialization/best-practices
- Unity 6 ScriptableObject documentation: https://docs.unity.cn/6000.6/Documentation/Manual/class-ScriptableObject.html
- Unity UI optimization guidance: https://unity.com/how-to/unity-ui-optimization-tips
- Unity 6 Android input guidance: https://docs.unity.com/en-us/engine/6000.3/manual/platform-specific/android/developing/input

Design implications: authoritative persistent balances remain in the campaign save, not ScriptableObject runtime mutations; derived assessments are not duplicated into save data; the mobile panel refreshes at a configurable low frequency instead of rebuilding text every frame.

No third-party source code or packages were copied or added in VS100.
