# VS95 Integration Audit

## Source baseline
Built cumulatively from `THE_GORGE_HOLLOW_MEN_COMPLETE_PROGRAM_VS94.zip` after archive inspection. VS94 contained 763 entries and passed ZIP CRC validation before extraction.

## Key integration points
- `CampaignState.towerDepots` is a serializable list of plain `[Serializable]` records, consistent with Unity's supported JsonUtility field/list serialization model.
- `CampaignSaveService` v7-to-v8 migration preserves the old shared inventory and creates empty `tower_a` / `tower_b` depots.
- `SupplyConvoyRules.TryDeliver` now resolves a depot by the convoy's exact destination ID and commits the delivery ID only after the full depot addition passes overflow checks.
- `TowerStructure.HasRepairResources` checks the structure's owning tower depot.
- `GameBootstrap.TryRepairTowerStructure` clones campaign state, applies local depot spend + structure repair to the candidate, saves it, then swaps the live state.

## Invariants checked in source
- A convoy cannot deposit into an unrelated tower depot.
- A missing destination depot rejects delivery without clearing cargo.
- Depot overflow rejects the entire delivery.
- Delivery remains protected by the stable `supply-convoy-delivery:<identity>` transaction ID.
- Repair spends only from the depot matching the structure record's `towerId`.
- No cross-tower transfer operation exists.
- Existing global resource fields are preserved for compatibility with older world pickups/crafting. They are not copied to depots.
- VS90 bridge-collapse fatal fall and no-bridge-spawn rules were not modified by VS95.

## Static checks performed
- ZIP CRC test passed.
- All `.json` files parsed.
- All `.asmdef` files parsed as JSON.
- C# lexical delimiter scan run over all C# files.
- New depot code and edited repair/delivery paths inspected for balanced blocks and expected call-site references.
- VS94 delivery test expectations updated to assert tower-local stockpile values.

## Not verified
- Unity Editor compilation.
- NUnit/EditMode execution.
- PlayMode, physics, NavMesh, AI, scene/prefab wiring, or bridge-collapse gameplay.
- Android/iOS build or physical-device performance.

The archive remains a Unity source foundation, not a fully authored playable Unity project. It still requires project settings/packages, scenes, prefabs, art/audio assets, and Unity-side integration/verification.
