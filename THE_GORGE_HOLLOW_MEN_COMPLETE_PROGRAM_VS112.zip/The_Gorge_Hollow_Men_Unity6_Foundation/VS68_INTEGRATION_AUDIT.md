# VS68 Integration Audit

## Integration points
- `AnimalCompanionController` resolves the optional feedback component at bind/use time.
- Threat cue fires only when a newly perceived threat replaces the previous target; repeated scans of the same target do not retrigger it.
- Injury and death cues are connected to the existing damage/permanent-death paths.
- Attack cue fires on a successful companion support hit, not merely on entering attack range.
- Forage-complete cue fires only after the campaign food collection succeeds.
- Distraction cue fires only when the existing Falcon/Cat stimulus emission succeeds.
- Missing cue fires only after the campaign successfully marks the companion missing.

## Safety and compatibility
- Missing AudioSource/component/clip is non-fatal.
- One-shot playback uses a shared cooldown to reduce audio spam; permanent-death cue can bypass it.
- Source defaults to 3D spatial blend, logarithmic rolloff, 2m minimum distance and 24m maximum distance; tune for scene scale and mix.
- Audio is presentation-only: it does not create monster stimuli, alter hearing AI, affect gameplay stats, or persist into saves. Existing Falcon/Cat gameplay distraction stimuli remain separate.
- No animal species were added or removed.

## Known limitations
- Audio clips, voice identity, environmental ambience, mixer routing, accessibility volume controls and device-specific mix remain to be authored/configured.
- The cue set uses one clip per cue/species; variation comes from pitch randomization only.
- Unity Editor/runtime verification was unavailable.
