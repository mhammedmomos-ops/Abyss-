# VS111 Tower Concealment — Authoring Guide

## Generated scene
Use `THE GORGE / Vertical Slice / Generate Greybox Scene`. The generator creates `WORLD VISIBILITY — LOCAL TOWER STRUCTURES ONLY` and assigns the player `TowerLocalAccessTracker` plus the West/East tower roots.

## Hierarchy rule
Every detailed object that belongs to Tower A must be a descendant of Tower A's root. Every detailed object that belongs to Tower B must be a descendant of Tower B's root. This includes:
- walls, floors, doors, roofs, damaged structure variants and repair visuals;
- worker workstations and local decorations;
- tower-local lights and world-space UI;
- tower-local audio emitters and ambient loops.

Do not parent the gorge, bridge, shared terrain, global weather, global sky, or global landmarks beneath either tower root. Those remain world-level presentation.

## Local visibility behavior
- Player inside Tower A access radius: Tower A details visible; Tower B details hidden.
- Player inside Tower B access radius: Tower B details visible; Tower A details hidden.
- Player on bridge / in gorge / outside both access radii: both detailed tower roots hidden.

The generated greybox uses a local footprint on `TowerLocalAccessTracker`: 9m half-width/depth, local height 0.5–12m. This matches the 18m square tower platform and prevents the player losing access at courtyard corners. The bridge begins immediately beyond the platform edge, so stepping onto the bridge removes tower-local access. Custom scenes can leave `useLocalFootprintBounds` disabled and use the radius fallback, or configure a footprint that matches their actual walkable tower area.

## Runtime-created structures
`TowerStructureVisibilityController` caches descendants during `Awake`. If another system creates a new tower renderer, canvas, light, or audio source after startup, that system must register the new object with a future refresh/registration extension or ensure it is created before the visibility controller caches the tower. Do not place dynamic tower detail outside its owning tower root.

## Important limitation
This is not multiplayer security. When multiplayer is implemented, the server must only send each player information they are authorized to know. Client-side hiding alone is insufficient.

## Threat and enemy visibility is not yet fully localized
The current campaign phase and some raid UI/audio cues are global. Enemy actors may also exist outside the tower-root hierarchies. VS111 conceals tower structures, but does not yet provide a complete per-tower fog-of-war policy for enemy silhouettes and raid notifications. Avoid adding new remote-state HUD widgets until a per-tower observation model is implemented.
