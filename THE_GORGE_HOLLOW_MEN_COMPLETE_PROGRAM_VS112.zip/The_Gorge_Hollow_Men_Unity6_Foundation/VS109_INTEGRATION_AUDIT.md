# VS109 Integration Audit

## Source integration
- `TowerWorkerCommandPanel` delegates all persistent assignment changes to `TowerWorkforceController.Assign`; it does not write campaign records directly.
- `TowerWorkerCommandRules` is the single read-only eligibility implementation. `TowerWorkerRules.TryAssign` delegates to it before mutating the record, so panel availability and authoritative assignment cannot drift apart.
- Panel listeners are attached in `OnEnable` and removed in `OnDisable`; there are no duplicate persistent/runtime listeners in the generated HUD.
- Campaign replacement refreshes the roster while retaining the selected worker identity where possible.
- Dead and captured workers are omitted from command selection. Injured and exhausted workers remain visible, but only Rest is enabled.
- Assignment capacity is evaluated within the selected worker's tower.

## Scene generator
- Greybox generation now creates a `TowerWorkforceController` beside the worker spawn director and adds the workforce command panel to the generated mobile HUD.
- The panel is positioned as a compact roster/command strip at the upper-left portion of the screen. Device safe-area and actual aspect-ratio review remains outstanding.

## Save and bridge compatibility
- No campaign schema changes; save schema remains v15.
- No changes to bridge enemy spawn rules, enemy bridge-entry rules, collapse/fall rules, or worker bridge restrictions.

## Verification status
- Static source checks and archive integrity can be performed in this delivery.
- Unity compilation, scene generation, UGUI runtime interaction, touch-device testing and EditMode execution have not been performed in this environment.
