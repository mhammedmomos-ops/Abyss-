# VS3 — Persistent Tower Damage & Repair (Mobile)

## Added
- Campaign-persistent tower structure records, keyed by stable structure identity and associated tower ID.
- Deterministic damage and repair domain service; damage clamps at zero and repair clamps at maximum health.
- Destruction state is derived/validated against zero health; destroyed structures remain destroyed until repaired.
- Resource-cost repair uses the existing idempotent ResourceTransactionService; failed costs do not alter structure health.
- Scene-facing `TowerStructure` component implements the existing `IDamageable` contract and saves campaign changes.
- `TowerRepairInteraction` plugs into the existing raycast interaction system.
- Tower state change event and EditMode regression tests.

## Compatibility
- Added a serialized `towerStructures` collection without changing the save version. Existing VS1/VS2 JSON saves that omit the field deserialize with a null collection; `CampaignState.IsValid` normalizes it to an empty list, preserving prior campaign data.

## Not included yet
- Physical construction placement, barricade snapping, structural material classes, multi-part collapse physics, enemy siege targeting, repair animations/audio/VFX, or a complete tower HUD.
- Unity compilation, test execution, mobile build and device playtesting have not been performed.
