# VS105 — Worker Relationships, Personalities and Social Bonds

## Added
- Added five persisted worker personality labels: Balanced, Brave, Cautious, Empathetic and Driven. Existing workers migrate to Balanced; traits are descriptive at this stage and do not secretly alter combat or assignment outcomes.
- Added a bounded campaign relationship ledger (maximum 128 pairs) with canonical worker-ID ordering, bond, friction and interaction count.
- Added deterministic social interaction rules for shared duties, mutual protection, resolved disagreements and harmful rivalry incidents.
- Added a bounded 0–10 cooperation-readiness value derived from bond/friction for future explicit team-assist integration. It is not yet wired to combat or worker AI, so it cannot silently buff or penalize gameplay.
- Workforce monitor now shows personality and the number of recorded social bonds.
- Save schema advanced from v13 to v14. Migration preserves worker morale, loyalty, stress, assignments, health and raid posture; initializes personality to Balanced and starts an empty relationship ledger.

## Compatibility and limits
- No worker enum numeric values changed.
- No resource balances or depot access rules changed.
- Relationships are restricted to workers at the same tower; cross-tower bonds are rejected.
- Relationships are not automatically generated from proximity or random rolls. A trusted gameplay event must explicitly call `TryCreate` and `ApplyInteraction`.
- Rivalry does not trigger sabotage, refusal or combat penalties. No automatic social simulation runs while offline.
- The bridge gateway, enemy spawn exclusion and fatal collapse fall rules are unchanged.

## Verification boundary
- Six VS105 EditMode test methods added, including v13-to-v14 migration coverage.
- Static source, JSON/asmdef parsing, schema assertions and ZIP integrity checks are run during packaging.
- Unity compilation, NUnit execution, PlayMode, scene/prefab wiring, UI rendering, mobile performance and Android/iOS builds are not performed in this environment.
