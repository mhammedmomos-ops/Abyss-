# VS55 — Third-Party Research and Reuse Decisions

Research was performed before implementation to identify reusable controller, animation and evasion patterns.

## Evaluated

1. **Unity Starter Assets — First Person + Third Person Character Controllers**  
   https://assetstore.unity.com/packages/3d/characters/first-person-third-person-character-controllers-196526  
   Unity-maintained controller samples include CharacterController movement, Animator parameter wiring, Input System support, Cinemachine and mobile UI overlays. They are free under the Unity Companion License, subject to that licence's terms. The package is a useful candidate for a future character-art/controller integration pass, but it was not imported here: the project already has a custom mobile `CharacterController` movement path and importing Starter Assets now would require reconciling input, camera and movement ownership before a tested migration. No Starter Assets code or art was copied.

2. **marcsansDEV Unity Third Person Controller**  
   https://github.com/marcsansDEV/Unity-Third-Person-Controller  
   MIT-licensed open-source controller describes a small movement FSM with roll/glide states and UnityEvents for animation/VFX integration. Its separation of transient movement states informed the decision to isolate dodge timing/rules in `PlayerDodgeController` rather than layering another independent CharacterController mover. No source code was copied; the existing project input and movement APIs were retained.

3. **Unity AI Navigation / NavMeshAgent**  
   https://docs.unity3d.com/Packages/com.unity.ai.navigation@2.0/manual/index.html  
   The existing NavMeshAgent remains the monster movement authority. VS55 only adds attack timing and presentation events; it does not replace the existing navigation or behaviour-tree implementation.

## Reuse decision

VS55 uses the project's existing `PlayerMovement`, `PlayerVitals`, `MobileInputState`, `MonsterAIController`, `MonsterAnimationBridge`, `MonsterRaidDirector` and generated prefab workflow. This minimizes dependency growth and avoids two controllers writing to the same CharacterController or two independent systems owning monster navigation.

No third-party code, models, animation clips or paid assets were copied into the archive. Unity's built-in CharacterController, Animator, NavMeshAgent and UGUI APIs are used through the already declared Unity package/runtime setup.
