# VS29 — Combat Feedback HUD, Compass, Night Ambient & Toasts

## Scope
VS29 adds combat/readability feedback for mobile: generic toast queue, low-health pulse, reload prompt, aim-target health bar, compass, and night ambient lighting driven by campaign phase. Objective completion also pushes a toast.

## Added
- `GenericToastUI.cs`
- `LowHealthWarningUI.cs`
- `ReloadPromptUI.cs`
- `TargetHealthUI.cs`
- `CompassUI.cs`
- `NightAmbientController.cs`
- `VS29NightPhaseRulesTests.cs`

## Modified
- `ObjectiveTracker.cs` — shows toast on objective complete.

## Scene setup
1. Toast panel → `GenericToastUI`.
2. Full-screen warning Image + CanvasGroup → `LowHealthWarningUI`.
3. “Reload” label → `ReloadPromptUI`.
4. Target HP bar under reticle → `TargetHealthUI`.
5. Compass needle/strip → `CompassUI` (assign gameplay camera).
6. Directional light → `NightAmbientController`.

## Limitations
- Compass is cosmetic (not GPS).
- Target health requires `DamageableHealth` on the aimed object.
- Night ambient does not change skybox assets automatically.
- Unity compile / device builds not performed here.
