# VS57 — Companion threat response and monster retaliation

## What changed
- Added a bounded companion targeting rule: a monster may retaliate against the selected companion only while it directly sees that companion's owner, the companion is alive/operational, the companion has independently confirmed that exact monster through its local perception scan, and the companion is within the monster's attack range.
- Added a readable monster attack wind-up against the companion using the existing `AttackStarted`, `AttackWindupStarted` and `AttackResolved` presentation events. Existing monster attack telegraph/animation listeners can therefore present the warning without a parallel combat pipeline.
- Added impact-time revalidation. The attack is cancelled if the pet dies/becomes unavailable, stops threatening that monster, the monster loses sight of its owner, or the pet moves out of range before impact.
- Resolved strikes apply injury through the selected pet's existing campaign record and permanent-death pathway. Species damage mitigation remains applied by the pet's existing profile.
- A companion that is not selected, is missing/dead, or has not locally detected the monster does not become an invisible aggro target. No global monster-location feed or omniscient pet targeting was added.
- Added pure EditMode source tests for target eligibility, cancellation, range and invalid numeric inputs.

## Compatibility
- No campaign save schema changes and no new package dependencies.
- Existing player attack wind-up and dodge pipeline remains intact. Companion retaliation shares the monster's existing attack cooldown and presentation events to avoid simultaneous duplicate attacks.
- The approved pet roster and player-entered naming workflow are unchanged.

## Remaining boundaries
- This is a combat-response prototype, not final pet animation, sound or damage presentation.
- Monster target selection is currently gated by direct sight of the player owner and the pet's own local confirmation of that monster. Independent monster sensory acquisition of a pet is not yet implemented.
- No Unity Editor/compiler or runtime is available in this environment; compilation, EditMode execution, scene simulation, NavMesh baking and device tests remain unverified.
