# THE GORGE: HOLLOW MEN — VS14

Adaptive Siege Intelligence. This cumulative Unity 6 source package extends VS13 with authored structure categories and resistance, nest-scoped persistent observations of actual siege damage efficiency, role-specific structure preferences, and save schema v4 migration.

Read `README.md`, `CHANGELOG_VS14.md`, `THIRD_PARTY_RESEARCH_VS14.md`, and `Assets/_Project/BUILD_VERIFICATION.txt` before importing.
