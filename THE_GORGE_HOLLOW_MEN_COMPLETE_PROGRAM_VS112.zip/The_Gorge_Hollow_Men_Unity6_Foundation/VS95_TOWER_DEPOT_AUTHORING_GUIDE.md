# VS95 Tower Depot Authoring Guide

## Required IDs
Use the stable IDs `tower_a` and `tower_b` on tower structures and convoy destinations. Depot identity is a campaign key, not a scene object name.

## Convoys
1. Keep the convoy's `destinationTowerId` equal to the intended receiving tower ID.
2. Assign cargo before registration; a new convoy must carry at least one resource.
3. Route the convoy physically to the destination tower's delivery trigger/waypoint. The existing controller owns its saved movement and delivery call.
4. A successful delivery deposits the complete manifest into only that tower's depot. Do not create duplicate convoy identities to retry a delivered or destroyed convoy.
5. A destroyed convoy loses its cargo; it does not deposit partial cargo.

## Structures and repair stations
1. Set each `TowerStructure` component's `towerId` to the owning tower's stable ID.
2. Place bridge supports and repair stations under the tower that owns the support. The repair transaction resolves the depot through the campaign structure record's `towerId`.
3. A repair is available only when that local depot has the required scrap and timber. Materials in the opposite tower depot are intentionally inaccessible.
4. Bridge repair work continues to charge only on successful completion; interrupted work consumes no materials.

## Migration and existing campaigns
- Opening a v7 save migrates it to v8. Existing shared campaign balances remain unchanged.
- The migration creates empty tower depots; it does not clone the shared balances into both towers.
- New campaigns also start with empty tower depots. Ensure the authored early-game supply plan includes a convoy to the tower expected to perform repairs.

## Current scope boundary
There is no tower-to-tower transfer feature. Do not add a transfer UI or direct stockpile mutation until the game has a validated route/bridge availability check and a persisted transfer transaction. Shared legacy inventory is still used by older pickup/crafting interactions and is not a substitute for tower depot stock.
