# VS94 Third-party implementation research

## Unity navigation review
- Reviewed the official Unity 6 `NavMeshAgent` API documentation: https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/ai/navmeshagent
- `NavMeshAgent.SetDestination` requests an asynchronous path calculation; path readiness and status must be checked. The agent also depends on valid NavMesh placement and authored navigation data.
- The inherited VS93 package does not contain authored scenes, baked NavMesh data, or project settings. To avoid shipping a convoy that silently cannot move in the current source foundation, VS94 uses explicit authored route waypoints and deterministic transform movement. This keeps route geometry visible and testable in scene authoring. A NavMesh-driven vehicle/escort variant can be added when the actual road scene and navigation surfaces exist.
- No third-party source code was copied. The convoy controller and persistence logic are original project code using Unity's built-in `Vector3.MoveTowards`, `MonoBehaviour`, serialization and campaign save services.

## Licensing
No third-party code or assets were added in VS94.
