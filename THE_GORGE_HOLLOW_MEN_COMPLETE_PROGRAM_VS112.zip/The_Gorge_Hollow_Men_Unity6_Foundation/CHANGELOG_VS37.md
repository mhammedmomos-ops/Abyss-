# VS37 — Hotbar Consumables, Hazard Zones, Bloom Warning, Tutorial Checklist & Resource Caps

## Scope
VS37 adds a mobile hotbar consumable slot, environmental hazard volumes, bloom exposure warning UI, optional camera pitch limiter, first-session checklist, resource soft-cap rules, and compass markers.

## Added
- `HotbarConsumableSlot.cs`
- `HazardZoneVolume.cs`
- `BloomWarningUI.cs`
- `CameraLookLimiter.cs`
- `TutorialChecklistUI.cs`
- `ResourceCapRules.cs`
- `CompassMarker.cs`
- `VS37ResourceCapRulesTests.cs`

## Modified
- `GameVersionLabel.cs` / `GameFoundationInfo.cs` → VS37

## Scene setup
1. HUD button → `HotbarConsumableSlot` (optional bound consumable + charges).
2. Toxic/gorge mist areas → `HazardZoneVolume` trigger.
3. HUD → `BloomWarningUI` when bloom ≥ threshold.
4. First-run panel → `TutorialChecklistUI`.
5. Landmark objects → `CompassMarker`.

## Limitations
- Resource caps are pure helpers; callers must apply them when granting loot.
- Hotbar charges are session-local unless you persist them.
- Unity compile / device builds not performed here.
