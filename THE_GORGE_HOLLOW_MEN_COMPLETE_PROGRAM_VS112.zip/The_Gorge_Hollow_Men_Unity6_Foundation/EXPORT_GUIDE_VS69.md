# VS69 export and setup

1. Extract the complete VS69 archive.
2. Open the project using Unity 6 (6000.x) and allow Unity to regenerate missing `.meta` files/import assets.
3. Open the existing companion/monster scene and confirm the Falcon companion prefab has the existing `AnimalCompanionController` and the scene has a `GenericToastUI` instance.
4. Ensure Falcon threat detection layers include the monster colliders and the obstruction mask is configured consistently with the companion prefab.
5. Enter Play Mode and place a living monster within Falcon detection range with clear line of sight. On first acquisition, the toast should report its archetype role, rounded distance and bearing relative to the owner's forward direction.
6. Move behind line-of-sight obstruction; no fresh report should be produced until the Falcon reacquires the monster.
7. Run `VS69AnimalScoutingIntelTests` and the full EditMode suite.

No scene or prefab is silently rewritten by this code-only phase. If the scene lacks `GenericToastUI`, scouting still compiles but its toast has no visible consumer until that UI component is present.
