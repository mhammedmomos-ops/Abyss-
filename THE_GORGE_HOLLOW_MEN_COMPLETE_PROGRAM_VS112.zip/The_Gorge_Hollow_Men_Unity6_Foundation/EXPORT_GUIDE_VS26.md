# Export Guide — VS26

1. Unity 6 URP project → copy `Assets/_Project`.
2. Packages: AI Navigation 2.0.16, Splatter.AI git dependency, Unity UI.
3. Compile + run all EditMode tests.
4. Wire gameplay Canvas (vitals, prompt, objective, resources, status, damage flash, save toast) and optional MainMenu scene.
5. Build Android/iOS only after device validation.

Cumulative VS1–VS26 mobile foundation source. Not an APK or finished game.
