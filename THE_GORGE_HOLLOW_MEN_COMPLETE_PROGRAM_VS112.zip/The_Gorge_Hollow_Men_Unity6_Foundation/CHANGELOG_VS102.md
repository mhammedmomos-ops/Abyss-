# VS102 — Tower Workforce and Production Management

## Added
- Persistent, tower-local survivor workforce records (schema v11).
- Explicit one-time survivor rescue/recruitment interaction; no paid or passive worker generation.
- Four distinct roles: Mechanic, Scavenger, Guard and Medic.
- Assignments: Idle, Production, Salvage, Guard and Rest.
- Per-tower roster capacity of eight; assignment limits of three production, two salvage and two guard workers.
- Health, injury, permanent death, fatigue, experience and skill progression.
- Injured workers are forced to Rest; workers recover fatigue over time and health while resting.
- A resting Medic accelerates health recovery for other workers at the same tower.
- Worker damage adapter implements the existing `IDamageable` contract so authored monster siege target lists can select and injure/kill workers.
- Mechanics improve production speed (maximum +45%); production retains fractional work progress across campaign saves.
- Scavengers improve rewards only when a real authored salvage node is recovered (maximum +50%); no passive resource generation.
- Guards reduce monster siege damage to their own tower structures (maximum 15%); ordinary player damage is unchanged.
- Scene actor adapter using authored NavMeshAgent and assignment targets. It never warps a worker to a destination.
- Read-only mobile workforce roster monitor and transactional assignment/damage controller.
- 18 EditMode workforce tests and one schema migration test added.

## Save compatibility
- Save schema advances from v10 to v11.
- v10 campaigns receive an empty workforce roster. Existing depots and production queues remain unchanged.
- Production jobs gain a fractional work-progress field; old jobs default to zero progress.

## Explicit boundaries
- Worker rescue points, worker prefabs/actors, NavMesh surfaces, assignment stations, UI and combat hooks require scene authoring.
- Worker damage is exposed through an `IDamageable` adapter and transactional controller. Monster target lists still require scene authoring; no automatic target discovery is claimed.
- Salvage bonus applies only when the player actually recovers an authored salvage node.
- Production continues at the existing base rate without a Mechanic; Mechanics improve, but are not required to unlock, production.
- No Unity compilation, EditMode execution, PlayMode, NavMesh bake, physics, Android or iOS build was performed.
