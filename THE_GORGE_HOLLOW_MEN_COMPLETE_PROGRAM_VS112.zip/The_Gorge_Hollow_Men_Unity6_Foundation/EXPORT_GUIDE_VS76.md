# VS76 export and setup

1. Extract VS76 archive, open in Unity 6.
2. Regenerate the vertical-slice scene (or wire a Button to CompanionCommandUI.CommandGuard and assign guardButton).
3. Select an operational companion, move to a choke point, press GUARD. Detection expands; first confirmed threat reports once.
4. Run VS76GuardPostTests.

Unity compilation and device testing were not performed in this environment.
