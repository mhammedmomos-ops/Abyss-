# Export Guide — VS34

1. Unity 6 URP → copy `Assets/_Project`.
2. Packages: AI Navigation 2.0.16, Splatter.AI, Unity UI.
3. Compile + run EditMode tests.
4. Wire music beds, hold-confirm, safe zone, damage numbers.
5. Build mobile only after device validation.

Cumulative VS1–VS34 source. Not an APK or finished game.
