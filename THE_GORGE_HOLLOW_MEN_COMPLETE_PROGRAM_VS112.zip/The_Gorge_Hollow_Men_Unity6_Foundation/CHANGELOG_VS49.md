# VS49 — Weapon Switch Hotbar, Alarm Bell, Health Delta Popup, Mantle Assist, Credits, Respawn Beacon

## Scope
VS49 adds 2-slot weapon switching, alarm bell interactable, health delta HUD popup, mantle/step-up assist, credits scroller, and respawn beacon set/respawn hooks.

## Added
- `WeaponSwitchHotbar.cs`
- `AlarmBellInteraction.cs`
- `HealthDeltaPopup.cs`
- `MantleAssist.cs`
- `CreditsScrollerUI.cs`
- `RespawnBeaconInteraction.cs`
- `BeaconRespawnHook.cs`
- `VS49MantleAssistTests.cs`
