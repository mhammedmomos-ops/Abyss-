# VS89 Export Guide

1. Extract the cumulative archive into the Unity 6 workspace, preserving `Assets/_Project`.
2. Resolve existing package/import issues and allow script compilation to finish.
3. Follow `CHANGELOG_VS88.md` for the mandatory bridge zone, both tower gateways, recovery points and NavMesh topology. VS89 does not change those rules.
4. For each intended attackable bridge support, set its `TowerStructure` kind to `Bridge`, add `MonsterBridgeSiegeTarget` beside its `TowerStructuralSegment`, and assign the correct `BridgeSpanController`. Ensure the support segment is in that controller's required-support list and the `TowerStructure` has a stable campaign identity.
5. Confirm `TowerSiegeAttacker` targets the marked support's collider/transform and has correct attack range, obstruction layers and line of sight.
6. Run the full EditMode suite. Specifically verify that stable and strained spans permit support damage, while collapsed/unconfigured spans and non-required supports reject it.
7. In PlayMode, verify that support damage persists after save/reload, causes the structural segment state to update, and can collapse the bridge. Then confirm VS88 still blocks unauthorized bridge entry and all deck spawn attempts.
8. Build and test Android/iOS only after Editor compilation, EditMode and PlayMode validation.

This is a cumulative Unity source archive, not a compiled APK/IPA or a scene-complete turnkey project. Unity compilation and runtime tests are not claimed by this export.
