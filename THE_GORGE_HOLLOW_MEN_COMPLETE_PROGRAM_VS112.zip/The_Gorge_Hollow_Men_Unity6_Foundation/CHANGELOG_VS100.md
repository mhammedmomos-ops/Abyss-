# VS100 — Campaign Logistics Intelligence and Concurrent Operations

## Added
- Read-only logistics assessment for Tower A and Tower B using local depot stock plus cargo already travelling toward each destination.
- Reserve-based shortage scoring for scrap, timber, ammunition and medical supplies, with Stable / Monitor / High / Critical priority bands.
- Active inter-tower transfer slot accounting and a hard cap of three simultaneous transfers.
- Dispatch preflight now rejects a fourth transfer before source stock is debited.
- Mobile-friendly logistics overview panel showing tower priority, inbound transfer count, active operations and remaining slots.
- Nine EditMode regression tests covering concurrency, status filtering, inbound cargo, priority ordering, null state and overflow-safe assessment.

## Preserved
- Save schema remains v9: no new persistent fields were necessary because the plan is derived from existing authoritative depot and convoy records.
- Dispatch remains an explicit player/system action; the planner never creates a convoy or moves inventory.
- Physical route, live bridge traversability, source debit, destination-only credit and destruction/collapse cargo loss remain governed by existing VS97/VS98 systems.
- Monster bridge access and the fatal bridge-collapse rule are unchanged.

## Configuration
Attach `SupplyCampaignLogisticsPanel` to a mobile Canvas object. Assign `GameBootstrap`, `towerPriorityLabel`, and `operationsLabel`. The component is read-only and refreshes on an interval; no scene or prefab is included.
