# VS19 third-party research and reuse

## Unity built-in pooling

- Official Unity 6 `UnityEngine.Pool.ObjectPool<T>` API: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/pool/objectpool1
- Official Unity performance guidance on pooling and reuse: https://docs.unity.com/en-us/engine/6000.3/manual/analysis/performance-memory/managed-memory/optimizing-code-managed-memory/reusable-code
- Decision: reuse the engine-provided pool rather than introduce a third-party pool package. The API lives in UnityEngine.CoreModule and adds no package dependency.
- Adaptation: the project-specific emitter supplies authored prefab creation, pool callbacks, prewarm, per-emitter active caps, lifetime return, physics reset and collapse-event integration.

## Unity AI Navigation

- Official Unity 6 NavMeshObstacle reference: https://docs.unity.com/en-us/engine/6000.5/script-reference/unityengine/ai/navmeshobstacle
- Official AI Navigation 2.0 obstacle guidance: https://docs.unity.cn/Packages/com.unity.ai.navigation%402.0/manual/AboutObstacles.html
- Decision: keep using the project's existing AI Navigation dependency and VS18's pre-authored static obstacle activation. Do not enable NavMesh carving on every moving debris fragment; Unity documents carving recalculation and a performance-aware stationary/moving distinction.

## Code provenance

No third-party source code was copied. VS19 uses Unity's documented built-in APIs and original GorgeHollow integration code. No new external package was added.
