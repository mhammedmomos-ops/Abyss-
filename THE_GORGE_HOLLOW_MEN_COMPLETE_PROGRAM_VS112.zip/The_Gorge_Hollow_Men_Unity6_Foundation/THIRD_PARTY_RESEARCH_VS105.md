# VS105 Third-Party Research

## Unity serialization guidance reviewed
- Unity 6 Serialization best practices: https://docs.unity.com/en-us/engine/6000.6/manual/programming-environment/code-reload-serialization/script-serialization/best-practices
- Unity 6 serialization rules: https://docs.unity.com/en-us/engine/7000.0/manual/programming-environment/code-reload-serialization/script-serialization/rules
- Unity scripting formatting/serialization guidance: https://unity.com/how-to/formatting-best-practices-c-scripting-unity

## Applied decisions
- Keep the persisted relationship model flat and small: stable worker IDs plus bounded scalar values.
- Avoid nested graph references and cyclic object graphs in campaign serialization.
- Do not duplicate cached relationship data in worker records; the campaign relationship ledger is the single source of truth.
- Use deterministic, explicit event calls rather than per-frame polling or random social simulation.

## Reuse and licensing
No third-party source code or assets were copied. The implementation uses the project's existing Unity/C# and NUnit dependencies. Unity documentation was used as design guidance, not imported code.
