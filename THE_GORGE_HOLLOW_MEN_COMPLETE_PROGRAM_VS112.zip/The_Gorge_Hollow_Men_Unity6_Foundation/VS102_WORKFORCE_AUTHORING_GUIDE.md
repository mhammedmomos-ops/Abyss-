# VS102 Workforce Authoring Guide

## 1. Rescue survivor scene objects
1. Place a survivor GameObject at a believable rescue location inside the tower-side playable area.
2. Add `WorkerRescueInteraction` and configure a unique stable `workerIdentity` (never reuse an identity for another person), display name, `towerId`, role and starting skill.
3. Add `TowerWorkerActor` to the same GameObject and assign it to the rescue interaction's `workerActor` field.
4. Add a NavMeshAgent, `TowerWorkerDamageable` and a visible character model/Animator. The actor script does not create or animate a character.
5. Assign the `TowerWorkerDamageable` reference on `WorkerRescueInteraction`. The rescue interaction binds the stable identity to both actor and damage adapter.
6. Keep the survivor object active before rescue. The actor deliberately remains visible when no workforce record exists; after recruitment it binds to the persistent record.
7. The interaction is one-time. Repeated interactions cannot recruit the same identity twice.

## 2. Assignment stations
Create a destination Transform for each assignment at each tower:
- Production: workshop/workbench.
- Salvage: sorting/recovery area.
- Guard: authored defensive post.
- Rest: bunk/medical area.

Assign these Transforms to `TowerWorkerActor`. Bake a NavMesh for the safe walkable tower area and confirm the agent is placed on it. The actor calls `NavMeshAgent.SetDestination`; it does not use `Warp` or teleport. If the agent is not on a baked NavMesh or the target is unassigned, it will remain stopped.

## 3. Workforce commands
1. Add one `TowerWorkforceController` to the scene.
2. Connect mobile UI command buttons to `Assign(workerIdentity, assignment, out error)` through a small UI adapter or UnityEvent-compatible wrapper.
3. Present the returned error to the player; do not optimistically change the UI before a successful save.
4. Add `TowerWorkforceMonitor` and assign two Text labels to show Tower A/B workforce health, fatigue, skill and assignments.
5. Maximum eight living workers per tower. Maximum three production, two salvage and two guard assignments per tower. Rest and Idle have no assignment slot cap.

## 4. Role effects
- **Mechanic:** while assigned Production, increases tower production speed by up to 45% in total. No Mechanic means the original base production speed remains.
- **Scavenger:** while assigned Salvage, adds a skill-scaled bonus (capped at 50%) only when the player actually recovers a salvage node. It does not create supplies over time.
- **Guard:** while assigned Guard, reduces monster siege damage to structures belonging to that tower by up to 15% in total. It does not reduce ordinary player damage.
- **Medic:** while assigned Rest, improves health recovery for other workers resting at the same tower. A Medic is not an automatic combat healer.

## 5. Injury, fatigue and death
- Active work adds fatigue; Guard duty accumulates it fastest, Salvage next, Production slowest.
- Rest reduces fatigue. Health regenerates while resting; a resting Medic accelerates recovery for other workers.
- Below 30 HP, a worker becomes Injured and is forced to Rest until health reaches 30 again.
- At 0 HP, a worker becomes permanently Dead. The record remains in the campaign and cannot be reassigned or recruited again under the same identity.
- To make workers attackable by monsters, include their worker Transform in the appropriate `MonsterAIController.siegeTargets` array. `TowerSiegeAttacker` already supports generic `IDamageable` targets, and `TowerWorkerDamageable` routes damage through the transactional workforce controller. This is explicit scene targeting; workers are not automatically added to every monster target list. Do not apply area damage to every worker by default.

## 6. Mobile UI
Use a compact roster panel per tower. Keep commands touch-sized and show the selected worker's role, health, fatigue, skill, current assignment and injury/death status. Provide confirmation for dangerous assignments if the worker is already fatigued. Avoid updating UI every frame; the monitor refreshes at a configurable interval.

## 7. Save migration
Schema v10 automatically migrates to v11 with an empty workforce. Existing tower depot balances and queued production jobs are retained. Existing production jobs begin with zero fractional progress.
