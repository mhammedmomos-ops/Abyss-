# VS11 — Archetype-Specific Tactical Decision Profiles

## Added
- Added immutable branch-priority profiles for Stalker, Brute, Skirmisher and Lurker roles.
- Kept direct visual contact as the highest-priority branch for every role.
- Brutes prioritize structural siege over squad-shared contact; Lurkers prioritize nest defence and local investigation; Stalkers prioritize shared contact; Skirmishers prioritize contact and investigation before siege.
- Added role-specific pursuit speed and flank-radius tuning.
- Split direct sight and squad-shared contact into separate behaviour-tree leaves while preserving the existing `TickContact()` compatibility method.
- Kept Splatter.AI as the behaviour-tree scheduler/composite implementation; retained existing perception, movement, combat, learning, nest and campaign systems.
- Added four EditMode regression tests for role priorities and shared profile immutability.

## Compatibility
- Existing archetype assets remain valid; the existing four `MonsterArchetypeRole` enum values are unchanged.
- Existing squad coordinator callers retain the original four-argument `GetFlankDestination` overload.
- No save schema changes.

## Not implemented
- Distinct monster animation controllers, mesh/rig assets, unique attack move sets, advanced cover/line-of-sight flanking, trap disarm/avoidance, or campaign-persistent learned tactics.
- The tactical profiles currently use the same underlying perception and combat components with role-specific priorities and tuning.
