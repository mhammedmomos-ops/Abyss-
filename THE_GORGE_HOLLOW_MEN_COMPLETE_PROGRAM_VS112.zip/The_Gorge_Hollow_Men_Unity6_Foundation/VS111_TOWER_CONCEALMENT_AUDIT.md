# VS111 Integration Audit — Tower Structure Concealment

## Source of truth
Built cumulatively from `THE_GORGE_HOLLOW_MEN_COMPLETE_PROGRAM_VS110.zip` after inspecting its local access tracker, worker visibility implementation, and greybox scene generator.

## Existing problem
VS110 filtered local workforce and depot information and hid remote worker actors, but it explicitly left the remote tower's structure renderers visible. That meant a player could still inspect the other tower visually from across the gorge.

## Changes
1. Added a fail-closed policy allowing only the exact local tower ID to render detailed tower presentation.
2. Added a scene controller that applies the policy to every Renderer, Canvas, Light, and AudioSource beneath each tower root.
3. Used `Renderer.forceRenderingOff` rather than changing `Renderer.enabled`, so authored enabled states and independent renderer control are preserved.
4. Disabled world-space canvases and lights and muted audio belonging to the remote tower.
5. Configured the generated greybox scene to create and wire the controller.
6. Added seven EditMode policy/access tests covering both tower directions, no local tower, invalid IDs, exact matching, platform-corner access, bridge-edge rejection, and vertical bounds.
7. Replaced the generated scene's circular 8.5m local access test with a platform-footprint check so the player does not lose their own tower visibility in courtyard corners. The bridge begins immediately beyond the tower platform boundary.

## Compatibility checks
- No save schema change; VS110's v15 remains current.
- Existing local workforce, supply, and worker command restrictions remain in place.
- Worker campaign records and background campaign simulation are untouched.
- Worker actors remain governed by their existing local presentation logic; the tower-root controller adds a second visual concealment layer.
- Bridge/gorge environment roots are not assigned to either tower root, so the bridge and gorge remain visible.
- No worker bridge access, cross-gorge worker routes, or enemy bridge rules were changed.

## Risks and limitations
- All detailed tower presentation must remain parented beneath the appropriate tower root. Runtime-created child renderers after `Awake` are not automatically cached.
- Outside both tower access radii, both detailed tower structures are hidden. This is deliberate: the player has no local tower access context there.
- This does not implement line-of-sight visibility for unrelated objects outside tower roots.
- This is client presentation only. Future multiplayer needs server-side information authorization and per-player replication filtering.
- Unity camera/render-pipeline behavior, shadows, light contribution, and spatial audio must be verified in the Editor and on target devices.

## Verification performed
- C# lexical delimiter scan.
- JSON/asmdef/asmref parsing.
- Source assertions for generator wiring, fail-closed policy, renderer force-off usage, and no save-version changes.
- ZIP duplicate-path and CRC integrity checks.

Unity compilation and tests were not run.

## Explicitly unresolved information leaks
- Campaign `CampaignPhase` remains global. Existing phase-driven raid banners, threat meters, campaign status labels, and some audio cues may reveal that a raid is active even if its target is the other tower.
- Monster actors are not all parented beneath either tower root, so this phase does not guarantee that every enemy at the remote tower is concealed.
- These require a dedicated per-tower threat/observation model. Do not treat VS111 as complete information isolation until that work is done.
