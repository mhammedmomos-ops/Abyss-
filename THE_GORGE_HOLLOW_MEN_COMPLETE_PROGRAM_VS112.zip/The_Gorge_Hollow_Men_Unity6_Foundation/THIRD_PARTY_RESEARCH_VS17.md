# VS17 third-party research — structural damage and mobile destruction

Research date: 2026-11-03

## 1. OpenFracture
- Repository: https://github.com/dgreenheck/OpenFracture
- Licence: MIT (`LICENSE.md` in upstream repository).
- Documented capabilities: editor/runtime mesh slicing and fracturing, convex/non-convex closed meshes, asynchronous runtime fracturing, configurable fragment count, custom inside material.
- Documented limitations relevant to this game: multiple submeshes unsupported; skinned meshes unsupported; physics joints are destroyed and not transferred; localized impact fracturing unsupported; source geometry must be closed and non-self-intersecting.
- Decision: evaluated, not added. Tower assemblies will likely contain separate materials, joints, hinges and localized weak points. The documented limitations make it a poor direct fit without splitting/preparing assets and writing extra integration. Avoid adding it as a dependency before tower meshes exist.

## 2. Unity Mesh Fracture by sinanata
- Repository: https://github.com/sinanata/unity-mesh-fracture
- Licence: MIT (`LICENSE` in upstream repository).
- Documented capabilities: pure-C# Voronoi fracturing; pre-bake cache; cooked convex collider meshes; CPU simulation by default; optional Unity physics; progressive fragment spawning; tested against Unity 6 and a cross-platform game that ships on iOS and Android.
- Documented trade-offs: URP-oriented material setup; fragment objects are temporary; no persistent debris; heavy stacks of breakables are not the intended use; each fragment is a GameObject with renderer and optional physics components.
- Decision: evaluated, not added in VS17. The repository's pre-bake approach is a good candidate for a later optional one-shot debris effect, but the project currently has no confirmed URP pipeline or actual tower mesh/material assets to integrate and profile. Do not introduce an unused runtime dependency.

## 3. Unity built-in approach selected for VS17
- Use existing campaign structure health as the single source of truth.
- Use ordinary C# events to notify components when that health changes.
- Use authored intact/damaged/critical/destroyed visual groups and GameObject activation rather than generating mesh fragments at runtime.
- Use `ParticleSystem` only as an optional one-shot transition effect.
- Use existing Unity object activation and the existing repair service; no duplicate health records or new persistence schema.

## 4. Mobile performance guidance
Unity's official architecture guidance recommends pooling recurring GameObjects rather than repeatedly instantiating/destroying them, and Android's Unity guidance similarly recommends object pools for recurring gameplay elements. VS17 does not yet spawn debris; therefore it avoids adding a debris pool until a concrete debris lifecycle exists.

## Sources
- OpenFracture repository and MIT licence: https://github.com/dgreenheck/OpenFracture
- OpenFracture README limitations: https://github.com/dgreenheck/OpenFracture
- Unity Mesh Fracture repository and MIT licence: https://github.com/sinanata/unity-mesh-fracture
- Unity Mesh Fracture architecture, pre-bake and trade-offs: https://github.com/sinanata/unity-mesh-fracture
- Unity object pooling and architecture guidance: https://unity.com/how-to/advanced-programming-and-code-architecture
- Android Unity game memory/performance guidance: https://developer.android.com/games/engines/unity/start-in-unity

No third-party source files were copied into the project in VS17. The new components are project-specific integration glue around Unity's built-in event and GameObject systems.
