# VS71 third-party research and reuse decision

Research confirmed that no external library is required for a timed defensive state, stamina cost, damage multiplier and cooldown.

- Unity 6 timing uses the existing project `Time.time` pattern already employed by brace, lure, forage and scent systems.
- Damage mitigation continues to flow through the existing companion injury path and `AnimalBehaviourBase.ApplyInjury`.
- UI wiring reuses the established `CompanionCommandUI` + vertical-slice generator pattern introduced for TrackScent and Lure.

Decision: no external library or third-party source code was added. The feature is implemented with original project rules, the existing NavMeshAgent stop/hold pattern, and the project's mobile toast/haptic feedback helpers. This keeps package weight and licensing surface unchanged.
