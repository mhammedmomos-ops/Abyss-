# VS51 Integration Audit Report

## Scope
Static inspection of the uploaded VS50 cumulative archive, its scripts, package manifest, assembly definitions, test source, README, changelogs and declared verification boundary.

## Findings addressed
0. **Runtime assembly boundary was incorrectly scoped:** `GorgeHollow.Runtime.asmdef` sat inside `Scripts/Core`, so only Core and its descendants belonged to that assembly. Core code references scripts in sibling folders, and the custom test assembly references the runtime assembly. Relocated the runtime asmdef to `Scripts/` so all game runtime folders compile together and the test assembly can reference the complete runtime API.
1. **New Game transaction mismatch:** old code wrote a new save through `CampaignSaveService` without replacing the live `GameBootstrap.Campaign` and `Clock`; it also continued scene loading even if the save failed. Fixed with `TryStartNewCampaign` and a canonical factory.
2. **Bridge-fall persistence gap:** player/animal fall damage and animal death changed runtime records but did not save those campaign-critical consequences. Fixed to persist after landing; animal records are upserted into the campaign roster by stable identity, with duplicates rejected.
3. **Initialization ordering risk:** multiple scene consumers resolve `GameBootstrap` in `Awake`; Unity does not otherwise guarantee which object's `Awake` executes first. Added `DefaultExecutionOrder(-1000)` to the bootstrap.
4. **Package setup omission:** source uses uGUI and its test assembly requires Unity Test Framework, but the package manifest did not declare either. Added explicit dependencies and clarified manifest merge instructions.
5. **Main-menu New Campaign placeholder:** the existing button did not actually reset the campaign. It now uses the same save-first operation as the gameplay reset service.
6. **False Continue availability:** a new in-memory campaign receives an ID even when no save exists. The menu now checks the validated primary/backup files instead of the in-memory ID.
7. **Corrupt-primary save blockage:** saving previously failed whenever the primary was corrupt, even if a valid backup existed. Promotion now preserves that verified backup and allows a new commit.
8. **Newer-schema overwrite risk:** an older build must not overwrite primary or backup data from a newer save schema. Save now checks both files and refuses the downgrade.
8. **Newer-schema overwrite risk:** a save created by a newer build must not be replaced by an older build. Save now checks both primary and backup schema versions before committing.

## Baseline retention
- All 443 VS50 file contents are accounted for.
- 442 original paths remain unchanged; 9 original files were modified; the original runtime `.asmdef` was relocated (content preserved) to the Scripts root.
- 10 additional VS51 source/test/documentation files were added; final archive contains 453 files.

## Static checks performed
- Archive integrity check.
- Retention comparison against VS50.
- JSON parse for package manifest and assembly definitions.
- Duplicate type declaration scan (the three `CampaignEvents` declarations are intentional partial classes).
- C# delimiter balance scan after removing comments and string/character literals.
- New campaign factory, animal-record upsert, save-availability and backup-recovery test cases added to the EditMode suite (not executed).
- Animal record upsert rules and duplicate-identity handling covered by new EditMode tests.
- Fall persistence call-site and save-service wiring review.
- Manifest dependency and assembly-reference cross-check.
- Runtime/test assembly folder-scope check: one root runtime asmdef, one nested EditMode test asmdef, no nested runtime asmdef.

## Not performed
Unity Editor was not available in this environment. No Unity Package Manager resolution, C# compilation, EditMode/PlayMode test execution, scene/prefab integration, NavMesh bake, physics simulation, Android/iOS build, or device test was performed.

## Remaining audit risks
- Splatter.AI Git URL is not pinned to a commit.
- `MonsterNestPersistenceService` and other scene services still depend on authored scene wiring; execution order reduces but does not eliminate missing-reference/configuration errors.
- Bridge-fall recovery still requires a valid floor or authored recovery anchor; a player/animal can remain in an unbounded fall if the level has no landing surface.
- PlayerPrefs-backed settings are not secure storage and must not contain sensitive data.
- VS50 stubs/placeholders and unconnected gameplay helpers remain; see README and prior changelogs.
