# VS72 third-party research and reuse decision

No external library is required for a timed command state, move-speed/detection multipliers or a one-shot confidence bonus.

- Movement and perception continue to use the project's existing NavMeshAgent and Physics.OverlapSphereNonAlloc patterns.
- Threat confidence still flows through AnimalBehaviourBase.EvaluateThreat.
- UI wiring reuses the established CompanionCommandUI + vertical-slice generator pattern.

Decision: no external library or third-party source code was added. The feature is original project rules layered on the existing companion controller and stimulus bus.
