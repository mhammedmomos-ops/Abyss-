# VS56 — Player-selected companion framework

## What changed
- Replaced the dog-first implementation direction with a species-agnostic companion actor. The active pet comes from the campaign-selected `AnimalRecord`; its custom `displayName` is used by the command HUD.
- Added `AnimalBehaviourFactory` for the four approved roster entries only: German Shepherd, Falcon, Pangolin and Cat.
- Added distinct species tuning profiles for movement, detection, attack support, threat-confidence weighting and injury mitigation: German Shepherd direct protector, Falcon broad local detection, Pangolin most resilient, Cat faster reconnaissance. These are gameplay tuning differences, not four additional breeds or species.
- Implemented Follow, Stay, Search, Alert and Protect command handling in a shared NavMesh companion controller. Return returns to Follow. Retrieve remains a safe Follow fallback until a world-item retrieval contract exists.
- Added local collider/line-of-sight threat scanning against existing `MonsterAIController` + `DamageableHealth` actors. The companion does not receive omniscient monster locations.
- Added bounded pet name validation (1–24 characters), persistent custom naming, species-specific campaign roster reuse, and permanent-death reselection prevention.
- Updated the Editor greybox scene generator to create a generic companion actor, four species-selection buttons, custom-name input, confirmation flow and six-command mobile bar. The player can choose any approved pet; it saves through `GameBootstrap` before binding the live actor.
- Companion experience, stamina recovery and injury/death changes are coalesced into campaign saves (10-second dirty-save interval, immediate injury/death save, flush on disable).
- Campaign validation now rejects undefined species/lifecycle enums and out-of-range animal statistics.
- Added VS56 EditMode source tests covering all species, naming, reuse, permanent death and profile availability.

## Important implementation boundary
The actor uses Unity AI Navigation `NavMeshAgent`, which requires a baked NavMesh and a valid agent placement. The current actor is a functional framework and combat/support prototype, not a finished animal presentation: no authored animal meshes, species animation controllers, sound sets, flight locomotion for Falcon, pangolin roll/defensive animation, cat stealth animation, pet-specific needs UI, or polished selection scene are included. Falcon currently uses the same ground NavMesh locomotion substrate with a faster/wider scouting profile; true flight requires a separate aerial navigation layer.

## Save compatibility
No campaign save version increment. Existing `AnimalRecord` fields remain intact. The added validation is stricter for invalid enum values/statistics; valid existing records remain compatible.
