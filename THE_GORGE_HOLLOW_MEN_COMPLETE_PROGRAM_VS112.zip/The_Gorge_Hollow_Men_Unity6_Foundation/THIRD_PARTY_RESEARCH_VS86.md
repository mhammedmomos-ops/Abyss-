# VS86 Third-Party Research Notes

Research performed before implementation; Unity's documented APIs and existing project systems were preferred over introducing a new dependency.

## References
- Unity 6 `NavMeshAgent.CalculatePath`: https://docs.unity.com/en-us/6000.3/ScriptReference/AI.NavMeshAgent.CalculatePath — synchronous path calculation can affect frame time; relevant to the bounded path-selection patterns already used by VS85. VS86 does not add path calculations.
- Unity 6 `NavMeshAgent.SetDestination`: https://docs.unity.com/en-us/6000.5/ScriptReference/AI.NavMeshAgent.SetDestination — destination requests may remain pending for several frames; VS86 avoids adding new movement requests.
- Unity 6 `NavMeshObstacle`: https://docs.unity.com/en-us/6000.7/ScriptReference/UnityEngine/AI/NavMeshObstacle — moving obstacles primarily use local avoidance unless carving is enabled; VS86 does not add obstacle carving or alter navigation.
- Unity Technologies AI Navigation implementation guidance: https://github.com/Unity-Technologies/skills/blob/main/skills/initialize-ai-navigation/references/navigation-system.md — reinforces avoiding conflicting Rigidbody/NavMeshAgent movement ownership and using obstacle carving selectively.

## Reuse decision
VS86 reuses the project's existing `AnimalCompanionController` combat events, `MonsterAIController` target identity, `HitscanWeapon` damage pipeline, and EditMode assembly. No third-party runtime package was needed for this phase. The Unity references were reviewed for compatibility/performance context; the new work is a lightweight session rules/state layer rather than a new navigation system.
