# VS69 integration audit

## Integration path
`AnimalCompanionController.ScanThreats` remains the authority for local threat acquisition. It performs the existing non-alloc overlap scan, validates a live monster and confirms unobstructed line of sight. On a newly acquired threat, the Falcon now reads the target's `MonsterAIController.ActiveRole`, builds an `AnimalScoutingReport`, and sends a toast through the existing `GenericToastUI`.

## Safety / regression review
- No additional physics scan or per-frame work was introduced.
- Reports occur only on a change from the previously selected threat, not on every scan tick.
- No global enemy positions, target locks, or persistent records are created.
- Null owner/target inputs are safe in the pure report rules.
- Unknown/missing monster controller falls back to the existing Stalker role label; normal monster prefabs are expected to carry the controller.
- The feature does not modify NavMesh movement, animal health, hunger, stamina, bond, experience, save schema, monster AI or campaign progression.
- Existing non-Falcon species behavior is unchanged.

## Known limits
- The report uses the owner's facing direction as the bearing reference; it does not claim a compass heading.
- The toast is an acquisition-time snapshot and can become stale after the monster moves out of sight.
- GenericToastUI must exist in the active scene for the report to be visible.

## Test status
Three NUnit EditMode test methods were added. They are included but have not been executed because a Unity Editor/test runner is unavailable in this environment. Static checks do not substitute for Unity compilation or runtime verification.
