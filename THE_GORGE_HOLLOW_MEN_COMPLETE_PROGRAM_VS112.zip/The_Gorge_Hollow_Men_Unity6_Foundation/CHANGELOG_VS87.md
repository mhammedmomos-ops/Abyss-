# VS87 — Adaptive Enemy Response to Repeated Companion Decoys

## Design
VS86 introduced companion/player coordination, but enemy monsters still accepted repeated animal decoys with the same investigation duration. VS87 adds bounded, local learning so an enemy becomes less susceptible to a repeatedly reused decoy without gaining hidden information or global awareness.

## Added
- `MonsterLearningMemory` records accepted animal-distraction observations by source GameObject identity.
- Learning is limited to the same source and a rolling 60-second interval; a different source or expired interval starts a fresh sequence.
- First and second accepted decoys retain the existing 5.5-second investigation duration and 0.9 movement-speed multiplier.
- Third and fourth accepted decoys from the same source are treated as suspicious: investigation duration drops to 2.25 seconds and movement returns to base speed.
- Fifth and later accepted decoys from that same source are ignored; the monster preserves its current combat commitment rather than cancelling an attack to investigate.
- Existing hearing range, obstruction checks, and acceptance cooldown remain the gate before learning is updated.
- Added six VS87 EditMode test methods covering response tiers, source separation, learning-window reset, invalid inputs, and memory clearing.

## Compatibility / balance boundaries
- No campaign save schema, animal record, companion command, species roster, or mobile control changes.
- Learning is per-monster runtime memory and is not persisted across sessions.
- The rule is deterministic and bounded; it is not machine learning and does not reveal animal/player positions beyond stimuli the monster already perceived.
- Changing companion source resets the same-source sequence. A 60-second gap also resets it.
- The fifth-decoy threshold is deliberately conservative so companions remain useful when changing tactics or during longer encounters.
