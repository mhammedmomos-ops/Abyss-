# VS68 Export and Setup Guide

1. Open the cumulative project in Unity 6 using the existing `Packages/manifest.json`.
2. Run the existing vertical-slice scene generator if you need a fresh generated scene; its companion actor now receives an AudioSource and `AnimalCompanionAudioFeedback`.
3. Select the generated companion actor prefab/object. In `AnimalCompanionAudioFeedback`, populate the species cue sets for German Shepherd, Falcon, Pangolin and Cat. Do not assign a different species' vocalizations to fill empty slots.
4. Use mono recordings for positional animal vocalizations where practical. Set import compression, sample rate and load type according to clip duration and target device memory.
5. Tune AudioSource min/max distance and volume against the actual world scale, then route through an AudioMixer when the project mixer and accessibility controls are ready.
6. Missing clips are optional and will be skipped without affecting gameplay.
7. Run Unity compilation, EditMode tests, scene generation, PlayMode audio checks and Android/iOS device checks before treating this as verified.

The project does not include audio recordings.
