# VS86 — Companion/Player Combat Coordination

## Design decision
The VS85 source architecture binds one active companion actor to the player at a time (`CompanionCommandRelay.BindSelected` and the campaign's active-companion flush path). VS86 therefore implements meaningful companion/player teamwork rather than falsely assuming all four animals are simultaneously present in the scene.

## Added
- `AnimalTeamworkRules`: pure species-to-role mapping and bounded, deterministic damage-window rules.
- `AnimalTeamworkState`: session-only, per-monster coordination ledger. It validates the exact target Transform, expires after five seconds, prunes expired entries, and never writes campaign data.
- Shepherd contribution when its confirmed attack-support action lands.
- Falcon contribution when its confirmed-threat distraction pulse is emitted.
- Pangolin contribution when its Guard Post confirms and reports a threat.
- Cat contribution when Stalk first acquires a threat or its active Lure emits a distraction pulse.
- Player hitscan follow-through receives an 8% damage increase against that exact monster during the short companion-created opening. The effect does not stack with repeated pulses or increase damage against another target.
- A one-time toast when a companion first opens the follow-through window.
- Twelve VS86 EditMode test cases across nine test methods.

## Compatibility and boundaries
- No changes to campaign save schema, animal record fields, species roster, command enum, or existing mobile controls.
- One active companion remains the current scene contract; the player is the second half of the teamwork loop.
- The coordination ledger is transient and target-scoped. It is intentionally not saved across sessions.
- Existing weak-point callout damage bonus remains independent and may combine multiplicatively with the coordination window.
- No monster AI target-selection or monster damage-received rules were changed.
