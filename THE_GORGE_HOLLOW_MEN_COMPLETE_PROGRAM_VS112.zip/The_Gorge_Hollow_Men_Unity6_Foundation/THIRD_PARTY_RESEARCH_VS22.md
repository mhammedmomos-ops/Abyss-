# VS22 Third-Party Research and Reuse

Research performed before implementation:

1. Unity 6.0.7 documentation describes `UnityEngine.Pool` as the built-in reusable-object API. VS22 does not need a new pooling dependency; it reuses the project's existing Unity runtime and does not allocate debris or temporary objects during a fall. Source: https://docs.unity.com/en-us/engine/6000.7/manual/analysis/performance-memory/managed-memory/optimizing-code-managed-memory/reusable-code
2. Unity's AI Navigation guidance describes `NavMeshAgent` use, path replanning, NavMesh links, and the incompatibility of simultaneously moving an object with an enabled NavMeshAgent and a non-kinematic Rigidbody. VS22 temporarily disables an assigned companion agent during a Rigidbody fall and only re-enables it after a successful NavMesh sample. Source: https://github.com/Unity-Technologies/skills/blob/main/skills/initialize-ai-navigation/references/navigation-system.md
3. Unity Learn's Unity 6 object-pooling tutorial reinforces that pooling should be profiled and not applied indiscriminately. VS22 introduces no new object pool because fall handling is event-driven and does not repeatedly instantiate transient objects. Source: https://learn.unity.com/tutorial/65df850fedbc2a082fb11029
4. Unity's mobile optimisation documentation cautions that physics and mesh colliders can be costly on mobile. VS22 uses the existing CharacterController or one Rigidbody per physical companion, a single trigger occupancy volume per bridge, and no runtime mesh or joint generation. Source: https://docs.unity.cn/Manual/iphone-Optimizing-Physics.html

No third-party source code was copied into VS22. The new fall rules and integration components are original project code using Unity built-in APIs and the project's existing `PlayerVitals`, `AnimalRecord`, `CampaignEvents`, and `BridgeSpanController` contracts.
