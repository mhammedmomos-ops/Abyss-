# VS57 third-party research and reuse decision

## Research reviewed
- Unity 6 `NavMeshAgent` scripting reference: https://docs.unity.com/en-us/6000.0/script-reference/UnityEngine/AI/NavMeshAgent.html
- Unity AI Navigation `NavMeshAgent` component reference: https://docs.unity.cn/Packages/com.unity.ai.navigation%401.1/manual/NavMeshAgent.html
- Unity AI Navigation system reference material: https://github.com/Unity-Technologies/skills/blob/main/skills/initialize-ai-navigation/references/navigation-system.md

## Decision
The project already uses Unity AI Navigation and its existing monster wind-up event path. Reusing the current `NavMeshAgent` movement and attack events is safer than importing a second companion/combat framework. The new retaliation logic is original project integration code and uses pure targeting gates so it can be tested independently of scene physics.

No third-party source code was copied and no package dependency was added. Unity documentation is used as API/architecture guidance; it does not imply runtime compatibility has been verified in this project.
