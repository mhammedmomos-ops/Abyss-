# VS108 — Worker scene integration and tower-local navigation

## Implemented
- The greybox scene generator now retains both generated tower roots and creates a `TowerWorkerSpawnDirector` wired to the campaign bootstrap and both towers.
- Each tower receives four explicit work destinations: Production, Salvage, Guard and Rest. Each set is parented beneath its own tower root and placed inside that tower courtyard.
- Worker actors receive their correct tower-local target set when spawned or discovered as pre-authored actors.
- Greybox capsule workers now receive a configured `NavMeshAgent`; authored worker prefabs receive one if missing. Agents are configured for slower human-scale movement, have automatic Off-Mesh Link traversal disabled, and exclude the built-in `Jump` NavMesh area.
- The generated bridge root receives a `NavMeshModifier` that marks its geometry as `Jump` for baking. Non-worker agents retain their normal area masks; worker agents cannot route across the bridge even if the baked surface connects both towers.
- Injured workers route to their tower's rest point without overwriting an active tactical destination.
- Worker actor binding, target configuration and bridge-area exclusion have three new EditMode regression tests.
- No save schema change. Existing worker records, identities and v14 saves remain compatible.

## Boundaries
- The generated scene still requires NavMeshSurface baking in Unity Editor. A worker whose agent is not bound to a baked NavMesh remains visible but will not move.
- The capsule is a greybox visual, not a finished human model or animation rig.
- Worker destinations are authored per tower and do not create bridge routes. Worker Off-Mesh Link traversal is disabled. The game still requires in-Editor path and physics validation before claiming navigation safety.
- Work destinations are positional staging points. Full work animations, contextual tools, task loops and player-issued movement commands remain future work.
- No Unity compilation, EditMode/PlayMode execution, NavMesh bake, physics validation, Android/iOS build or device test was performed for this archive.

## Save migration addition
- Save schema advances from v14 to v15.
- A legacy campaign with no recorded worker identity receives the four-person starting roster during the one-time migration.
- Any campaign containing at least one recorded worker preserves its complete roster, including injured, captured and dead records; no starter duplication occurs.
- The v10 migration regression expectation is updated to reflect the eventual v15 migration. Two additional migration tests cover empty and existing v14 rosters.

## Regression suite alignment
- Updated older workforce, morale, relationship and cooperation tests to construct an explicitly empty roster when testing recruitment or isolated worker-pair behaviour. The campaign factory collection-independence test now also checks the worker and relationship lists. This prevents the VS107 starting roster from contaminating test assumptions.
- Updated the legacy v10 migration expectation and v13 relationship migration assertions for the v15 starter-roster migration.
