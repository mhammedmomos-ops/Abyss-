# VS107 Workforce Authoring Guide

## New campaign opening roster

`CampaignStateFactory.CreateNew()` creates this persistent opening workforce:

| Tower | Worker | Role | Initial assignment |
|---|---|---|---|
| Tower A | Mara | Mechanic | Production |
| Tower A | Tunde | Guard | Guard |
| Tower B | Nia | Mechanic | Production |
| Tower B | Jonah | Guard | Guard |

All begin Active, at 100 health, 0 fatigue, skill 25, morale 70, loyalty 50, stress 0, and Balanced personality. Their IDs are stable within the campaign. Each tower retains six recruitment spaces under the current capacity of eight.

## Make workers visible in a gameplay scene

1. Create or identify a root Transform for Tower A and another for Tower B. The roots should be positioned inside their respective tower safe areas, not on the bridge.
2. Add `TowerWorkerSpawnDirector` to a scene-level GameObject.
3. Assign the scene's `GameBootstrap` if automatic lookup is not desired.
4. Assign `towerARoot` and `towerBRoot`.
5. Optionally assign a `TowerWorkerActor` prefab. Without one, the director creates role-tinted capsule placeholders.
6. Adjust `localSpawnOrigin` and `spawnSpacing` so actors appear on safe, walkable floor clear of doors, defenses, and interaction volumes.
7. If using a moving worker prefab, include a configured `NavMeshAgent` and `TowerWorkerActor`, then assign its Production, Salvage, Guard, and Rest target Transforms. Bake the NavMesh for the tower floors.
8. Enter Play Mode with a new campaign and confirm two actors appear at each tower. Load a saved campaign and confirm the saved roster appears without duplication.

## Recruitment and lifecycle

- Survivor recruitment still uses `WorkerRescueInteraction`; successful recruitment now publishes a campaign replacement event for the spawner.
- Worker actors are keyed by stable worker identity, not display name or list index.
- Dead and captured workers are hidden without disabling the actor's update loop. A released captive can therefore become visible again while preserving identity.
- Do not put worker spawn points on the bridge. Workers remain assigned to exactly one tower and have no bridge traversal authorization.

## Visual quality

The capsule fallback is deliberately a development placeholder. Replace it with an authored low-poly character prefab after the gameplay camera scale, animation rig, equipment silhouettes, and mobile rendering budget are settled. Use one shared material/texture set where possible and keep skinned-mesh bone counts modest for mobile.
