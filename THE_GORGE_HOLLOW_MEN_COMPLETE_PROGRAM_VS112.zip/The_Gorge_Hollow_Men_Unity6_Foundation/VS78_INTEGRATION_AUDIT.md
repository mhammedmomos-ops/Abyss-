# VS78 integration audit

## Integration path
- Controller wiring: scan radius uses the Guard overload with `record.learnedAbilities`; Resonance expiry and Callout issue use the cooldown overloads.
- A null or empty learned list always yields a neutral 1.0 multiplier, so legacy and test records behave exactly as before.

## Verification boundary
Static checks only. Unity compilation, EditMode execution and device testing were not performed.
