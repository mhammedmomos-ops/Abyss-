# VS53 — First Monster Encounter Integration

## Baseline
Built cumulatively from the actual user-provided VS52 complete source archive. All VS52 files are retained. This milestone connects the VS52 generated greybox scene to the existing monster AI, perception, archetype, damage and raid systems.

## Delivered
- Added `MonsterEncounterRules` for finite-value validation, deterministic encounter seed resolution and safe `MonsterRaidRequest` construction.
- Added `MonsterEncounterTrigger`, an authored trigger-volume component that starts an encounter only when the player enters the bridge approach. It does not create a timer-based or fixed-night raid schedule.
- Extended `VerticalSliceLayout` with validated north/south monster spawn sockets on the east tower and a first-encounter trigger position at the west bridge approach.
- Extended the VS52 Unity Editor scene generator to create a prototype Stalker prefab and `MonsterArchetypeDefinition` asset.
- Generated monster prefab uses the existing `NavMeshAgent`, `MonsterPerception`, `MonsterAIController`, `DamageableHealth`, `TowerSiegeAttacker` and `MonsterDeathHandler` systems.
- Generator creates two authored `MonsterSpawnPoint` sockets, configures the existing `MonsterRaidDirector` roster/player target, and adds a kinematic-Rigidbody trigger volume at the bridge approach.
- Encounter request is configured for a small first contact: threat budget 4, maximum 2 Stalkers, minimum player/spawn distance 16 m, deterministic configured seed.
- Successful encounter starts once and disables its trigger. A failed request does not consume the trigger, allowing the player to leave and re-enter after setup is corrected.
- Added EditMode test source covering invalid encounter requests, deterministic seeds, spawn socket safety distance and trigger placement.

## Reuse and dependencies
- Reuses existing in-project raid director, spawn socket, archetype definition, monster perception, AI controller, behaviour-tree runner, damage/death handlers and Unity NavMeshAgent. No second AI framework was introduced.
- Official Unity NavMeshAgent and AI Navigation documentation was reviewed. The scene still requires a baked NavMesh before the encounter can spawn monsters.
- Unity Behavior was reviewed as an alternative graph-based behaviour system but not added because the project already uses Splatter.AI and has a functioning behaviour-tree adapter; introducing a second framework would add migration and package risk without improving this vertical-slice milestone.
- No third-party source code was copied into the project and no package dependency was added.

## Setup in Unity
1. Open the Unity 6 project and allow Package Manager to resolve the existing manifest.
2. Run `THE GORGE > Vertical Slice > Generate Greybox Scene`.
3. Open `Assets/_Project/Scenes/GorgeVerticalSlice.unity`.
4. Select the generated `NAVIGATION — BAKE SURFACE IN INSPECTOR` object and configure its NavMeshSurface to collect the scene geometry. Bake a NavMesh covering both tower platforms and the complete bridge deck. Verify both east spawn sockets are on the baked surface and that the bridge is continuously walkable.
5. Enter Play mode. Walk from the west tower towards the bridge. Crossing `FIRST ENCOUNTER TRIGGER — BRIDGE APPROACH` requests the first Stalker encounter. Monsters spawn on the east tower and use the existing AI to pursue the player.
6. Test firing at the Stalker, monster damage to player health, death handling and raid resolution. If the encounter does not start, inspect the Console for the exact validation or NavMesh error.

## Known limitations
- The scene generator has not been executed in Unity in this environment. Generated scene, prefab and ScriptableObject assets are created only by running the Editor menu command; they are not falsely represented as already-generated assets in this ZIP.
- The Stalker is a dark capsule placeholder, not a final monster model. No animation controller, rig, attack animation, audio, VFX, hit reactions or unique monster materials are supplied.
- The encounter requires a correctly baked NavMesh over both towers and the bridge. Spawn requests fail closed if no spawn socket can be sampled.
- This first encounter targets the player. The generated greybox scene does not yet contain authored `TowerStructure` instances, so tower siege behaviour is not demonstrated in this scene.
- No campaign progression objective/reward is bound to raid resolution yet.
- No runtime pooling or wave scheduling was added; this is one small authored encounter using the existing raid director.
- Unity compilation, EditMode execution, scene generation, prefab validation, NavMesh baking, physics simulation, Android/iOS builds and device playtesting have NOT been performed.
