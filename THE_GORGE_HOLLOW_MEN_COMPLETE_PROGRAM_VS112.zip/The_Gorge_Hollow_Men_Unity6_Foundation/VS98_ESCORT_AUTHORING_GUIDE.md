# VS98 Mobile Escort Authoring Guide

1. Open the carrier prefab/scene object that already has `SupplyConvoyController`.
2. Create a lightweight child/root group named `TransferEscorts`; add one or more escort character GameObjects with their normal renderers/animators. Do not add NavMeshAgents unless the chosen escort prefab actually uses NavMesh navigation; this controller follows with direct transform movement.
3. Add `SupplyTransferEscortController` to the group. Assign the carrier component and each escort Transform in `Escort Units`.
4. On the carrier's `SupplyConvoyController`, assign the same `SupplyTransferEscortController` to `Transfer Escort`. This link is required for damage mitigation.
5. Set `Hostile Mask` to monster collider layers. Monster colliders must be children of objects containing both `MonsterAIController` and `DamageableHealth`.
6. Suggested initial values: detection 10 m, attack 7 m, interval 1.1 s, damage 8, follow distance 3.2 m. These are tuning defaults, not balanced final values.
7. Enter Play Mode in a fully authored test scene and verify: escorts follow; a monster within attack range receives damage; threat classification changes as hostiles approach; convoy damage is reduced only while escorts are active; zero escorts gives full incoming damage.
8. Test the bridge independently: escorts must not create a bridge, open a collapsed bridge, authorize enemy access or prevent a carrier from falling when the bridge collapses mid-crossing.
9. For mobile, keep escort count modest, use simple colliders/meshes, and profile the fixed-buffer overlap scan on target devices.

No scene or prefab is supplied in this phase; references must be assigned in the Inspector.
