# VS48 — Gesture Help, Supply Drops, Armor Break Vignette, Slide Boost, Fog Density

## Scope
VS48 adds first-run gesture help, supply drop crates, armor-break vignette, sprint-crouch slide boost, offline services banner, phase fog density, and a device manifest utility for bug reports.

## Added
- `GestureHelpOverlay.cs`
- `SupplyDropInteraction.cs`
- `DamageVignetteFromArmor.cs`
- `SlideBoostController.cs`
- `OnlineServicesStubBanner.cs`
- `FogDensityController.cs`
- `BuildManifestUtility.cs`
- `VS48FogDensityTests.cs`
