# VS58 third-party research and reuse

Research checked Unity's current NavMeshAgent API, the Unity 6 AI Navigation package listing, and Unity Technologies' AI Navigation implementation guidance.

- Unity NavMeshAgent reference: https://docs.unity.com/en-us/engine/6000.7/script-reference/unityengine/ai/navmeshagent
- Unity AI Navigation 2.0.16 package page: https://docs.unity.com/en-us/engine/6000.0/manual/packages-list/packages-all/pack-safe/com-unity-ai-navigation
- Unity Technologies navigation-system guide: https://github.com/Unity-Technologies/skills/blob/main/skills/initialize-ai-navigation/references/navigation-system.md

Decision: VS58 is a campaign lifecycle/care phase, so no new movement library or third-party source code was necessary. Existing campaign clock, AnimalRecord, medical-supply economy and save APIs were reused. The Unity guidance reinforces retaining the existing NavMesh architecture and validating links/agent setup in-editor; no new package was added.
