# VS61 Integration Audit

## Scope
VS61 adds a persistent pet-food inventory and hunger/care loop while preserving the existing player-selected companion architecture and all four approved species.

## Integration map
- Persistence: `CampaignModels.cs`, `CampaignSaveService.cs` (schema v5).
- Fictional time: `CampaignClock.cs` invokes `AnimalCareRules.AdvanceHunger` alongside lifecycle ageing.
- Rules: `AnimalCareRules.cs` validates feeding and hunger changes without Unity scene dependencies.
- Atomic campaign operation: `GameBootstrap.TryFeedAnimal` clones the campaign, applies food cost and companion changes, saves the candidate, then replaces live state and publishes replacement/transaction events.
- Economy: `ResourceTransactionService`, `CraftingRules`, and `TowerConstructionService` account for the additional resource field.
- Supply acquisition: `LootContainerInteraction`, `SupplyDropInteraction`, and `ScavengeInteraction` can grant configured pet food.
- Presentation: `CompanionCommandUI` displays the selected pet's health/hunger and food balance and exposes Feed/Rest/Treat actions. The greybox scene generator wires these buttons and the care service.

## Compatibility
- Existing save schema v4 migrates to v5. Existing animals are assigned 100 hunger to avoid penalizing players for a need that did not previously exist. Pet-food balance begins at zero; prior resources, campaign progress, animal identities, and names are otherwise retained.
- No new package dependencies or third-party source code.
- Existing species selection and player-entered companion naming remain unchanged.

## Balance guardrails
- Hunger drains only by fictional day progression; no wall-clock/offline drain.
- Feed cost: 1 unit; hunger restored: up to 60; bond gain: 1.
- Hunger loss: 18 per fictional day.
- Low hunger reduces stamina recovery only. It does not directly inflict health damage or kill a pet.
- Dead pets cannot be fed and remain permanently dead under the existing death rules.
- Hunger is applied to all living/missing owned animal records, including inactive roster members. This is intentional roster-care behaviour and should be revisited if the game later limits the player to one owned companion.

## Static validation
- C# lexical delimiter scan performed across all source files.
- JSON and assembly-definition parsing performed.
- Duplicate non-partial type scan performed.
- Integration assertions checked for save migration, food resource flow, care UI wiring, fictional-day hunger drain, and transactional feed operation.
- ZIP integrity tested after packaging.

## Not performed
- No Unity Editor/compiler available in this environment; no Unity compilation or EditMode execution is claimed.
- No PlayMode, scene-generation, NavMesh bake, Android/iOS build, or physical-device test performed.
