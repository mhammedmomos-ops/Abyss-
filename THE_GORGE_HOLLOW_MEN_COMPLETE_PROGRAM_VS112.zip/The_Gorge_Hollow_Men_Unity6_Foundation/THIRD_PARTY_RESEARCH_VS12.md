# VS12 Third-Party Research and Reuse Record

Research performed 3 November 2026 before implementation.

## Reused existing systems

### Unity Physics non-allocating overlap queries
- API: `Physics.OverlapSphereNonAlloc` (UnityEngine.Physics).
- Use: nearby trap recognition scans reuse a fixed collider buffer rather than allocating a new collider array on every scan. This is an existing Unity engine API, not copied third-party code.
- Official API documentation: https://docs.unity3d.com/ScriptReference/Physics.OverlapSphereNonAlloc.html

### Unity AI Navigation / NavMeshAgent
- Package: `com.unity.ai.navigation` 2.0.16, retained from prior phases.
- Use: route execution and sampling of detour waypoints continue through Unity's NavMesh APIs. No replacement pathfinding library was introduced.
- Unity 6 NavMeshAgent API: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/ai/navmeshagent

### Splatter.AI
- Repository: https://github.com/ormesam/splatter.ai
- Licence: MIT. Retained from VS10/VS11 as the behaviour-tree runner and central scheduler. VS12 adds tactical actions under the existing decision layer; it does not create another behaviour-tree framework.
- Upstream README documents Unity 6 compatibility and the central manager's tick scheduling. The repository has a small public adoption footprint, so it remains a dependency risk requiring commit pinning and Unity Editor validation before production.

## Original project code
- `PlayerTrap`: game-specific trigger trap component and learning signal.
- Bounded per-monster learned-hazard memory and local route waypoint avoidance.
- `MonsterTargetScoring`: project-specific siege target vulnerability/priority weighting.

No third-party source files were copied into the project for VS12.
