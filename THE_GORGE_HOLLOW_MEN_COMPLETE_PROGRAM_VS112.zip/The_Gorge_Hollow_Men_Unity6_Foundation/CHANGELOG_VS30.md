# VS30 — Camera Shake, Run Stats, Sprint/Raid Indicators & Auto-Interact

## Scope
VS30 adds camera trauma shake (bridge collapse binding), session run statistics, sprint/exhausted indicator, raid progress readout, and a proximity interact helper for mobile loot density.

## Added
- `CameraShake.cs`
- `BridgeShakeListener.cs`
- `RunStatsTracker.cs` / `RunStatsHUD.cs`
- `SprintIndicatorUI.cs`
- `RaidProgressUI.cs`
- `AutoInteractProximity.cs`
- `VS30CameraShakeTraumaTests.cs`

## Scene setup
1. Add `CameraShake` to the gameplay camera (with `IsometricCameraFollow`).
2. Add `BridgeShakeListener` on bridges.
3. Add `RunStatsTracker` to a persistent object; optional `RunStatsHUD` on the pause panel.
4. Wire sprint/exhausted icons via `SprintIndicatorUI`.
5. Add `RaidProgressUI` label on the HUD.
6. Optional: `AutoInteractProximity` on the player; call `TryInteractNearest` from a UI button for dense loot.

## Limitations
- Shake is translational/yaw offset only (no full impulse system).
- Stats are session-only unless you persist them yourself.
- Auto-interact is a helper, not a replacement for raycast interaction.
- Unity compile / device builds not performed here.
