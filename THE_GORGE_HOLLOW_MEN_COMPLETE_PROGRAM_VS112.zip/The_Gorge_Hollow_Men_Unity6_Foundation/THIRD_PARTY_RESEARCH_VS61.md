# VS61 Third-Party Research and Reuse Review

## Research performed
- Reviewed Unity 6 AI Navigation package documentation. It confirms the package provides NavMesh pathfinding, runtime/edit-time NavMesh building, dynamic obstacles, and links for special traversal. The existing project already has this dependency and uses `NavMeshAgent`; VS61 does not need a new movement or navigation package.
- Reviewed Unity's NavMeshAgent reference for supported navigation behaviour. No changes to agent movement authority were needed for feeding/hunger.
- Reviewed Unity's mobile input documentation. The existing project uses uGUI button events in its greybox HUD; the new care actions reuse that established path rather than introducing a second input stack.

## Decision
No third-party library was added or copied. Feeding, resource accounting, hunger decay, and migration are deterministic campaign rules and fit the existing C# architecture. Reusing the existing save service, resource transaction service, campaign clock, and uGUI controls minimizes integration and mobile compatibility risk.

## References
- Unity 6 AI Navigation package: https://docs.unity.com/en-us/engine/6000.0/manual/packages-list/packages-all/pack-safe/com-unity-ai-navigation
- Unity 6 NavMeshAgent API: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/ai/navmeshagent
- Unity Android input overview: https://docs.unity.com/en-us/engine/6000.3/manual/platform-specific/android/developing/input
- Unity iOS input overview: https://docs.unity.com/en-us/engine/6000.0/manual/platform-specific/iphone/ios-developing/ios-input

No external source code was copied into the project.
