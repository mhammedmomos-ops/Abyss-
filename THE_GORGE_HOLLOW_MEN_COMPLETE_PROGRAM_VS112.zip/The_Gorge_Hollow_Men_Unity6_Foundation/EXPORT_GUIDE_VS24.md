# Export Guide — VS24

## What to import

1. Create or open a Unity 6 project using the Universal 3D (URP) template.
2. Close Unity.
3. Copy the entire `Assets/_Project` folder from this archive into the project's `Assets` folder.
4. Merge package dependencies into the project manifest:
   - `com.unity.ai.navigation` version `2.0.16`
   - `com.samorme.splatter.ai` from `https://github.com/ormesam/splatter.ai.git?path=/src/Assets/Splatter.AI`
5. Ensure **Unity UI (UGUI)** is installed (required by InteractionPromptUI / PlayerVitalsHUD).
6. Reopen Unity, let packages and scripts import.
7. Open **Window > General > Test Runner** → EditMode → run all tests.
8. Author scenes: player + camera + mobile controls + bridge systems + Canvas with prompt + vitals HUD + optional medical kits. Follow README and CHANGELOG_VS*.md.
9. Build Android/iOS only after compilation and device testing.

## What this export is

- Complete cumulative source package for VS1–VS24.
- Mobile-first Unity 6 foundation: campaign, persistence, combat, towers, monsters, bridges (failure, collapse, fall, reconstruction), injury recovery, interaction prompt UI and vitals HUD.
- Includes tests, changelogs and integration instructions.

## What this export is not

- Not an APK/AAB/IPA or finished commercial game.
- Not a complete art/audio/level package.
- Not compiled or playtested in this environment.

## Recommended first validation pass

1. Resolve packages and compile.
2. Run all EditMode tests (including VS24).
3. Build a minimal scene: player, joystick, interact button, prompt UI, vitals HUD, one bridge with repair + fall volume, one medical kit.
4. Verify injury from bridge fall reduces speed, recovers after lockout, prompt appears on bridge repair / medical kit, HUD updates, and campaign save/load preserves vitals.
5. Profile on a baseline Android device before expanding content.
