# VS76 — Guard Post

## Added
- New cross-species **Guard** command: companion holds its current position with elevated detection (+25%).
- First confirmed threat while guarding triggers a one-shot toast, audio cue and ability XP (then will not re-report until Guard is re-issued).
- Pure rules in AnimalGuardPostRules; GUARD button in the vertical-slice HUD (two-row care layout).
- Five EditMode tests for eligibility, detection boost, one-shot report, toasts and constants.

## Design boundaries
- Distinct from Stay: Stay is silent hold; Guard is an active watch with detection boost and threat report.
- Available to all four species. Transient command state; not campaign-persisted beyond XP from a successful report.
- No third-party packages added.

## Validation
Static checks only. Run VS76GuardPostTests in Unity 6.
