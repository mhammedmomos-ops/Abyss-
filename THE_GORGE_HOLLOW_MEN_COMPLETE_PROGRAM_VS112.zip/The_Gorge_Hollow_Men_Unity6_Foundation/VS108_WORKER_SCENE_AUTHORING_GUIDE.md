# VS108 worker scene authoring guide

## Automatic greybox setup
1. Open the Unity 6 project and allow package resolution and script compilation to finish.
2. Use `THE GORGE > Vertical Slice > Generate Greybox Scene`.
3. The generator creates `WORKFORCE — VISIBLE WORKER SPAWNER`, references the campaign bootstrap and both tower roots, and creates four work target transforms under each tower.
4. Enter Play Mode. A fresh campaign should materialize Mara and Tunde at Tower A and Nia and Jonah at Tower B. Existing saves should materialize their saved living workers.
5. The fallback actors are coloured capsules. They are deliberately temporary greybox visuals.

## NavMesh setup
1. Select `NAVIGATION — BAKE SURFACE IN INSPECTOR`.
2. Inspect the surface collection settings. The bridge root is marked as the built-in `Jump` area by a NavMeshModifier. Worker agents exclude `Jump` from their area masks; player/monster agents retain their normal masks. Confirm the bridge geometry is baked as Jump.
3. Bake the NavMesh using the AI Navigation package workflow.
4. Confirm each worker starts on its own tower's NavMesh and can reach the four work points on that same tower.
5. Confirm no worker can traverse the bridge. Off-Mesh Link traversal is disabled and the worker area mask excludes Jump. Confirm the bridge remains usable by the intended non-worker agents and that existing enemy bridge entry/collapse rules still govern monster traversal.
6. Test injury, rest, Guard, Production, Salvage, capture and rescue states in Play Mode.

## Custom worker prefab
- Assign a `TowerWorkerActor` prefab to the director's `workerPrefab` field.
- Keep the prefab root at foot level, with its visual model positioned relative to that root.
- Add an Animator and animation driver only after valid clips/controllers exist.
- The spawner adds a NavMeshAgent if the prefab lacks one. Tune the prefab's agent radius, height and base offset for its rig, then validate on the baked NavMesh.
- Keep collision geometry appropriate for the courtyard and avoid oversized agent radii that prevent passage through doors.

## Work point placement
- Tower A targets are children of Tower A; Tower B targets are children of Tower B.
- Keep all four points within the corresponding tower's safe courtyard and away from the bridge entrance, walls and blocking props.
- Production, Salvage, Guard and Rest are staging destinations only. Actual task animation and contextual work interactions are not yet implemented.

## Existing campaign saves
- Save schema v15 performs a one-time repair for legacy campaigns with no recorded worker identities by adding the four opening workers.
- If any worker identity is already recorded, the migration preserves the roster exactly. Captured and dead records are not replaced with fresh starters.
