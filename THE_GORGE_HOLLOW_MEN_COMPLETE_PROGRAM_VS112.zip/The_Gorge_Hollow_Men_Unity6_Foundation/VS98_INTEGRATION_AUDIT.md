# VS98 Integration Audit

## Source integration
- Escort controller targets the existing `MonsterAIController` and `DamageableHealth` types; it does not introduce a parallel enemy taxonomy.
- Threat scan uses `Physics.OverlapSphereNonAlloc` with a fixed 32-collider buffer and a reusable `HashSet` to avoid counting multi-collider enemies more than once.
- The selected enemy must have a live `DamageableHealth`; attacks use the existing `IDamageable` implementation.
- Convoy damage continues through `GameBootstrap.TryDamageSupplyConvoy`, preserving save-before-publish transaction behaviour. Escort mitigation is applied before that transaction.
- Mitigation is intentionally bounded to 48% maximum. A disabled/destroyed escort provides no mitigation.
- Threat levels are tactical information only; they do not automatically dispatch, reroute or teleport a carrier.

## Scene authoring
- Add `SupplyTransferEscortController` to an escort-team root or convoy child.
- Assign the active `SupplyConvoyController` and each escort unit Transform. Use distinct, active escort GameObjects.
- Set hostileMask to the layers containing monster colliders. Ensure those colliders are children of objects with `MonsterAIController` and `DamageableHealth`.
- Assign the same escort controller to the convoy's `transferEscort` field. Without this reference, escorts may attack but provide no convoy damage mitigation.
- Configure detection radius, attack range, attack cadence and damage after playtesting. Keep escort units lightweight for mobile.
- Threat state is available as `CurrentThreat` for a future mobile HUD; no HUD prefab/scene is included in this source foundation.

## Risks / limitations
- Threat scanning is proximity-based, not line-of-sight or route-ahead prediction. Occluded enemies inside the scan radius may be counted and targeted.
- Escort units are scene objects and their own positions are not persisted. They should be reconstructed from the carrier's persisted position on load.
- No escort ammunition, morale, individual health or attrition economy is introduced in this phase.
- If more than 32 colliders overlap the scan sphere, later colliders are not observed in that scan. Increase the fixed buffer only after profiling.
- Threat counts can still fluctuate as enemies enter/leave the scan radius; avoid using this readout as a guaranteed route-safety assertion.
- This phase does not change route validation or carrier movement. It does not create a rerouting path around a collapsed bridge.

## Validation status
- Archive integrity and source-level structural checks performed.
- Unity compilation and EditMode test execution not performed; tests are authored only.
- No runtime physics, combat, NavMesh, scene/prefab, mobile performance or device validation performed.
