# VS65 — Animal distraction, Cat lure and starvation death

## Player-facing changes

### Falcon distraction
- A selected Falcon that locally confirms a nearby monster emits a periodic audible decoy from its own position while observing the threat.
- The monster must hear it through the existing `MonsterPerception` hearing-range and line-of-sight/obstruction checks.
- A monster that accepts the decoy temporarily prioritizes investigating that position over pursuing the player. The decoy is time-bounded and rate-limited.
- Pending player or companion attack wind-ups are cancelled when the decoy is accepted.

### Cat lure
- Added `AnimalCommand.Lure` and a Cat-only `IssueLure` path.
- The Cat moves to a reachable NavMesh position on the far side of the confirmed threat relative to the protected position, then emits repeated audible decoys for a bounded interval.
- The generated HUD adds `LURE (CAT)`. Its default protected position is the player.
- `CompanionCommandUI.CommandLureFrom(Transform protectedTarget)` is exposed for world interactions to direct a lure away from a tower, convoy or other object.
- The Cat returns to Follow when the lure expires or the threat dies. An unreachable lure point is rejected rather than issuing a false-success command.

### Starvation death
- Zero hunger still incapacitates the pet immediately; it cannot follow, fight, protect, search, forage, rest or receive treatment.
- If hunger remains at zero for two additional fictional campaign-day advances, the pet is permanently marked Dead. The day it first reaches zero does not count as one of those two days.
- Feeding during the grace period restores hunger and resets the starvation counter.
- Death is committed in the campaign save before `AnimalDied` is published for campaign-clock starvation transitions. The HUD announces the animal's custom name and permanent loss.
- Missing pets do not lose hunger or accrue starvation days while separated, because they are assumed to hunt independently. Recovery rolls hunger from 20–85 and clears the starvation counter.

## Persistence
- Campaign save schema advances from v5 to v6.
- Added `AnimalRecord.starvationDaysAtZero`.
- v5 saves migrate with a fresh grace period (counter 0), including pets already at zero hunger.
- Earlier v1–v4 migrations remain chained and supported.

## Compatibility and dependencies
- Reuses the existing `MonsterStimulusBus`, `MonsterPerception`, monster behaviour-tree priority, `NavMeshAgent`, companion controller, campaign clock and transactional save path.
- No third-party code copied and no new package dependency added.
- Existing non-Cat companion commands remain unchanged.
