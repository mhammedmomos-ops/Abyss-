# VS103 Worker Raid Response — Scene Authoring Guide

## 1. Tower raid director
Create one empty GameObject per tower, for example `TowerA_WorkerRaidResponse` and `TowerB_WorkerRaidResponse`.

Add `TowerWorkerRaidResponseDirector` and assign:
- `GameBootstrap`
- `MonsterRaidDirector`
- `TowerWorkforceController`
- `towerId` (`tower_a` or `tower_b`)
- `bindings` for the workers assigned to that tower

For each binding, enter the persistent `workerIdentity`, the worker's `TowerWorkerActor`, and:
- `coverPoint`: a protected interior position.
- `evacuationPoint`: a safe room/corridor point (may be the same as coverPoint).
- `defensivePoint`: a firing/guard position inside the same tower.

Do not place these points on the bridge or on the opposite tower. Do not use a NavMeshLink to cross the gorge. The actor's NavMeshAgent must be on a baked NavMesh and able to reach its assigned points. The director does not teleport workers or fabricate a path when no NavMesh path exists.

## 2. Role behaviour
- Mechanic and Scavenger: move to evacuation/cover; state changes from Evacuating to Sheltered when within the arrival radius.
- Guard assigned to Guard: move to defensivePoint. A Guard not assigned to Guard follows the general shelter response.
- Medic: move toward the most injured worker in the same tower. When close enough, one medical supply from that tower's depot restores 10 health. The medic falls back to cover if no injured worker is available.
- Injured, resting or exhausted workers evacuate before role-specific work.

## 3. Player override
Wire mobile assignment controls to `TowerWorkforceController.Assign(workerIdentity, assignment, out error)` using a small project UI adapter or UnityEvent wrapper. If the command is accepted during a raid, that worker receives a saved manual override and the director stops issuing automatic destinations for that worker until the raid ends. The assignment must still pass the normal workforce rules (injured/exhausted workers cannot be sent back to active duty).

## 4. Overrun and capture volume
For an exposed tower breach area:
1. Add a GameObject with a BoxCollider or other suitable Collider. The component also requires a Rigidbody and configures it as kinematic with gravity disabled.
2. Enable `Is Trigger` (the component also enforces this at Awake).
3. Add `TowerWorkerCaptureVolume`.
4. Set `monsterLayers` to only the actual monster layers.
5. Assign the tower's worker actors in `workers` (recommended; leaving it empty permits any configured worker actor in the volume).
6. Ensure worker actors have `TowerWorkerDamageable` on the same root GameObject as `TowerWorkerActor`, so the capture volume can resolve the stable identity.
7. Keep the volume inside the tower. Do not put it on the bridge or use it to authorize bridge access.

A capture requires an active raid and both a monster and worker physically inside the same volume. The volume checks periodically as well as on trigger entry, so a raid starting while both are already inside is handled. On successful capture, the worker record becomes Captured and the actor is hidden; no resources are generated or refunded.

## 5. Captive holding point
Place a separate interaction object at the location where the captured worker is held. Add `TowerWorkerCaptureRescueInteraction` and assign:
- `TowerWorkforceController`
- exact `workerIdentity`
- the original `TowerWorkerActor`
- the original `TowerWorkerDamageable`

The rescue interaction releases the existing record. A worker below the injury threshold returns as Injured and assigned to Rest; a healthier worker returns Active and Idle. The actor and damage adapter are re-enabled. Do not create a second `WorkerRescueInteraction` for the same identity.

## 6. Mobile UI
Keep the existing `TowerWorkforceMonitor`; its roster now includes raid posture and Captured status. Wire command buttons through the existing controller rather than changing campaign records directly.

## 7. Test checklist for Unity
- Start a raid with a Mechanic and Scavenger: both move to authored evacuation points and become Sheltered on arrival.
- Start a raid with a Guard assigned to Guard: it moves to the defensive point.
- Place an injured worker and Medic in the same tower: medic moves to the patient and spends one local medical supply per 10 HP.
- Give a worker a manual assignment during a raid: automatic director does not overwrite it.
- End the raid: tactical state resets to Normal and manual override clears; worker assignment remains the saved assignment.
- Enter an overrun volume with a worker, then let a monster enter during a raid: worker becomes Captured, actor is hidden, and capacity remains occupied.
- Use the holding-point interaction: the same worker identity returns; no duplicate roster entry appears.
- Save/reload while a worker is captured and verify the captive remains captured.
- Verify no worker destination crosses the gorge and all previous bridge enemy rules remain unchanged.

Unity compilation, NavMesh, physics, and device tests are still required; the source archive alone does not prove these scene behaviours at runtime.
