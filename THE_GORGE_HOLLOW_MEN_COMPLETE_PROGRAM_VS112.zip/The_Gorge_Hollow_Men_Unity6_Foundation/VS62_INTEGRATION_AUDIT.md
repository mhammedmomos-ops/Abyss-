# VS62 Integration Audit

## Existing architecture inspected
- VS61 campaign model and save service; `CampaignState.campaignFlags` is already persisted and validated.
- `AnimalCareRules`, `AnimalCareService`, `AnimalCompanionController`, `CompanionCommandRelay`, `CompanionCommandUI` and `AnimalCompanionProfile`.
- `GameBootstrap` transactional clone/save/replace methods.
- Existing greybox scene generator and generated companion HUD.
- Existing resource acquisition paths (`LootContainerInteraction`, `ScavengeInteraction`, `SupplyDropInteraction`).

## Starvation gate
- `AnimalCompanionController.IsOperational` requires Alive status, positive health and hunger > 0.
- The controller stops and clears its NavMesh path when a campaign replacement sets hunger to zero.
- `CompanionCommandRelay.HasCompanion` intentionally remains true for an alive starved pet so the care HUD remains visible; `IsOperational` is false and all command attempts are rejected.
- Feed remains permitted at hunger zero. Rest and medical treatment require hunger > 0. No starvation damage/death is applied.

## Foraging flow
1. Player taps FORAGE while the pet is operational.
2. Controller finds nearby enabled `AnimalForageFoodSource` components.
3. It validates complete paths using the existing NavMeshAgent path calculation; unreachable sources are ignored.
4. The pet navigates to the closest available source.
5. If its local monster scan confirms a threat, it abandons foraging and retreats toward its owner.
6. At the source, it waits 2.5 seconds and asks `GameBootstrap.TryCollectForagedPetFood` to commit the yield.
7. `AnimalForageRules` uses a stable source ID and fictional day to prevent duplicate harvesting on that day. The campaign flag, food inventory, one experience point and 10-point stamina cost are saved together.
8. On success, the pet receives one experience point, loses 10 stamina, and returns to Follow. Player then uses FEED to consume the recovered inventory.

## Missing-pet recovery flow
- `TryMarkAnimalMissing` accepts only an alive, healthy record and persists Missing status.
- `MissingAnimalRecoveryInteraction` is configured with the animal's stable identity, appears interactable only while that record is Missing, and calls `TryRecoverMissingAnimal` when found. The same recovery point can be reused if that animal becomes Missing again later.
- Recovery accepts only Missing records with positive health; dead animals cannot be revived.
- Recovery sets status Alive and rolls hunger with `Random.Range(20, 86)`, i.e. integer values 20–85 inclusive. Existing identity, display name, species, life stage, health, stamina, bond and experience are retained.
- The recovered animal is available in the selection panel again. Player confirms selection to bind its world actor.

## Greybox integration
- Scene generator adds three stable-ID forage patches on the west tower platform and a FORAGE button.
- NavMesh must be baked for the pet to path to the patches. The generator does not bake or test navigation.
- `MissingAnimalRecoveryInteraction` is a reusable objective/interactable component; a rescue/search objective must place it in the scene and assign the missing animal's identity. No rescue encounter is fabricated in the greybox by default.

## Save compatibility
- No save schema change. The existing campaign flags collection stores daily source depletion; existing `AnimalStatus` persists missing/recovered state.
- No third-party package or source code added. Existing Unity AI Navigation / NavMeshAgent stack retained.

## Static checks
- Nine new EditMode tests included for starvation gating, feeding from zero, missing/recovered status, identity reuse and once-per-day foraging.
- Unity compilation and test execution not performed.
