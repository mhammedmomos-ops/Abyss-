# VS79 — Companion Status Readout and Version Cleanup

## Added / changed
- `AnimalStatusSummaryRules` builds the companion HUD line: existing HP / HUNGER / FOOD / starvation text is kept verbatim, then an active-state tag (GUARDING, STALKING, CURLED, RESONATING, STAYING, FORAGING and so on), XP and an ABILITIES n/6 count are appended.
- `CompanionCommandRelay.CurrentCommand` exposes the live command to the HUD. `CompanionCommandUI` now formats its status label through the new rules class.
- Package version constants moved from VS50 to VS79 (`GameFoundationInfo`, `FoundationProgressReport`, `GameVersionLabel` default tag).
- Seven EditMode tests in `VS79StatusSummaryTests`.

## Design boundaries
- Test fix: `VS36FoundationInfoTests.PackageVersionIsVS36` hard-coded "VS36" while the constant said VS50, so it would have failed in the Test Runner. It now checks that the tag has the form VS<number>, and that `GameFoundationInfo` and `FoundationProgressReport` agree.
- A `GameVersionLabel` already placed in a saved scene keeps its serialized tag; only newly generated scenes pick up the new default.
- Presentation only. No gameplay, persistence or scene-generator change.

## Validation
Static checks only (brace balance and symbol cross-references). Run the VS79 tests in Unity 6.
