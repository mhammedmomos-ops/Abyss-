# VS35 — Loading Splash, Loot Glow, Kill Feed, Aggro Ping, Battery Hint & Playtime

## Scope
VS35 improves presentation and feedback: async loading splash, loot prop pulse, kill/scavenge feed, monster aggro ping, low-battery FPS hint, and session playtime tracking (surfaced on dawn summary).

## Added
- `LoadingSplashUI.cs`
- `LootGlowPulse.cs`
- `StaminaBarPulse.cs`
- `KillFeedUI.cs`
- `MonsterAggroPing.cs`
- `BatterySaverHintUI.cs`
- `SessionPlaytimeTracker.cs`
- `VS35PlaytimeFormatTests.cs`

## Modified
- `DawnSummaryUI.cs` — includes session playtime when tracker is present.

## Scene setup
1. Persistent canvas splash → `LoadingSplashUI`; call `LoadingSplashUI.Load("Gameplay")` from menu.
2. Scavenge props → `LootGlowPulse`.
3. Stamina fill image → `StaminaBarPulse`.
4. Feed line prefab → `KillFeedUI`.
5. Monsters → `MonsterAggroPing` (call `NotifyAggro` from perception when implemented).
6. HUD banner → `BatterySaverHintUI`.
7. Persistent object → `SessionPlaytimeTracker`.

## Limitations
- Aggro ping must be called from perception/AI (stub hook).
- Battery level is unavailable on some platforms (hint stays hidden).
- Unity compile / device builds not performed here.
